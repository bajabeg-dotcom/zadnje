# Katalog svih ZIP-ova na Drive-u
### 04.10.2026. · 110 arhiva · ~3,9 GB ukupno

Pregledano je **sve**. Nije se moglo sve skinuti — zato je svaki razvrstan po
tome da li može pomaknuti neki od otvorenih problema. Četiri su skinuta i
otvorena u ovoj sesiji, ostali su procijenjeni po imenu, veličini i po tome
što već znam iz onih koje sam otvorio.

---

## A. ISKORIŠTENO — ugrađeno u rad

| ZIP | MB | Šta je dalo |
|---|---:|---|
| `4.zip` | 115 | **`full-out/` matrica (81 STY)** → oborila moje pravilo o elementima (V-1.3). `pa800_catalog`: 1068 zvukova s imenima, 65 kitova, 8320 redova po tipkama, 307 velocity prozora |
| `Desktop.zip` | 0,15 | **PA Manager oracle**: 2.623 stvarne remap odluke → dokaz da PA Manager piše LSB 64/65 kojih na Pa800 nema (V-1.2) |
| `1.zip` | 3,6 | `korf_parse_style.py` → **TrackData je po kolonama**, `cv_mask` je bitmaska (V-1.1) |
| `INIT_STY_OUT.zip` | 7,4 | **97 uparenih v5/v4 stilova** — glavna fikstura, 93/97 bajt-u-bajt |
| `Dokazi.zip` | 0,4 | drugi toolkit, `PA800_OS_RE_REPORT.md` |
| `v5-stream-RE.zip` | 11,6 | **lažni trag** — ondje „v5" = PA Manager v5 / Pa5X clip format. Korisno samo kao potvrda kontejnera (KBEG/KORF/OC3x) |
| `kpmv3_unpacked_image.zip` | 44 | **slijepa ulica** — nije PA Manager slika nego 128 MiB snimak Windows desktopa (Chrome, OneDrive). Ne otvarati ponovo |

---

## A2. OTVORENO NAKNADNO (04.10., nakon pitanja „znači sve si pregledao")

| ZIP | MB | Nalaz |
|---|---:|---|
| `NEWNAME.SET.zip` | 2,1 | **STYLE mapa je PRAZNA.** Nema `USER01.STY`. Unutra: 35 PCM, 2 PCG (`USER01`, `USERDK`), 2 GLOBAL, 1 MULTISMP, plus `setconvert/` Python paket. Raniji nalaz je taj STY imao („Modern Ballad", 12.070 B) — ovaj primjerak na Drive-u ga nema. **Hardverski baseline se iz ovog zipa ne može provjeriti.** |
| `Pa4X_OS2_USEFUL_RESOURCES.zip` | 3,7 | FACTORY_PAD (30 banaka), USER_RESOURCES/STYLE i KEYBOARDSET, `EMBEDDED_RESOURCE_INVENTORY.csv` (putanja/offset/span u pkg-u). **Nema tabele imena zvukova.** |
| `pa4x-workspace.zip` | 49 | **Cijeli Pa4X OS**: `omega_sys/OPOS` (17 MB), `Factory.BKP` (14 MB), `boot/ramdisk.gz`, `uImage`. U `OPOS` su samo debug/UI stringovi. U **`Factory.BKP` JESU Pa4X imena zvukova** (Grand Piano @912164, Nylon Guitar, Spanish Guitar, Standard Kit…), ~499 muzičkih naziva — ali utkani u binarne zapise, bez indeksa, i to su **Pa4X, ne Pa3X**. Za naš remap ne pomažu. Nema ni Pa700/Pa1000 materijala, pa **TrackData 96 i dalje stoji nerazriješen**. |

---

## B. JOŠ VRIJEDI OTVORITI

| ZIP | MB | Zašto |
|---|---:|---|
| `NEWNAME.SET.zip` | 2,1 | **jedini hardverski baseline** — SET izvezen s tvog Pa800. „Modern Ballad", v4, 13 elemenata. Mjerilo za sve ostalo |
| `Pa4X_OS2_USEFUL_RESOURCES.zip` | 3,7 | Pa4X OS resursi — mogu nositi **imena zvukova novije generacije**, što je glavni nedostatak |
| `Pa800_os_res_v202_EXTRACTED_MASTER_EVIDENCE_REPORT.zip` | 26 | izvor iz kojeg je napravljen `pa800_catalog` (1068 zvukova) — korisno za provjeru porijekla |
| `PA800_FACTORY_STYLES_PATTERNS_PADS_REFERENCE.zip` | 6,9 | fabrički patterni i padovi — proširenje referentnog korpusa |
| `kpmv3_runtime.zip` | 50 | drugi pokušaj PA Manager slike; nakon neuspjeha s `unpacked_image` **vjerovatnoća mala**, ali je jedini preostali trag za Pa3X imena |
| `pa4x-workspace.zip` | 49 | Pa4X radni prostor — kandidat za **TrackData 96** (Pa700/Pa1000), jedini format koji još ne čitam |

---

## C. TVOJ MATERIJAL — stilovi i SET-ovi

| ZIP | MB | Napomena |
|---|---:|---|
| `SETOVI.zip` | 363 | najveći skup tvojih SET-ova; dio je već u korpusu |
| `Baja.zip` | 524 | najveća arhiva uopšte, nepregledana |
| `Midi.zip` | 324 | MIDI materijal |
| `2025.zip` | 236 | nepregledano |
| `Hammy.SET.zip` | 52 | tuđi SET |
| `Pa3xStyle Wrhunski.zip` | 8,5 | izvor `corpus/pa3x` (= `Dzony 2024_PA800.SET`) |
| `VALJA_PA800_SONG_STYLES_FINAL` | 3,5 | izvor `VALJA_SONG_STYLES` |
| `STYLE.zip`, `123.zip`, `122.zip`, `ZAARENU*.zip`, `valja.zip`, `01.zip`, `02.zip` | — | manji skupovi stilova, vjerovatno podskupovi gore navedenih |

---

## D. STARIJE VERZIJE ALATA — nema nove informacije

`DNA-MIDI-Studio-*` (5 arhiva, 55–91 MB), `PA800_Profile_Optimizer_*` (4),
`MIDI_Performance_Engine_*` (2), `New Project (N).zip` (6+),
`korg_pa800_optimizer*`, `PA800_Optimizer_Portable`, `pa800_studio`,
`MIDI_Enhancer_Pro`, `korg_style_optimizer`, `pa800-midi-optimizer`,
`midi-main`, `Korg_Pa800_MIDI_Optimizer_Pro` (×2),
`KORG_PA800_FULL_*` (×4, duplikati), `PA800_Manager_Web_*` (×2),
`BAJA_MUSIC_*` (×2), `PA_SET_Converter`, `PA_FULL_KONVERTER_V1`,
`korg-pa4-to-pa800-converter`, `pa800-rx-dnc-enhancer`, `Pydroid3`,
`novo.zip`, `zaea.zip`, `Aa.zip`, `doktoruser1.zip`, `zadnjevaljda.zip`,
`prism-projects-*` (210 MB), `objects.zip` (121 MB),
`v5-stream*` (5 arhiva — isti sadržaj kao već pregledani),
`PA800_REVERSE_*` (3, duplikati).

**Napomena:** `PA800_REVERSE_EVIDENCE_COMPLETE_2026-09-22.zip`,
`KORG_PA800_FULL_EXTRACTION_TOOLKIT_v1.zip`,
`KORG_PA800_FULL_EDITOR_DATA_v1.zip`,
`KORG_PA800_PCG_SOUND_DRUM_MAPPER_v6.zip`,
`112-fixed-v4.zip`, `pa4x-kod.zip` i `Korg_Pa800_MIDI_Optimizer_Pro.zip`
postoje **po dva puta** s istom veličinom — čisti duplikati.

---

## E. NIJE ZA OVAJ POSAO

`Soundfonts.zip` (1,15 GB), `E-A7_ROM_Package_v202.zip` (109 MB, **Roland**,
ne Korg), `REVOLUCIJA_BEST_40_WAVS_GAIN_CLEAN.zip` (17 MB, audio),
`drumsetsamples.zip`, `SMDrums_Kontakt_1.1.zip`, `Nova mapa.zip`,
`Kimi_Agent_...zip`, `pa800_full_app (2).zip` (62 MB).

---

## Zaključak

Od 110 arhiva, **10 je stvarno pročitano** i sve što su nosile je ugrađeno.
Još **3 vrijede otvoriti**. Ostalih ~97 su starije verzije alata, duplikati,
audio ili tuđi materijal.

**Pa3X lista imena zvukova i dalje nije nađena ni u jednoj arhivi.** To je
jedina stvar koja blokira remap po imenu umjesto po broju. Provjereni i odbačeni tragovi: `kpmv3_unpacked_image` (snimak Windows
desktopa), `Pa4X_OS2_USEFUL_RESOURCES` (nema tabele), `pa4x-workspace`
(ima Pa4X imena, ali ne Pa3X). Ostaje samo `kpmv3_runtime.zip`, s malom
nadom.

**Brži put je hardver, ne arhiva:** izvezi sa svog Pa800 jedan SET u kojem si
promijenio SAMO zvuk na Upper1. To daje pravi par ulaz/izlaz.

Mjesta za uštedu: duplikati i starije verzije alata zauzimaju preko 1,5 GB.

---

# DODATAK — 04.10., nakon „samo refrešuj"

## Novo na Drive-u

| Stavka | Nalaz |
|---|---|
| `4 (Unzipped Files)` | Drive je raspakirao `4.zip`. Isti sadržaj koji sam već obradio — ništa novo |
| `pa3x-pkg.zip` (972 B) | **nije paket nego izvještaj o neuspjehu.** `oc20_records/` je prazna. Skener našao **1 kandidat** (`F:\Updater.mzx`), **0 OC20 stranica** |

## Gdje je tačno bio zid

`pkg_file_records.json` daje presudni detalj: `payload_magic_hex = 5f 4d 5a 58`
= **`_MZX`**, uz `metadata_declared_bytes 1.036.205` prema
`physical_payload_bytes 262.145`. Dakle **kompresija ~4:1**. Skener je tražio
F8/FB markere — to nije gramatika tog formata, zato je našao jedan jedini zapis.

## Format je sada dokumentovan

`github.com/Polprzewodnikowy/KorgPackage` (GPL-3.0) dokumentuje cijeli
kontejner: `chunk = [u32 id][u32 size][payload]`, id 1 header, 2–14 sistemski
fajlovi, 15 installer script, 16 direktorij, 18 fajl, 19 rootfs. Kompresija
tip 0 = sirovo, **tip 1 = zlib u blokovima ≤1 MiB** (`0x100` podatak,
`0x101` kraj), tip 16 = šifrovano.

Mach id: Pa600 `Z103A` · Pa900 `Z104A` · Pa300 `Z106A` · Pa3XLe `Z107A` ·
Havian30 `Z108A` · Pa4X `Z110A`. Pa3X nosi **`Z102A`**.

Implementirano u **`tools/korg_pkg.py`** (`list` / `unpack` / `names`).

## Pa3X OS je skinut i otvoren

Skinuo sam **Pa3X_Operating_System_v163** direktno s korg.com
(`cdn.korg.com/.../e7bd8217fb8b392119d993cad9e9fe1b.zip`, 17,8 MB →
`Pa3X_OS.pkg`, 18.084.850 B).

**Pa3X NIJE u toj familiji** — paket počinje s `fd 00 00 16`, starija
generacija od one koju KorgPackage pokriva. Ali sadrži formate koje moj kodek
već poznaje:

```
OC20  272 pojave        KORF   62
OC31  178               KBEG   71
OC32   15               _MZX    2
```

Sirovi (nekompresovani) dio nosi **310 muzičkih naziva** — Organ 79×,
Brass 53×, Piano 51×, Tenor Sax 42×, Accordion 25×, Nylon Guitar 17×,
Jazz Guitar 15×… ali to su **imena Keyboard Set / STS zapisa, bez
bank/program adresa**. Indeksirana fabrička lista je u kompresovanim
OC20/OC31 blokovima; `decode_oc` na sirovi isječak ne radi jer traži pravo
zaglavlje resursa.

**Status:** blokada više nije „ne znamo gdje je" nego „treba pročitati OC20
okvir unutar `FD` kontejnera". To je konkretan, rješiv zadatak.

---

# DODATAK 2 — kad je raspakiravanje završilo

## `USER01.STY` 12.070 B — PRAVI hardverski baseline

Onaj od 24.103 B je nosio dvije kopije istog stila. Ovaj je original iz
ranijeg nalaza:

```
1 stil "Modern Ballad"  ·  v4  ·  ElementInfo 28  ·  TrackData 80
13 elemenata  ·  invarijanta VRIJEDI  ·  ID-09 2873 B legacy
NEVAZECIH SELEKTORA: 0 od 104
```

Čuva se kao `corpus/evidence_re/hardware_baseline/NEWNAME_USER01_original_12070.STY`.

## `Prvi.STY` — konverterski izlaz, pokvaren na tri načina

31 stil, geometrija `(4, 28, 80)`, imena iz `Pa3x--PA800` familije.

| Problem | Mjereno |
|---|---|
| nevažeći zvukovi | **1.746 od 2.704 = 64,6 %** |
| elemenata preko granice | **4 stila** imaju 14 i 15 (Pa800 adresira 13) |
| ID-09 | **9403 B = nested Pa3X** u v4 fajlu |

Hardverski izvoz ima legacy ID-09 od 2873 B i 13 elemenata. Ovaj fajl ima
oboje pogrešno.

## `Drugi.STY` — ne da se ni pročitati

`VerificationError: CBarc match precedes output buffer`. Veličina 1.471.008 B
je identična `Pa900--PA800.sty`, dakle to je Pa900→PA800 izlaz — a cijela
`Pa900--*` familija pada na istu grešku, uključujući i konverziju identiteta.
**Taj fajl je neupotrebljiv.**

## Šta je moj alat uradio na `Prvi.STY`

```
nevažeći zvukovi:  1.746  ->  1     (64,6 %  ->  0,04 %)
izmjena: 4.139      pomjerenih nota: 0
```

**Ali dvije stvari NIJE popravio**, i to priznajem kao rupu:

1. **4 stila i dalje imaju 14/15 elemenata.** Moja v5→v4 konverzija radi samo
   na v5 ulazu; ovo je već v4, pa se granica od 13 ne primjenjuje.
2. **Nested ID-09 (9403 B) je ostao.** Ne diram STS ni na jednom ulazu.

Oba su rješiva istim mehanizmom koji već imam (maska + granica 13), ali traže
zaseban prolaz za v4 ulaz — `convert_style` se ne može direktno iskoristiti
jer bi skratio StyleInfo drugi put.

---

# DODATAK 3 — `SETOVI.zip` i `kpmv3_runtime.zip` otvoreni

## `SETOVI.zip` (363 MB) — ovdje je bilo zlata

Dva kompleta, oba narodnjačka:

| SET | banaka | stilova | format |
|---|---:|---:|---|
| **Korg Pa3x Team Serbian** | 4 | **110** | čisti v5 (28/88) |
| Pa4x Pro Dejan Shiki | 3 | 26 čitljivih | v5, većinom (44/88) |

`Pa4x Pro .../USER02.STY` ne čita se — **TrackData 96**, jedini format
koji još ne podržavam.

### Isporučeno: `OUT/SRPSKI_TEAM_CLEAN.SET`

```
                        prije            poslije
format                  Pa3X v5          Pa800 v4 (28/80)
pogrešni zvukovi        6.144 (46,5 %)   0  (0,00 %)
kršenja granice 13      110              0
pomjerenih nota         —                0
```

110 stilova, 14.331 izmjena. Tabela zamjene bubnjeva proširena
**s 68 na 77 adresa** upravo zbog ovog seta
(`120.64.54 → 120.0.64 Percussion Kit`, 315 traka, pokrivenost 77,4 %).

### Dva bug-a koja je ovaj set otkrio

1. **Lažna prijava „1 pomjerena nota".** Banka legitimno sadrži dva stila
   istog imena („Begin"), a moja provjera ih je ključevala **po imenu** —
   pa je uparila pogrešan par. Sada se ključuje po **poziciji**.
2. **Obmanjujuća poruka.** Pisalo je „Pomjerenih nota: 0 — tvoja muzika je
   netaknuta", što nije bilo pošteno jer S-05 namjerno mijenja velocity.
   Sada stoji „Nota pomjereno pri promjeni formata" plus izričita rečenica
   da se jačine doteruju.

## `kpmv3_runtime.zip` (50 MB) — mrtav trag

Unutra je `kpmv3_runtime.mdmp`, **Windows minidump od 179 MB**. Pretraga na
`PA_OS_SOUND`, `PA3X`, `Z102A`, `Z105A`, `Z110A`, `STYTrack`, `Grand Piano`
— u ASCII i UTF-16 — daje **nula pogodaka**.

## ZAKLJUČAK O LISTI IMENA Pa3X ZVUKOVA

Provjereni i odbačeni svi tragovi:

| trag | ishod |
|---|---|
| `kpmv3_unpacked_image` | snimak Windows desktopa |
| `kpmv3_runtime` | Windows minidump, nula markera |
| `Pa4X_OS2_USEFUL_RESOURCES` | padovi, nema tabele |
| `pa4x-workspace` | ima imena, ali **Pa4X** |
| `Pa3X_OS.pkg` (s korg.com) | 310 naziva, ali **bez bank/program adresa**; indeksirana lista je u kompresovanim OC20 blokovima |

**Liste nema na Drive-u.** Jedini preostali put je čitanje OC20 okvira
unutar `FD` kontejnera Pa3X paketa.

## Oslobođen prostor

`corpus/pa3x/` (24 MB) obrisan — to je bio PA Manager-ov izlaz
(`Dzony 2024_PA800.SET`), a očišćena verzija je isporučena u
`OUT/PA3X_CLEAN.SET`. Original se po potrebi vraća iz
`Pa3xStyle Wrhunski.zip`.

---

# DODATAK 4 — PROBOJ: tabele zvukova svih 10 modela su NAĐENE

Sistematska pretraga Drive-a (ne samo zipova) našla je ono što je 110 arhiva
krilo: **`v5-image-xor3f.bin`, 65.027.123 B** — KORG PA Manager v5,
**već raspakovan iz PECompact2 i XOR 0x3f dekodiran**.

Zato su sve moje ranije pretrage promašivale: tražio sam ASCII i običan
UTF-16, a slika je bila XOR-kodirana. Neko ju je već skinuo s tog sloja.

## Potvrđeno u slici

Deset tabela, po jedna za svaki model:

```
0x256b84  PA_OS_SOUND_PA4X        0x256d2c  PA_OS_SOUND_PA80
0x256bfc  PA_OS_SOUND_PA1000      0x256d74  PA_OS_SOUND_PA500
0x256c54  PA_OS_SOUND_PA3X   <--  0x256dd8  PA_OS_SOUND_PA600
0x256c9c  PA_OS_SOUND_PA2X        0x256e30  PA_OS_SOUND_PA900
0x256ce4  PA_OS_SOUND_PA1X        0x256e78  PA_OS_SOUND_Pa5X
```

**PA800 nema svoju tabelu** — dijeli je s `PA2X`, što se tačno slaže s mojim
`MODEL_REGISTRY` gdje su PA2X / PA500 / PA600 / PA800 ista v4 familija.

## Izvučeno

`corpus/evidence_re/katalog/v5_model_sound_pool.json` — **8.621 imena
zvukova s ofsetima**, zona `0x25a45c..0x2a2000`.

Provjera protiv moje Pa800 liste od 1.067 imena pokazuje gdje je koja
familija: poklapanja rastu od indeksa ~6600 i vrhune **158/200 na indeksu
8000–8200**. Dakle v4 familija (PA2X/PA800/PA500/PA600) je u zoni 6600–8400.

## Što još treba

Imena su tu; nedostaje **vez ime → (MSB, LSB, PC)**. Dvije mogućnosti:

1. adresa je implicitna po **indeksu** u tabeli — tada je rješiva tako što se
   Pa800 blok poravna s mojim katalogom od 1.068 zvukova (gdje adrese znam),
   iz toga izvede pravilo indeks→adresa, pa isto primijeni na Pa3X blok;
2. postoji odvojena tabela adresa, koju treba naći u istoj slici.

## Status blokade

Prije: *„lista imena Pa3X zvukova ne postoji nigdje"*.
Sada: **postoji, izvučena je, i stoji u workspaceu.** Ostalo je samo
segmentirati bazen po modelu i vezati adrese.

To je prvi put da je remap **po imenu** tehnički nadohvat ruke.

---

# DODATAK 5 — 05.10., nakon „preuzmi sa drivea i nastavi"

## `pa4x-kod.zip` NIJE duplikat — ispravka kataloga

Vođen je pod „starije verzije alata, čisti duplikat". **Pogrešno.** Unutra je
Pa4X toolkit s dokumentacijom izvučenom iz firmvera, među kojima:

| fajl | sadržaj |
|---|---|
| `docs/pa4x-sounds.csv` | **2059 zvukova Pa4X s imenom i MSB/LSB/PC adresom** (OS v3.1.0, iz SOUNDS.xml) |
| `docs/factory-sounds.md` | objašnjenje tri sloja: Factory 694 / **Legacy 658** / GM-XG 707 |
| `tools/pa4x_pkg.py` i dr. | KorgPackage-style alati (za budući rad s PKG fajlovima) |

Ovo **rješava ime→adresa vezu za Pa4X iz hardverskog izvora** (jače od Style
Works .SND tabela). Iskorišćeno odmah: V-1.9, `data/pa4x_to_pa800_by_name.json`.
Kopija izvora: `corpus/pa4x_docs/pa4x-sounds.csv`.

Ostatak DODATKA 4 (OC20 okviri u FD kontejneru Pa3X OS paketa) i dalje stoji
kao jedini put za **Pa3X** imena s adresama.

## `INIT_STY_OUT.zip` — drugi život

Ponovo skinut i konačno iskorišćen do kraja: `pa4x` porodica (EI 44 / TD 96)
dekodirana je iz njegovih 97 parova (V-1.7), a `pa4x` vs `pa3x` vs `pa800`
poredbe dokazale su i ispravku bajta 27 (V-1.8). Fikstura je sada u
`corpus/init/INIT_STY_OUT` i tri testa je koriste.

## Pojedinačni fajlovi matrice (full-out iz `4.zip`)

Skidani: `Pa4x--Pa4X.sty`, `Pa4x--Pa700.sty`, `Pa700--Pa4X.sty`.
Prva dva su sada dokazni materijal za prave konverzije (V-1.7/V-1.8).
Treći je otvorio NOVI problem: 7/64 OC31 resursa pada na CBarc dekompresiji
— vjerovatno varijanta enkodiranja PA700-izvornih arhiva (vidi STANJE 2.2).

## Šta i dalje treba s Drive-a (za sljedeću sesiju)

- **`Pa4x Pro Dejan Shiki`** SET (26 stilova; USER02.STY je nečitljiv bio
  zbog TrackData 96 — sada ga čitamo). Jedini dostupni primjerci su u
  `SETOVI.zip` (363 MB) i 169 MB RAR — oba prevelika za direktan download.
  **Zamoli korisnika da ubaci samo taj SET kao zip.**
- `Pa900--*` familija (CBarc pad — vjerovatno isti problem kao Pa700--Pa4X).
