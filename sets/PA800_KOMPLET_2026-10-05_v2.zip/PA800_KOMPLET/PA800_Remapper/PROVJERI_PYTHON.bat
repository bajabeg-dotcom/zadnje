@echo off
chcp 65001 >nul
title Provjera
cd /d "%~dp0"
echo Trazim Python...
echo.
where py   2>nul && py -3 --version
where python 2>nul && python --version
echo.
echo Provjeravam tkinter (prozor aplikacije)...
python -c "import tkinter; print('   tkinter radi')" 2>nul || py -3 -c "import tkinter; print('   tkinter radi')" 2>nul || echo    tkinter NEDOSTAJE - reinstaliraj Python i cekiraj "tcl/tk and IDLE"
echo.
pause
