# Korg Pa800 — FACTORY_MEASURED + STYLE OPTIMIZER
### Verzija S-1.0 · 03.10.2026. · sve brojke u ovom dokumentu su izmjerene, ne pretpostavljene

---

## 0. Šta je ovim isporučeno

Tri stvari koje su bile otvorene:

1. **Dug iz F/K-1.0 je zatvoren.** Lanac E1–E7 je napisan, izvršen i verifikovan.
   Svi `PROVISIONAL` brojevi su zamijenjeni sa `FACTORY_MEASURED`.
2. **Istražen je rad iz druge sesije** o kreiranju Styleova — i njegov native
   codec je ugrađen kao temelj ovog alata.
3. **Style Optimizer (S-serija)** — ista tvornička logika kao Song Optimizer,
   ali primijenjena na native Style objekt.

---

## 1. Kako je korpus uopšte dospio ovdje (bitno za ponovljivost)

Ranije je zaključeno da se 6,9 MB tvorničkog korpusa ne može dovući jer bi
base64 zagušio kontekst. To je bilo tačno, ali rješenje je postojalo:

1. `google_drive__make_public(role=reader, allow_file_discovery=false)` — privremeni link-pristup,
2. `curl` sa `drive.usercontent.google.com/download?id=…&confirm=t` direktno u radni prostor,
3. `google_drive__make_private` — pristup vraćen **odmah nakon preuzimanja**.

Svih pet fajlova je vraćeno na privatno u istom koraku. Ništa nije ostalo javno.
Preuzeto: tvornički Style korpus (6,9 MB), demo MIDI (752 KB), `STYLE.zip` (2,5 MB),
`VALJA_SONG_STYLES_FINAL` (3,5 MB), lista zvukova (58 KB).

---

## 2. Šta si radio u drugoj sesiji (odgovor na pitanje)

Paket `VALJA_PA800_SONG_STYLES_FINAL_2026-10-03` sadrži završen posao:

- **163 song-specific native Pa800 Stylea**, raspoređena u USER01–03 i FAVORITE01–04.
- Svaka pjesma ima **originalni instrumentalni uvod u Intro 1**, kodiran u
  native PPQ 384 Pattern streamove.
- Lead, harmonizovani lead i delay kopije su izolovani na **Acc5** Intro laneu;
  pratnja je raspoređena na Drum, Bass i Acc1–Acc4.
- Variation / Fill / Break / Ending su ostali **byte-identični** odabranom
  optimizovanom osnovnom Styleu (1.946 objekata, 17.315 Pattern referenci).
- Softverski acceptance: 7/7 bankova ponovo otvoreno, 224/224 slotova,
  21.868 Patterna, 2.321.078 događaja — bez parser greške. SHA-256 po banci je zapisan.
- Fizički Pa800 nije bio dostupan; slušna potvrda je ostala kao obaveza.

**Najvrjednije od svega:** u `TOOLS/` se nalazi `PA800_Native_Style_Studio_v1.1`
— kompletan **native .STY codec** (BARC dekompresija, OC20/OC31/OC32, node walk,
TrackData v4/v5, type-09 mixer, Pattern event framing). To znači da Style
Optimizer **ne mora ništa pogađati** — on čita i piše iste bajtove koje Pa800 čita.

Taj codec je ugrađen u `pa800_remap/native/` **nepromijenjen**, da bi oba alata
gledala na isti format na isti način.

---

## 3. E1–E7 — izvršeno

### Obim korpusa (E1)

| | |
|---|---|
| Tvorničkih banaka | **18** (`BANK01..17` + `USER01.sty`) |
| Stilova | **435** |
| Style Elemenata | **5.655** |
| Traka (element × lane) | **45.240** |
| Patterna | **58.933** |
| Native događaja parsiranih | **4.264.484** |
| Grešaka parsiranja | **0** |

Alat: `tools/extract_factory.py` → `data/factory_profiles.json`,
`data/CORPUS_MANIFEST.json`, `data/STYLE_ROLE_PROFILES.json`.

### Izmjerene tvorničke vrijednosti (E2–E5)

Medijane po ulozi. Uloga se određuje istim `role_from_pc()` koji koristi i
Song Optimizer, pa se Song i Style slažu oko toga šta je "bas".

| Uloga | CC7 | CC11 | CC10 | CC91 | CC93 | Key range | Vel min/med/max | Poly p95 | Stilova | Note-On |
|---|---|---|---|---|---|---|---|---|---|---|
| GUITAR | 93 | 100 | 64 | 45 | 33 | 24..127 | 37/79/116 | 21 | 348 | 486.063 |
| DRUM | 105 | 115 | 64 | 45 | 0 | 0..127 | 33/89/127 | 5 | 428 | 397.193 |
| PERC | 100 | 112 | 64 | 50 | 0 | 0..127 | 34/78/122 | 6 | 428 | 287.670 |
| PIANO | 93 | 100 | 64 | 50 | 0 | 9..120 | 50/88/118 | 8 | 348 | 261.068 |
| BASS | 101 | 105 | 64 | **0** | 0 | 12..113 | 64/101/124 | 9 | 428 | 152.000 |
| BRASS | 89 | 100 | 64 | 56 | 18 | 12..98 | 51/97/124 | 6 | 135 | 77.423 |
| STRINGS | 79 | 100 | 64 | 60 | 1 | 24..101 | 32/87/121 | 6 | 183 | 51.906 |
| ORGAN | 83 | 100 | 64 | 50 | 22 | 10..108 | 48/97/126 | 8 | 66 | 42.488 |
| ACCORDION | 98 | 100 | 74 | 50 | 0 | 24..108 | 51/93/120 | 5 | 55 | 32.695 |
| PAD | 86 | 100 | 64 | 60 | 38 | 24..96 | 42/83/126 | 6 | 107 | 23.450 |
| REED | 94 | 100 | 64 | 55 | 0 | 9..103 | 59/99/125 | 6 | 59 | 22.170 |
| OTHER | 92 | 100 | 64 | 47 | 36 | 12..112 | 54/88/126 | 5 | 46 | 17.897 |
| LEAD | 93 | 100 | 64 | 42 | 31 | 9..120 | 36/85/115 | 4 | 49 | 15.374 |
| CHROM_PERC | 100 | 100 | 64 | 54 | 6 | 24..103 | 54/87/114 | 5 | 36 | 10.414 |

### Tri nalaza koja mijenjaju pravila

**(a) Bas nikada nema reverb.** Pojas CC91 za BASS je `0..0` kroz svih 428
stilova — ne medijana 0, nego **cijeli raspon p10..p90 je nula**. Isto tako
Drum/Perc i Bass pan je `64..64`: tvornica ih nikada ne pomjera iz centra.
Ovo više nije stilska preporuka, nego mjerenje.

**(b) Postoji i DONJA RX zona, ne samo gornja.** Do sada je bila poznata samo
noise zona C7..G9 (96..127). Mjerenje pokazuje da tvornica piše note i na
**0–11** na melodijskim trakama: Guitar od 0, Organ/Brass/Reed od 1, Piano od 5,
Bass od 6. To su **articulation keyswitch** note, nisu visine. Zato je uvedeno
pravilo **K-16** — zona 0..11 je zaštićena od transpozicije isto kao 96..127.
Bez toga su tvorničke note bježale iz modela (vidi E7 niže).

**(c) Humanize je isključivo gitarska funkcija.** Od svih 45.240 izmjerenih
traka, `humanize ≠ 0` se javlja **samo** na GUITAR ulogama (vrijednosti 1,4,5,6).
Sve ostale uloge imaju striktno 0. Ovo potvrđuje raniji status "Humanize GTR
0..25 CLOSED" — sada sa brojem iza sebe.

NTT/NTR packed bajt uzima vrijednosti `{0,1,2,3,32}`. **Ne tumači se i ne
upisuje se** — čuva se numerički, kako je i dogovoreno.

### Pošteno ograničenje (E6, FX tipovi)

Mixer ima tri FX bajta. Mjerenje pokazuje da je `fx_main` (offset p+8)
**byte-identičan Bank LSB-u** na praktično svakoj traci — to nije FX send nego
kopija LSB-a, i ekstraktor ga **odbija koristiti**. `fx_aux1` i `fx_aux2` se
ponašaju kao pravi sendovi i mapirani su na CC91 / CC93.

**Tipovi efekata** (koji od 125 multiefekata sjedi na A/B/C/D) se **ne čuvaju u
Style banci** — žive u Performance/Editor podacima. Zato je `fx_hint` ostavljen
prazan, a ne izmišljen. Status: **OPEN**.

---

## 4. E7 — holdout test (najjači dokaz)

Model je izmjeren na **14 banaka** (347 stilova, 3.158.350 događaja), pa suočen
sa **4 banke koje ekstraktor nikada nije vidio** (88 stilova, 1.106.134 događaja).

```
RESULT  107/124 provjera prolazi (86,3 %)   key range bježi: 0/12
```

Šta je prošlo savršeno:

| Parametar | Tipična greška na neviđenom materijalu |
|---|---|
| Expression CC11 | 0 jedinica na 12 od 14 uloga |
| Pan CC10 | 0–1 jedinica na 9 uloga |
| Volume CC7 | medijan odstupanja 5 |
| Velocity median | medijan odstupanja 6 |
| Key range | **0 od 12 uloga bježi iz modela** |

Šta nije prošlo (17 promašaja) i zašto je to pošteno prijaviti:
**CC93 chorus** i **velocity floor** imaju veliku varijansu između žanrova
(npr. GUITAR chorus pojas je 0..100). To nije greška modela nego osobina
tvornice — zato se ti parametri koriste kao **pojas**, a ne kao ciljna vrijednost.

> Prvi pokušaj je pao na 82,3 % sa **5/12 key rangea koji bježe**. Uzrok je bio
> upravo nalaz (b): model je imao jedan opseg umjesto muzičkog prozora + dvije
> RX zone. Nakon ispravke: 0/12. To je zapisano namjerno — pokazuje da je test
> stvarno nešto hvatao.

---

## 5. Pravilo koje je test oborio, i kako je popravljeno

Prva verzija Style Optimizera je gurala svaku traku na **medijanu** uloge.
Mjerenje na tvorničkom materijalu:

```
tvorničke banke:  47,7 % traka bi bilo promijenjeno
```

To je po definiciji pogrešno — **ispravan model ne smije mijenjati tvornicu.**
Medijana je centralna tendencija, nije pravilo; tvornica legitimno varira.

Pravilo je prepravljeno: koristi se **izmjereni tvornički pojas p10..p90** po
ulozi i parametru. Vrijednost **unutar** pojasa se ne dira. Vrijednost **izvan**
pojasa se vraća **na najbliži rub pojasa**, nikad na medijanu.

Pojasevi (p10..p90), izvod:

| Uloga | CC7 | CC11 | CC10 | CC91 | CC93 |
|---|---|---|---|---|---|
| BASS | 89..120 | 98..120 | **64..64** | **0..0** | 0..14 |
| DRUM | 92..122 | 100..123 | **64..64** | 20..67 | **0..0** |
| PERC | 81..119 | 100..120 | **64..64** | 20..77 | **0..0** |
| PIANO | 74..112 | 94..110 | 42..86 | 20..80 | 0..76 |
| GUITAR | 60..112 | 86..115 | 34..98 | 15..71 | 0..100 |
| STRINGS | 52..103 | 78..112 | 44..84 | 25..90 | 0..64 |
| ACCORDION | 72..106 | 70..118 | 34..94 | 29..74 | 0..50 |
| ORGAN | 60..104 | 70..110 | 44..91 | 16..74 | 0..84 |

Rezultat nakon ispravke — **veličina** korekcije, ne samo broj:

| | n | medijan korekcije | p90 | korekcije > 20 |
|---|---|---|---|---|
| Tvorničke banke | 4.197 | **7 jedinica** | 18 | **7,7 %** |
| Korisničke banke | 5.048 | 10 jedinica | 29 | **18,7 %** |

Na tvorničkom materijalu optimizator radi samo kozmetičke, **nečujne** korekcije
(7 MIDI jedinica od 127). Na tvom materijalu radi stvarne — velikih korekcija
ima **2,4× više**. To je razlika koju model treba praviti.

---

## 6. S-serija — pravila Style Optimizera

| Pravilo | Šta radi | Dokaz / status |
|---|---|---|
| **S-01** | Određuje ulogu svake od 8 traka (Drum, Perc, Bass, Acc1–5) | isti `role_from_pc()` kao Song Optimizer |
| **S-02** | Volume CC7, Pan CC10, FX send 1/2 vraća u tvornički pojas | p10..p90 iz 45.240 traka |
| **S-03** | Expression (TrackData bajt) vraća u tvornički pojas | isto |
| **S-04** | Velocity preseljava u izmjerenu tvorničku envelopu, monotono | `VelocityEnvelope.map_value()`, isti kod kao Song |
| **S-05** | Key Range zdravorazumska provjera i svođenje u muzički prozor uloge | E4 |
| **S-06** | NTT / NTR — **čita, prijavljuje, nikada ne upisuje** | vrijednosti 2/4 ostaju OPEN, kako je traženo |
| **S-07** | Humanize na ne-gitarskoj traci se prijavljuje kao anomalija | mjerenje: humanize ≠ 0 samo na GUITAR |
| **S-08** | Polifonijski budžet po stilu protiv granice od 120 glasova | Pa800 priručnik str. 24 i 338 |
| **S-09** | Drum i Perc se **nikada** ne transponuju; Pattern i Chord Variation reference se ne diraju; banka se ponovo otvara i kompletno parsira prije prihvatanja | diferencijalni test niže |
| **S-16** | RX zone (keyswitch 0..11, noise 96..127) zadržavaju originalni velocity — tamo velocity bira artikulacijski sloj, nije dinamika | nalaz (b) |

Podrazumijevani režim je **dry-run**. Ništa se ne upisuje bez `--apply`.

---

## 7. Dokaz da Style Optimizer ne kvari Style

Puni ciklus na tvojoj banci `USER01.STY` (32 stila): učitaj → optimizuj →
upiši → **ponovo otvori** → uporedi događaj po događaj.

```
                                         PRIJE     POSLIJE
note (tick, on/off, visina)            141.668     141.668
note-on velocity vrijednosti            71.420      71.420
strukturnih zapisa                          64          64

S-09a  note identične (tick+visina+on/off) : DA  (pomjereno 0)
S-09b  struktura identična (elementi, CV)  : DA
S-04   velocity promijenjen                : 44.851 nota (62,8 %)

INTEGRITET: 344.525 bajtova · 32 stila · 1.922 patterna · 152.364 događaja · bez greške
```

Dakle: **nijedna nota nije pomjerena, nijedna visina promijenjena, nijedan
element ni Chord Variation dirnut** — a 44.851 velocity je presjelo u tvorničku
envelopu. Original fajl ostaje netaknut (provjereno MD5 prije i poslije).

Ovo je Style ekvivalent pravila M-053 / M-054 iz Song Optimizera.

### Stvarni nalaz na tvom materijalu

```
PAŽNJA: stil "9/8 bandzy" dostiže vrh od 159 istovremenih glasova
        — granica Pa800 je 120. Na instrumentu će doći do krađe glasova.
```

Drugi po redu je `DISC&OR WAX WAX` sa 103 — unutar granice ali bez rezerve za
keyboard trake koje sviraš preko stila.

---

## 8. Kako se koristi

```bat
install.bat                  :: jednom
run.bat                      :: Song Optimizer (F/K serija)
run_style.bat                :: Style Optimizer (S serija)
```

Komandna linija:

```bat
:: Song — sada sa izmjerenim profilima
python -m pa800_remap.cli PJESMA.MID -o OUT.MID -p RX_READY --articulated ^
       --factory-profiles data\factory_profiles.json --report

:: Style — prvo analiza, ništa se ne upisuje
python -m pa800_remap.stylecli USER01.STY

:: Style — stvarni upis u novi fajl
python -m pa800_remap.stylecli USER01.STY -o USER01_OPT.STY --apply

:: Ponovno mjerenje tvorničkog korpusa (ako dodaš još banaka)
python tools\extract_factory.py PUT\DO\STYLE -o data\factory_profiles.json

:: Holdout provjera modela
python tools\parity_test.py train.json test.json

:: Diferencijalna provjera prije/poslije
python tools\verify_style.py PRIJE.STY POSLIJE.STY
```

Tvorničke banke su OC20 i **read-only** — mogu se analizirati, ne i prepisati.
Upis radi na USER i FAVORITE bankama.

---

## 9. Šta je i dalje otvoreno (pošteno)

1. **Tipovi efekata (FX A/B/C/D)** — nisu u Style banci. Treba
   `KORG_PA800_FULL_EDITOR_DATA_v1.zip` ili Performance podaci. Status OPEN.
2. **NTR vrijednosti 2 i 4** — čuvaju se numerički, nisu imenovane. Namjerno OPEN.
3. **Žanrovski profili.** Trenutni profili su globalni. Korpus ima 435 stilova
   i moguće je izvući zasebne profile za narodnu / sevdah / oriental / zabavnu —
   to bi smanjilo varijansu CC93 i velocity floora koja je oborila 17 provjera u E7.
   **Za ovo mi treba tvoj odgovor koji ti je žanr primaran.**
4. **Slušna potvrda.** Nijedan softverski test ne zamjenjuje Pa800. Učitaj
   `USER01_OPT.STY` uz backup i uporedi sa originalom na istoj jačini.
5. **Demo MIDI (56 fajlova) je preuzet ali još nije iskorišten** — i po tvom
   pravilu smije se koristiti **samo** za artikulacije, šum i ponašanje zvučnog
   modula, nikada za ritam. Ritam ostaje isključivo iz tvorničkih Styleova.

---

## 10. Nove datoteke

```
pa800_remap/native/          vendorirani native .STY codec (iz tvoje druge sesije)
pa800_remap/styleopt.py      S-serija, jezgro Style Optimizera
pa800_remap/stylecli.py      komandna linija Style Optimizera
pa800_remap/style_gui.py     Windows GUI Style Optimizera
tools/extract_factory.py     E1–E6 ekstraktor tvorničkih parametara
tools/parity_test.py         E7 holdout test
tools/verify_style.py        S-09 diferencijalna provjera prije/poslije
data/factory_profiles.json   IZMJERENI profili — 14 uloga, 4.264.484 događaja
data/CORPUS_MANIFEST.json    popis svega što je izmjereno
data/STYLE_ROLE_PROFILES.json profili po laneu (Drum..Acc5), za Style rad
run_style.bat                pokretač
```

Promijenjeno: `trackparams.py` (`rx_keyswitch_max`, `rx_noise_min`, učitavanje
pojaseva), `autofix.py` (novo pravilo **K-16**, RX keyswitch zona).

---

# Dodatak v S-1.2 — pravila S-04b, S-11, S-12 i ispravka S-16
### 03.10.2026.

## S-04b — velocity remap ne smije preći drum layer prag

**Dokaz:** reverse engineering zvaničnog Pa800 OS v2.02 PKG-a (134.050.105 B,
`cdn.korg.com`), drum kit resursi; tabela `PA800_DRUM_KIT_LAYERS`.

Bubnjarska tipka može nositi više oscilatorskih slojeva biranih velocityjem.
Prelazak praga **ne čini udarac glasnijim nego okida drugi sample**. Svaki
remap koji prekorači prag mijenja zvuk kvalitativno.

```
Pop Std. Kit RX (120.0.4)   38 Snare [80] · 46 Open Hat [90] · 48 Tom1 [85]
                            50 Tom2 [85] · 49 Crash [80] · 51 Ride [80]
                            57 Crash2 [85]
Jazz Kit                    38 Snare [70] · 49 Crash [75]
```

Kako ne znamo koji kit svaka traka učitava, tabela `DRUM_LAYER_SWITCHES` je
**unija** svih dokumentovanih pragova po tipki. Ostanak unutar pojasa unije
je konzervativan: ne može prebaciti sloj ni na jednom dokumentovanom kitu.

**Mjereno na korisnikovom SET-u**, 33.778 udaraca na tipkama sa slojevima:
verzija bez pravila **7.220 preskoka (21,37 %)**, sa pravilom **0 (0,00 %)**.

Isto pravilo u Song Optimizeru nosi oznaku **K-08b**.

## S-11 — mikser vrijednosti izvan upisivog opsega

Stvarni korisnički podaci nose vrijednosti koje native model odbija.
`USER03.STY` je imao `EQ High = -19` i banka se **uopšte nije mogla upisati**
dok nije klampovana. Klampuje `eq_high/eq_mid/eq_low` (-18..18),
`detune` (-64..63), `octave` (-24..24), `pb_sensitivity` (0..24),
`input_trim` (-64..63). **43 pojave** (USER03 ×38, USER01 ×4, USER02 ×1).

## S-12 — zamjena drum kita po pokrivenosti tipki

Nakon S-10 ostaje ostatak koji S-10 ne može riješiti: adrese sa **MSB 120**
(drum kitovi) kojih na Pa800 **nema ni pod jednim LSB-om**. Kod korisnika:
**667 traka, svedeno na samo 15 različitih adresa**.

Zamjena se ne pogađa. Postupak:

1. Iz `PA800_INSTRUMENTI_I_DRUM_KITOVI` parsirana je tvornički **izmjerena**
   mapa tipki za **51 Pa800 kit** (po tipki: broj Note-On i stilova) →
   `data/pa800_drum_kits.json`.
2. Za svaku nevažeću adresu izmjereno je koje tipke korisnikovi patterni
   **stvarno sviraju** na toj traci.
3. Izabran je kit sa najvećom pokrivenošću tih tipki, ponderisano brojem
   nota; izjednačenja rješava popularnost kita u tvorničkom korpusu.
4. Trake bez ijedne note dobijaju siguran default `120.0.5 Standard Kit RX1`.

Rezultat → `data/drum_kit_substitution.json`. Pokrivenost **88,7 – 100 %**.
Metod se sam potvrdio: `120.64.63` je izabrao **Arabian Kit 2**, što odgovara
orijentalnom karakteru tog materijala.

**S-12 je jedino pravilo koje zvuk namjerno mijenja, a ne samo popravlja.**
Zato je cijela tabela ispisana korisniku u `README_SET_BS.txt`.

**Ukupni učinak S-10 + S-12:** nevažeće adrese **48,0 % → 0,00 %**
(1 traka od 23.360).

## Ispravka S-16 — "keyswitch" je bio pogrešan naziv

Raniji tekst je zonu nota 0..11 nazivao RX keyswitch zonom. **To nije tačno.**
89-stranični drum/instrument PDF pokazuje da je RX OSC zona
**C-1..B6 (0..95)** za muzičke slojeve i **C7..G9 (96..127)** za RX_NOISE, te
da se RX artikulacije (HARMONIC / WORKING / STOP / GLISS) biraju
**velocityjem**, ne tipkom. Primjer, E.Bass: HARMONIC 114-127,
WORKING_BASS 53-113, STOP 23-52, GLISS 1-22.

Prolaz zone 0..11 ostaje jer je bezopasan, ali se ispravno zove
**sub-muzička zona**. `rx_noise_min = 96` je PDF-om potvrđen.

## Geometrija formata — kontrola

Detekcija po stvarnoj geometriji (`MODEL_REGISTRY`, 12 Korg PA modela):

| Korpus | v2 (27/48) | v4 (28/80) | v5 (28/88) |
|---|---|---|---|
| Pa800 tvornički | 330 | 79 | 0 |
| Korisnikove banke | 4 | 335 | 0 |
| Pa3x "Wrhunski" | 0 | 430 | **21** |
| Očišćeni SET | 4 | 335 | 0 |

SET **ne mijenja geometriju**. Nalaz uz put: Pa800 tvornička biblioteka je
većinom naslijeđena v2 (PA80/PA1X) geometrija.

## Negativan nalaz — OS paket ne donosi nove stilove

Zvanični `Pa800_os_res_v202.zip` je preuzet i PKG dekodiran (745/746 OC20
stranica). Izvučeno je 18 banaka / **435 stilova — identičan skup imena**
postojećem korpusu. Mjerna baza je već bila kompletna. Paket obrisan.

## Negativan nalaz — cross-model konverter nije upotrebljiv

`korg_pa_converter.py` prijavljuje uspjeh, ali njegov izlaz **moj validirani
čitač odbija** (`CBarc left 8 compressed bytes unread`), i to **i kod banaka
gdje konvertuje 0 stilova** — svaka banka je kraća za tačno 12 bajtova, dok se
original parsira uredno. Kvar u sastavljanju kontejnera. Izlaz nije isporučen.
Siguran put za onih 21 v5 stila je v5→v4 resize unutar vlastitog codeca.

---

# Dodatak v V-1.6 — PRAVILO S-14: remap Pa3X → Pa800 PO IMENU ZVUKA
### 05.10.2026.  Blokada koja je trajala cijeli projekat — RIJEŠENA

## Gdje je bilo

Ne u PA Manager slici, nego u **`1.zip`**, u fajlu koji sam ranije obrisao:
`snd_all.csv`, 62.181 red iz **Style Works XT Universal** `.SND` definicija.

```
rom_PA3x.SND   2.522 zvuka
rom_PA2x.SND   2.033 zvuka      <- ista v4 familija kao Pa800
rom_PA4x.SND   3.332
rom_PA1x.SND   1.841
rom_PA80.SND     984
```

## Zamka u kolonama

CSV kolone su **zamijenjene** u odnosu na stvarni selektor:

```
CC00 (MSB) = kolona 'type'
CC32 (LSB) = kolona 'pc'      <-- nije PC
PC         = kolona 'msb'     <-- nije MSB
```

Dokaz: `Grand Piano` je u SND-u `type=121, msb=0, pc=3`, a u Pa800 katalogu
`cc00=121, cc32=3, pc=0`. Pod pogrešnim tumačenjem poklapanje s mojim
`valid_selectors` je bilo **7 %**; pod ispravnim **52 %**, i pokriva
**1.058 od 1.060** mojih dokazanih Pa800 selektora.

## Potvrda na hardveru

Provjereno protiv `NEWNAME.SET/USER01.STY` („Modern Ballad", izvoz s
instrumenta):

| selektor | traka | ime iz tabele |
|---|---|---|
| `120.0.15` | 0 (bubnjevi) | **Techno Kit 3** |
| `121.13.33` | 2 (bas) | **Finger Bass RX** |
| `121.30.25` | 7 | **RealFolk Gtr ST2** |
| `121.3.0` | — | **Grand Piano** |

Bubanj kit na bubanj traci, bas na bas traci. Tumačenje je tačno.

## S-14

```
1. uzmi ime Pa3X zvuka na toj adresi
2. ako isto ime postoji u Pa800 tabeli -> ta adresa
3. inače: najbliže ime unutar ISTE kategorije (prag sličnosti 0.55)
4. inače: ostavi S-10 (brojčani) da radi
```

Cilj je uvijek ograničen na **dokazano važeće Pa800 selektore**.

## Rezultat na svih 2.522 Pa3X adresa

| metoda | adresa | udio |
|---|---:|---:|
| tačno po imenu | 946 | 37,5 % |
| kategorija + sličnost | 527 | 20,9 % |
| nema zamjene | 1.049 | 41,6 % |
| **mijenja adresu** | **454** | |

Primjeri koje brojčani remap nikad ne bi pogodio:

```
Grand Piano Live  -> Grand Piano        0.82
Honky-Tonk RX     -> Honky-Tonk GM      0.85
Harpsichord RX    -> Harpsichord GM     0.86
E. Grand Phaser   -> E. Grand Wide      0.71
Nylon Guitar 2    121.3.24 -> 121.15.24
Finger Bass 3     121.10.33 -> 121.7.33
```

Tabela: `data/pa3x_to_pa800_by_name.json`.

## Ograničenje

**41,6 % Pa3X zvukova nema Pa800 parnjaka** — Pa3X ih ima 2.522, Pa800
oko 1.058. Za njih i dalje radi S-10 (zadrži PC, popravi LSB), uz istu
ogradu: zvuk je siguran, ali može biti pogrešan instrument.

---

# Dodatak v V-1.5 — PRAVILO S-13: Pa800 granica elemenata na BILO KOJEM ulazu
### 04.10.2026.

## Zašto

`Prvi.STY` (iz raspakiranog `4.zip`) je verzija 4, geometrija `(4, 28, 80)` —
dakle naizgled uredan Pa800 fajl — ali:

```
4 stila imaju 14 i 15 Style Elemenata
ID-09 = 9403 B  (nested Pa3X)
nevažećih zvukova 1.746 / 2.704 = 64,6 %
```

Hardverski izvoz i svih 339 korisnikovih pravih stilova imaju **najviše 13**.
Moja v5→v4 konverzija to nije hvatala jer radi samo na v5 ulazu.

## S-13 — `enforce_pa800_limits()`

Zaseban prolaz koji **ne dira** verziju, StyleInfo ni TrackData. Radi samo
jedno: svodi broj Style Elemenata na 13 i usklađuje bitmapu.

### Zamka koja me prvo prevarila

Kod **već gustog v4** stila *j*-ti zapisani element odgovara ***j*-tom
postavljenom bitu**, a ne bitu *j*. Ispravan stil ima npr. 10 elemenata i
masku `0x6ccf` čiji su bitovi raštrkani. Prva verzija je pretpostavila
`indeks == bit` i **odsjekla elemente iz svih 31 stila**, pa su kršenja
skočila s 4 na 30.

`indeks == bit` vrijedi **samo za v5 ulaz**, gdje su svih 15 slotova
materijalizovani — zato ga v5→v4 putanja smije koristiti, a ova ne.

### Konačna logika

```
n = broj elemenata,  pc = popcount(maske)
n == pc i n <= 13   -> ništa (već ispravno)
n != pc             -> ništa (nedosljedno, ne nagađam)
n > 13              -> zadrži prvih 13, očisti višak visokih bitova,
                       preračunaj PatternInfo asocijacije
```

## Rezultat na `Pa3x--PA800.sty` (31 stil)

| | prije | poslije |
|---|---|---|
| kršenja invarijante | 4 | **0** |
| nevažeći zvukovi | 1.746 / 2.704 (64,57 %) | **1 / 2.664 (0,04 %)** |
| dirani stilovi | — | **samo ona 4** |
| eventa | 208.933 | **208.933** |

## Idempotentnost

Na sva tri isporučena SET-a (339 + 224 + 451 stilova): **0 kršenja, novi
prolaz ne bi dirao nijedan stil.**

## Usput popravljen pravi bug

`find_style_folder()` i `list_banks()` su tražili samo `*.STY`. Na Linuxu i
nekim USB datotečnim sistemima velika i mala slova nisu isto, a prave Korg
medije nose i `USER01.STY` i `Pa3x--PA800.sty`. Zbog toga je cijela mapa
bila nevidljiva alatu. Sada se poredi `suffix.lower()`.

## Što S-13 NE radi

**Nested ID-09 (9403 B) ostaje.** STS se međugeneracijski ne može
konvertovati — to je i PA Manager-ovo vlastito ograničenje
(`Cannot Copy/Paste STS! STS Version NOT Compatible.`). Jedina dokazana
opcija bi bila izbaciti ga da Pa800 primijeni svoje default STS postavke;
nije implementirano jer mijenja strukturu banke.

---

# Dodatak v V-1.4 — HARDVERSKA POTVRDA
### 04.10.2026. · `NEWNAME.SET/STYLE/USER01.STY`, izvezen s korisnikovog Pa800

Do sada je sve bilo mjereno na konverterskim izlazima, od kojih nijedan nije
bio potvrđen na instrumentu. Sada postoji **stvarni izvoz s hardvera**.
Drive ga je izbacio tek pri raspakiranju `4.zip` (24.103 B; u samom
`NEWNAME.SET.zip` je STYLE mapa prazna).

## Mjerenje

```
stil            : "Modern Ballad"  (dva primjerka, identična)
verzija         : 4
ElementInfo     : 28
TrackData       : 80
elemenata       : 13     maska 0x1fff     popcount 13
ID-09           : 2873 B  = legacy
patterna/eventa : 115 / 7182
NEVAZECIH SELEKTORA : 0 od 104
```

Selektori elementa 0:
`120.0.15 · 120.0.30 · 121.13.33 · 121.3.0 · 121.6.28 · 121.3.50 · 121.7.27 · 121.30.25`

## Šta je time dokazano

| Tvrdnja | Status |
|---|---|
| Pa800 geometrija je `(4, 28, 80)` | **potvrđeno na hardveru** |
| `broj elemenata == popcount(maske)`, najviše 13 | **potvrđeno** (13 = 13, maska 0x1fff) |
| Lista važećih selektora (MSB 120/121, LSB 0..36) | **potvrđeno** — pravi Pa800 izvoz ima **0 od 104** izvan liste |
| ID-09 na Pa800 je legacy, ne nested | **potvrđeno** (2873 B) |
| PA Manager piše LSB 64/65 | **oboreno definitivno** — hardver nikad ne piše iznad LSB 30 u ovom uzorku, a fabrički korpus nikad iznad 35 |

Time je zatvorena rasprava iz V-1.2: moja lista nije bila preuska, nego je
PA Manager-ov izlaz bio van važećeg prostora.

I pravilo iz V-1.3 je potvrđeno iz trećeg nezavisnog izvora: `full-out`
matrica, 339 korisnikovih stilova, i sada hardverski izvoz.

Dokaz: `corpus/evidence_re/hardware_baseline/NEWNAME_USER01.STY`.

## Što i dalje nije dokazano

Ovaj fajl potvrđuje da **čitam** Pa800 format ispravno. Ne dokazuje da
instrument **prihvata** fajl koji ja napišem. Za to i dalje treba učitati
jedan moj izlaz na Pa800.

---

# Dodatak v V-1.3 — ISPRAVKA: pravilo o elementima je bilo POGREŠNO
### 04.10.2026.  Izvor: `4.zip` (115 MB, `full-out/` matrica + `pa800_catalog`)

## Greška koju sam napravio

V-1.1 je tvrdio: *„Pa3X ima 15 elemenata, Pa800 adresira 13, zadrži prvih 13
i maskiraj bitmapu na 0x1FFF."* To je **pogrešno**. Reproduciralo je Init
fiksturu (93/97), ali je taj fixture bio poseban slučaj u kojem je maska
uvijek bila 0x7FFF.

`full-out/` matrica pokazuje drugo: izvor `Pa3x--Pa3X` ima svih 15 elemenata,
a izlaz `Pa3x--PA800` ima **7 do 15** — i u svakom slučaju
`broj elemenata == popcount(maske)`, uz **nepromijenjenu masku**.

## Presuda — tvojih 339 pravih Pa800 stilova

| korpus | elemenata | `elem == popcount(maske)` |
|---|---|---|
| **tvoji pravi Pa800 user stilovi (339)** | **4..13, nikad više** | **339 / 339** |
| PA Manager izlaz (451) | 3..13 **+ 21 × 15** | 437 / 451 |

Invarijanta je apsolutna na stvarnom Pa800 materijalu. Mjerilo je to, a ne
drugi konverter.

## Posljedica: 14 od 21 mojih konvertovanih stilova bilo je neispravno

```
KadBiLjudiBili G   elemenata=13  popcount=11   maska=0x0dff
Ceca - Bivsi       elemenata=13  popcount=7    maska=0x00df
Sirtaki EXP7       elemenata=13  popcount=7    maska=0x08cf
...
```

## Ispravljeno pravilo

```
zadrži element i   <=>   bit i je postavljen u content bitmapi
masku NE mijenjaj
ako je popcount > 13 (Pa800 granica): očisti višak visokih bitova
```

Drugi uslov je ono što Init fikstura mjeri (0x7FFF → 0x1FFF), prvi je ono
što `full-out` i tvoji pravi stilovi mjere. Oba su sada u istom pravilu.

## Ponovo primijenjeno i provjereno

`OUT/PA3X_CLEAN.SET/` — 21 stil ponovo konvertovan iz kopije:

```
451 stilova, geometrija (4,28,80) x451
elemenata po stilu: 3..13   (prije: i 15)
kršenja invarijante: 0
note: bit-identične
neispravnih selektora: 10 / 35.112  (0,03 %)
Init fikstura: i dalje 93/97 PASS
```

## Nusnalazi iz `4.zip`

* **`korg_sty_tool` je nepouzdan za pola porodica.** Njegovi izlazi za
  `Pa3xle--*`, `Pa700--*`, `Pa900--*` i `Pa800-PA2-PA500--*` ne daju se
  pročitati — uključujući i konverzije identiteta (`Pa900--Pa900`).
  Nije stvar mog čitača.
* **ElementInfo v2 je 27 B, ne 26.** `Pa1--PA1` mjeri `(2, 27, 48)`.
  Ispravi `MODEL_REGISTRY`.
* **TrackData 96 (Pa700)** i dalje nepodržan — jedini preostali.
* **Hardverski baseline postoji**: `NEWNAME.SET` je izvezen s korisnikovog
  Pa800 — `USER01.STY`, „Modern Ballad", v4, **13 elemenata**, STS slotovi
  Piano/Cornet/Brass Band/Nylon Guitar, Upper1 = `121.0.25`. Potvrđuje i
  LSB opseg i granicu od 13 elemenata.
* **`pa800_catalog`**: 1068 zvukova **s imenima**, 65 drum kitova,
  8320 redova po tipkama, 307 velocity prozora. Bogatije od mojih
  51 kita i 8 velocity prekidača — kandidat za nadogradnju S-12 i S-04b.
  Spremljeno u `corpus/evidence_re/katalog/`.
* Pa3X lista **imena** i dalje ne postoji; `pa-manager-remap-xrefs.md`
  izričito kaže da modelska remap tabela nije izvedena.

---

# Dodatak v V-1.2 — PA Manager oracle: S-10 POTVRĐEN, PA Manager OBOREN
### 04.10.2026.  Izvor: `Desktop.zip` + `v5-stream-RE.zip`

## 1. SET koji sam čistio NIJE bio izvorni Pa3X SET

`BAJAPA800.md` otkriva lanac: `Dzony 2024.SET` → (PA Manager) →
`Dzony 2024_PA800.SET`. Brojevi se poklapaju s mojim korpusom do zadnje
cifre: **12 banaka, 451 resurs, 35.664 selektora**.

Mjereno na `corpus/pa3x`:

| | nalaz |
|---|---|
| ID-09 (STS) | **2873 B × 451** = legacy (Pa800), a nested bi bio 9403 B |
| verzije stilova | 430 × v4 + **21 × v5** |

Dakle dobio sam **PA Manager-ov već konvertovani izlaz**, ne original.
Posljedice:

* **Nema STS rupe u mom radu.** Bojao sam se da sam ostavio nested Pa3X STS
  u Pa800 SET-u. Nisam — bio je legacy prije nego sam ga dotakao.
* **Onih 21 v5 stilova su PA Manager-ovi promašaji** (njegov `--allow-lossy`
  ih nije dovršio). Moja v5→v4 konverzija je dovršila njegov posao.

## 2. ORACLE: 2.623 stvarne PA Manager odluke

`pa800-remap-table.json` nosi 1033 različita para `before`/`after` kao sirove
6-bajtne TrackData zapise `(expr, msb, lsb, pc, lo, hi)`.

Šta PA Manager zapravo mijenja: **lsb 2623 ×, pc 2054 ×**, ništa drugo.
Tipično: `121.66.5 → 121.64.6`, `121.67.46 → 121.65.46` — dakle **LSB−2,
PC+1**.

## 3. PRESUDA — fabrički stilovi obaraju PA Manager

Provjera svih 435 fabričkih Pa800 stilova, **45.240 traka**:

```
MSB:              121 -> 33.997      120 -> 11.243
MSB 121, LSB:     0..35  I NISTA VISE
```

**Nijedan fabrički Pa800 stil nikada ne koristi LSB 64 ili 65.**

A PA Manager svoj „Pa800 izlaz" upisuje upravo u LSB 64/65 — **0 od 2.623
njegovih izlaznih selektora postoji u važećem Pa800 prostoru.** Njegov remap
je puko aritmetičko pomjeranje unutar Pa3X opsega, ne prelazak u Pa800.

To se slaže s njihovim vlastitim priznanjem u `pa800-remap-findings.md`:
aritmetičko pravilo pogađa **19,0 %**, naučena globalna tabela **25,1 %**,
a 443 od 586 ulaza je višeznačno.

I konačno objašnjava forume: *„Pa3X stilovi na Pa800 tehnički rade, bez
greške, ali zvuče loše."* Rade jer je adresa sintaksno ispravna; zvuče loše
jer u njoj nema zvuka.

**Zaključak: S-10 (zadrži PC, povuci LSB u važeći opseg) i S-12 (bubanj kit
po pokrivenosti tipki) stoje. Oslonjeni su na fabrički korpus, a ne na
aritmetiku.**

## 4. Što i dalje stoji kao ograničenje

Nalaz da remap **mora ići po imenu zvuka**, a ne po broju, je tačan i pogađa
i moj S-10: ja čuvam PC, što pretpostavlja da Pa3X PC znači približno isto
što i Pa800 PC. To nije dokazano.

Pravo rješenje traži **listu imena fabričkih Pa3X zvukova**. Nje i dalje nema:
`v5-model-string-map.json` daje samo ofsete u PA Manager sliku
(`PA_OS_SOUND_<model>` @ VA 0x657b84+), ne i same tabele. Ostaje otvoreno.

## 5. Usput: „v5" u `v5-stream-RE.zip` nije naš v5

Tamo `v5` znači **PA Manager verzija 5**, a sadržaj je Pa5X clip format
(XML `<CLIP>/<SESSION>/<SCENE>/<STAGE>`), REX biblioteka i µ-law audio.
Nema veze s v5 stilskim formatom (Pa3X 28/88). Korisno je samo kao nezavisna
potvrda kontejnera: `KBEG <u32 BE ofseti> KEND <u32 BE n>`, `KORF` objekti,
oznake `OC31`/`OC32`, 384 TPQ — sve se poklapa s mojim čitačem.

---

# Dodatak v V-1.1 — PA3X (v5) -> Pa800 (v4): RIJEŠENO I PRIMIJENJENO
### 04.10.2026.

## Dokazna osnova

`INIT_STY_OUT.zip` daje **97 uparenih stilova istog sadržaja u v5 i v4**.
`1.zip` (korisnikov RE radni direktorij, 177 fajlova) dao je ključ u
`korf_parse_style.py`.

## Potpuno pravilo v5 -> v4

| Dio | v5 | v4 | Pravilo |
|---|---|---|---|
| root verzija | 5 | 4 | bajt 1 |
| **minor u SVAKOM zaglavlju čvora** | 3 | 2 | tag = `[ident, 00, minor, 08]` |
| StyleInfo | 29 B | 27 B | odbaci zadnja 2 |
| **maska elemenata** | 0x7FFF | 0x1FFF | na `1 + len(ime) + 3`, **pomična** |
| Style Elementi | 15 | 13 | zadrži prvih 13 |
| ElementInfo | 28 B | 28 B | bajt 27: 3 -> 2 |
| TrackData | 88 B | 80 B | `v5[:80]` |
| PatternInfo asocijacije | n | n - k | k = zbir CV `nmap` izbačenih elemenata |
| Patterni | — | — | **netaknuti** |

**Rezultat: 93 / 97 bajt-u-bajt identično.**

## Geometrija TrackData je PO KOLONAMA (iz `parse_style_tracks`)

```
8x(expr,msb,lsb,pc,lo,hi) = 48   -> v2
+ 8 x u1[3]               = 72
+ 8 x ntt                 = 80   -> v4  (Pa800)
+ 8 x u3                  = 88   -> v5  (Pa3X)
+ 8 x u4                  = 96   -> pa4x / PA700 / PA1000
```

Ovo objašnjava **cijelu** tabelu geometrija i dokazuje zašto je skraćivanje
na 80 ispravno: briše tačno v5-only kolonu `u3`. Dodavanje podrške za 96
je sada trivijalno (još jedna kolona).

## Tri zamke koje su me koštale

1. `cv_mask` (ElementInfo bajt 0) je **bitmaska**, ne broj CV-ova.
2. Broj asocijacija po CV-u nije broj CV-ova nego `nmap` iz repa CV čvora:
   `[4B dur][4B len][stream][count u8][count x 2B]`. Oko 6x razlika.
3. Maska elemenata u StyleInfo je na **pomičnoj** poziciji jer StyleInfo
   počinje Pascal-stringom imena. Fiksni ofset 14 radi samo za imena
   od 10 znakova.

## Primjena

`OUT/PA3X_CLEAN.SET/` — svih **21 v5 stilova konvertovano**.
Cijeli SET je sada `(4, 28, 80) x 451`, bez ijednog v5.
Note bit-identične, role map prolazi, neispravnih selektora 0.03 %.
Kopija prije konverzije: `OUT/.pa3x_pre_v5to4/`.

Upozorenje: kod **273 trake** v5 kolona `u3` nije bila prazna; taj podatak
na Pa800 nema gdje stati i odbačen je.

Modul: `pa800_remap/v5to4.py`.

---

# Dodatak v V-1.0 — PA3X (v5) -> Pa800 (v4), dekodirano iz `INIT_STY_OUT.zip`
### 03.10.2026.

## Dokazna osnova

Korisnik je dostavio `INIT_STY_OUT.zip`: istih 7 Init banaka izrenderovanih u
svaku Korg PA porodicu (`legacy`, `pa1x`, `pa3x`, `pa4x`, `pa800`,
`transition`). To daje **97 uparenih stilova istog muzičkog sadržaja u v5 i v4
obliku** — tačno onaj kontrolisani before/after par koji je cross-model
problem tražio i kojeg do sada nije bilo.

Učitavanje mojim čitačem: `legacy` v0 26/48, `pa1x` v2 26/48, `pa3x` v5 28/88,
`pa800` v4 28/80, `transition` v1 26/48 — svih 7 banaka u svakoj porodici.
`pa4x` ne učitava: TrackData 96 još nije podržan.

## Izmjerena transformacija v5 -> v4

| Dio | v5 | v4 | Pravilo | Dokaz |
|---|---|---|---|---|
| root verzija | 5 | 4 | postavi na 4 | 97/97 |
| StyleInfo (ident 1) | 34 B | 32 B | odbaci zadnja 2 B | 97/97 |
| PatternData (ident 2) | — | — | **gotovo nepromijenjen** | v. ispod |
| StyleElement (ident 3) | 15 kom. | 13 kom. | **zadrži prvih 13** | **93/93, bez protuprimjera** |
| ElementInfo | 28 B | 28 B | bajtovi 0..26 isti; **bajt 27: 3 -> 2** | 93/97 |
| TrackData | 88 B | 80 B | **`v5[:80]`**, odbačenih 8 B su nule | 93/97 |

Ključno: ovo je **skraćivanje, ne ponovno kodiranje**. Ništa muzičko se ne
izmišlja i ništa muzičko se ne gubi. Kada zadnjih 8 bajtova TrackData **nisu**
nule, stil nosi v5-only podatke po traci i modul odbija dirati (fail-closed).

## Stanje implementacije — `pa800_remap/v5to4.py`

Validacija protiv poznatog ispravnog `pa800/` izlaza, 97 parova:

* struktura: identi, broj i dužine svih čvorova se poklapaju
* StyleInfo, ElementInfo, TrackData, Style Elementi: **poklapaju se**
* **preostala razlika: 18–74 bajta (najčešće 24 i 48), uvijek u PatternData**

Uzrok je poznat i lokalizovan: `PatternInfo` nosi listu 2-bajtnih Chord
Variation asocijacijskih indeksa, i ona mora izgubiti indekse dva izbačena
elementa. Dvije pretpostavke su probane i obje grubo precjenjuju:

1. jedan indeks po CV čvoru elementa  -> precijenjeno
2. `ElementInfo` bajt 0 kao broj CV-ova -> precijenjeno

Dok se pravilo potrošnje te liste ne dekodira, lista se **ostavlja netaknuta**:
rezultat je 24 bajta duži od referentnog, ali interno konzistentan.

**Zato konverzija još nije primijenjena na onih 21 stil.** Ne isporučujem
nešto što se razlikuje od dokazanog ispravnog izlaza, makar i za 24 bajta.

## Sljedeći korak

Dekodirati potrošnju `PatternInfo` asocijacijske liste po elementu —
najbrže preko `pattern_role_map()`, koji tu listu već tačno konzumira pri
čitanju. Kad to legne, očekivano je 93/97 bajt-u-bajt poklapanje, pa onda
v5->v4 + S-10 + S-12 nad onih 21 stila.

## Usput: `pa4x` porodica

`INIT_STY_OUT/pa4x` koristi TrackData **96**, ne 88 kako `MODEL_REGISTRY`
tvrdi za PA4X (44/88). Ili je registar netačan za PA4X, ili je ovaj izlaz
zapravo PA700/PA1000 geometrija. Nerazriješeno.

---

# Dodatak v V-1.7 — Pa4X / PA700 / PA1000: ElementInfo 44 → 28 i TrackData 96 → 80, RIJEŠENO
### 05.10.2026. · dokaz: istih 97 stilova iz `INIT_STY_OUT.zip`, porodica `pa4x`

## Dokazna osnova

`INIT_STY_OUT/pa4x` su istih 7 Init banaka (97 stilova) renderovanih u
Pa4X porodicu: unutrašnja verzija **5**, ElementInfo **44**, TrackData
**96** — geometrija koju po evidenciji koriste i PA700 i PA1000. Kako su
`pa3x` (28/88) i `pa800` (28/80) istog muzičkog sadržaja, imamo kontrolisani
par za cijelu novu generaciju.

Prije ovog dodatka kodek je odbijao `pa4x` s `unsupported TrackData
length 96` — jedini padajući format od 12 modela.

## Izmjereno (85 stilova zajedničkih svim porodicama, 1113/1275 elemenata)

| Dio | pa4x | pa3x | pravilo | dokaz |
|---|---|---|---|---|
| root verzija | 5 | 5 | isto | 97/97 |
| StyleInfo | isti sadržaj | — | ne dira se | 85/85 bajt-identično |
| PatternData + CV čvorovi | isti sadržaj | — | ne diraju se | 85/85 / 2265/2265 |
| **ElementInfo** | **44 B** | 28 B | **odbaci zadnjih 16 B** | bajtovi 0..27 identični pa3x EI **1113/1113** |
| **TrackData** | **96 B** | 88 B | **`v5[:80]`** | prefiks 0..87 identičan pa3x TD **1275/1275** |
| broj elemenata | 15 | 15 | isto pravilo kao V-1.1 | 97/97 |

**ElementInfo rep (bajtovi 28..43)** je u cijelom korpusu **konstantan**:

```
00 00 0A 00 00 00 00 00 00 00 00 00 00 00 00 01     (1455/1455 elemenata)
```

To je marker nove generacije, ne podatak — nijedan muzički sadržaj se ne
gubi odbacivanjem.

**TrackData u4 kolona (bajtovi 88..95)** je **nula u 1275/1275** elemenata.
Time je geometrija po kolonama iz V-1.1 potvrđena do kraja:

```
48 → 80 → 88 → 96  (svaka generacija dodaje tačno jednu kolonu od 8 bajta)
```

## Nova izmjerna činjenica: release bajt zaglavlja dječjeg čvora

Zaglavlje svakog čvora je `[ident, verzija, release, 08]`. Release bajt
**prati geometriju payloada**, izmjereno na svih 6 porodica:

| čvor | dužina → release |
|---|---|
| ElementInfo | 26 → 0 · 28 → 1 · 44 → 3 |
| TrackData | 48 → 0 · 80 → 2 · 88 → 3 · 96 → 4 |

Zato opšte pravilo `_hdr` (release 3 → 2) nije dovoljno za pa4x ulaz:
ElementInfo 44 → 28 mora ići **3 → 1**, a TrackData 96 → 80 **4 → 2**.
Bez toga izlaz ima pogrešan release bajt i razlikuje se od hardverske
reference.

## Rezultat

* konverzija pa4x → pa800: **93/97 bajt-u-bajt** identično `pa800` referenci
  (istih 4 „known-different" kao i pa3x put — anomalije referentnog
  konvertera, ne naše)
* konverzija pa4x == konverzija pa3x: **97/97 bajt-identično**
* čitanje selektora iz 96-bajtnog TrackData: **97/97 identično** pa3x
* end-to-end `convert_bank` + export + ponovno učitavanje: 93/97, svi
  izlazi (4, 28, 80)

## Uz to popravljeno

`v5to4.convert_bank` je rebajndao `style.data = new` umjesto kopiranja
u postojeći bytearray (`style.data[:] = new`), pa bi `export()` ponovo
kodirao **originalne v5 bajtove**. Produkcijski put u `pipeline.py` to
radi ispravno (`data[:] = new`), pa OUT setovi nisu pogođeni; ispravljeno
radi konzistentnosti.

## Granice (posteno)

* Uzorci su Pa4X renderi; **stvarni PA700/PA1000 fajlovi nisu testirani**
  (nemam ih). Unutrašnja geometrija je ista prema NALAZ tablici, pa se
  očekuje da rade, ali to tvrdim samo za Pa4X.
* STS (ID-09) i dalje nije prenosiv među generacijama; Guitar Mode 2 i
  4. fill ostaju nerešivi (hardverska granica Pa800).

## Testovi

```
python tools/test_v5to4.py        # Pa3X put:  93/97  PASS (nepromijenjen)
python tools/test_v5to4_pa4x.py   # Pa4X put:  93/97 + 97/97  PASS (novo)
```

Moduli: `pa800_remap/native/model.py` (TrackDataView 96),
`pa800_remap/v5to4.py` (EI 44, TD 96, release mapa), `tools/test_v5to4_pa4x.py`.

---

# Dodatak v V-1.8 — ISPRAVKA V-1.1: bajt 27 ElementInfo je SADRŽAJ, ne verzija
### 05.10.2026. · povod: validacija V-1.7 na pravom materijalu (matrica iz 4.zip)

## Šta je V-1.1 tvrdio

„ElementInfo bajtovi 0..26 isti; bajt 27: 3 → 2 (93/97)" — pravilo izvedeno
isključivo iz INIT parova, gdje referentni renderer u `pa800` porodici piše 2
na Variation elementima.

## Novi dokazi (svi iz tvog materijala)

| Izvor | Variation byte27 | Dokaz |
|---|---|---|
| `NEWNAME_USER01.STY` — **hardverski izvoz s tvog Pa800** | **3** (8/8 elemenata) | hardware_baseline, „mjerilo za sve" |
| VALJA set — **339 tvojih pravih Pa800 stilova** | **3** (66–75 po banci; rijetko 2) | OUT/VALJA_PA800_CLEAN |
| Style Works ciljni renderi (18 narodnjaka × 4 porodice) | **3** na svim ciljevima: Pa4X, PA700, Pa3X, PA800 | corpus/matrix, identično po ciljevima |
| INIT porodice `pa3x` / `pa4x` | **3** (388/388) | INIT_STY_OUT |
| INIT porodica `pa800` | 2 (372), 3 (16) | INIT_STY_OUT — **autsajder** |

Zaključak: jedini korpus u kojem Variation nosi 2 je INIT `pa800` render.
Style Works piše **istu vrijednost u sve ciljne porodice** — to je ponašanje
polja sa sadržajem, ne verzije. Vrijednost 3 na Variation elementima postoji
u tvom pravom hardverskom izvozu, dakle Pa800 je prihvata i čuva.

## Šta je promijenjeno

`v5to4._convert_element` više **ne dira bajt 27**. Konverzija je sada
čisti truncation i na tom bajtu — u duhu principa „ništa se ne izmišlja".

Posljedica za INIT parove: 93/97 izlaza se od INIT `pa800` reference razlikuje
**tačno i samo na bajtu 27** (mjereno; nijedan drugi bajt), a 4 poznata
„known-different" ostaju. Testovi su re-bazirani na tu činjenicu.

## Uz to: validacija na pravom materijalu (matrica 18 narodnjaka)

Pravi Style Works fajlovi s Drive-a: `Pa4x--Pa4X.sty` (EI miješan 44/28,
TD 88), `Pa4x--Pa700.sty` (EI 44, TD 96 — **pravi PA700-formatni fajl**),
`Pa4x--PA800.sty` (referentni izlaz). Rezultati:

* naša konverzija iz Pa4X-rendera == iz PA700-rendera: **18/18 bajt-identično**
* naš izlaz: `pattern_role_map()` prolazi 18/18 — **interno konzistentan**
* referentni PA800 izlaz: **pada** s `unused Pattern associations` —
  Style Works na pravom materijalu ne trimira listu asocijacija kad baci
  elemente (ostavlja mrtve indekse; na INIT materijalu JE trimirao)
* referentni PA800 izlaz drži **14–15 elemenata** u 10/18 stilova;
  mi držimo ≤ 13 kao svih 339 tvojih pravih stilova i hardverski izvoz (S-13)

Sve tri razlike prema referentnom alatu idu u korist naše implementacije.

## Iskrena napomena o postojećim OUT setovima

`OUT/PA3X_CLEAN.SET` je građen sa starim pravilom (21 v5 stil konvertovano
s bajtom 27 = 2 na varijacijama). Vrijednost 2 hardverski radi (INIT renderi
je koriste), ali je vjerovatno mijenjala nepoznato semantičko svojstvo
varijacija. Čista popravka je ponovna gradnja iz originalnih izvora
(SETOVI.zip i ostali na Drive-u) — to je prvi korak sljedeće sesije.
NIJEDAN drugi dio OUT setova nije pogođeno (S-pravila ne diraju EI).

## Testovi

```
python tools/test_v5to4.py            # 93/97 samo-byte27 + 4 known  PASS
python tools/test_v5to4_pa4x.py       # isto + 97/97 == pa3x put     PASS
python tools/test_v5to4_real_matrix.py # pravi Style Works fajlovi   PASS
```

---

# Dodatak v V-1.9 — PRAVILO S-14 prošireno na Pa4X izvore (tabela imena iz firmvera)
### 05.10.2026. · novi izvor dokaza: `pa4x-kod.zip` (Pa4X OS v3.1.0, SOUNDS.xml)

## Šta je novo

U `pa4x-kod.zip` (do sada vođen kao "duplikat") nalazi se **kompletna tabela
zvukova Pa4X firmvera**: 2059 zvukova s imenom i MIDI adresom (MSB/LSB/PC),
u tri sloja — Factory 694, **Legacy 658** (preneseni stariji zvukovi),
GM/XG 707. Za razliku od Style Works `.SND` tabela (koje tvrde 3332), ovo je
**hardverski izvor** — izvučen iz SOUNDS.xml u firmveru.

## Metoda (ista kao V-1.6 za Pa3X, + jedna nova faza)

```
1. ime (normalizovano) — egzaktno                    853  (41,4 %)
2. ime (gotovo) — GLOBALNO najbolje >= 0.90          272  (nova faza)
3. kategorija+slicnost — unutar porodice >= 0.55     583
   ─────────────────────────────────────────────────────
   mapirano                                          1708  (83,0 %)
   bez zamjene (ostaje S-10/S-12)                     351
```

Faza 2 postoji jer familijarno ograničen fuzzy propušta očigledne parove
kad je Pa4X blizanac usidren u drugačije označenoj porodici
(npr. `Muted Trumpet GM` — `Mute Trumpet GM`, 0,968). Globalni pogodak
≥ 0,90 je praktično isto ime i nosi oznaku `ime (gotovo)`.

Kategorije na Pa800 strani izvedene su iz 853 sidra istih imena (Pa800
zvuk nasljeđuje porodicu svog istoimenog Pa4X para) — ništa se ne izmišlja.

## Kolizije s Pa3X tabelom

1119 adresa postoji u obje tabele; 898 mapira na ISTI cilj, 221 različito.
Pravilo: **Pa3X ima prednost** — zajednička adresa znači isti lineage slot,
a Pa3X materijala je u praksi daleko više. (`styleopt.load_name_remap`
spaja tabele s tim redoslijedom.)

## Bubnjevi

Zadržan stari čuvar: na drum selektoru (MSB 120) S-14 radi samo na egzaktnom
imenu — fuzzy za bubnjeve ostaje slabiji dokaz od S-12 (koji gleda koje
tipke patern stvarno svira).

## Rezultat na pravom materijalu

`Pa4x--Pa4X.sty` + `Pa4x--Pa700.sty` (36 stilova, pravi narodnjaci) kroz
cijeli „Popravi sve":

```
Pogrešni zvukovi:  2824  ->  2   (65,4 %  ->  0,05 %)
Pa3X/Pa4X stilova prebačeno u Pa800 format: 36
Nota pomjereno: 0
```

Preostala 2 = jedna traka (`Meni je stobom`/Variation 4, 120.64.58) —
**User Kit** slot koji ne postoji ni u firmveru ni u S-12 tabeli; ispravno
je ostaviti uz prijavu, jer korisnički kit nema fabrički ekvivalent.

## Datoteke

```
data/pa4x_to_pa800_by_name.json     tabela (istog formata kao Pa3X)
tools/build_pa4x_name_remap.py      builder (iz CSV-a firmvera)
corpus/pa4x_docs/pa4x-sounds.csv    izvor (sa Drive-a, pa4x-kod.zip)
```
