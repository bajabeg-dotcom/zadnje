# Korg Pa800 — DEFAULT PRAVILA, FORUMSKO ZNANJE I PA3X PORTABILNOST
### Verzija D-1.0 · 03.10.2026. · svaka tvrdnja ima izvor: priručnik, forum, ili mjerenje na tvom materijalu

---

## 0. Najvažnije prvo

Tražio si da istražim forume i default pravila. Jesam — i to je dovelo do
nalaza koji objašnjava problem u tvojoj biblioteci stilova:

> **48 % traka u tvojim USER/FAVORITE bankama pokazuje na zvuk koji na Pa800
> ne postoji.** Isti test na tvorničkim bankama daje **0 %**.

Nije tvoja logika problem. Tvoja biblioteka nosi **Pa3x adrese zvukova**.
Popravljeno je; detalji u poglavlju 4.

---

## 1. Šta kaže Korg (priručnik) — tvrda default pravila

Izvor: **Pa3X Advanced Edit Manual v1.00 (E)**, 250 strana, preuzet sa Korgovog
servera i sačuvan lokalno (`corpus/docs/Pa3X_AE_Manual_v100_E.pdf`). Style
engine je isti kao Pa800 u svemu što se ovdje navodi.

### D-01 · NTT na Intro 1 i Ending 1

> *"To conform to Korg specifications, it is advisable to set the NTT to
> 'No Transpose' on the Intro 1 and Ending 1."*

Razlog koji priručnik daje: u Intro 1 i Ending 1 je obično snimljena **cijela
akordska progresija**, i ona mora ostati nepromijenjena u svakom tonalitetu.

### D-02 · Dvije porodice NTT-a i gdje koja ide

| Tip | Ponašanje | Priručnik preporučuje za |
|---|---|---|
| **Parallel** | note se transponuju unutar zone koju određuje **Wrap Around** | **melodijske** dionice |
| **Fixed** | arranger pomjera **što manje nota**, traži zajedničke tonove | **akordske** dionice — strings, klavir, mute gitara |

Ovo je direktna potvrda pravila koje sam ranije izveo mjerenjem: *Fixed*
postoji upravo zato da legato linije i promjene akorda zvuče prirodno.

### D-03 · Parallel/i-Series zahtijeva maj7 ili min7

Ako se koristi `Parallel/i-Series`, **svi originalni patterni moraju biti
programirani na akordu "Maj7" ili "min7"**. Za snimanje samo jedne Chord
Variation po elementu, priručnik predlaže **maj7**.

### D-04 · NTT ne postoji na Drum i Percussion

NTT parametri su **zasivljeni** za Drum i Perc trake. Potvrđuje pravilo S-09:
ritam trake se nikada ne transponuju.

### D-05 · NTT je po traci *i* po Style Elementu

Nije globalno po stilu. Svaka traka svakog elementa ima svoj NTT.

### D-06 · Default velocity krivulja

Pa800 User Manual: *"Velocity Curve … By default, it is set to **Medium 2**."*
Fiksna dinamika (kao kod klasičnih orgulja) je zasebna opcija — slaže se sa
mojim mjerenjem da orgulje imaju najuži velocity raspon.

---

## 2. Mjerenje koje potvrđuje D-01

Nisam se oslonio samo na priručnik. Izmjerio sam `NTT/NTR packed` bajt na
**435 tvorničkih stilova**, samo melodijske trake (Bass..Acc5):

| Element | vrijednost 0 | 1 | 2 | 3 | 32 |
|---|---|---|---|---|---|
| **Intro 1** | 1980 | 0 | 0 | **474** | 0 |
| **Ending 1** | 1980 | 0 | 0 | **474** | 0 |
| Intro 2 | 2032 | 265 | 143 | 0 | 14 |
| Variation 1 | 2060 | 221 | 122 | 0 | 51 |
| Variation 2–4 | ~2060 | ~215 | ~115 | **0** | ~60 |
| Fill 1/2, Break | ~2030 | ~290 | ~110 | **0** | ~20 |
| Ending 2/3 | ~2030 | ~248 | ~147 | ~12 | 15 |

Dva nalaza, oba čvrsta:

1. **Vrijednost 3 se pojavljuje isključivo na Intro 1 i Ending 1** — nigdje
   drugo, ni jednom, u 435 stilova.
2. **Vrijednosti 1, 2 i 32 se nikada ne pojavljuju na Intro 1 i Ending 1.**

Intro 1 i Ending 1 imaju **identičnu** raspodjelu (1980 / 474). To je potpis
pravila iz priručnika, vidljiv u bajtovima.

> Ostajem pri dogovoru: **NTT/NTR se ne upisuje.** Ovo je dekodiranje, ne
> dozvola za pisanje. Vrijednost 3 i dalje ne imenujem kao "No Transpose" u
> kodu — samo bilježim da je ekskluzivna za ta dva elementa.

### Koliko tvoj materijal odstupa

| | Intro1/Ending1 melodijskih traka | vrijednosti koje tvornica tu NIKADA ne koristi |
|---|---|---|
| Pa800 tvornički | 4.908 | **0** |
| **Tvoje USER/FAVORITE** | 3.090 | **574** (1 → 504×, 32 → 52×, 2 → 18×) |
| Pa3x Wrhunski | 3.540 | **494** |

574 tvoje trake na Intro 1 / Ending 1 nose NTT kombinaciju koju tvornica tu
nikad ne stavlja. To je tačno ono mjesto gdje se čuje da "intro ne sjeda".

---

## 3. Šta kažu forumi (korgforums.com i Korg Pa Helper)

Ovo je znanje koje nije ni u jednom priručniku.

### F-01 · Pa3x stilovi se **službeno** ne mogu učitati u Pa800

Korgova zvanična tabela kompatibilnosti:

| Format | Učitava se u |
|---|---|
| Pa80 | sve Pa serije |
| Pa1X | sve osim Pa80/Pa60/Pa50 |
| **Pa800** | sve osim Pa1X, Pa80, Pa60, Pa50 |
| **Pa3X** | **samo Pa3X** |

Forumaši potvrđuju: tehnički se učitaju bez greške, ali *"most of them don't
sound good at all. Drums & percussion tracks need to be remapped in most
cases… and still most styles seem out of tune."*

### F-02 · Pa3x drum kitovi imaju drugačije mapiranje tipki

Citat profesionalca koji komercijalno radi stilove:
*"New Drumkits & percussions of Pa3X have a different key mapping and
especially new percussion kits are totally new samples."*

**Ovo je direktno potvrđeno mjerenjem — poglavlje 4.**

### F-03 · Guitar Mode 2 je nerješiv na Pa800

Pa800 ima Guitar Mode **1**: traka sadrži samo guitar-mode note.
Pa3X ima Guitar Mode **2**: ista traka može sadržati i obične MIDI note.
Pri konverziji nastaje konflikt. Preporuka sa foruma je brutalna ali iskrena:
*"those style tracks that use Guitar mode 2 really need all those guitar
tracks deleted… sounds awful."*

Djelimično rješenje koje spominju: oktavna transpozicija može spasiti
jednostavno pisanu GM2 traku.

### F-04 · Pri exportu SMF-a tonalitet nije C

*"Exporting SMF has as reference mostly in C key and factory tracks are
written to various keys, so you have to investigate tonality for every acc
track and change keys for every single variation & CV."*
Zato je za kompleksnu harmoniju (džez) konverzija praktično neisplativa.

### F-05 · FX send se gubi pri konverziji nadole

Korg sam navodi: pri učitavanju Pa800 stilova u slabiji model
*"the FX Send might be set to zero (dry) to avoid unwanted results."*
Treba ga ručno vratiti. Moje pravilo **S-02** to radi automatski.

### F-06 · Univerzalnog konvertera nema

*"In regards to a conversion program, no there is none."* Postoji komercijalni
**EMC StyleWorks XT**, ali i forumaši i korisnici javljaju bugove kod Pa3X
konverzija — nestajanje traka, potreba da se ručno remapiraju svi instrumenti
i FX postavke.

### F-07 · Dijagnostika "čudnih zvukova" — народни recept sa foruma

Pitanje koje je neko postavio doslovno opisuje tvoju situaciju:
*"factory styles play normally but when I play my own styles then the style is
making queer noises."*
Odgovor: *"Could be that the Instruments in the style Track are wrong. Play
the style with Track Screen on, mute the sounds one by one until you identify
which Instrument is causing the noise."*

To je ručna verzija onoga što sada radi pravilo **S-10** — automatski, nad
23.360 traka odjednom.

---

## 4. Glavni nalaz — tvoji stilovi nose Pa3x adrese zvukova

### Dokaz iz tri nezavisna izvora

**Izvor 1 — zvanična lista zvukova** (`PA800_FACTORY_SOUND_LIST_CC00_CC32_PC.txt`,
1003 veze): CC32 (Bank LSB) ide od **0 do 36**. Vrijednosti 64 i 65 **ne
postoje**.

**Izvor 2 — tvoj vlastiti tehnički dosje** (`PA800_INSTRUMENTI_I_DRUM_KITOVI.pdf`,
89 strana, 51 drum kit adresa sa per-key dokazom iz 541.086 Note-On
događaja): svaka drum adresa je oblika **120.0.PC**. LSB je **uvijek 0**.

**Izvor 3 — 18 tvorničkih Style banaka** (45.240 traka): Drum/Perc Bank LSB
je 0 u 810 od 817 slučajeva.

### Mjerenje

Skup važećih selektora = 1003 iz liste zvukova ∪ 640 viđenih u tvorničkim
stilovima = **1060 adresa**. Kontrola prvo:

| Materijal | Traka | Nevažećih adresa | Popravljivo sa LSB→0 |
|---|---|---|---|
| **Pa800 tvornički (kontrola)** | 42.536 | **0 (0,0 %)** | — |
| **Tvoje USER/FAVORITE** | 23.360 | **11.224 (48,0 %)** | 94 % |
| Pa3x Wrhunski (480 stilova) | 35.664 | **26.486 (74,3 %)** | 96 % |

Kontrola od 0 % na tvorničkom materijalu znači da validator **ne proizvodi
lažne uzbune**. Najčešći krivci kod tebe:

```
121.65.56   x1380      120.64.0    x723
120.64.10   x618       120.64.2    x552
```

Sve su to Pa3x bank adrese. Pa800 ih ne može razriješiti — otuda tihe trake,
pogrešni bubnjevi i "queer noises" iz F-07.

### Novo pravilo S-10

Svaka traka se provjerava protiv skupa od 1060 važećih adresa. Ako adresa ne
postoji, LSB se spušta na prvu važeću vrijednost (0..3) uz isti MSB i PC.
Ako ni to ne pomogne, traka se **prijavljuje, ne dira**.

### Pravilo S-11 (nađeno slučajno, pravi kvar)

`USER03.STY` se **uopšte nije mogao prepisati**: nosi `EQ High = -19`, a native
polje prima samo -18..18. Ukupno **43 takve vrijednosti** u tvom SET-u.
Sada se ispravljaju i prijavljuju.

---

## 5. Šta nudi koji fajl tvorničkog dokaza

Tražio si da svaki dokazni fajl "radi svoj posao". Evo šta je svaki dao:

| Fajl | Veličina | Šta je dao | Status |
|---|---|---|---|
| `PA800_FACTORY_STYLES_PATTERNS_PADS_REFERENCE.zip` | 6,9 MB | 435 stilova, 4.264.484 događaja → **svi izmjereni profili** | ✅ iskorišten do kraja |
| `PA800_FACTORY_SOUND_LIST_CC00_CC32_PC.txt` | 58 KB | 1003 važeće adrese zvuka → **osnova pravila S-10** | ✅ iskorišten |
| `PA800_INSTRUMENTI_I_DRUM_KITOVI.pdf` | 12,7 MB / 89 str. | drum kit adrese, **RX velocity zone po oscilatoru** | ✅ iskorišten, **i ispravio me** (vidi dolje) |
| `Pa3xStyle Wrhunski.zip` | 8,5 MB | 480 Pa3x stilova → dokaz o LSB 64 | ✅ iskorišten |
| `STYLE.zip` | 2,5 MB | tvojih 339 stilova → ulaz za očišćeni SET | ✅ iskorišten |
| `VALJA_SONG_STYLES_FINAL` | 3,5 MB | **native .STY codec** iz druge sesije | ✅ temelj svega |
| `Pa3X_AE_Manual_v100_E.pdf` | 14,5 MB | NTT/NTR specifikacija, D-01..D-05 | ✅ preuzet sa Korga |
| `demo_midis.zip` | 752 KB | 56 demo MIDI-ja | ⏳ **još neiskorišteno** — i smije samo za artikulacije, ne za ritam |
| `PA800-MIDI-Enhancer-…zip` | 24 MB | nepoznato | ⏳ nije otvoreno |
| `KORG_PA800_FULL_EDITOR_DATA_v1.zip` | — | FX tipovi | ⏳ nije nađeno u pretrazi |

### Gdje me tvorničko dokazno gradivo ispravilo

`PA800_INSTRUMENTI_I_DRUM_KITOVI.pdf` za E.Bass RX navodi:

```
1 HARMONIC            114-127   C-1..B6
2 WORKING_BASS         53-113   C-1..B6
3 STOP                 23-52    C-1..B6
4 GLISS                 1-22    C-1..B6
5 RX_NOISE             1-127    C7..G9
```

Dvije stvari:

**Potvrda.** RX noise zona je **C7..G9** — tačno moj izmjereni `rx_noise_min = 96`.
A moj izmjereni BASS velocity (floor 64 / median 101 / ceiling 124) leži
precizno unutar `WORKING_BASS` (53–113) i `HARMONIC` (114–127). Statistika i
specifikacija se poklapaju bez da sam ih spajao.

**Ispravka koju moram priznati.** U prošlom dokumentu sam zonu 0..11 nazvao
"RX articulation keyswitch". **To je pogrešno.** Ovaj PDF pokazuje da se RX
artikulacije na basu biraju **velocityjem** (GLISS 1-22, STOP 23-52), a ne
tipkom. Ključna zona je samo gornja, C7..G9. Note 0..11 u tvorničkim stilovima
su unutar legitimne key zone C-1..B6, ali muzički su besmislene na toj poziciji.

Pravilo **K-16** ostaje korisno (ne transponuje ih, pa ih ne kvari), ali
**obrazloženje je bilo netačno** i ovdje je ispravljeno. Naziv u kodu treba
promijeniti iz "keyswitch" u "sub-musical zone".

---

## 6. Tvoj očišćeni SET

`/home/user/OUT/VALJA_PA800_CLEAN.SET/` — 13 banaka, **339 stilova**.

| Banka | Stilova | S-10 zvuk | S-11 opseg | S-02 mikser | S-03 expr | S-05 key | velocity |
|---|---|---|---|---|---|---|---|
| FAVORITE01 | 32 | 985 | 0 | 86 | 373 | 790 | 308 |
| FAVORITE02 | 32 | 1123 | 0 | 52 | 625 | 858 | 484 |
| FAVORITE03 | 32 | 1019 | 0 | 35 | 533 | 843 | 1.307 |
| FAVORITE04 | 32 | 981 | 0 | 36 | 480 | 755 | 922 |
| FAVORITE05 | 32 | 881 | 0 | 60 | 368 | 768 | 2.140 |
| FAVORITE06 | 32 | 874 | 0 | 54 | 517 | 806 | 1.582 |
| FAVORITE07 | 8 | 310 | 0 | 37 | 358 | 280 | 0 |
| FAVORITE08 | 16 | 382 | 0 | 177 | 499 | 460 | 685 |
| FAVORITE09 | 3 | 100 | 0 | 9 | 134 | 84 | 2.917 |
| FAVORITE10 | 25 | 1449 | 0 | 144 | 1176 | 606 | 1.732 |
| USER01 | 32 | 801 | 4 | 156 | 538 | 423 | 44.851 |
| USER02 | 32 | 1267 | 1 | 139 | 677 | 479 | 65.432 |
| USER03 | 31 | 384 | 38 | 147 | 760 | 480 | 150.801 |
| **UKUPNO** | **339** | **10.556** | **43** | **1.132** | **7.038** | **7.632** | **273.161** |

**Rezultat:** nevažeće adrese zvuka **48,0 % → 2,9 %**.

Preostalih 668 traka (2,9 %) nema zamjenu sa LSB 0..3 — prijavljene su, nisu
dirnute. To su vjerovatno Pa3x-only zvuci koji na Pa800 jednostavno ne postoje
i treba im ručno odrediti zamjenu.

### Verifikacija — ni jedna nota nije pomjerena

```
USER01      note identične: DA (pomjereno 0)   struktura: DA   velocity: 44.851 (62,8 %)
USER03      note identične: DA (pomjereno 0)   struktura: DA   velocity: 150.801 (83,8 %)
FAVORITE10  note identične: DA (pomjereno 0)   struktura: DA   velocity: 1.732 (1,2 %)
```

Svaka banka je nakon upisa **ponovo otvorena i kompletno isparsirana**.

### 23 stila prelaze 120 glasova

Pa800 ima 120 glasova. Ovi stilovi će krasti glasove — i to se čuje kao
"nestajanje" bubnja ili basa kad sviraš preko njih:

| Stil | Vrh glasova |
|---|---|
| **Snadji se sam** (FAVORITE05) | **392** |
| **Serif-Gdje su Gm** (FAVORITE06) | **288** |
| U RODNI GRAD SE (USER02) | 261 |
| ZAVOLEH TE (USER02) | 212 |
| AKO ME TRAZIS (USER02) | 180 |
| BO CA CE ZO (USER02) | 172 |
| PLAVUSA (USER02) | 171 |
| 9/8 bandzy (USER01) | 159 |
| NE ZIVIM SAMA (USER02) | 159 |
| KADA BI ME PITAL (USER02) | 158 |
| … još 13 stilova | 129–156 |

`USER02` je najgori — **13 od 32 stila** prelazi granicu.

---

## 7. Šta sljedeće — i gdje mi treba tvoja riječ

1. **Učitaj očišćeni SET uz backup** i poslušaj. Softver ne može čuti.
   Posebno uporedi `USER03` (150.801 izmijenjen velocity — najveća promjena)
   i neki stil iz `FAVORITE07` (0 velocity izmjena — kontrolni uzorak).
2. **668 traka bez zamjene** — treba ručna odluka koji Pa800 zvuk ide umjesto
   Pa3x-only zvuka. Mogu napraviti prijedlog po imenu zvuka iz liste od 1003.
3. **23 stila preko 120 glasova** — mogu automatski prorijediti (ukloniti
   dvostruke note i preduge repove) uz pravilo da se ritam ne dira. Reci da
   krenem.
4. **480 Pa3x stilova** — nakon S-10 bi bili 96 % važeći, ali ostaje problem
   Guitar Mode 2 (F-03) i tonaliteta (F-04). Mogu ih obraditi i dati ti
   rang-listu koji su vrijedni prenosa.
5. **Žanr** — i dalje čekam odgovor: narodna, sevdah, oriental ili zabavna?
   Sa 435 tvorničkih stilova mogu napraviti **žanrovske profile** umjesto
   globalnih, što rješava 17 promašaja iz E7 testa.

---

## 8. Čišćenje radnog prostora

Obrisano: svi ZIP-ovi nakon raspakivanja, `__pycache__`, duplirana kopija
native editora. Radni prostor: **31 MB → 18 MB prije dovlačenja Pa3x
materijala**, sada 60 MB sa Pa3x stilovima i priručnicima.

Zadržano jer **još treba**: tvornički Style korpus (žanrovski profili),
Pa3x stilovi (tačka 4), demo MIDI (artikulacije), priručnici, tvoji dosjei.
