#!/usr/bin/env python3
"""Build data/pa4x_to_pa800_by_name.json — S-14 table for Pa4X sources.

Source of Pa4X sound names+addresses: the Pa4X firmware table extracted in
the user's `pa4x-kod` toolkit (OS v3.1.0, SOUNDS.xml -> CSV, 2059 sounds in
three groups: Factory / Legacy / GM-XG).  This is a *hardware* source, so it
is more authoritative than the Style Works `.SND` tables used for the Pa3X
table (which claim 3332 Pa4X entries).

Target: the 1003 proven-valid Pa800 selectors (factory_sound_list.json).

Method (mirrors the Pa3X table, annex V-1.6):
  1. exact normalised name match          -> how 'ime',    score 1.0
  2. else closest name inside the same
     sound family, similarity >= 0.55     -> how 'kategorija+slicnost'
  3. else no entry                        -> S-10 fallback keeps working

Family categories on the Pa800 side are derived from the 853 exact-name
anchors: a Pa800 sound inherits the family of its same-named Pa4X sound.
Unmatched Pa4X sounds may then fuzzy-match only within that family.

Guards mirrored from S-14: names starting with 'user' are empty USER slots
and are never mapped.

    python tools/build_pa4x_name_remap.py
"""
from __future__ import annotations

import csv
import json
import re
import sys
from difflib import SequenceMatcher
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))

CSV_PATH = Path("/home/user/corpus/pa4x_docs/pa4x-sounds.csv")
OUT_PATH = ROOT / "data" / "pa4x_to_pa800_by_name.json"
FAMILY_THRESHOLD = 0.55


def norm(s: str) -> str:
    return re.sub(r"[^a-z0-9]+", " ", s.strip().lower()).strip()


def main() -> int:
    if not CSV_PATH.exists():
        print(f"SKIP: {CSV_PATH} not present")
        return 0

    p800 = json.loads((ROOT / "data" / "factory_sound_list.json").read_text())
    valid = {(s["cc00"], s["cc32"], s["pc"]): s["name"] for s in p800}
    by_name: dict[str, tuple[int, int, int]] = {}
    for addr, name in valid.items():
        by_name.setdefault(norm(name), addr)

    rows = list(csv.DictReader(CSV_PATH.open(encoding="utf-8")))
    # dedupe: same address may appear in more than one group
    by_addr: dict[tuple[int, int, int], dict] = {}
    for r in rows:
        if r["grupa"] != "Factory" and r["grupa"] != "Legacy" and r["grupa"] != "GM/XG":
            continue
        addr = (int(r["msb"]), int(r["lsb"]), int(r["pc"]))
        by_addr.setdefault(addr, r)

    # Pa800 family anchors from exact matches
    p800_family: dict[str, str] = {}
    exact = 0
    for addr, r in by_addr.items():
        key = norm(r["ime"])
        if key in by_name:
            p800_family.setdefault(key, r["porodica"])
            exact += 1

    table: dict[str, dict] = {}
    by_method = {"ime": 0, "kategorija+slicnost": 0, "bez zamjene": 0}
    changes_address = 0
    for addr, r in sorted(by_addr.items()):
        name = r["ime"].strip()
        if name.lower().startswith("user"):
            by_method["bez zamjene"] += 1
            continue
        key = norm(name)
        src = f"{addr[0]}.{addr[1]}.{addr[2]}"
        if key in by_name:
            target = by_name[key]
            table[src] = {"name": name, "to": f"{target[0]}.{target[1]}.{target[2]}",
                          "to_name": valid[target], "how": "ime", "score": 1.0}
            by_method["ime"] += 1
            if target != addr:
                changes_address += 1
            continue
        # stage 2: near-exact GLOBAL match.  Family-restricted fuzzy alone
        # misses obvious pairs when the Pa800 twin is anchored to a
        # differently-labelled family (e.g. 'Muted Trumpet GM' vs Pa800
        # 'Mute Trumpet GM', score 0.966).  A >= 0.90 global hit is safe:
        # it is virtually the same name.
        best, best_score = None, 0.0
        for cand, cand_addr in by_name.items():
            score = SequenceMatcher(None, key, cand).ratio()
            if score > best_score:
                best, best_score = cand, score
        if best is not None and best_score >= 0.90:
            target = by_name[best]
            table[src] = {"name": name, "to": f"{target[0]}.{target[1]}.{target[2]}",
                          "to_name": valid[target], "how": "ime (gotovo)",
                          "score": round(best_score, 3)}
            by_method["ime"] += 1
            if target != addr:
                changes_address += 1
            continue
        # stage 3: fuzzy inside the same family
        family = r["porodica"]
        best, best_score = None, 0.0
        for cand, cand_addr in by_name.items():
            if p800_family.get(cand) != family:
                continue
            score = SequenceMatcher(None, key, cand).ratio()
            if score > best_score:
                best, best_score = cand, score
        if best is not None and best_score >= FAMILY_THRESHOLD:
            target = by_name[best]
            table[src] = {"name": name, "to": f"{target[0]}.{target[1]}.{target[2]}",
                          "to_name": valid[target], "how": "kategorija+slicnost",
                          "score": round(best_score, 3), "cat": family}
            by_method["kategorija+slicnost"] += 1
            if target != addr:
                changes_address += 1
        else:
            by_method["bez zamjene"] += 1

    out = {
        "note": ("Pa4X -> Pa800 po IMENU. Izvor: Pa4X firmver OS v3.1.0 "
                 "(SOUNDS.xml, iz pa4x-kod paketa; 2059 zvukova: Factory/Legacy/GM-XG). "
                 "Cilj ogranicen na dokazano vazeci Pa800 selektori. "
                 "Kategorije Pa800 strane izvedene iz 853 sidra istih imena."),
        "total_pa4x": len(by_addr),
        "by_method": by_method,
        "changes_address": changes_address,
        "map": table,
    }
    OUT_PATH.write_text(json.dumps(out, ensure_ascii=False, indent=1), encoding="utf-8")
    print(f"Pa4X zvukova: {len(by_addr)}")
    print(f"po metodi: {by_method}")
    print(f"mijenja adresu: {changes_address}")
    print(f"zapisano: {OUT_PATH}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
