#!/usr/bin/env python3
"""Unpack a KORG Professional Arranger OS package (.pkg).

The Pa3X / Pa600 / Pa900 / Pa4X operating systems ship as a chunked package.
Earlier attempts in this project scanned for F8/FB byte markers and found
almost nothing (1 candidate, 0 OC20 pages) -- that is the wrong grammar.
The real container is a simple chunk list, documented by the KorgPackage
project (github.com/Polprzewodnikowy/KorgPackage, GPL-3.0):

    chunk = [int32 id][int32 size][payload]

    id  1      header (mach id, build info, dates)
    id  2..14  system files (kernels, ramdisks, bootloaders, installers)
    id 15      installer script
    id 16      directory entry
    id 17      symlink                  (not handled there, nor here)
    id 18      file
    id 19      file system image (rootfs)

A file chunk (18) is:

    [md5 16][owner u16][group u16][attrs u16][cond u16][data_size u32]
    [compression u8][path cstr][date cstr][time cstr][data]

    compression 0  -> raw
    compression 1  -> zlib, in blocks of <= 1 MiB:
                      [u32 block_type][u32 comp_size][u32 raw_size LE-reversed]
                      [comp_size - 4 bytes of zlib data]
                      block_type 0x00000100 = data, 0x00000101 = end
    compression 16 -> encrypted (cannot be read)

Machine ids:  Pa600 Z103A · Pa900 Z104A · Pa300 Z106A · Pa3XLe Z107A
              Havian30 Z108A · Pa4X Z110A.  The Pa3X package carries
              `Z102A.mzx`, i.e. mach id **Z102A**.

Why this matters here: the Pa3X factory SOUND NAME list is the one piece of
evidence still missing for a name-based (rather than number-based) selector
remap.  It lives inside this package.

Usage:
    python tools/korg_pkg.py list   Pa3X_OS.pkg
    python tools/korg_pkg.py unpack Pa3X_OS.pkg OUTDIR
    python tools/korg_pkg.py names  Pa3X_OS.pkg      # hunt for sound names
"""
from __future__ import annotations

import re
import struct
import sys
import zlib
from pathlib import Path

HEADER, SCRIPT, DIRECTORY, LINK, FILE, ROOTFS = 1, 15, 16, 17, 18, 19
SYSTEM_FILES = {
    2: "/update/uImage", 3: "/update/ramdisk.gz", 4: "/update/lfo-pkg-install",
    5: "/update/lfo-pkg-install.xml", 6: "/service/uImage",
    7: "/service/ramdisk.gz", 8: "/service/lfo-service",
    9: "/service/lfo-service.xml", 10: "/service/lfo-pkg-launcher",
    11: "/service/lfo-pkg-launcher.xml", 12: "/boot/MLO",
    13: "/boot/u-boot.bin", 14: "/kernel/uImage",
}
MACH = {"Z102A": "Pa3X", "Z103A": "Pa600", "Z104A": "Pa900", "Z105A": "?",
        "Z106A": "Pa300", "Z107A": "Pa3XLe", "Z108A": "Havian 30",
        "Z110A": "Pa4X"}


def _cstr(buf: bytes, pos: int) -> tuple[str, int]:
    end = buf.index(b"\0", pos)
    return buf[pos:end].decode("latin-1"), end + 1


def _inflate_blocks(data: bytes) -> bytes:
    """zlib payload split into <=1 MiB blocks."""
    out = bytearray()
    pos = 0
    while pos + 8 <= len(data):
        btype, csize = struct.unpack_from(">II", data, pos)
        if btype == 0x00000101:
            break
        if btype != 0x00000100:
            raise ValueError(f"unknown block type 0x{btype:08x} at {pos}")
        pos += 8
        blob = data[pos + 4:pos + csize]
        out += zlib.decompress(blob)
        pos += csize
    return bytes(out)


def parse(path: str | Path):
    """Yield (chunk_id, info dict) for every chunk in the package."""
    raw = Path(path).read_bytes()
    pos = 0
    while pos + 8 <= len(raw):
        cid, size = struct.unpack_from(">II", raw, pos)
        body = raw[pos + 8:pos + 8 + size]
        pos += 8 + size
        info: dict = {"size": size}
        try:
            if cid == HEADER:
                p = 12
                fields = []
                for _ in range(7):
                    if p >= len(body):
                        break
                    s, p = _cstr(body, p)
                    fields.append(s)
                info["fields"] = fields
                info["mach"] = fields[0] if fields else ""
            elif cid in SYSTEM_FILES:
                info["path"] = SYSTEM_FILES[cid]
                info["data"] = body[16:]
            elif cid == DIRECTORY:
                info["path"], _ = _cstr(body, 8)
            elif cid == FILE:
                owner, group, attrs, cond, dsize = struct.unpack_from(">HHHHI", body, 16)
                comp = body[28]
                p = 29
                fpath, p = _cstr(body, p)
                date, p = _cstr(body, p)
                time, p = _cstr(body, p)
                info.update(path=fpath, date=date, time=time,
                            compression=comp, declared=dsize)
                blob = body[p:]
                if comp == 0:
                    info["data"] = blob
                elif comp == 1:
                    info["data"] = _inflate_blocks(blob)
                else:
                    info["data"] = None   # encrypted
            elif cid == ROOTFS:
                dsize, = struct.unpack_from(">I", body, 16)
                info["path"], _ = _cstr(body, 22)
                info["data"] = body[-dsize:] if dsize else b""
        except Exception as exc:                      # keep walking
            info["error"] = f"{type(exc).__name__}: {exc}"
        yield cid, info
        if size == 0:
            break


def cmd_list(pkg: str) -> int:
    n = 0
    for cid, info in parse(pkg):
        n += 1
        if cid == HEADER:
            mach = info.get("mach", "")
            print(f"HEADER  mach={mach} ({MACH.get(mach.split('/')[0], '?')})  "
                  f"{info.get('fields')}")
        else:
            d = info.get("data")
            print(f"  id={cid:<3} size={info['size']:>10}  "
                  f"comp={info.get('compression','-'):<3} "
                  f"out={len(d) if d is not None else 'ENCRYPTED':>10}  "
                  f"{info.get('path','')}"
                  + (f"   !{info['error']}" if "error" in info else ""))
    print(f"\nchunks: {n}")
    return 0


def cmd_unpack(pkg: str, out: str) -> int:
    root = Path(out)
    written = 0
    for cid, info in parse(pkg):
        data = info.get("data")
        p = info.get("path")
        if data is None or not p:
            continue
        target = root / p.replace("\\", "/").lstrip("/")
        target.parent.mkdir(parents=True, exist_ok=True)
        target.write_bytes(data)
        written += 1
    print(f"written {written} files to {root}")
    return 0


def cmd_names(pkg: str) -> int:
    """Pull plausible factory sound names out of every decoded chunk."""
    pat = re.compile(rb"[\x20-\x7e]{4,24}")
    musical = re.compile(
        r"(Piano|Guitar|Bass|Strings|Brass|Organ|Accord|Sax|Trumpet|Flute|"
        r"Choir|Pad|Synth|Perc|Kit|Clav|Vibe|Harp|Oboe|Clarinet|Violin)")
    seen: dict[str, int] = {}
    for cid, info in parse(pkg):
        data = info.get("data")
        if not data:
            continue
        for m in pat.findall(data):
            s = m.decode("latin-1").strip()
            if 4 <= len(s) <= 24 and musical.search(s):
                seen[s] = seen.get(s, 0) + 1
    print(f"distinct musical-looking strings: {len(seen)}")
    for s, c in sorted(seen.items(), key=lambda kv: -kv[1])[:80]:
        print(f"   {c:>5}  {s}")
    return 0


def main(argv: list[str]) -> int:
    if len(argv) < 3:
        print(__doc__)
        return 2
    cmd, pkg = argv[1], argv[2]
    if cmd == "list":
        return cmd_list(pkg)
    if cmd == "unpack":
        return cmd_unpack(pkg, argv[3] if len(argv) > 3 else "pkg_out")
    if cmd == "names":
        return cmd_names(pkg)
    print(__doc__)
    return 2


if __name__ == "__main__":
    raise SystemExit(main(sys.argv))
