#!/usr/bin/env python3
"""S-12 — build/extend the drum-kit substitution table for a Style corpus.

For every selector on a Drum/Percussion lane that does not exist on the Pa800,
measure which keys the corpus actually plays on that lane and pick the Pa800
kit whose factory-measured key map covers those keys best.

Evidence:
  data/pa800_drum_kits.json   51 Pa800 kits, per-key Note-On counts measured
                              on the factory corpus (parsed from
                              PA800_INSTRUMENTI_I_DRUM_KITOVI).
  data/valid_selectors.json   1060 selector triples proven to exist.

Usage:
  python3 tools/build_drum_subs.py "corpus/**/*.STY" [more globs ...]
"""
from __future__ import annotations

import collections
import glob
import json
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))

from pa800_remap.native import NativeStyleBank           # noqa: E402
from pa800_remap.native.codec import walk_children, _be32  # noqa: E402
from pa800_remap.native.events import parse_pattern_stream  # noqa: E402

DEFAULT_KIT = "120.0.5"          # Standard Kit RX1 - most used universal RX kit
DRUM_LANES = (0, 1)              # Drum, Percussion


def load(name):
    with open(ROOT / "data" / name, encoding="utf-8") as fh:
        return json.load(fh)


def main(patterns):
    valid = {tuple(x) for x in load("valid_selectors.json")}
    kits = {k: {"name": v["name"], "keys": {int(a): b for a, b in v["keys"].items()}}
            for k, v in load("pa800_drum_kits.json").items()}
    pop = {k: sum(v["keys"].values()) for k, v in kits.items()}

    usage = collections.defaultdict(collections.Counter)
    lanes = collections.Counter()
    files = sorted({f for p in patterns for f in glob.glob(p, recursive=True)})
    print(f"skeniram {len(files)} banaka")

    for f in files:
        try:
            bank = NativeStyleBank.load(f)
        except Exception as exc:                       # unreadable bank
            print(f"  preskacem {Path(f).name}: {exc}")
            continue
        for entry in bank.entries:
            style = entry.style
            bad = collections.Counter()
            for el in style.elements:
                for t in DRUM_LANES:
                    ts = el.track_data.get(t)
                    addr = (ts.msb, ts.lsb, ts.program)
                    if addr not in valid:
                        bad[addr] += 1
                        lanes[addr] += 1
            if not bad:
                continue
            try:
                rolemap = style.pattern_role_map()
                pool = walk_children(style.data, style.pattern_pool.offset)
            except Exception:
                continue
            hist = collections.Counter()
            for i, p in enumerate(pool[1:], start=1):
                if not (rolemap.get(i, set()) & set(DRUM_LANES)):
                    continue
                st = p.offset + 8
                dur = _be32(style.data, st)
                ln = _be32(style.data, st + 4)
                for ev in parse_pattern_stream(style.data[st + 8:st + 8 + ln], dur):
                    if ev.opcode == 1 and ev.velocity:
                        hist[ev.pitch] += 1
            tot = sum(bad.values())
            for addr, c in bad.items():
                for k, v in hist.items():
                    usage[addr][k] += v * c / tot

    out = {}
    try:
        out.update(load("drum_kit_substitution.json"))
    except Exception:
        pass

    added = 0
    for addr, n in lanes.most_common():
        key = f"{addr[0]}.{addr[1]}.{addr[2]}"
        if key in out:
            continue
        if addr[0] != 120:          # melodic selectors are S-10's job, not S-12
            continue
        h = usage[addr]
        total = sum(h.values())
        if total == 0:
            pick, cov = DEFAULT_KIT, None
        else:
            scored = sorted(
                ((sum(v for k, v in h.items() if k in kv["keys"]) / total, pop[ka], ka)
                 for ka, kv in kits.items()), reverse=True)
            cov, _, pick = scored[0]
        out[key] = {"to": pick, "name": kits[pick]["name"], "lanes": n,
                    "coverage": round(cov, 4) if cov is not None else None}
        added += 1
        c = f"{cov*100:5.1f}%" if cov is not None else " nijem"
        print(f"  + {key:<12} x{n:<5} -> {pick:<10} {kits[pick]['name']:<20} {c}")

    with open(ROOT / "data" / "drum_kit_substitution.json", "w", encoding="utf-8") as fh:
        json.dump(out, fh, indent=1, ensure_ascii=False)
    print(f"\ndodano {added}, tabela sada ima {len(out)} adresa")


if __name__ == "__main__":
    main(sys.argv[1:] or ["/home/user/corpus/**/*.STY"])
