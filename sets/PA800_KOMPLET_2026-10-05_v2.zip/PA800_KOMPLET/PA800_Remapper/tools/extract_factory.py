#!/usr/bin/env python3
"""E1..E6 -- Factory parameter extractor for the Korg Pa800.

Turns the PROVISIONAL numbers in pa800_remap/trackparams.py into
FACTORY_MEASURED ones by reading the native factory .STY banks directly.

Evidence chain
--------------
E1  walk every bank -> every Style -> every Style Element -> every track,
    and every Pattern stream, building CORPUS_MANIFEST.json.
E2  per instrument role: median Volume / Pan / Expression / FX sends,
    taken from the native mixer + TrackData bytes (not guessed).
E3  per instrument role: velocity envelope = p5 / p50 / p95 of every
    note-on velocity the factory actually wrote for that role.
E4  per instrument role: key range.  Two independent measurements --
    the DECLARED range (TrackSettings.key_low/key_high) and the PLAYED
    range (p1/p99 of real note numbers).  They are reported separately;
    the profile uses the union, so nothing the factory plays is ever
    considered out of range.
E5  per instrument role: max polyphony = p95 of simultaneous sounding
    notes inside one Pattern.
E6  FX: only what the bytes prove.  See FX_NOTE below.

Usage
-----
    python tools/extract_factory.py <STYLE_dir> [-o data/factory_profiles.json]
"""
from __future__ import annotations

import argparse
import json
import sys
from collections import defaultdict
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

from pa800_remap.native import NativeStyleBank, ROLES, ModelError  # noqa: E402
from pa800_remap.native.codec import walk_children, _be32  # noqa: E402
from pa800_remap.native.events import parse_pattern_stream  # noqa: E402
from pa800_remap.trackparams import Role, role_from_pc  # noqa: E402

# ---------------------------------------------------------------------------
# FX_NOTE (E6, honest limitation)
#
# CompanionView exposes three FX-ish mixer bytes: fx_main (p+8), fx_aux1
# (p+26) and fx_aux2 (p+27).  Measured across the factory corpus, fx_main is
# byte-identical to the track's Bank LSB on essentially every track, so it is
# NOT an FX send -- it is an LSB mirror and this extractor refuses to use it.
# fx_aux1 behaves like a real send (clusters around 55..63 for pitched tracks,
# 0 for Bass) and is mapped to CC91 reverb.  fx_aux2 behaves like the second
# send and is mapped to CC93 chorus.  The FX *type* numbers (which of the 125
# multi-effects sits on A/B/C/D) are not stored in the Style bank at all --
# they live in Performance/Editor data -- so fx_hint is left empty rather
# than invented.  This is recorded as OPEN, not as measured.
# ---------------------------------------------------------------------------

DRUM_TRACKS = {0: Role.DRUM, 1: Role.PERC}

# Korg RX architecture: articulation/noise keys live outside the musical
# window and are never transposed.  Measured in the factory corpus on pitched
# lanes (Guitar from 0, Organ/Brass/Reed from 1, Piano from 5, Bass from 6).
RX_KEYSWITCH_MAX = 11      # 0..11   C-1..B-1  articulation keyswitches
RX_NOISE_MIN = 96          # 96..127 C7..G9   RX noise / release layer
KEY_PAD = 12               # one octave of safety on the musical window


def pct(sorted_vals, q):
    if not sorted_vals:
        return None
    if len(sorted_vals) == 1:
        return sorted_vals[0]
    i = (len(sorted_vals) - 1) * q
    lo, hi = int(i), min(int(i) + 1, len(sorted_vals) - 1)
    return int(round(sorted_vals[lo] + (sorted_vals[hi] - sorted_vals[lo]) * (i - lo)))


def role_of(track_index: int, ts) -> Role:
    """Instrument role of one Style track.

    Tracks 0/1 are the drum lanes by definition.  Everything else is keyed
    off the real native program number, through the same role_from_pc() the
    Song Optimizer uses -- so Song and Style agree on what a 'bass' is.
    """
    if track_index in DRUM_TRACKS:
        return DRUM_TRACKS[track_index]
    if ts.msb == 120:                      # drum bank on an Acc lane
        return Role.PERC
    if track_index == 2:
        return Role.BASS
    return role_from_pc(ts.program, channel=track_index)


class Acc:
    """Accumulator for one instrument role."""

    __slots__ = ("volume", "pan", "expression", "aux1", "aux2", "octave",
                 "declared_lo", "declared_hi", "played", "vel", "poly",
                 "ntt", "humanize", "tracks", "styles")

    def __init__(self):
        for f in ("volume", "pan", "expression", "aux1", "aux2", "octave",
                  "declared_lo", "declared_hi", "played", "vel", "poly",
                  "ntt", "humanize"):
            setattr(self, f, [])
        self.tracks = 0
        self.styles = set()


def max_simultaneous(events) -> int:
    """Peak simultaneous sounding notes in one parsed Pattern stream."""
    # opcode 1 = Note-On, opcode 0 = Note-Off.  A Note-Off may carry a
    # non-zero RELEASE velocity, so the opcode -- never the velocity byte --
    # decides direction.  (Getting this wrong inflates both polyphony and the
    # velocity histogram; it was caught by a 186-voice guitar reading.)
    opens, peak, cur = defaultdict(int), 0, 0
    for ev in events:
        p = ev.pitch
        if p is None:
            continue
        if ev.opcode == 1 and ev.velocity:
            opens[p] += 1
            cur += 1
            peak = max(peak, cur)
        elif opens.get(p):
            opens[p] -= 1
            cur -= 1
    return peak


def main() -> int:
    ap = argparse.ArgumentParser(description="E1..E6 factory parameter extractor")
    ap.add_argument("style_dir", help="directory holding factory .STY banks")
    ap.add_argument("-o", "--out", default="data/factory_profiles.json")
    ap.add_argument("-m", "--manifest", default="data/CORPUS_MANIFEST.json")
    ap.add_argument("--style-roles", default="data/STYLE_ROLE_PROFILES.json")
    args = ap.parse_args()

    banks = sorted(p for p in Path(args.style_dir).iterdir()
                   if p.suffix.lower() == ".sty")
    if not banks:
        print(f"no .STY banks in {args.style_dir}", file=sys.stderr)
        return 2

    acc: dict[Role, Acc] = defaultdict(Acc)
    lane: dict[str, Acc] = defaultdict(Acc)          # per Drum..Acc5 lane
    manifest = {"banks": [], "totals": {}}
    n_styles = n_elements = n_patterns = n_events = n_tracks = 0
    failures = []

    for bank_path in banks:
        try:
            bank = NativeStyleBank.load(bank_path)
        except (ModelError, Exception) as exc:                 # noqa: BLE001
            failures.append(f"{bank_path.name}: {exc}")
            continue
        b_rec = {"bank": bank_path.name, "styles": []}

        for entry in bank.entries:
            style = entry.style
            comp = entry.companion
            n_styles += 1
            s_rec = {"name": style.name, "elements": len(style.elements)}

            # ---- E1/E3/E5: note material, attributed to a lane -------------
            try:
                role_map = style.pattern_role_map()
            except Exception:                                   # noqa: BLE001
                role_map = {}
            pool = walk_children(style.data, style.pattern_pool.offset)[1:]
            lane_role: dict[int, Role] = {}
            if style.elements:
                td0 = style.elements[0].track_data
                for t in range(8):
                    lane_role[t] = role_of(t, td0.get(t))

            vel_by_lane: dict[int, list[int]] = defaultdict(list)
            pit_by_lane: dict[int, list[int]] = defaultdict(list)
            poly_by_lane: dict[int, list[int]] = defaultdict(list)
            for idx, pattern in enumerate(pool, start=1):
                start = pattern.offset + 8
                duration = _be32(style.data, start)
                length = _be32(style.data, start + 4)
                stream = style.data[start + 8:start + 8 + length]
                try:
                    evs = parse_pattern_stream(stream, duration)
                except Exception:                               # noqa: BLE001
                    continue
                n_patterns += 1
                n_events += len(evs)
                tracks = role_map.get(idx) or set()
                if len(tracks) != 1:
                    continue        # ambiguous ownership -> not used as evidence
                t = next(iter(tracks))
                peak = max_simultaneous(evs)
                if peak:
                    poly_by_lane[t].append(peak)
                for ev in evs:
                    if ev.opcode == 1 and ev.pitch is not None and ev.velocity:
                        vel_by_lane[t].append(ev.velocity)
                        pit_by_lane[t].append(ev.pitch)

            # ---- E2/E4: declared parameters, per element and track ---------
            for el in style.elements:
                n_elements += 1
                for t in range(8):
                    ts = el.track_data.get(t)
                    r = lane_role.get(t, role_of(t, ts))
                    a, l = acc[r], lane[ROLES[t]]
                    n_tracks += 1
                    a.tracks += 1
                    l.tracks += 1
                    a.styles.add(style.name)
                    for tgt in (a, l):
                        tgt.expression.append(ts.expression)
                        tgt.declared_lo.append(ts.key_low)
                        tgt.declared_hi.append(ts.key_high)
                        tgt.ntt.append(ts.ntt_ntr_packed)
                        tgt.humanize.append(ts.humanize)
                    if comp is not None:
                        try:
                            ms = comp.get(t)
                        except Exception:                       # noqa: BLE001
                            continue
                        for tgt in (a, l):
                            tgt.volume.append(ms.volume)
                            tgt.pan.append(ms.pan)
                            tgt.aux1.append(ms.fx_aux1)
                            tgt.aux2.append(ms.fx_aux2)
                            tgt.octave.append(ms.octave)

            for t in range(8):
                r = lane_role.get(t)
                if r is None:
                    continue
                for tgt in (acc[r], lane[ROLES[t]]):
                    tgt.vel.extend(vel_by_lane.get(t, ()))
                    tgt.played.extend(pit_by_lane.get(t, ()))
                    tgt.poly.extend(poly_by_lane.get(t, ()))
            b_rec["styles"].append(s_rec)
        manifest["banks"].append(b_rec)

    def summarise(a: Acc, role_name: str) -> dict:
        vel = sorted(a.vel)
        played = sorted(a.played)
        poly = sorted(a.poly)
        dlo, dhi = sorted(a.declared_lo), sorted(a.declared_hi)
        # E4 revision.  Key range is a SAFETY NET for user material, so it must
        # never be narrower than what the factory itself plays -- a p1/p99 range
        # let unseen factory notes escape it on the holdout (BASS 104, GUITAR
        # 125, CHROM_PERC 96, REED 93).  Use the full observed extent.
        p_lo = pct(played, 0.01)
        p_hi = pct(played, 0.99)
        d_lo = pct(dlo, 0.50)
        d_hi = pct(dhi, 0.50)
        # E4 final.  Two separate concepts, both measured:
        #  * the MUSICAL WINDOW  = p1..p99 of played notes, unioned with the
        #    declared TrackData range, padded by one octave either way.
        #  * the RX PASS-THROUGH ZONES = RX_KEYSWITCH (0..11) and RX_NOISE
        #    (96..127).  Factory pitched lanes genuinely write notes there --
        #    measured as low as 0 on Guitar and 1 on Organ/Brass/Reed -- and
        #    those are articulation keys, not pitches.  They must never be
        #    octave-wrapped.  Treating the whole thing as one range is what
        #    made the first holdout run leak.
        cands_lo = [x for x in (p_lo, d_lo) if x is not None]
        cands_hi = [x for x in (p_hi, d_hi) if x is not None]
        key_lo = max(0, min(cands_lo) - KEY_PAD) if cands_lo else 0
        key_hi = min(127, max(cands_hi) + KEY_PAD) if cands_hi else 127
        is_drum = role_name in ("DRUM", "PERC")
        return {
            "role": role_name,
            "volume": pct(sorted(a.volume), 0.50) if a.volume else 100,
            "expression": pct(sorted(a.expression), 0.50) if a.expression else 127,
            "pan": (pct(sorted(a.pan), 0.50) + 64) if a.pan else 64,
            "reverb_send": pct(sorted(a.aux1), 0.50) if a.aux1 else 30,
            "chorus_send": pct(sorted(a.aux2), 0.50) if a.aux2 else 0,
            "key_low": 0 if is_drum else key_lo,
            "key_high": 127 if is_drum else key_hi,
            "wrap_around": not is_drum,
            "rx_keyswitch_max": RX_KEYSWITCH_MAX,
            "rx_noise_min": RX_NOISE_MIN,
            "allow_noise_zone": role_name in ("BASS", "GUITAR"),
            "octave": pct(sorted(a.octave), 0.50) if a.octave else 0,
            "velocity": {
                "floor": pct(vel, 0.05) if vel else 1,
                "median": pct(vel, 0.50) if vel else 80,
                "ceiling": pct(vel, 0.95) if vel else 127,
                "evidence": "FACTORY_MEASURED" if vel else "PROVISIONAL",
            },
            "max_polyphony": pct(poly, 0.95) if poly else 16,
            "fx_hint": "",
            "evidence": "FACTORY_MEASURED" if (a.volume and vel) else "PARTIAL",
            # The ACCEPTABLE FACTORY BAND.  p10..p90 of what the factory
            # actually does for this role.  The optimizer corrects values that
            # fall OUTSIDE this band and leaves everything inside it alone --
            # pushing every track to the median would erase the factory's own
            # legitimate variety (measured: doing that rewrote 47.7% of
            # factory lanes, which is by definition wrong).
            "band": {
                "volume": [pct(sorted(a.volume), .10), pct(sorted(a.volume), .90)],
                "expression": [pct(sorted(a.expression), .10), pct(sorted(a.expression), .90)],
                "pan": [(pct(sorted(a.pan), .10) or 0) + 64, (pct(sorted(a.pan), .90) or 0) + 64],
                "reverb_send": [pct(sorted(a.aux1), .10), pct(sorted(a.aux1), .90)],
                "chorus_send": [pct(sorted(a.aux2), .10), pct(sorted(a.aux2), .90)],
            },
            "_variance": {
                "volume_p25_p75": [pct(sorted(a.volume), .25), pct(sorted(a.volume), .75)],
                "chorus_p25_p75": [pct(sorted(a.aux2), .25), pct(sorted(a.aux2), .75)],
                "reverb_p25_p75": [pct(sorted(a.aux1), .25), pct(sorted(a.aux1), .75)],
                "velocity_p25_p75": [pct(vel, .25), pct(vel, .75)],
            },
            "_measured": {
                "tracks_seen": a.tracks,
                "styles_seen": len(a.styles),
                "note_ons": len(vel),
                "declared_key_range_median": [d_lo, d_hi],
                "played_key_range_min_max": [p_lo, p_hi],
                "played_key_range_p1_p99": [pct(played, .01), pct(played, .99)],
                "polyphony_p50_p95_max": [pct(poly, .5), pct(poly, .95),
                                          poly[-1] if poly else None],
                "ntt_ntr_packed_values": sorted(set(a.ntt))[:16],
                "humanize_values": sorted(set(a.humanize))[:16],
            },
        }

    profiles = {r.value: summarise(a, r.value) for r, a in acc.items() if a.tracks}
    style_roles = {k: summarise(a, k) for k, a in lane.items() if a.tracks}

    manifest["totals"] = {
        "banks": len(banks), "banks_failed": failures, "styles": n_styles,
        "style_elements": n_elements, "tracks": n_tracks,
        "patterns": n_patterns, "native_events": n_events,
    }

    out = {
        "source": "FACTORY_MEASURED",
        "extractor": "tools/extract_factory.py (E1..E6)",
        "corpus": {"dir": str(args.style_dir), "banks": [b.name for b in banks]},
        "totals": manifest["totals"],
        "fx_note": ("FX send levels measured from mixer aux1/aux2. fx_main is a "
                    "Bank-LSB mirror and is deliberately unused. FX *types* are "
                    "not stored in Style banks -> fx_hint stays empty (OPEN)."),
        "profiles": profiles,
    }
    for path, payload in ((args.out, out), (args.manifest, manifest),
                          (args.style_roles, {"source": "FACTORY_MEASURED",
                                              "lanes": style_roles})):
        p = Path(path)
        p.parent.mkdir(parents=True, exist_ok=True)
        p.write_text(json.dumps(payload, indent=2), encoding="utf-8")

    t = manifest["totals"]
    print(f"banks {t['banks']}  styles {t['styles']}  elements {t['style_elements']}  "
          f"tracks {t['tracks']}  patterns {t['patterns']}  events {t['native_events']}")
    if failures:
        print("FAILED:", *failures, sep="\n  ")
    print(f"roles measured: {len(profiles)} -> {args.out}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
