#!/usr/bin/env python3
"""E7 -- factory-parity holdout test.

The strongest honest test of the F-series model: measure the profiles on one
part of the factory corpus, then confront them with a part the extractor
never saw.  If the model is right, the unseen factory material must already
satisfy it -- a correct model changes (almost) nothing on factory input.

    python tools/parity_test.py TRAIN.json TEST.json

TRAIN.json is the measured profile set.  TEST.json is the *same extractor*
run over the holdout banks; its `_measured` block carries the ground truth
of what the holdout actually contains.
"""
from __future__ import annotations

import json
import sys
from pathlib import Path

TOL_CC = 12          # controller units; Pa800 mixer resolution is coarse
TOL_VEL = 12         # velocity units


def band(label, got, exp, tol):
    if got is None or exp is None:
        return None, f"{label}: n/a"
    d = abs(got - exp)
    return d <= tol, f"{label:<12} model {exp:>4}  holdout {got:>4}  delta {d:>3}  {'OK' if d <= tol else 'MISS'}"


def main() -> int:
    if len(sys.argv) < 3:
        print(__doc__)
        return 2
    train = json.loads(Path(sys.argv[1]).read_text())["profiles"]
    test = json.loads(Path(sys.argv[2]).read_text())["profiles"]

    rows, passes, total = [], 0, 0
    range_notes_total = range_notes_out = 0

    for role in sorted(set(train) & set(test)):
        tr, te = train[role], test[role]
        mt = te["_measured"]
        if mt["note_ons"] < 500:
            continue
        rows.append(f"\n--- {role}  ({mt['note_ons']:,} unseen note-ons, "
                    f"{mt['styles_seen']} unseen styles) ---")
        checks = [
            band("Volume CC7", te["volume"], tr["volume"], TOL_CC),
            band("Expr CC11", te["expression"], tr["expression"], TOL_CC),
            band("Pan CC10", te["pan"], tr["pan"], TOL_CC),
            band("Reverb CC91", te["reverb_send"], tr["reverb_send"], TOL_CC),
            band("Chorus CC93", te["chorus_send"], tr["chorus_send"], TOL_CC),
            band("Vel floor", te["velocity"]["floor"], tr["velocity"]["floor"], TOL_VEL),
            band("Vel median", te["velocity"]["median"], tr["velocity"]["median"], TOL_VEL),
            band("Vel ceiling", te["velocity"]["ceiling"], tr["velocity"]["ceiling"], TOL_VEL),
        ]
        for ok, line in checks:
            if ok is None:
                continue
            total += 1
            passes += bool(ok)
            rows.append("  " + line)

        # Key range is the rule that actually rewrites notes (K-01), so it is
        # tested as a containment question, not a tolerance question: does the
        # model's range already cover what unseen factory material plays?
        p_lo, p_hi = mt["played_key_range_min_max"]
        if p_lo is not None and role not in ("DRUM", "PERC"):
            ks = tr.get("rx_keyswitch_max", 11)
            nz = tr.get("rx_noise_min", 96)
            covered = ((tr["key_low"] <= p_lo or p_lo <= ks) and
                       (p_hi <= tr["key_high"] or p_hi >= nz))
            total += 1
            passes += bool(covered)
            rows.append(f"  {'Key range':<12} model {tr['key_low']:>3}-{tr['key_high']:<3}"
                        f"  holdout plays {p_lo:>3}-{p_hi:<3} (RX zones <={ks}, >={nz})  "
                        f"{'CONTAINED' if covered else 'ESCAPES'}")
            range_notes_total += 1
            range_notes_out += 0 if covered else 1

    print("=" * 72)
    print("E7  FACTORY-PARITY HOLDOUT TEST")
    print("=" * 72)
    print(*rows, sep="\n")
    print("\n" + "=" * 72)
    print(f"RESULT  {passes}/{total} checks pass "
          f"({100.0*passes/total:.1f}%)   key ranges escaping: "
          f"{range_notes_out}/{range_notes_total}")
    print("=" * 72)
    return 0 if passes == total else 1


if __name__ == "__main__":
    raise SystemExit(main())
