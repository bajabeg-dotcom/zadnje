#!/usr/bin/env python3
"""Regression test for the Pa3X (v5) -> Pa800 (v4) downgrade.

The user's `INIT_STY_OUT.zip` contains the same Init styles rendered into
every Korg PA family, which gives 97 matched pairs of identical musical
content in both v5 and v4 form.  Converting the v5 side must reproduce the
v4 side, with one documented exception:

* ElementInfo byte 27 is per-element CONTENT (V-1.8).  The INIT pa800
  renderer normalised Variation elements to 2 there, while the user's
  hardware export and all genuine Pa800 styles carry 3.  We preserve the
  source value, so converted output differs from the INIT reference at
  byte 27 and nowhere else.

Expected: 93 of 97 "byte-27-only" different, 4 known-different (styles
where the reference converter left 15 Style Elements and dead PatternInfo
associations inside a v4 file; this implementation normalises to the 13
the Pa800 actually addresses and trims the association list correctly).

    python tools/test_v5to4.py
"""
from __future__ import annotations

import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))

from pa800_remap.native import NativeStyleBank          # noqa: E402
from pa800_remap.native.codec import walk_children       # noqa: E402
from pa800_remap.v5to4 import convert_style, ConvertReport  # noqa: E402

FIXTURE = Path("/home/user/corpus/init/INIT_STY_OUT")
BANKS = ("InitPx01", "InitPx02", "InitPx03", "initPx04",
         "Initpa01", "INITPA02", "INITPA03")
EXPECT_B27_ONLY = 93
KNOWN_DIFFERENT = {"Discofox Platin", "8Beat Rock", "Liquid Rock", "Basic Rock"}


def diff_only_at_ei_byte27(a: bytes, b: bytes) -> bool:
    """True when a != b and every differing byte is ElementInfo byte 27."""
    if a == b or len(a) != len(b):
        return False
    na, nb = walk_children(a), walk_children(b)
    if [n.ident for n in na] != [n.ident for n in nb]:
        return False
    allowed: set[int] = set()
    for x, y in zip((n for n in na if n.ident == 3),
                    (n for n in nb if n.ident == 3)):
        ka, kb = walk_children(a, x.offset), walk_children(b, y.offset)
        ei_a = a[ka[0].offset + 8:ka[0].end]
        ei_b = b[kb[0].offset + 8:kb[0].end]
        if len(ei_a) != len(ei_b):
            return False
        for j in range(len(ei_a)):
            if ei_a[j] != ei_b[j]:
                if j != 27:
                    return False
                allowed.add(ka[0].offset + 8 + j)
    return all(i in allowed for i, (x, y) in enumerate(zip(a, b)) if x != y)


def main() -> int:
    if not FIXTURE.is_dir():
        print(f"SKIP: fixture not present at {FIXTURE}")
        return 0

    rep = ConvertReport()
    exact = b27_only = 0
    unexpected: list[str] = []
    total = 0

    for name in BANKS:
        v5 = FIXTURE / "pa3x" / f"{name}.STY"
        v4 = FIXTURE / "pa800" / f"{name}.STY"
        if not (v5.exists() and v4.exists()):
            continue
        a = NativeStyleBank.load(v5)
        b = {e.style.name: e.style.data for e in NativeStyleBank.load(v4).entries}
        for entry in a.entries:
            ref = b.get(entry.style.name)
            if ref is None:
                continue
            total += 1
            out = convert_style(entry.style.data, rep)
            if out == ref:
                exact += 1
            elif diff_only_at_ei_byte27(out, ref):
                b27_only += 1
            elif entry.style.name not in KNOWN_DIFFERENT:
                unexpected.append(entry.style.name)

    print(f"matched pairs          : {total}")
    print(f"byte-for-byte exact    : {exact}")
    print(f"differs only at EI b27 : {b27_only}  (expected {EXPECT_B27_ONLY})")
    print(f"known-different        : {total - exact - b27_only}")
    if unexpected:
        print("UNEXPECTED differences:")
        for s in unexpected[:10]:
            print(f"  - {s}")
    known = total - exact - b27_only
    ok = (b27_only == EXPECT_B27_ONLY and not unexpected and known == len(KNOWN_DIFFERENT))
    print("RESULT:", "PASS" if ok else "FAIL")
    return 0 if ok else 1


if __name__ == "__main__":
    raise SystemExit(main())
