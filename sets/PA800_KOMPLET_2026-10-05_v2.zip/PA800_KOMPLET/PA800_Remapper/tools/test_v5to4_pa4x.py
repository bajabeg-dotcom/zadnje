#!/usr/bin/env python3
"""Regression test for the Pa4X / PA700 / PA1000 (v5, 44/96) -> Pa800 (v4) path.

`INIT_STY_OUT.zip` renders the same 7 Init banks into every Korg PA family.
The `pa4x` family carries ElementInfo 44 + TrackData 96 -- the geometry the
PA700 and PA1000 use as well -- while `pa3x` (28/88) and `pa800` (28/80) give
the controlled before/after pair.  Because the pa4x render is byte-identical
to the pa3x render everywhere except the ElementInfo tail, the TrackData u4
column and the two child-header release bytes (annex V-1.7), converting the
pa4x side must reproduce exactly what converting the pa3x side produces, and
must reproduce the pa800 reference output modulo the documented byte-27
content rule (annex V-1.8).

    python tools/test_v5to4_pa4x.py
"""
from __future__ import annotations

import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))

from pa800_remap.native import NativeStyleBank          # noqa: E402
from pa800_remap.v5to4 import convert_style, ConvertReport  # noqa: E402
from test_v5to4 import diff_only_at_ei_byte27           # noqa: E402

sys.path.insert(0, str(ROOT / "tools"))

FIXTURE = Path("/home/user/corpus/init/INIT_STY_OUT")
BANKS = ("InitPx01", "InitPx02", "InitPx03", "initPx04",
         "Initpa01", "INITPA02", "INITPA03")
EXPECT_B27_ONLY = 93
KNOWN_DIFFERENT = {"Discofox Platin", "8Beat Rock", "Liquid Rock", "Basic Rock"}


def load(family: str, bank: str) -> dict:
    path = FIXTURE / family / f"{bank}.STY"
    if not path.exists():
        return {}
    return {e.style.name: e.style for e in NativeStyleBank.load(path).entries}


def main() -> int:
    if not FIXTURE.is_dir():
        print(f"SKIP: fixture not present at {FIXTURE}")
        return 0

    rep = ConvertReport()
    exact = b27_only = total = 0
    unexpected: list[str] = []
    pa4x_vs_pa3x_diff: list[str] = []

    for name in BANKS:
        pa4x, pa3x, pa800 = load("pa4x", name), load("pa3x", name), load("pa800", name)
        if not pa4x:
            continue
        for style_name, src in pa4x.items():
            if style_name not in pa800:
                continue
            total += 1
            converted = convert_style(src.data, rep)
            if converted is None:
                unexpected.append(f"{style_name}: refused (not v5?)")
                continue
            ref = pa800[style_name].data
            if converted == ref:
                exact += 1
            elif diff_only_at_ei_byte27(converted, ref):
                b27_only += 1
            elif style_name not in KNOWN_DIFFERENT:
                unexpected.append(style_name)
            # cross-check: converting the pa4x render must equal converting
            # the pa3x render of the same style, byte for byte.
            if style_name in pa3x:
                twin = convert_style(pa3x[style_name].data, ConvertReport())
                if twin is not None and twin != converted:
                    pa4x_vs_pa3x_diff.append(style_name)

    print(f"matched pairs pa4x->pa800  : {total}")
    print(f"byte-for-byte exact        : {exact}")
    print(f"differs only at EI b27     : {b27_only}  (expected {EXPECT_B27_ONLY})")
    print(f"known-different            : {total - exact - b27_only}")
    print(f"pa4x-convert == pa3x-convert: {total - len(pa4x_vs_pa3x_diff)}/{total}")
    print(f"ElementInfo tails dropped  : {rep.ei_tails_dropped}")
    print(f"u4 columns with data       : {rep.u4_nonzero}")
    print(f"nonzero v5 tails dropped   : {rep.nonzero_tail}")
    if unexpected:
        print("UNEXPECTED differences:")
        for s in unexpected[:10]:
            print(f"  - {s}")
    if pa4x_vs_pa3x_diff:
        print("pa4x/pa3x conversion mismatch:")
        for s in pa4x_vs_pa3x_diff[:10]:
            print(f"  - {s}")

    ok = (b27_only == EXPECT_B27_ONLY and not unexpected
          and not pa4x_vs_pa3x_diff and rep.ei_tails_dropped > 0)
    print("RESULT:", "PASS" if ok else "FAIL")
    return 0 if ok else 1


if __name__ == "__main__":
    raise SystemExit(main())
