#!/usr/bin/env python3
"""S-09 differential verification: BEFORE vs AFTER native Style bank.

The Style Optimizer is allowed to change velocities and declared track
parameters.  It is NOT allowed to change what is played or when: note count,
pitch and tick must be identical, and so must the Style / Element / Pattern
structure and the Chord-Variation references.
"""
import sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from pa800_remap.native import NativeStyleBank, ROLES
from pa800_remap.native.codec import walk_children, _be32
from pa800_remap.native.events import parse_pattern_stream


def fingerprint(path):
    bank = NativeStyleBank.load(path)
    notes, vels, struct = [], [], []
    for e in bank.entries:
        s = e.style
        struct.append((s.name, tuple(x.name for x in s.elements)))
        try:
            struct.append(tuple(sorted((k, tuple(sorted(v)))
                                       for k, v in s.pattern_role_map().items())))
        except Exception:
            struct.append(("rolemap-unavailable",))
        for p in walk_children(s.data, s.pattern_pool.offset)[1:]:
            st = p.offset + 8
            dur = _be32(s.data, st); ln = _be32(s.data, st + 4)
            for ev in parse_pattern_stream(s.data[st+8:st+8+ln], dur):
                if ev.opcode in (0, 1) and ev.pitch is not None:
                    notes.append((ev.tick, ev.opcode, ev.pitch))
                    if ev.opcode == 1:
                        vels.append(ev.velocity)
    return notes, vels, struct


a, b = sys.argv[1], sys.argv[2]
na, va, sa = fingerprint(a)
nb, vb, sb = fingerprint(b)
print(f"{'':<34}{'PRIJE':>12}{'POSLIJE':>12}")
print(f"{'note (tick, on/off, visina)':<34}{len(na):>12,}{len(nb):>12,}")
print(f"{'note-on velocity vrijednosti':<34}{len(va):>12,}{len(vb):>12,}")
print(f"{'strukturnih zapisa':<34}{len(sa):>12,}{len(sb):>12,}")
print()
ok_notes = na == nb
ok_struct = sa == sb
moved = sum(1 for x, y in zip(na, nb) if x != y) if len(na) == len(nb) else -1
changed_vel = sum(1 for x, y in zip(va, vb) if x != y) if len(va) == len(vb) else -1
print(f"S-09a  note identicne (tick+visina+on/off) : {'DA' if ok_notes else 'NE'}  (pomjereno {moved})")
print(f"S-09b  struktura identicna (elementi, CV)  : {'DA' if ok_struct else 'NE'}")
print(f"S-04   velocity promijenjen                : {changed_vel:,} nota "
      f"({100*changed_vel/max(1,len(va)):.1f}%)")
sys.exit(0 if (ok_notes and ok_struct) else 1)
