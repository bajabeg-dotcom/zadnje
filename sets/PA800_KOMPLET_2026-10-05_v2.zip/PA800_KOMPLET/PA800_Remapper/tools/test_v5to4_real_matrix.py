#!/usr/bin/env python3
"""Validation of the v5 -> v4 conversion on REAL Style Works material.

`corpus/matrix` holds real Balkan folk styles rendered by Style Works into
several target families (from the user's Drive, originally `4.zip`):

    Pa4x--Pa4X.sty    EI mixed 44/28, TD 88   (real Pa4X-target file)
    Pa4x--Pa700.sty   EI 44,         TD 96    (real PA700-target file)
    evidence/fixture_fullout/Pa4x--PA800.sty  (reference PA800 output)

Checks (annexes V-1.7 / V-1.8):
 1. converting the Pa4X render == converting the PA700 render, 18/18
 2. our output is internally consistent (pattern_role_map passes)
 3. the reference PA800 output itself carries dead PatternInfo
    associations on this material (documented Style Works behaviour)
 4. our element count stays <= 13 (genuine Pa800 invariant, S-13)
 5. ElementInfo bytes (incl. preserved byte 27) match the reference
    wherever the reference kept the same element count

    python tools/test_v5to4_real_matrix.py
"""
from __future__ import annotations

import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))

from pa800_remap.native import NativeStyleBank          # noqa: E402
from pa800_remap.native.codec import walk_children       # noqa: E402
from pa800_remap.v5to4 import convert_style, ConvertReport, PA800_MAX_ELEMENTS  # noqa: E402

MATRIX = Path("/home/user/corpus/matrix")
SRC_4X = MATRIX / "Pa4x--Pa4X.sty"
SRC_700 = MATRIX / "Pa4x--Pa700.sty"
REF = ROOT.parent / "evidence" / "fixture_fullout" / "Pa4x--PA800.sty"
EXPECT_STYLES = 18


def profile(data: bytes) -> tuple[int, int, int]:
    """(element count, association slots, associations consumed)."""
    nodes = walk_children(data)
    els = [n for n in nodes if n.ident == 3]
    pd = [n for n in nodes if n.ident == 2][0]
    kids = walk_children(data, pd.offset)
    info = data[kids[0].offset + 8:kids[0].end]
    assoc = int.from_bytes(info[2:4], "big")
    consumed = 0
    for el in els:
        for cv in walk_children(data, el.offset)[2:]:
            s = cv.offset + 8
            sl = int.from_bytes(data[s + 4:s + 8], "big")
            consumed += data[s + 8 + sl]
    return len(els), assoc, consumed


def main() -> int:
    if not (SRC_4X.exists() and SRC_700.exists() and REF.exists()):
        print(f"SKIP: matrix files not present under {MATRIX}")
        return 0

    src4x = {e.style.name: e.style for e in NativeStyleBank.load(SRC_4X).entries}
    src700 = {e.style.name: e.style for e in NativeStyleBank.load(SRC_700).entries}
    ref = {e.style.name: e.style for e in NativeStyleBank.load(REF).entries}
    common = sorted(set(src4x) & set(src700) & set(ref))

    out4x = {n: convert_style(src4x[n].data, ConvertReport()) for n in common}
    out700 = {n: convert_style(src700[n].data, ConvertReport()) for n in common}

    ok = True

    # 1) both new-gen geometries convert to identical bytes
    twin = sum(1 for n in common if out4x[n] == out700[n])
    print(f"1) Pa4X-render convert == PA700-render convert: {twin}/{len(common)}"
          f"  (expected {EXPECT_STYLES})")
    ok &= twin == EXPECT_STYLES and len(common) == EXPECT_STYLES

    # 2) internal consistency + 4) element limit
    consistent = limited = 0
    for n in common:
        els, assoc, consumed = profile(out4x[n])
        if assoc == consumed:
            consistent += 1
        if els <= PA800_MAX_ELEMENTS:
            limited += 1
    print(f"2) output internally consistent (assoc == consumed): {consistent}/{len(common)}")
    print(f"4) output element count <= {PA800_MAX_ELEMENTS}:            {limited}/{len(common)}")
    ok &= consistent == len(common) and limited == len(common)

    # 3) the reference PA800 output carries dead associations on real material
    ref_dead = sum(1 for n in common
                   if (lambda p: p[1] != p[2])(profile(ref[n].data)))
    print(f"3) reference PA800 files with dead associations:    {ref_dead}/{len(common)}"
          f"  (documented Style Works behaviour)")

    # 5) ElementInfo bytes match the reference on styles with equal element count
    ei_same = ei_checked = 0
    for n in common:
        ours, theirs = out4x[n], ref[n].data
        eo, _, _ = profile(ours)
        er, _, _ = profile(theirs)
        if eo != er:
            continue
        ei_checked += 1
        no, nt = walk_children(ours), walk_children(theirs)
        eo_nodes = [x for x in no if x.ident == 3]
        er_nodes = [x for x in nt if x.ident == 3]
        match = True
        for x, y in zip(eo_nodes, er_nodes):
            ko, kt = walk_children(ours, x.offset), walk_children(theirs, y.offset)
            if ours[ko[0].offset + 8:ko[0].end] != theirs[kt[0].offset + 8:kt[0].end]:
                match = False
                break
        ei_same += 1 if match else 0
    print(f"5) ElementInfo bajt-identican s referencom:         {ei_same}/{ei_checked}"
          f"  (stilovi s istim brojem elemenata)")

    print("RESULT:", "PASS" if ok else "FAIL")
    return 0 if ok else 1


if __name__ == "__main__":
    raise SystemExit(main())
