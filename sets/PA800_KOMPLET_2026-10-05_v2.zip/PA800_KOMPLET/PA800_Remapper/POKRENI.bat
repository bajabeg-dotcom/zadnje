@echo off
chcp 65001 >nul
title Pa800 Doktor za stilove
cd /d "%~dp0"

rem  Nista se ne instalira. Treba samo Python 3 sa ukljucenim tkinter-om.

set "PY="
where pythonw >nul 2>&1 && set "PY=pythonw"
if not defined PY where py >nul 2>&1 && set "PY=py -3"
if not defined PY where python >nul 2>&1 && set "PY=python"

if not defined PY (
    echo.
    echo   Python nije pronadjen na ovom racunaru.
    echo.
    echo   1. Idi na https://www.python.org/downloads/
    echo   2. Skini Python 3 i instaliraj ga
    echo   3. VAZNO: cekiraj "Add Python to PATH" na prvom ekranu
    echo   4. Onda ponovo klikni POKRENI.bat
    echo.
    pause
    exit /b 1
)

start "" %PY% -m pa800_remap.app
exit /b 0
