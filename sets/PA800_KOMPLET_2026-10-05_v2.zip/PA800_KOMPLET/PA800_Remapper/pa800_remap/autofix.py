"""K-series — logical self-healing rules.

These repair the MIDI *by themselves*, before any sound decision is taken.
Every fix is deterministic, counted and attributed to a rule id; nothing is
removed silently.

    K-01  Key Range clamp / wrap-around into the track's factory key window
    K-02  RX noise zone (C7..G9) protection
    K-03  Stuck notes (missing Note-Off) closed at track end
    K-04  Zero / negative length notes extended to a minimum gate
    K-05  Duplicate Note-On on a sounding pitch -> legal retrigger
    K-06  Orphan Note-Off removed
    K-07  Note-On velocity 0 normalised to Note-Off
    K-08  Velocity re-seated into the factory envelope (monotone)
    K-09  Missing CC7 / CC10 / CC11 / CC91 / CC93 inserted from factory profile
    K-10  CC11 expression floor (silent track guard)
    K-11  Pitch bend returned to centre at end
    K-12  Damper (CC64) released at end
    K-13  GS / XG / GM-reset SysEx stripped (confuses the Pa800 bank select)
    K-14  Melodic content detected on channel 10 (reported, never auto-moved)
    K-15  Per-track polyphony above the factory ceiling (reported)
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Dict, List, Optional, Tuple

import mido

from .trackparams import (CC_CHORUS_SEND, CC_DAMPER, CC_EXPRESSION, CC_PAN,
                          CC_REVERB_SEND, CC_VOLUME, Role, TrackProfile,
                          clamp_to_drum_layer)

NOISE_LO, NOISE_HI = 96, 127   # C7 .. G9 (RX OSC5 zone)


@dataclass
class Fix:
    rule: str
    title: str
    count: int = 0
    details: List[str] = field(default_factory=list)

    def add(self, detail: str = "") -> None:
        self.count += 1
        if detail and len(self.details) < 12:
            self.details.append(detail)


@dataclass
class AutofixReport:
    fixes: Dict[str, Fix] = field(default_factory=dict)
    profile_source: str = ""

    def f(self, rule: str, title: str) -> Fix:
        if rule not in self.fixes:
            self.fixes[rule] = Fix(rule, title)
        return self.fixes[rule]

    @property
    def total(self) -> int:
        return sum(x.count for x in self.fixes.values())

    def text(self) -> str:
        if not self.fixes:
            return "AUTO-FIX: nema nalaza."
        out = ["AUTO-FIX (K-serija)", "-" * 72]
        for r in sorted(self.fixes):
            fx = self.fixes[r]
            if fx.count == 0:
                continue
            out.append(f"  {fx.rule:<7} {fx.title:<46} {fx.count:>5}")
            for d in fx.details[:4]:
                out.append(f"          · {d}")
        out.append(f"  {'ukupno':<54} {self.total:>5}")
        return "\n".join(out)

    def to_dict(self) -> dict:
        return {"profile_source": self.profile_source,
                "fixes": [{"rule": f.rule, "title": f.title, "count": f.count,
                           "details": f.details}
                          for f in self.fixes.values() if f.count]}


# ---------------------------------------------------------------------------
def _abs_events(track: mido.MidiTrack) -> List[Tuple[int, mido.Message]]:
    t = 0
    out = []
    for msg in track:
        t += msg.time
        out.append((t, msg))
    return out


def _rebuild(track: mido.MidiTrack, events: List[Tuple[int, mido.Message]]) -> None:
    events.sort(key=lambda e: (e[0], 0 if e[1].type == "note_off" else 1))
    track.clear()
    prev = 0
    for t, msg in events:
        track.append(msg.copy(time=max(0, t - prev)))
        prev = t


def _wrap_into(note: int, lo: int, hi: int, wrap: bool) -> Optional[int]:
    if lo <= note <= hi:
        return note
    if not wrap:
        return max(lo, min(hi, note))
    n = note
    guard = 0
    while n < lo and guard < 12:
        n += 12
        guard += 1
    while n > hi and guard < 24:
        n -= 12
        guard += 1
    return n if lo <= n <= hi else None


# ---------------------------------------------------------------------------
def autofix(
    mid: mido.MidiFile,
    profiles: Dict[int, TrackProfile],
    rx_targets: Optional[Dict[int, bool]] = None,
    write_factory_params: bool = True,
    apply_velocity_envelope: bool = True,
    apply_key_range: bool = True,
    report: Optional[AutofixReport] = None,
) -> AutofixReport:
    """Repair `mid` in place.  `profiles` maps MIDI channel -> TrackProfile."""
    rep = report or AutofixReport()
    rx_targets = rx_targets or {}
    ppq = mid.ticks_per_beat or 480
    min_gate = max(1, ppq // 16)

    k01 = rep.f("K-01", "Key Range: note vracene u opseg")
    k01b = rep.f("K-01b", "Key Range: note van opsega i poslije wrap-a")
    k02 = rep.f("K-02", "RX noise zona C7..G9 zasticena / oznacena")
    k16 = rep.f("K-16", "RX keyswitch zona 0..11 zasticena od transpozicije")
    k03 = rep.f("K-03", "Zaglavljene note zatvorene")
    k04 = rep.f("K-04", "Note nulte duzine produzene")
    k05 = rep.f("K-05", "Dupli Note-On -> legalan retrigger")
    k06 = rep.f("K-06", "Siroce Note-Off uklonjene")
    k07 = rep.f("K-07", "Note-On vel=0 normalizovan u Note-Off")
    k08 = rep.f("K-08", "Velocity useljen u Factory envelopu")
    k09 = rep.f("K-09", "Nedostajuci CC7/10/11/91/93 upisani")
    k10 = rep.f("K-10", "CC11 ekspresija podignuta sa nule")
    k11 = rep.f("K-11", "Pitch bend vracen u centar")
    k12 = rep.f("K-12", "Damper CC64 otpusten na kraju")
    k13 = rep.f("K-13", "GS/XG/GM-reset SysEx uklonjen")
    k14 = rep.f("K-14", "Melodijski sadrzaj na kanalu 10 (samo prijava)")
    k15 = rep.f("K-15", "Polifonija iznad Factory stropa (samo prijava)")

    # --- velocity statistics per channel (needed for K-08) -----------------
    vel_stats: Dict[int, List[int]] = {}
    for track in mid.tracks:
        for msg in track:
            if msg.type == "note_on" and msg.velocity > 0:
                vel_stats.setdefault(msg.channel, []).append(msg.velocity)
    vel_window: Dict[int, Tuple[int, int, int]] = {}
    for ch, vals in vel_stats.items():
        vals.sort()
        n = len(vals)
        vel_window[ch] = (vals[0], vals[n // 2], vals[-1])

    for ti, track in enumerate(mid.tracks):
        events = _abs_events(track)
        out: List[Tuple[int, mido.Message]] = []
        sounding: Dict[Tuple[int, int], int] = {}      # (ch,note) -> tick
        poly: Dict[int, int] = {}
        poly_peak: Dict[int, int] = {}
        last_bend: Dict[int, int] = {}
        damper: Dict[int, int] = {}
        seen_cc: Dict[int, set] = {}
        channels_here: set = set()
        last_tick = 0

        for tick, msg in events:
            last_tick = max(last_tick, tick)

            # --- K-13 SysEx ------------------------------------------------
            if msg.type == "sysex":
                k13.add(f"track {ti}")
                continue

            ch = getattr(msg, "channel", None)
            if ch is None:
                out.append((tick, msg))
                continue
            channels_here.add(ch)
            prof = profiles.get(ch)

            # --- K-07 vel 0 -> note_off -----------------------------------
            if msg.type == "note_on" and msg.velocity == 0:
                msg = mido.Message("note_off", channel=ch, note=msg.note, velocity=0, time=0)
                k07.add()

            if msg.type == "note_on":
                note = msg.note
                is_drum = prof is not None and prof.role in (Role.DRUM, Role.PERC)

                # --- K-16 RX keyswitch zone (0..11) ------------------------
                # Measured: factory pitched lanes write notes as low as 0
                # (Guitar) / 1 (Organ, Brass, Reed) / 5 (Piano) / 6 (Bass).
                # These are articulation keyswitches, not pitches, and must
                # never be octave-wrapped.
                ks_max = prof.rx_keyswitch_max if prof is not None else 11
                if note <= ks_max and not is_drum:
                    k16.add(f"ch{ch+1} nota {note} RX keyswitch - zasticena")
                    out.append((tick, msg))
                    sounding[(ch, note)] = tick
                    poly[ch] = poly.get(ch, 0) + 1
                    poly_peak[ch] = max(poly_peak.get(ch, 0), poly[ch])
                    continue

                # --- K-02 noise zone ---------------------------------------
                nz_lo = prof.rx_noise_min if prof is not None else NOISE_LO
                if nz_lo <= note <= NOISE_HI and not is_drum:
                    allowed = rx_targets.get(ch, False) or (prof.allow_noise_zone if prof else False)
                    if not allowed:
                        k02.add(f"ch{ch+1} nota {note} (nije RX cilj) -> ostavljena, oznacena")
                    else:
                        k02.add(f"ch{ch+1} nota {note} RX noise - zasticena od transpozicije")
                    out.append((tick, msg))
                    sounding[(ch, note)] = tick
                    poly[ch] = poly.get(ch, 0) + 1
                    poly_peak[ch] = max(poly_peak.get(ch, 0), poly[ch])
                    continue

                # --- K-01 key range ----------------------------------------
                if apply_key_range and prof is not None and not is_drum:
                    new = _wrap_into(note, prof.key_low, prof.key_high, prof.wrap_around)
                    if new is None:
                        k01b.add(f"ch{ch+1} nota {note} izvan {prof.key_low}..{prof.key_high}")
                        new = max(prof.key_low, min(prof.key_high, note))
                    if new != note:
                        k01.add(f"ch{ch+1} {note} -> {new} ({prof.role.value} "
                                f"{prof.key_low}..{prof.key_high})")
                        msg = msg.copy(note=new)
                        note = new

                # --- K-08 velocity envelope --------------------------------
                if apply_velocity_envelope and prof is not None and ch in vel_window:
                    lo, med, hi = vel_window[ch]
                    nv = prof.velocity.map_value(msg.velocity, lo, med, hi)
                    # K-08b: on drum channels a velocity switch selects a
                    # different SAMPLE, not a louder one.  Keep the remapped
                    # value inside the layer the original hit selected.
                    if is_drum:
                        nv = clamp_to_drum_layer(msg.note, msg.velocity, nv)
                    if nv != msg.velocity:
                        k08.add()
                        msg = msg.copy(velocity=nv)

                # --- K-05 duplicate note-on --------------------------------
                if (ch, note) in sounding:
                    out.append((tick, mido.Message("note_off", channel=ch, note=note,
                                                   velocity=0, time=0)))
                    k05.add(f"ch{ch+1} nota {note}")
                    poly[ch] = max(0, poly.get(ch, 1) - 1)

                sounding[(ch, note)] = tick
                poly[ch] = poly.get(ch, 0) + 1
                poly_peak[ch] = max(poly_peak.get(ch, 0), poly[ch])
                out.append((tick, msg))
                continue

            if msg.type == "note_off":
                note = msg.note
                # key range must follow the note-on transformation
                if apply_key_range and prof is not None and prof.role not in (Role.DRUM, Role.PERC):
                    if not (NOISE_LO <= note <= NOISE_HI):
                        new = _wrap_into(note, prof.key_low, prof.key_high, prof.wrap_around)
                        if new is not None and new != note and (ch, new) in sounding:
                            msg = msg.copy(note=new)
                            note = new
                if (ch, note) not in sounding:
                    k06.add(f"ch{ch+1} nota {note}")
                    continue
                start = sounding.pop((ch, note))
                poly[ch] = max(0, poly.get(ch, 1) - 1)
                if tick - start < min_gate:          # --- K-04
                    tick = start + min_gate
                    k04.add(f"ch{ch+1} nota {note}")
                out.append((tick, msg))
                continue

            if msg.type == "control_change":
                seen_cc.setdefault(ch, set()).add(msg.control)
                if msg.control == CC_DAMPER:
                    damper[ch] = msg.value
                if msg.control == CC_EXPRESSION and msg.value == 0:
                    msg = msg.copy(value=1)          # --- K-10
                    k10.add(f"ch{ch+1}")
                out.append((tick, msg))
                continue

            if msg.type == "pitchwheel":
                last_bend[ch] = msg.pitch
                out.append((tick, msg))
                continue

            out.append((tick, msg))

        # --- K-03 stuck notes ---------------------------------------------
        for (ch, note), start in list(sounding.items()):
            end = max(last_tick, start + min_gate)
            out.append((end, mido.Message("note_off", channel=ch, note=note, velocity=0, time=0)))
            k03.add(f"ch{ch+1} nota {note}")
            last_tick = max(last_tick, end)

        # --- K-11 / K-12 tail cleanup --------------------------------------
        for ch, pitch in last_bend.items():
            if pitch != 0:
                out.append((last_tick, mido.Message("pitchwheel", channel=ch, pitch=0, time=0)))
                k11.add(f"ch{ch+1}")
        for ch, val in damper.items():
            if val >= 64:
                out.append((last_tick, mido.Message("control_change", channel=ch,
                                                    control=CC_DAMPER, value=0, time=0)))
                k12.add(f"ch{ch+1}")

        # --- K-09 factory parameter block (F-02..F-05) ---------------------
        if write_factory_params:
            header: List[Tuple[int, mido.Message]] = []
            for ch in sorted(channels_here):
                prof = profiles.get(ch)
                if prof is None:
                    continue
                have = seen_cc.get(ch, set())
                wanted = [
                    (CC_VOLUME, prof.volume),
                    (CC_PAN, prof.pan),
                    (CC_EXPRESSION, prof.expression),
                    (CC_REVERB_SEND, prof.reverb_send),
                    (CC_CHORUS_SEND, prof.chorus_send),
                ]
                for cc, val in wanted:
                    if cc in have:
                        continue
                    header.append((0, mido.Message("control_change", channel=ch,
                                                   control=cc, value=val, time=0)))
                    k09.add(f"ch{ch+1} CC{cc}={val} ({prof.role.value})")
            out = header + out

        # --- K-14 / K-15 reporting ----------------------------------------
        for ch, peak in poly_peak.items():
            prof = profiles.get(ch)
            if prof and peak > prof.max_polyphony:
                k15.add(f"ch{ch+1} peak {peak} > strop {prof.max_polyphony} ({prof.role.value})")
        if 9 in channels_here:
            melodic = sum(1 for t, m in out
                          if getattr(m, "channel", None) == 9 and m.type == "note_on"
                          and m.velocity > 0 and (m.note < 27 or m.note > 87))
            if melodic:
                k14.add(f"{melodic} nota izvan drum opsega na kanalu 10")

        _rebuild(track, out)

    return rep
