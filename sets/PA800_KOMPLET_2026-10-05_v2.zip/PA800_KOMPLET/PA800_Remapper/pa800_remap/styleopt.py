"""S-series -- STYLE OPTIMIZER for the Korg Pa800.

The Song Optimizer (F + K series) makes a MIDI song behave like the factory.
This module applies the *same* factory logic to a native Style bank, in the
Style's own object model: 8 lanes (Drum, Percussion, Bass, Acc1..Acc5),
up to 13 Style Elements (Variation 1-4, Intro 1-3, Fill 1-3, Break,
Ending 1-3) and their Chord-Variation Pattern references.

Shared with the Song Optimizer
------------------------------
* the same Role taxonomy and the same role_from_pc() detection,
* the same FACTORY_MEASURED profile set (data/factory_profiles.json),
* the same VelocityEnvelope.map_value() monotone re-seating,
* the same RX zone model (keyswitch 0..11, noise 96..127 never transposed).

Style-only rules
----------------
S-01  role detection per lane; Drum/Percussion are fixed by definition
S-02  mixer parity   -- Volume, Pan, FX send 1/2 toward the factory median
S-03  expression parity (TrackData Expression byte)
S-04  velocity parity -- re-seat into the measured factory envelope
S-05  key-range sanity, inside the measured role window
S-06  NTT / NTR  -- read, reported, NEVER written (values 2/4 stay open)
S-07  Humanize    -- measured non-zero on Guitar lanes only
S-08  polyphony budget per Style Element against the 120-voice ceiling
S-09  integrity    -- Drum/Percussion pitches are never transposed, Pattern
      and Chord-Variation references are never rewritten, and the bank is
      re-opened and fully re-parsed before it is accepted

Nothing is written unless `apply=True`.  Default is a dry run.
"""
from __future__ import annotations

import json
import dataclasses
from dataclasses import dataclass, field
from pathlib import Path
from typing import Dict, List, Optional

from .native import NativeStyleBank, ROLES, ModelError
from .native.codec import walk_children, _be32
from .native.events import parse_pattern_stream, mutate_note_on_velocities
from .trackparams import (FactoryProfileSet, Role, TrackProfile, role_from_pc,
                          clamp_to_drum_layer)

_VALID_PATH = Path(__file__).resolve().parents[1] / "data" / "valid_selectors.json"


def load_drum_subs(path: str | Path | None = None) -> dict:
    """S-12 table: Pa3X-only drum kit -> best-covering Pa800 kit."""
    p = Path(path) if path else Path(__file__).resolve().parent.parent / "data" / "drum_kit_substitution.json"
    if not p.exists():
        return {}
    with open(p, encoding="utf-8") as fh:
        return json.load(fh)


def load_name_remap(path: str | Path | None = None) -> dict:
    """S-14 table: source selector -> Pa800 selector, matched BY SOUND NAME.

    Two tables are loaded and merged (Pa3X first, then Pa4X):

    * `pa3x_to_pa800_by_name.json` — built from the Style Works XT `.SND`
      sound tables (`rom_PA3x.SND` / `rom_PA2x.SND`), whose columns are
      transposed relative to the selector: CC00 = 'type', CC32 = 'pc',
      PC = 'msb'.  Verified against the user's own hardware export:
      120.0.15 = Techno Kit 3 on the drum lane, 121.13.33 = Finger Bass RX
      on the bass lane.
    * `pa4x_to_pa800_by_name.json` — built from the Pa4X FIRMWARE table
      (OS v3.1.0 SOUNDS.xml, 2059 sounds; see tools/build_pa4x_name_remap.py).
      Pa4X selectors only the Pa4X would resolve get the Pa800 sound of the
      same name, exactly like Pa3X ones.

    On keys present in both tables with different targets the Pa3X entry
    wins: Pa3X material is far more common, and a shared address means the
    same lineage slot on both models.

    Why this beats S-10: S-10 keeps the Program Change and only repairs the
    Bank LSB, which yields a selector that EXISTS but may be the wrong
    instrument.  S-14 looks up what the source sound was actually called and
    finds the Pa800 sound of that name -- or, failing that, the closest name
    inside the same category.
    """
    base = Path(__file__).resolve().parents[1] / "data"
    paths = ([Path(path)] if path
             else [base / "pa3x_to_pa800_by_name.json",
                   base / "pa4x_to_pa800_by_name.json"])
    merged: dict = {}
    for p in paths:
        if not p.exists():
            continue
        try:
            with open(p, encoding="utf-8") as fh:
                table = json.load(fh).get("map", {})
        except Exception:                                          # noqa: BLE001
            continue
        for key, value in table.items():
            merged.setdefault(key, value)
    return merged


def load_valid_selectors():
    """Set of (MSB, LSB, PC) a Pa800 can actually resolve.

    Union of the 1003 bindings in the factory Sound List and the 640 distinct
    selectors observed in the 18 factory Style banks.  Control test: 0 of
    42,536 factory Style tracks fall outside this set, so it produces no
    false positives.
    """
    import json
    try:
        return {tuple(x) for x in json.loads(_VALID_PATH.read_text())}
    except Exception:                                              # noqa: BLE001
        return set()

def _band(profiles, role, key):
    """Measured p10..p90 band for one parameter of one role, if available."""
    raw = getattr(profiles, "bands", {}).get(role)
    return (raw or {}).get(key)


VOICE_CEILING = 120          # Pa800 maximum polyphony (manual p.24 / p.338)
DRUM_LANES = {0: Role.DRUM, 1: Role.PERC}


# ---------------------------------------------------------------------------
# reporting
# ---------------------------------------------------------------------------
@dataclass
class Change:
    rule: str
    where: str
    what: str
    before: object
    after: object


@dataclass
class StyleReport:
    bank: str = ""
    applied: bool = False
    editable: bool = True
    styles: int = 0
    elements: int = 0
    lanes: int = 0
    patterns: int = 0
    events: int = 0
    velocities_changed: int = 0
    velocities_skipped: int = 0
    changes: List[Change] = field(default_factory=list)
    findings: List[str] = field(default_factory=list)
    lane_roles: Dict[str, str] = field(default_factory=dict)
    poly_peaks: List[tuple] = field(default_factory=list)
    export: Optional[dict] = None
    profile_source: str = "provisional-defaults"

    def add(self, rule, where, what, before, after):
        self.changes.append(Change(rule, where, what, before, after))

    @property
    def total(self) -> int:
        return len(self.changes)

    def by_rule(self) -> Dict[str, int]:
        out: Dict[str, int] = {}
        for c in self.changes:
            out[c.rule] = out.get(c.rule, 0) + 1
        return out

    def text(self, limit: int = 6) -> str:
        L = ["STYLE OPTIMIZER REPORT (S-serija)",
             "=" * 72,
             f"Bank          : {self.bank}",
             f"Rezim         : {'PRIMIJENJENO' if self.applied else 'DRY-RUN (nista nije upisano)'}",
             f"Profili       : {self.profile_source}",
             f"Sadrzaj       : {self.styles} stilova / {self.elements} elemenata / "
             f"{self.lanes} traka / {self.patterns} patterna / {self.events:,} dogadjaja",
             ""]
        L.append("ULOGE TRAKA (S-01)")
        L.append("-" * 72)
        for lane, role in self.lane_roles.items():
            L.append(f"  {lane:<12} {role}")
        L.append("")
        L.append("IZMJENE")
        L.append("-" * 72)
        if not self.changes:
            L.append("  nema izmjena - Style vec odgovara tvornickom modelu")
        else:
            for rule, n in sorted(self.by_rule().items()):
                L.append(f"  {rule:<8} {n:>6}")
                for c in [x for x in self.changes if x.rule == rule][:limit]:
                    L.append(f"           · {c.where}: {c.what} {c.before} -> {c.after}")
                rest = n - min(n, limit)
                if rest:
                    L.append(f"           · ... jos {rest}")
        L.append(f"  {'velocity':<8} {self.velocities_changed:>6} nota preseljeno "
                 f"({self.velocities_skipped} preskoceno zbog ne-kanonskog framinga)")
        L.append("")
        if self.poly_peaks:
            L.append(f"POLIFONIJSKI BUDZET (S-08), granica {VOICE_CEILING} glasova")
            L.append("-" * 72)
            for name, el, peak in self.poly_peaks[:12]:
                flag = "  <-- PREKO GRANICE" if peak > VOICE_CEILING else ""
                L.append(f"  {name[:28]:<28} {el:<14} vrh {peak:>4}{flag}")
            L.append("")
        if self.findings:
            L.append("NALAZI (bez izmjene)")
            L.append("-" * 72)
            for f in self.findings[:20]:
                L.append(f"  · {f}")
            L.append("")
        if self.export:
            e = self.export
            L.append("INTEGRITET (S-09): bank ponovo otvoren i kompletno isparsiran")
            L.append("-" * 72)
            L.append(f"  {e['bytes']:,} bajtova · {e['styles']} stilova · "
                     f"{e['patterns']} patterna · {e['events']:,} dogadjaja · bez greske")
        return "\n".join(L)


# ---------------------------------------------------------------------------
# helpers
# ---------------------------------------------------------------------------
def lane_role(track: int, ts) -> Role:
    if track in DRUM_LANES:
        return DRUM_LANES[track]
    if ts.msb == 120:
        return Role.PERC
    if track == 2:
        return Role.BASS
    return role_from_pc(ts.program, channel=track)


def _peak_polyphony(events) -> int:
    opens: Dict[int, int] = {}
    peak = cur = 0
    for ev in events:
        p = ev.pitch
        if p is None:
            continue
        if ev.opcode == 1 and ev.velocity:
            opens[p] = opens.get(p, 0) + 1
            cur += 1
            peak = max(peak, cur)
        elif opens.get(p):
            opens[p] -= 1
            cur -= 1
    return peak


def _near(a: int, b: int, tol: int) -> bool:
    return abs(a - b) <= tol


def _fit_band(value: int, band, median: int, tol: int):
    """Return the corrected value, or None when the value is acceptable.

    A value inside the measured factory band (p10..p90 for its role) is
    left exactly as it is -- the factory's own spread is legitimate music,
    not an error.  Only a value outside the band is pulled back, and only
    to the nearest band edge, never to the median.  Without a measured band
    we fall back to a tolerance window around the median.
    """
    if band and band[0] is not None and band[1] is not None:
        lo, hi = band
        if lo <= value <= hi:
            return None
        return lo if value < lo else hi
    return None if _near(value, median, tol) else median


def _copy_ts(ts):
    """Mutable copy of a TrackSettings record (dataclass or plain object)."""
    try:
        return dataclasses.replace(ts)
    except Exception:                                              # noqa: BLE001
        import copy as _c
        return _c.copy(ts)


# ---------------------------------------------------------------------------
# the optimizer
# ---------------------------------------------------------------------------
def optimize_style_bank(
    path: str | Path,
    out_path: str | Path | None = None,
    *,
    profiles: FactoryProfileSet | None = None,
    apply: bool = False,
    mixer: bool = True,
    expression: bool = True,
    velocity: bool = True,
    key_range: bool = True,
    humanize: bool = True,
    fix_sounds: bool = True,
    tolerance: int = 12,
    style_indices: Optional[List[int]] = None,
) -> StyleReport:
    """Run the S-series over one native .STY bank."""
    profiles = profiles or FactoryProfileSet()
    rep = StyleReport(bank=str(path), applied=False,
                      profile_source=profiles.source)

    selectors = load_valid_selectors() if fix_sounds else set()
    drum_subs = load_drum_subs() if fix_sounds else {}
    name_remap = load_name_remap() if fix_sounds else {}
    bank = NativeStyleBank.load(path)
    rep.editable = bank.editable
    for w in bank.warnings:
        rep.findings.append(w)
    if not bank.editable and apply:
        raise ModelError("factory OC20 banks are read-only; optimize a USER/FAVORITE bank")

    targets = range(len(bank.entries)) if style_indices is None else style_indices

    for si in targets:
        entry = bank.entries[si]
        style, comp = entry.style, entry.companion
        rep.styles += 1
        sname = style.name

        # ---- S-01 role per lane, from the first element -------------------
        roles: Dict[int, Role] = {}
        if style.elements:
            td0 = style.elements[0].track_data
            for t in range(8):
                roles[t] = lane_role(t, td0.get(t))
        for t, r in roles.items():
            rep.lane_roles.setdefault(ROLES[t], r.value)

        # ---- S-02 / S-03 / S-05 / S-06 / S-07 declared parameters ---------
        for el in style.elements:
            rep.elements += 1
            for t in range(8):
                rep.lanes += 1
                r = roles.get(t, Role.OTHER)
                prof: TrackProfile = profiles.get(r)
                ts = el.track_data.get(t)
                where = f"{sname[:20]}/{el.name}/{ROLES[t]}"
                is_drum = r in (Role.DRUM, Role.PERC)

                # S-06 NTT/NTR: read and report only.  Never written.
                if ts.ntt_ntr_packed not in (0,):
                    rep.findings.append(
                        f"{where}: NTT/NTR packed={ts.ntt_ntr_packed} ocuvan numericki (S-06)")

                # S-07 Humanize is a Guitar-only feature in the factory corpus
                if humanize and ts.humanize and r is not Role.GUITAR:
                    rep.findings.append(
                        f"{where}: Humanize={ts.humanize} na ne-gitarskoj traci "
                        f"({r.value}) - tvornicki se javlja samo na Guitar (S-07)")

                new_ts = None

                # --- S-10 sound selector validity (Pa3X portability) ------
                # Pa800 drum kits are always 120.0.PC and melodic Bank LSB
                # never exceeds 36.  Pa3X writes LSB 64/65, which the Pa800
                # cannot resolve -- the track then plays the wrong sound or
                # nothing at all.  Measured: 0% of factory tracks are invalid,
                # 48% of this user's own tracks and 74% of Pa3X tracks are.
                if selectors and (ts.msb, ts.lsb, ts.program) not in selectors:
                    # --- S-14 remap BY SOUND NAME (runs before S-10) -------
                    # Only invalid selectors are touched, exactly as before;
                    # the difference is the target.  If this address is a
                    # known Pa3X sound, use the Pa800 sound of the same name.
                    sel_key = f"{ts.msb}.{ts.lsb}.{ts.program}"
                    nm = name_remap.get(sel_key) if name_remap else None
                    if nm:
                        src_name = (nm.get("name") or "").strip()
                        how0 = nm.get("how", "ime")
                        # Two guards learned from the first run:
                        #  1. "User Kit 01", "User Sound 3" ... are empty USER
                        #     slots, not factory sounds.  Matching them by name
                        #     similarity produced nonsense (User Kit 01 ->
                        #     House Kit).  They carry no sound to preserve.
                        #  2. On a DRUM selector (MSB 120) a fuzzy name match is
                        #     weaker evidence than S-12, which measures which
                        #     keys the pattern actually plays.  So drums take
                        #     S-14 only on an EXACT name hit.
                        if src_name.lower().startswith("user"):
                            nm = None
                        elif ts.msb == 120 and how0 != "ime":
                            nm = None
                    if nm:
                        tm, tl, tp = (int(x) for x in nm["to"].split("."))
                        if (tm, tl, tp) in selectors:
                            new_ts = new_ts or _copy_ts(ts)
                            how = nm.get("how", "ime")
                            detail = nm.get("name", "")
                            if how != "ime" and nm.get("to_name"):
                                detail = f"{detail} -> {nm['to_name']}"
                            rep.add("S-14", where, f"Zvuk po imenu ({how}): {detail}",
                                    sel_key, nm["to"])
                            new_ts.msb, new_ts.lsb, new_ts.program = tm, tl, tp
                            ts = new_ts
                            continue_s10 = False
                        else:
                            continue_s10 = True
                    else:
                        continue_s10 = True

                    cand = None
                    if continue_s10:
                        for lsb_try in (0, 1, 2, 3):
                            if (ts.msb, lsb_try, ts.program) in selectors:
                                cand = lsb_try
                                break
                    if not continue_s10:
                        pass
                    elif cand is not None:
                        new_ts = new_ts or _copy_ts(ts)
                        rep.add("S-10", where, "Bank LSB (nevazeci zvuk)",
                                f"{ts.msb}.{ts.lsb}.{ts.program}",
                                f"{ts.msb}.{cand}.{ts.program}")
                        new_ts.lsb = cand
                    elif drum_subs and f"{ts.msb}.{ts.lsb}.{ts.program}" in drum_subs:
                        # --- S-12 drum kit substitution by key coverage ------
                        # The residual invalid selectors are all MSB 120 (drum
                        # kits) that simply do not exist on the Pa800: there is
                        # no same-PC alternative, so S-10 cannot help.  The
                        # replacement is chosen by measuring which keys the
                        # user's patterns actually play on that lane and
                        # picking the Pa800 kit whose factory-measured key map
                        # covers them best (data/drum_kit_substitution.json,
                        # built from the 51 kits documented per key in
                        # PA800_INSTRUMENTI_I_DRUM_KITOVI).
                        sub = drum_subs[f"{ts.msb}.{ts.lsb}.{ts.program}"]
                        tm, tl, tp = (int(x) for x in sub["to"].split("."))
                        new_ts = new_ts or _copy_ts(ts)
                        rep.add("S-12", where, f"Drum kit -> {sub['name']}",
                                f"{ts.msb}.{ts.lsb}.{ts.program}", sub["to"])
                        new_ts.msb, new_ts.lsb, new_ts.program = tm, tl, tp
                    else:
                        rep.findings.append(
                            f"{where}: zvuk {ts.msb}.{ts.lsb}.{ts.program} ne postoji "
                            f"na Pa800 i nema zamjene (S-10)")

                # S-03 Expression parity
                if expression:
                    want = _fit_band(ts.expression, _band(profiles, r, "expression"),
                                     prof.expression, tolerance)
                    if want is not None:
                        new_ts = new_ts or _copy_ts(ts)
                        rep.add("S-03", where, "Expression", ts.expression, want)
                        new_ts.expression = want

                # S-05 key-range sanity, never on drum lanes
                if key_range and not is_drum:
                    lo, hi = ts.key_low, ts.key_high
                    nlo, nhi = lo, hi
                    if lo > hi:
                        nlo, nhi = hi, lo
                    nlo = max(nlo, prof.key_low)
                    nhi = min(nhi, prof.key_high)
                    if nlo > nhi:                     # window collapsed -> keep factory
                        nlo, nhi = prof.key_low, prof.key_high
                    if (nlo, nhi) != (lo, hi):
                        new_ts = new_ts or _copy_ts(ts)
                        rep.add("S-05", where, "Key range", f"{lo}..{hi}", f"{nlo}..{nhi}")
                        new_ts.key_low, new_ts.key_high = nlo, nhi

                if new_ts is not None and apply:
                    el.track_data.set(t, new_ts)

            # ---- S-02 mixer parity (per Style, held on the companion) -----
        if mixer and comp is not None:
            for t in range(8):
                r = roles.get(t, Role.OTHER)
                prof = profiles.get(r)
                try:
                    ms = comp.get(t)
                except Exception:                                  # noqa: BLE001
                    continue
                where = f"{sname[:20]}/{ROLES[t]}"
                changed = False
                for label, cur, bkey, med, setter in (
                    ("Volume CC7", ms.volume, "volume", prof.volume, "volume"),
                    ("Pan CC10", ms.pan + 64, "pan", prof.pan, "pan"),
                    ("FX send 1 (CC91)", ms.fx_aux1, "reverb_send", prof.reverb_send, "fx_aux1"),
                    ("FX send 2 (CC93)", ms.fx_aux2, "chorus_send", prof.chorus_send, "fx_aux2"),
                ):
                    want = _fit_band(cur, _band(profiles, r, bkey), med, tolerance)
                    if want is None:
                        continue
                    rep.add("S-02", where, label, cur, want)
                    setattr(ms, setter, want - 64 if setter == "pan" else want)
                    changed = True
                # --- S-11 out-of-range native mixer values ----------------
                # Found in real user banks: EQ High = -19 where the native
                # field only accepts -18..18.  Such a bank cannot be written
                # back at all until the value is brought into range.
                for fld, lo, hi in (("eq_high", -18, 18), ("eq_mid", -18, 18),
                                    ("eq_low", -18, 18), ("detune", -64, 63),
                                    ("octave", -24, 24), ("pb_sensitivity", 0, 24),
                                    ("input_trim", -64, 63)):
                    cur = getattr(ms, fld)
                    fixed = max(lo, min(hi, cur))
                    if fixed != cur:
                        rep.add("S-11", where, f"{fld} izvan opsega {lo}..{hi}", cur, fixed)
                        setattr(ms, fld, fixed)
                        changed = True

                if changed and apply:
                    comp.set(t, ms)

        # ---- S-04 velocity parity + S-08 polyphony ------------------------
        try:
            role_map = style.pattern_role_map()
        except Exception:                                          # noqa: BLE001
            role_map = {}
        pool = walk_children(style.data, style.pattern_pool.offset)[1:]
        el_peak: Dict[int, int] = {}

        for idx, pattern in enumerate(pool, start=1):
            start = pattern.offset + 8
            duration = _be32(style.data, start)
            length = _be32(style.data, start + 4)
            raw = bytearray(style.data[start + 8:start + 8 + length])
            try:
                evs = parse_pattern_stream(raw, duration)
            except Exception:                                      # noqa: BLE001
                continue
            rep.patterns += 1
            rep.events += len(evs)
            peak = _peak_polyphony(evs)
            owners = role_map.get(idx) or set()
            for t in owners:
                el_peak[t] = max(el_peak.get(t, 0), peak)

            if not velocity or len(owners) != 1:
                continue
            t = next(iter(owners))
            r = roles.get(t, Role.OTHER)
            prof = profiles.get(r)
            if prof.velocity.evidence != "FACTORY_MEASURED":
                continue

            # measure this Pattern's own window so the remap is monotone and
            # relative dynamics inside the Pattern survive
            vals = sorted(ev.velocity for ev in evs
                          if ev.opcode == 1 and ev.velocity)
            if len(vals) < 4:
                continue
            s_lo, s_hi = vals[0], vals[-1]
            s_med = vals[len(vals) // 2]
            if s_hi <= s_lo:
                continue
            ks, nz = prof.rx_keyswitch_max, prof.rx_noise_min

            is_drum_lane = r in (Role.DRUM, Role.PERC)

            def _tx(pitch: int, vel: int, _p=prof, _lo=s_lo, _m=s_med,
                    _hi=s_hi, _ks=ks, _nz=nz, _d=is_drum_lane) -> int:
                # S-09: RX noise keys keep their velocity -- there velocity
                # selects the articulation layer, not the dynamic.
                if pitch <= _ks or pitch >= _nz:
                    return vel
                out = _p.velocity.map_value(vel, _lo, _m, _hi)
                # S-04b: on drum lanes a velocity switch selects a DIFFERENT
                # SAMPLE.  Never let the remap step over one.
                if _d:
                    out = clamp_to_drum_layer(pitch, vel, out)
                return out

            if apply:
                c, s = mutate_note_on_velocities(raw, duration, _tx)
                if c:
                    style.data[start + 8:start + 8 + length] = raw
                rep.velocities_changed += c
                rep.velocities_skipped += s
            else:
                probe = bytearray(raw)
                c, s = mutate_note_on_velocities(probe, duration, _tx)
                rep.velocities_changed += c
                rep.velocities_skipped += s

        total_peak = sum(el_peak.values())
        if total_peak:
            rep.poly_peaks.append((sname, "svi elementi", total_peak))

    rep.poly_peaks.sort(key=lambda x: -x[2])

    if apply:
        target = Path(out_path or path)
        rep.export = bank.export(target)
        rep.applied = True
        rep.bank = str(target)
    return rep
