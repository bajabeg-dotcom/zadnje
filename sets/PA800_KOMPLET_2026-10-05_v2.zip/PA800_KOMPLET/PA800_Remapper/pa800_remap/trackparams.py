"""Factory-parity track parameter model (F-series rules).

A Pa800 track is not just a sound address.  The factory material defines a full
parameter fingerprint per (Style, Element, CV, Track):

    sound · volume (CC7) · expression (CC11) · pan (CC10) ·
    reverb send (CC91) · chorus/mod send (CC93) · key range + wrap around ·
    velocity envelope · octave · NTT/NTR · trigger mode · tension

This module holds that model plus role defaults.

IMPORTANT — EVIDENCE DISCIPLINE
-------------------------------
Every numeric default below is marked PROVISIONAL.  They are musically sane
starting points, NOT measurements.  They are replaced wholesale by
`FactoryProfileSet.load()` once the factory registries are extracted:

    CP00  registry/factory_context_profiles.json     20,967 observations / 8,929 profiles
    FV00  registry/factory_velocity_envelopes.json      268 velocity profiles

Until that extraction runs, every value carries evidence="PROVISIONAL" and the
report says so explicitly.  Nothing here is presented as proven.

Closure status of the related native fields (from
PA800_CROSS_EVIDENCE_TRIANGULATION_2026-09-22.md):
    Trigger / TrackMode  0=Off 1=Retrigger 2=Repitch ......... CLOSED
    Humanize GTR / Floating Trigger, range 0..25 ............. CLOSED
    Tension .................................................. CLOSED_SEMANTIC
    NTR values 2 / 4 ......................................... KEEP OPEN (preserve numerically)
"""

from __future__ import annotations

import json
from dataclasses import asdict, dataclass, field
from enum import Enum
from pathlib import Path
from typing import Dict, Optional, Tuple

CC_VOLUME = 7
CC_PAN = 10
CC_EXPRESSION = 11
CC_DAMPER = 64
CC_REVERB_SEND = 91
CC_CHORUS_SEND = 93


class Role(str, Enum):
    DRUM = "DRUM"
    PERC = "PERC"
    BASS = "BASS"
    GUITAR = "GUITAR"
    PIANO = "PIANO"
    ACCORDION = "ACCORDION"
    ORGAN = "ORGAN"
    STRINGS = "STRINGS"
    PAD = "PAD"
    BRASS = "BRASS"
    REED = "REED"
    LEAD = "LEAD"
    CHROM_PERC = "CHROM_PERC"
    OTHER = "OTHER"


@dataclass
class VelocityEnvelope:
    """Factory velocity envelope for an instrument family (rule F-12)."""
    floor: int = 1
    median: int = 80
    ceiling: int = 127
    evidence: str = "PROVISIONAL"

    def map_value(self, v: int, src_lo: int, src_med: int, src_hi: int) -> int:
        """Monotone, piecewise-linear remap of a velocity into this envelope.

        Relative dynamics are preserved; only the window is re-seated.
        """
        v = max(1, min(127, v))
        if src_hi <= src_lo:
            return self.median
        if v <= src_med and src_med > src_lo:
            t = (v - src_lo) / (src_med - src_lo)
            out = self.floor + t * (self.median - self.floor)
        elif src_hi > src_med:
            t = (v - src_med) / (src_hi - src_med)
            out = self.median + t * (self.ceiling - self.median)
        else:
            out = self.median
        return max(1, min(127, int(round(out))))


@dataclass
class TrackProfile:
    """Full factory-parity fingerprint of one track (F-01 .. F-13)."""
    role: Role = Role.OTHER
    volume: int = 100                 # F-02  CC7
    expression: int = 127             # F-03  CC11
    pan: int = 64                     # F-04  CC10
    reverb_send: int = 30             # F-05  CC91
    chorus_send: int = 0              # F-05  CC93
    key_low: int = 0                  # F-08  key range bottom (MIDI note)
    key_high: int = 127               # F-08  key range top
    wrap_around: bool = True          # F-08  fold out-of-range notes by octaves
    allow_noise_zone: bool = False    # F-08b C7..G9 RX noise keys allowed
    rx_keyswitch_max: int = 11        # F-08c 0..11  RX articulation keyswitches
    rx_noise_min: int = 96            # F-08c 96..127 RX noise / release layer
    octave: int = 0                   # F-07
    velocity: VelocityEnvelope = field(default_factory=VelocityEnvelope)
    max_polyphony: int = 16           # F-13  factory note-density ceiling
    trigger: int = 0                  # F-10  0=Off 1=Retrigger 2=Repitch (CLOSED)
    humanize_gtr: int = 0             # F-10  0..25, guitar tracks only (CLOSED)
    ntt: Optional[int] = None         # F-09  preserved numerically, never invented
    ntr: Optional[int] = None         # F-09  values 2/4 KEEP OPEN
    tension: Optional[int] = None     # F-11  CLOSED_SEMANTIC
    fx_hint: str = ""                 # F-06  populated only from factory extraction
    evidence: str = "PROVISIONAL"

    def to_dict(self) -> dict:
        d = asdict(self)
        d["role"] = self.role.value
        return d


# ---------------------------------------------------------------------------
# PROVISIONAL role defaults.  Musically sane, explicitly NOT measured.
# Key ranges are deliberately conservative and sit inside the C-1..B6 melodic
# window proven for RX programs (OSC5 noise zone C7..G9 stays excluded).
# ---------------------------------------------------------------------------
_P = "PROVISIONAL"

ROLE_DEFAULTS: Dict[Role, TrackProfile] = {
    Role.DRUM: TrackProfile(Role.DRUM, volume=110, pan=64, reverb_send=25, chorus_send=0,
                            key_low=27, key_high=87, wrap_around=False,
                            velocity=VelocityEnvelope(8, 92, 127, _P),
                            max_polyphony=10, evidence=_P),
    Role.PERC: TrackProfile(Role.PERC, volume=100, pan=64, reverb_send=30,
                            key_low=27, key_high=87, wrap_around=False,
                            velocity=VelocityEnvelope(8, 85, 127, _P),
                            max_polyphony=8, evidence=_P),
    Role.BASS: TrackProfile(Role.BASS, volume=112, pan=64, reverb_send=12, chorus_send=0,
                            key_low=24, key_high=67, wrap_around=True,
                            velocity=VelocityEnvelope(20, 95, 127, _P),
                            max_polyphony=1, evidence=_P),
    Role.GUITAR: TrackProfile(Role.GUITAR, volume=100, pan=54, reverb_send=28, chorus_send=12,
                              key_low=40, key_high=88, wrap_around=True,
                              velocity=VelocityEnvelope(24, 84, 127, _P),
                              max_polyphony=6, humanize_gtr=6, evidence=_P),
    Role.PIANO: TrackProfile(Role.PIANO, volume=104, pan=64, reverb_send=32,
                             key_low=21, key_high=108, wrap_around=False,
                             velocity=VelocityEnvelope(12, 80, 127, _P),
                             max_polyphony=10, evidence=_P),
    Role.ACCORDION: TrackProfile(Role.ACCORDION, volume=102, pan=64, reverb_send=26, chorus_send=8,
                                 key_low=41, key_high=93, wrap_around=True,
                                 velocity=VelocityEnvelope(30, 88, 127, _P),
                                 max_polyphony=6, evidence=_P),
    Role.ORGAN: TrackProfile(Role.ORGAN, volume=100, pan=64, reverb_send=24,
                             key_low=36, key_high=96, wrap_around=True,
                             velocity=VelocityEnvelope(64, 100, 127, _P),
                             max_polyphony=8, evidence=_P),
    Role.STRINGS: TrackProfile(Role.STRINGS, volume=94, pan=64, reverb_send=44, chorus_send=10,
                               key_low=36, key_high=96, wrap_around=True,
                               velocity=VelocityEnvelope(28, 76, 120, _P),
                               max_polyphony=5, evidence=_P),
    Role.PAD: TrackProfile(Role.PAD, volume=84, pan=64, reverb_send=52, chorus_send=20,
                           key_low=36, key_high=96, wrap_around=True,
                           velocity=VelocityEnvelope(30, 70, 110, _P),
                           max_polyphony=5, evidence=_P),
    Role.BRASS: TrackProfile(Role.BRASS, volume=100, pan=70, reverb_send=30,
                             key_low=41, key_high=89, wrap_around=True,
                             velocity=VelocityEnvelope(32, 92, 127, _P),
                             max_polyphony=5, evidence=_P),
    Role.REED: TrackProfile(Role.REED, volume=100, pan=58, reverb_send=32,
                            key_low=45, key_high=93, wrap_around=True,
                            velocity=VelocityEnvelope(30, 88, 127, _P),
                            max_polyphony=3, evidence=_P),
    Role.LEAD: TrackProfile(Role.LEAD, volume=104, pan=64, reverb_send=30,
                            key_low=48, key_high=100, wrap_around=True,
                            velocity=VelocityEnvelope(40, 96, 127, _P),
                            max_polyphony=2, evidence=_P),
    Role.CHROM_PERC: TrackProfile(Role.CHROM_PERC, volume=98, pan=64, reverb_send=36,
                                  key_low=48, key_high=108, wrap_around=False,
                                  velocity=VelocityEnvelope(20, 84, 127, _P),
                                  max_polyphony=6, evidence=_P),
    Role.OTHER: TrackProfile(Role.OTHER, evidence=_P),
}


# --- GM program -> role (provisional bridge until MX-1 content detection) ---
def role_from_pc(pc: int, channel: int) -> Role:
    if channel == 9:
        return Role.DRUM
    if 0 <= pc <= 7:
        return Role.PIANO
    if 8 <= pc <= 15:
        return Role.CHROM_PERC
    if 16 <= pc <= 20:
        return Role.ORGAN
    if 21 <= pc <= 23:
        return Role.ACCORDION
    if 24 <= pc <= 31:
        return Role.GUITAR
    if 32 <= pc <= 39:
        return Role.BASS
    if 40 <= pc <= 51:
        return Role.STRINGS
    if 52 <= pc <= 55:
        return Role.PAD
    if 56 <= pc <= 63:
        return Role.BRASS
    if 64 <= pc <= 71:
        return Role.REED
    if 72 <= pc <= 79:
        return Role.LEAD
    if 80 <= pc <= 87:
        return Role.LEAD
    if 88 <= pc <= 95:
        return Role.PAD
    if 112 <= pc <= 119:
        return Role.PERC
    return Role.OTHER


def profile_for(role: Role) -> TrackProfile:
    import copy
    return copy.deepcopy(ROLE_DEFAULTS.get(role, ROLE_DEFAULTS[Role.OTHER]))


class FactoryProfileSet:
    """Container for profiles extracted from the factory corpus (F-serija).

    Expected JSON shape (produced by the Factory Styles extractor, phase P7):

        {"source": "...", "profiles": {"BASS": {...TrackProfile...}, ...}}
    """

    def __init__(self) -> None:
        self.profiles: Dict[Role, TrackProfile] = {r: profile_for(r) for r in Role}
        self.source = "provisional-defaults"
        self.bands: Dict[Role, dict] = {}

    @property
    def is_measured(self) -> bool:
        return self.source != "provisional-defaults"

    def get(self, role: Role) -> TrackProfile:
        import copy
        return copy.deepcopy(self.profiles.get(role, ROLE_DEFAULTS[Role.OTHER]))

    def load(self, path: str | Path) -> int:
        data = json.loads(Path(path).read_text(encoding="utf-8"))
        profs = data.get("profiles", {})
        n = 0
        for key, raw in profs.items():
            try:
                role = Role(key)
            except ValueError:
                continue
            vel = raw.get("velocity", {})
            tp = TrackProfile(
                role=role,
                volume=int(raw.get("volume", 100)),
                expression=int(raw.get("expression", 127)),
                pan=int(raw.get("pan", 64)),
                reverb_send=int(raw.get("reverb_send", 30)),
                chorus_send=int(raw.get("chorus_send", 0)),
                key_low=int(raw.get("key_low", 0)),
                key_high=int(raw.get("key_high", 127)),
                wrap_around=bool(raw.get("wrap_around", True)),
                allow_noise_zone=bool(raw.get("allow_noise_zone", False)),
                rx_keyswitch_max=int(raw.get("rx_keyswitch_max", 11)),
                rx_noise_min=int(raw.get("rx_noise_min", 96)),
                octave=int(raw.get("octave", 0)),
                velocity=VelocityEnvelope(
                    int(vel.get("floor", 1)), int(vel.get("median", 80)),
                    int(vel.get("ceiling", 127)), vel.get("evidence", "FACTORY_MEASURED")),
                max_polyphony=int(raw.get("max_polyphony", 16)),
                trigger=int(raw.get("trigger", 0)),
                humanize_gtr=int(raw.get("humanize_gtr", 0)),
                ntt=raw.get("ntt"), ntr=raw.get("ntr"), tension=raw.get("tension"),
                fx_hint=raw.get("fx_hint", ""),
                evidence=raw.get("evidence", "FACTORY_MEASURED"),
            )
            self.profiles[role] = tp
            if isinstance(raw.get("band"), dict):
                self.bands[role] = raw["band"]
            n += 1
        if n:
            self.source = str(path)
        return n


# ---------------------------------------------------------------------------
# Drum velocity LAYER SWITCHES  (rule F-14 / S-04b / K-08b)
#
# A Pa800 drum key can hold several oscillator layers that are selected by
# velocity.  Crossing a switch does not make the hit louder -- it makes a
# DIFFERENT SAMPLE fire.  Any velocity remap that steps over a switch changes
# the sound qualitatively, which is never what a volume-style correction is
# supposed to do.
#
# Evidence: Korg Pa800 OS v2.02 PKG reverse engineering (PA800_OS_RE_REPORT.md,
# drum kit resources extracted from the official 134 MB OS package) and the
# PA800_DRUM_KIT_LAYERS table derived from it.
#
#   Pop Std. Kit RX (120.0.4)   38 Snare [80] · 46 Open Hat [90] ·
#                               48 Tom1 [85] · 50 Tom2 [85] · 49 Crash [80] ·
#                               51 Ride [80] · 57 Crash2 [85]
#   Jazz Kit                    38 Snare [70] · 49 Crash [75]
#
# We do not know which kit every Style track loads, so the table below is the
# UNION of all documented switches per key.  Staying inside a band of the
# union is conservative: it cannot flip a layer on any documented kit.
# Keys with no documented switch are unconstrained.
# ---------------------------------------------------------------------------
DRUM_LAYER_SWITCHES: Dict[int, tuple] = {
    38: (70, 80),     # Snare      (Jazz 70, Pop 80)
    40: (70, 80),     # Snare 2    same family as 38
    46: (90,),        # Open Hat
    48: (85,),        # Tom 1
    50: (85,),        # Tom 2
    49: (75, 80),     # Crash      (Jazz 75, Pop 80)
    51: (80,),        # Ride
    57: (85,),        # Crash 2
}


def drum_layer_band(key: int, velocity: int) -> tuple:
    """Lowest/highest velocity that still fires the SAME layer for this key.

    Returns (lo, hi) inclusive.  For an undocumented key the band is the full
    legal range, i.e. no constraint.
    """
    sw = DRUM_LAYER_SWITCHES.get(key)
    if not sw:
        return (1, 127)
    lo, hi = 1, 127
    for s in sw:
        if velocity >= s:
            lo = max(lo, s)
        else:
            hi = min(hi, s - 1)
    return (lo, hi)


def clamp_to_drum_layer(key: int, original: int, mapped: int) -> int:
    """Keep a remapped drum velocity inside the layer the original selected."""
    lo, hi = drum_layer_band(key, original)
    return max(lo, min(hi, mapped))
