"""Sound database for the Pa800 remapper.

Address model (rule M-001 .. M-005):
    Pa800 sound = (CC00 bank MSB, CC32 bank LSB, PC program change 0-127)
    CC00 = 121 -> tonal / GM-compatible space
    CC00 = 0   -> drum kit space
    CC32 = 0   -> GM equivalent of that PC
    CC32 = k>0 -> Pa800 variant inside the SAME GM family (same PC)

The full catalogue (1003 bindings) is loaded from
`PA800_FACTORY_SOUND_LIST_CC00_CC32_PC.txt`.  When that file is not present the
module falls back to an embedded baseline: the 128 GM programs at (121, 0, PC)
plus the curated, evidence-verified RX/DNC table.
"""

from __future__ import annotations

import re
from dataclasses import dataclass, field
from pathlib import Path
from typing import Dict, List, Optional

# --------------------------------------------------------------------------
# GM program names (PC 0-127) — used for display and for the GM baseline
# --------------------------------------------------------------------------
GM_NAMES: List[str] = [
    "Acoustic Grand Piano", "Bright Acoustic Piano", "Electric Grand Piano", "Honky-tonk Piano",
    "Electric Piano 1", "Electric Piano 2", "Harpsichord", "Clavi",
    "Celesta", "Glockenspiel", "Music Box", "Vibraphone",
    "Marimba", "Xylophone", "Tubular Bells", "Dulcimer",
    "Drawbar Organ", "Percussive Organ", "Rock Organ", "Church Organ",
    "Reed Organ", "Accordion", "Harmonica", "Tango Accordion",
    "Acoustic Guitar (nylon)", "Acoustic Guitar (steel)", "Electric Guitar (jazz)",
    "Electric Guitar (clean)", "Electric Guitar (muted)", "Overdriven Guitar",
    "Distortion Guitar", "Guitar harmonics",
    "Acoustic Bass", "Electric Bass (finger)", "Electric Bass (pick)", "Fretless Bass",
    "Slap Bass 1", "Slap Bass 2", "Synth Bass 1", "Synth Bass 2",
    "Violin", "Viola", "Cello", "Contrabass",
    "Tremolo Strings", "Pizzicato Strings", "Orchestral Harp", "Timpani",
    "String Ensemble 1", "String Ensemble 2", "SynthStrings 1", "SynthStrings 2",
    "Choir Aahs", "Voice Oohs", "Synth Voice", "Orchestra Hit",
    "Trumpet", "Trombone", "Tuba", "Muted Trumpet",
    "French Horn", "Brass Section", "SynthBrass 1", "SynthBrass 2",
    "Soprano Sax", "Alto Sax", "Tenor Sax", "Baritone Sax",
    "Oboe", "English Horn", "Bassoon", "Clarinet",
    "Piccolo", "Flute", "Recorder", "Pan Flute",
    "Blown Bottle", "Shakuhachi", "Whistle", "Ocarina",
    "Lead 1 (square)", "Lead 2 (sawtooth)", "Lead 3 (calliope)", "Lead 4 (chiff)",
    "Lead 5 (charang)", "Lead 6 (voice)", "Lead 7 (fifths)", "Lead 8 (bass + lead)",
    "Pad 1 (new age)", "Pad 2 (warm)", "Pad 3 (polysynth)", "Pad 4 (choir)",
    "Pad 5 (bowed)", "Pad 6 (metallic)", "Pad 7 (halo)", "Pad 8 (sweep)",
    "FX 1 (rain)", "FX 2 (soundtrack)", "FX 3 (crystal)", "FX 4 (atmosphere)",
    "FX 5 (brightness)", "FX 6 (goblins)", "FX 7 (echoes)", "FX 8 (sci-fi)",
    "Sitar", "Banjo", "Shamisen", "Koto",
    "Kalimba", "Bag pipe", "Fiddle", "Shanai",
    "Tinkle Bell", "Agogo", "Steel Drums", "Woodblock",
    "Taiko Drum", "Melodic Tom", "Synth Drum", "Reverse Cymbal",
    "Guitar Fret Noise", "Breath Noise", "Seashore", "Bird Tweet",
    "Telephone Ring", "Helicopter", "Applause", "Gunshot",
]

TONAL_MSB = 121
DRUM_MSB = 0


@dataclass(frozen=True)
class Sound:
    name: str
    cc00: int
    cc32: int
    pc: int

    @property
    def address(self) -> str:
        return f"{self.cc00}.{self.cc32}.{self.pc}"

    @property
    def is_drum(self) -> bool:
        return self.cc00 == DRUM_MSB

    @property
    def is_gm(self) -> bool:
        return self.cc32 == 0 and self.cc00 == TONAL_MSB

    @property
    def is_rx(self) -> bool:
        return bool(re.search(r"\bRX\d*\b", self.name))

    @property
    def is_dnc(self) -> bool:
        return "DNC" in self.name

    @property
    def is_valve(self) -> bool:
        # organ rotary/valve variants — never auto-selected (rule M-015)
        return bool(re.search(r"\bV\.\s*$", self.name))

    def __str__(self) -> str:  # pragma: no cover - display helper
        return f"{self.name}  [{self.address}]"


# --------------------------------------------------------------------------
# Curated, evidence-verified table (see RULES_MAPIRANJE_PA800.md §3.1)
# --------------------------------------------------------------------------
CURATED_RX_DNC: List[Sound] = [
    Sound("Grand Piano RX", 121, 10, 0),
    Sound("Bright Piano RX", 121, 5, 1),
    Sound("Tine E.Piano RX", 121, 18, 4),
    Sound("EP+Damper1 DNC", 121, 25, 4),
    Sound("EP+Damper2 DNC", 121, 26, 4),
    Sound("Harpsi KeyOff RX", 121, 3, 6),
    Sound("Harpsi 16' RX", 121, 5, 6),
    Sound("Clav Wah RX", 121, 2, 7),
    Sound("Clav RX", 121, 5, 7),
    Sound("Synth Clav RX", 121, 6, 7),
    Sound("Jimmy Organ DNC", 121, 13, 18),
    Sound("Clean Funk RX2", 121, 11, 28),
    Sound("Clean Guitar RX1", 121, 14, 28),
    Sound("Acous. Bass RX", 121, 7, 32),
    Sound("Finger Bass RX", 121, 13, 33),
    Sound("Picked Bass RX", 121, 10, 34),
    Sound("FunkSlap Bass RX", 121, 3, 36),
    Sound("SlapFing Bass RX", 121, 4, 36),
    Sound("SlapPick Bass RX", 121, 5, 36),
    Sound("Strings Ens. RX", 121, 22, 48),
    Sound("Concert Str.RX", 121, 23, 48),
    Sound("Scat Voices RX", 121, 19, 52),
    Sound("Banjo RX", 121, 4, 105),
]

# Curated non-RX upgrades for the SAFE/STANDARD profiles. Only entries whose
# address is confirmed in the factory sound list are listed here.
CURATED_SAFE: List[Sound] = [
    Sound("Grand Piano", 121, 3, 0),
    Sound("Classic Piano", 121, 4, 0),
    Sound("Jazz Piano", 121, 5, 0),
    Sound("Bright Piano Wide", 121, 1, 1),
    Sound("M1 Piano", 121, 2, 2),
    Sound("Vintage EP", 121, 4, 4),
    Sound("Pro Stage EP", 121, 6, 4),
    Sound("EP Legend", 121, 3, 5),
    Sound("Harpsi Korg", 121, 4, 6),
    Sound("Pulse Clav", 121, 1, 7),
    Sound("Jazz Organ", 121, 8, 16),
    Sound("Drawbars Organ", 121, 14, 16),
    Sound("Rotary Organ", 121, 8, 17),
    Sound("Killer B", 121, 2, 18),
    Sound("Church Pipes", 121, 4, 19),
    Sound("Akordeon", 121, 2, 21),
    Sound("Musette 1", 121, 3, 21),
    Sound("Fisa Master", 121, 8, 21),
    Sound("Cassotto", 121, 9, 21),
]

LINE_RE = re.compile(r"^(?P<name>.+?)\s{2,}(?P<cc00>\d{1,3})\s+(?P<cc32>\d{1,3})\s+(?P<pc>\d{1,3})\s*$")


class SoundDB:
    """Holds every known Pa800 sound binding and answers lookup queries."""

    def __init__(self) -> None:
        self.sounds: List[Sound] = []
        self.by_pc: Dict[int, List[Sound]] = {}
        self.drums: List[Sound] = []
        self.source: str = "embedded"
        self._load_embedded()

    # ---------------- loading ----------------
    def _add(self, s: Sound) -> None:
        if any(x.cc00 == s.cc00 and x.cc32 == s.cc32 and x.pc == s.pc for x in self.sounds):
            return
        self.sounds.append(s)
        if s.is_drum:
            self.drums.append(s)
        else:
            self.by_pc.setdefault(s.pc, []).append(s)

    def _load_embedded(self) -> None:
        for pc, name in enumerate(GM_NAMES):
            self._add(Sound(f"{name} GM", TONAL_MSB, 0, pc))
        for s in CURATED_SAFE:
            self._add(s)
        for s in CURATED_RX_DNC:
            self._add(s)

    def load_factory_list(self, path: str | Path) -> int:
        """Load PA800_FACTORY_SOUND_LIST_CC00_CC32_PC.txt. Returns count added."""
        path = Path(path)
        added = 0
        text = path.read_text(encoding="utf-8", errors="replace")
        for raw in text.splitlines():
            line = raw.rstrip()
            if not line or line.startswith("-") or line.lower().startswith("name"):
                continue
            m = LINE_RE.match(line)
            if not m:
                continue
            name = m.group("name").strip()
            cc00, cc32, pc = int(m.group("cc00")), int(m.group("cc32")), int(m.group("pc"))
            if not (0 <= cc00 <= 127 and 0 <= cc32 <= 127 and 0 <= pc <= 127):
                continue
            before = len(self.sounds)
            self._add(Sound(name, cc00, cc32, pc))
            added += len(self.sounds) - before
        if added:
            self.source = str(path)
        return added

    # ---------------- queries ----------------
    def gm_baseline(self, pc: int) -> Sound:
        """Rule M-002 / M-014: guaranteed fallback."""
        for s in self.by_pc.get(pc, []):
            if s.is_gm:
                return s
        name = GM_NAMES[pc] if 0 <= pc < 128 else f"PC {pc}"
        return Sound(f"{name} GM", TONAL_MSB, 0, pc)

    def variants(self, pc: int) -> List[Sound]:
        return sorted(self.by_pc.get(pc, []), key=lambda s: s.cc32)

    def find(self, name: str) -> Optional[Sound]:
        low = name.strip().lower()
        for s in self.sounds:
            if s.name.lower() == low:
                return s
        return None

    def drum_kits(self) -> List[Sound]:
        return sorted(self.drums, key=lambda s: (s.cc32, s.pc))

    @property
    def stats(self) -> Dict[str, int]:
        return {
            "total": len(self.sounds),
            "tonal": len(self.sounds) - len(self.drums),
            "drum_kits": len(self.drums),
            "rx": sum(1 for s in self.sounds if s.is_rx),
            "dnc": sum(1 for s in self.sounds if s.is_dnc),
        }


def autoload(search_dirs: Optional[List[Path]] = None) -> SoundDB:
    """Build a SoundDB, auto-loading the factory list if it can be found."""
    db = SoundDB()
    names = ["PA800_FACTORY_SOUND_LIST_CC00_CC32_PC.txt"]
    dirs = search_dirs or []
    here = Path(__file__).resolve().parent
    dirs += [here / "data", here.parent / "data", here.parent, Path.cwd()]
    for d in dirs:
        for n in names:
            p = Path(d) / n
            if p.is_file():
                try:
                    if db.load_factory_list(p):
                        return db
                except Exception:
                    continue
    return db
