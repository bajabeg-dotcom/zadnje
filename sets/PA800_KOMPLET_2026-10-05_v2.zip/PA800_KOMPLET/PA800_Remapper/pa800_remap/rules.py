"""M-series mapping rule engine.

Every decision the remapper makes is attributed to a rule id so the resulting
report is fully auditable (rule M-055).
"""

from __future__ import annotations

from dataclasses import dataclass, field
from enum import Enum
from typing import Dict, List, Optional, Tuple

from .sounddb import CURATED_RX_DNC, CURATED_SAFE, DRUM_MSB, TONAL_MSB, Sound, SoundDB


class Profile(str, Enum):
    GM_BASELINE = "GM_BASELINE"
    SAFE = "SAFE"
    STANDARD = "STANDARD"
    RX_READY = "RX_READY"
    CUSTOM = "CUSTOM"


@dataclass(frozen=True)
class Rule:
    id: str
    title: str
    evidence: str


RULES: Dict[str, Rule] = {r.id: r for r in [
    Rule("M-000.1", "Remap runs after optimization; RX requires articulation layer",
         "I-REG velocity-layer architecture of RX sounds"),
    Rule("M-000.3", "Remap must never run before optimization", "pipeline guard"),
    Rule("M-001", "Sound = (CC00, CC32, PC)", "factory sound list header"),
    Rule("M-002", "Emit CC#0 -> CC#32 -> PC before first Note-On", "MIDI bank select + Pa800"),
    Rule("M-003", "CC00=121 tonal space, CC00=0 drum space", "factory sound list"),
    Rule("M-004", "CC32=0 is the GM equivalent; CC32=k>0 are variants of the same PC",
         "factory sound list (PC 0: 121.0.0 GM .. 121.10.0 Grand Piano RX)"),
    Rule("M-005", "PC numbering is 0-127", "factory sound list header"),
    Rule("M-010", "Selection stays inside the same PC family", "M-004"),
    Rule("M-011", "Priority: curated -> wide/stereo variant -> GM baseline", "catalogue naming"),
    Rule("M-012", "RX sound only in RX_READY and only with articulation layer",
         "RX velocity-layer split (e.g. Finger Bass RX 1-22/23-52/53-113/114-127)"),
    Rule("M-013", "DNC sound only when DNC controllers are present", "23 DNC sounds"),
    Rule("M-014", "Unknown PC -> GM baseline + UNRESOLVED log", "M-002"),
    Rule("M-015", "Organ 'V.' variants are never auto-selected", "rotary/percussion behaviour"),
    Rule("M-020", "Channel 10 maps only into CC00=0 drum space", "factory sound list"),
    Rule("M-021", "Drum kit untouched without the full factory list", "no address = no write"),
    Rule("M-022", "Per-key coverage check against the kit map", "I-REG 51 kits / 2003 per-key rows"),
    Rule("M-023", "Drum keys are never transposed by the remap", "PA800-002 arranger behaviour"),
    Rule("M-030", "Channel layout preserved unless normalization is requested", "arrangement safety"),
    Rule("M-032", "Guitar-mode control octaves and RX noise keys C7..G9 are not melodic",
         "OSC5 RX_NOISE key zone C7..G9"),
    Rule("M-033", "Noise keys on a non-RX target raise ORPHAN_NOISE_KEYS", "M-012"),
    Rule("M-040", "Existing CC0/CC32/PC events are replaced, not duplicated", "determinism"),
    Rule("M-041", "Mid-track sound change only on a phrase boundary", "musical safety"),
    Rule("M-042", "Bank/PC block is written before any CC/Note-On at the same tick", "M-002"),
    Rule("M-043", "Mix init block (CC7/10/91/93) is opt-in, default off", "remap touches sounds only"),
    Rule("M-050", "Every sounding channel has a complete triple", "verification"),
    Rule("M-051", "Every triple exists in the database", "verification"),
    Rule("M-052", "Tonal != CC00 0 and drum != CC00 121", "verification"),
    Rule("M-053", "Note count unchanged", "verification"),
    Rule("M-054", "Timing unchanged", "verification"),
    Rule("M-055", "Report carries a rule id for every change", "auditability"),
]}

# RX noise / guitar-mode control zone (rule M-032): MIDI C7 = 96 .. G9 = 127
NOISE_ZONE: Tuple[int, int] = (96, 127)

# Preferred RX choice per PC when several exist (rule M-012).
RX_PREFERENCE: Dict[int, str] = {
    0: "Grand Piano RX",
    1: "Bright Piano RX",
    4: "Tine E.Piano RX",
    6: "Harpsi KeyOff RX",
    7: "Clav RX",
    28: "Clean Guitar RX1",
    32: "Acous. Bass RX",
    33: "Finger Bass RX",
    34: "Picked Bass RX",
    36: "SlapFing Bass RX",
    48: "Strings Ens. RX",
    52: "Scat Voices RX",
    105: "Banjo RX",
}

_WIDE_HINTS = ("wide", "stereo", "ensemble")


@dataclass
class Decision:
    channel: int
    track_index: int
    before_pc: int
    before_cc00: Optional[int]
    before_cc32: Optional[int]
    sound: Sound
    rule_id: str
    reason: str
    warnings: List[str] = field(default_factory=list)

    def as_dict(self) -> dict:
        return {
            "track": self.track_index,
            "channel": self.channel + 1,
            "before": {"cc00": self.before_cc00, "cc32": self.before_cc32, "pc": self.before_pc},
            "after": {"cc00": self.sound.cc00, "cc32": self.sound.cc32,
                      "pc": self.sound.pc, "name": self.sound.name},
            "rule": self.rule_id,
            "reason": self.reason,
            "warnings": self.warnings,
        }


class MappingEngine:
    def __init__(self, db: SoundDB, profile: Profile = Profile.SAFE,
                 articulated: bool = False,
                 custom: Optional[Dict[int, Sound]] = None,
                 drum_kit: Optional[Sound] = None) -> None:
        self.db = db
        self.profile = profile
        self.articulated = articulated
        self.custom = custom or {}
        self.drum_kit = drum_kit
        self.unresolved: List[int] = []

    # ----------------------------------------------------------------
    def effective_profile(self) -> Profile:
        """Rule M-000.1 — downgrade RX_READY when no articulation layer."""
        if self.profile is Profile.RX_READY and not self.articulated:
            return Profile.SAFE
        return self.profile

    # ----------------------------------------------------------------
    def choose_drum(self) -> Tuple[Optional[Sound], str, List[str]]:
        warn: List[str] = []
        if self.drum_kit is not None:
            if self.drum_kit.cc00 != DRUM_MSB:
                warn.append("selected kit is not in the CC00=0 drum space")
            return self.drum_kit, "M-020", warn
        if not self.db.drum_kits():
            return None, "M-021", ["no factory sound list loaded -> drum channel left untouched"]
        return None, "M-021", ["no drum kit selected -> drum channel left untouched"]

    # ----------------------------------------------------------------
    def choose(self, pc: int, channel: int) -> Tuple[Sound, str, str, List[str]]:
        """Return (sound, rule_id, reason, warnings) for a tonal channel."""
        warnings: List[str] = []
        prof = self.effective_profile()

        if prof is Profile.CUSTOM and pc in self.custom:
            return self.custom[pc], "M-010", "custom mapping table", warnings
        if pc in self.custom:
            return self.custom[pc], "M-010", "custom override", warnings

        if not (0 <= pc <= 127):
            self.unresolved.append(pc)
            return self.db.gm_baseline(0), "M-014", "PC out of range -> GM baseline", \
                ["PC out of range 0-127"]

        candidates = [s for s in self.db.variants(pc) if s.cc00 == TONAL_MSB]
        if not candidates:
            self.unresolved.append(pc)
            return self.db.gm_baseline(pc), "M-014", "PC not in database -> GM baseline", \
                ["unresolved PC, GM baseline used"]

        if prof is Profile.GM_BASELINE:
            return self.db.gm_baseline(pc), "M-002", "GM baseline profile", warnings

        # ---- RX (rule M-012) --------------------------------------
        if prof is Profile.RX_READY:
            want = RX_PREFERENCE.get(pc)
            pick = None
            if want:
                pick = next((s for s in candidates if s.name.lower() == want.lower()), None)
            if pick is None:
                pick = next((s for s in candidates if s.is_rx and not s.is_valve), None)
            if pick is not None:
                return pick, "M-012", "RX variant (articulation layer present)", warnings

        # ---- DNC (rule M-013) is only chosen through CUSTOM / explicit UI ----

        # ---- curated non-RX upgrade (rule M-011) -------------------
        curated_names = {s.name.lower() for s in CURATED_SAFE}
        pick = next((s for s in candidates if s.name.lower() in curated_names), None)
        if pick is not None and prof in (Profile.SAFE, Profile.STANDARD, Profile.RX_READY):
            return pick, "M-011", "curated variant", warnings

        # ---- wide / stereo variant (STANDARD and above) ------------
        if prof in (Profile.STANDARD, Profile.RX_READY):
            pick = next((s for s in candidates
                         if any(h in s.name.lower() for h in _WIDE_HINTS)
                         and not s.is_valve and not s.is_rx and not s.is_dnc), None)
            if pick is not None:
                return pick, "M-011", "wide/stereo variant", warnings

        return self.db.gm_baseline(pc), "M-002", "GM baseline (no better candidate)", warnings
