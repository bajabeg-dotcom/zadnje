"""Pa800 Style Doctor - the simple window.

Design rule: a player who has never heard the words "selector", "element" or
"v5" must be able to finish the job.  So the window is one vertical path --

    1. where are your styles
    2. what do you want
    3. press the button

-- every option is a full sentence, nothing is abbreviated, and the result is
reported in the same plain language.  All the real work lives in
`pipeline.py`; this file only draws and dispatches.
"""
from __future__ import annotations

import os
import queue
import subprocess
import sys
import threading
import traceback
from pathlib import Path

import tkinter as tk
from tkinter import filedialog, messagebox, ttk

from . import pipeline as P

BG = "#101319"
CARD = "#1a1f28"
CARD_HI = "#232b38"
FG = "#eef2f8"
DIM = "#93a0b4"
ACC = "#4da3ff"
OK = "#51cf66"
WARN = "#ffa94d"
ERR = "#ff6b6b"

TITLE = "Pa800 Doktor za stilove"

JOBS = [
    ("check", "Samo provjeri",
     "Ništa ne mijenja i ništa ne snima.\nSamo ti kaže šta ne valja s tvojim stilovima.",
     False),
    ("repair", "Popravi sve     (preporučeno)",
     "Sređuje pogrešno postavljene zvukove, jačine i bubnjeve,\n"
     "i prebacuje Pa3X/Pa4X stilove u oblik koji Pa800 razumije.",
     True),
    ("convert", "Samo prebaci Pa3X/Pa4X stilove",
     "Mijenja isključivo format Pa3X, Pa4X, PA700 i PA1000 stilova\n"
     "u Pa800. Zvukove i jačine ne dira.",
     True),
]


class App:
    def __init__(self, root: tk.Tk) -> None:
        self.root = root
        root.title(TITLE)
        root.geometry("880x900")
        root.minsize(700, 480)
        root.configure(bg=BG)

        self.src = tk.StringVar()
        self.dst = tk.StringVar()
        self.job = tk.StringVar(value="repair")
        self.busy = False
        self.result: P.JobResult | None = None
        self.q: queue.Queue = queue.Queue()

        self._init_style()
        self._build()
        self._on_job_change()
        self.root.after(80, self._drain)

    # ------------------------------------------------------------ styling
    def _init_style(self) -> None:
        s = ttk.Style()
        try:
            s.theme_use("clam")
        except tk.TclError:
            pass
        s.configure(".", background=BG, foreground=FG)
        s.configure("TFrame", background=BG)
        s.configure("Card.TFrame", background=CARD)
        s.configure("TLabel", background=BG, foreground=FG, font=("Segoe UI", 10))
        s.configure("Card.TLabel", background=CARD, foreground=FG, font=("Segoe UI", 10))
        s.configure("Dim.TLabel", background=CARD, foreground=DIM, font=("Segoe UI", 9))
        s.configure("Step.TLabel", background=BG, foreground=ACC,
                    font=("Segoe UI", 11, "bold"))
        s.configure("Head.TLabel", background=BG, foreground=FG,
                    font=("Segoe UI", 19, "bold"))
        s.configure("Sub.TLabel", background=BG, foreground=DIM, font=("Segoe UI", 10))
        s.configure("TButton", font=("Segoe UI", 10), padding=6)
        s.configure("Go.TButton", font=("Segoe UI", 13, "bold"), padding=10)
        s.configure("TCheckbutton", background=CARD, foreground=FG,
                    font=("Segoe UI", 10))
        s.map("TCheckbutton", background=[("active", CARD)])
        s.configure("TRadiobutton", background=CARD, foreground=FG,
                    font=("Segoe UI", 11, "bold"))
        s.map("TRadiobutton", background=[("active", CARD)],
              indicatorcolor=[("selected", ACC), ("!selected", "#3a4454")],
              foreground=[("selected", ACC)])
        s.configure("TProgressbar", background=ACC, troughcolor=CARD,
                    borderwidth=0, thickness=16)

    def _card(self, parent, pady=(0, 10)) -> ttk.Frame:
        f = ttk.Frame(parent, style="Card.TFrame", padding=14)
        f.pack(fill="x", pady=pady)
        return f

    # ------------------------------------------------------------- layout
    def _scroll_host(self) -> ttk.Frame:
        """A scrollable body, so the window still works on a 768px laptop."""
        outer = ttk.Frame(self.root)
        outer.pack(fill="both", expand=True)
        canvas = tk.Canvas(outer, bg=BG, highlightthickness=0, borderwidth=0)
        bar = ttk.Scrollbar(outer, orient="vertical", command=canvas.yview)
        inner = ttk.Frame(canvas, padding=18)
        window = canvas.create_window((0, 0), window=inner, anchor="nw")

        def on_inner(_event=None):
            canvas.configure(scrollregion=canvas.bbox("all"))

        def on_canvas(event):
            canvas.itemconfigure(window, width=event.width)

        def on_wheel(event):
            delta = -1 if getattr(event, "num", 0) == 5 or event.delta < 0 else 1
            canvas.yview_scroll(-delta, "units")

        inner.bind("<Configure>", on_inner)
        canvas.bind("<Configure>", on_canvas)
        for seq in ("<MouseWheel>", "<Button-4>", "<Button-5>"):
            canvas.bind_all(seq, on_wheel)
        canvas.configure(yscrollcommand=bar.set)
        canvas.pack(side="left", fill="both", expand=True)
        bar.pack(side="right", fill="y")
        return inner

    def _build(self) -> None:
        wrap = self._scroll_host()

        ttk.Label(wrap, text=TITLE, style="Head.TLabel").pack(anchor="w")
        ttk.Label(wrap, style="Sub.TLabel",
                  text="Popravlja stilove za Korg Pa800. Tvoji originali se nikad ne mijenjaju."
                  ).pack(anchor="w", pady=(2, 12))

        # --- step 1 ----------------------------------------------------
        ttk.Label(wrap, text="1.  Gdje su tvoji stilovi?", style="Step.TLabel").pack(anchor="w")
        c1 = self._card(wrap, pady=(5, 10))
        row = ttk.Frame(c1, style="Card.TFrame")
        row.pack(fill="x")
        self.src_entry = tk.Entry(row, textvariable=self.src, font=("Segoe UI", 10),
                                  bg=CARD_HI, fg=FG, insertbackground=FG,
                                  relief="flat", highlightthickness=1,
                                  highlightbackground="#2e3849")
        self.src_entry.pack(side="left", fill="x", expand=True, ipady=7, padx=(0, 10))
        ttk.Button(row, text="Izaberi mapu...", command=self._pick_src).pack(side="left")
        self.src_info = ttk.Label(c1, text="Izaberi mapu koja se zove nešto.SET "
                                           "(ili mapu STYLE u njoj).", style="Dim.TLabel")
        self.src_info.pack(anchor="w", pady=(8, 0))

        # --- step 2 ----------------------------------------------------
        ttk.Label(wrap, text="2.  Šta hoćeš da uradim?", style="Step.TLabel").pack(anchor="w")
        c2 = self._card(wrap, pady=(5, 10))
        for key, title, desc, _writes in JOBS:
            ttk.Radiobutton(c2, text=title, value=key, variable=self.job,
                            command=self._on_job_change).pack(anchor="w")
            ttk.Label(c2, text=desc, style="Dim.TLabel", justify="left").pack(
                anchor="w", padx=(26, 0), pady=(1, 8))

        # --- step 3 ----------------------------------------------------
        self.step3 = ttk.Label(wrap, text="3.  Gdje da snimim rezultat?", style="Step.TLabel")
        self.step3.pack(anchor="w")
        self.c3 = self._card(wrap, pady=(5, 10))
        row3 = ttk.Frame(self.c3, style="Card.TFrame")
        row3.pack(fill="x")
        self.dst_entry = tk.Entry(row3, textvariable=self.dst, font=("Segoe UI", 10),
                                  bg=CARD_HI, fg=FG, insertbackground=FG,
                                  relief="flat", highlightthickness=1,
                                  highlightbackground="#2e3849")
        self.dst_entry.pack(side="left", fill="x", expand=True, ipady=7, padx=(0, 10))
        ttk.Button(row3, text="Izaberi mapu...", command=self._pick_dst).pack(side="left")
        ttk.Label(self.c3, text="Popuni se samo. Tu nastaje nova .SET mapa koju "
                                "prebaciš na USB.", style="Dim.TLabel").pack(anchor="w", pady=(8, 0))

        # --- go --------------------------------------------------------
        self.go = ttk.Button(wrap, text="URADI", style="Go.TButton", command=self._start)
        self.go.pack(fill="x", pady=(2, 10))

        self.bar = ttk.Progressbar(wrap, mode="determinate", maximum=100)
        self.bar.pack(fill="x")
        self.status = ttk.Label(wrap, text="Spreman.", style="Sub.TLabel")
        self.status.pack(anchor="w", pady=(5, 10))

        # --- result ----------------------------------------------------
        res = ttk.Frame(wrap, style="Card.TFrame", padding=14)
        res.pack(fill="both", expand=True)
        self.headline = ttk.Label(res, text="", style="Card.TLabel",
                                  font=("Segoe UI", 14, "bold"))
        self.headline.pack(anchor="w")
        self.out = tk.Text(res, height=8, bg=CARD, fg=FG, relief="flat",
                           font=("Consolas", 10), wrap="word",
                           highlightthickness=0, borderwidth=0)
        self.out.pack(fill="both", expand=True, pady=(8, 8))
        self.out.configure(state="disabled")
        btns = ttk.Frame(res, style="Card.TFrame")
        btns.pack(fill="x")
        self.open_btn = ttk.Button(btns, text="Otvori mapu s rezultatom",
                                   command=self._open_out, state="disabled")
        self.open_btn.pack(side="left")
        ttk.Button(btns, text="Snimi izvještaj", command=self._save_report).pack(
            side="left", padx=8)

    # ------------------------------------------------------------ actions
    def _pick_src(self) -> None:
        d = filedialog.askdirectory(title="Izaberi .SET mapu sa stilovima")
        if not d:
            return
        self.src.set(d)
        self._probe(d)

    def _probe(self, d: str) -> None:
        found = P.find_style_folder(d)
        if found is None:
            self.src_info.configure(
                text="Tu nema stilova. Traži mapu koja se zove nešto.SET, "
                     "ili mapu STYLE u kojoj su .STY fajlovi.", foreground=ERR)
            return
        banks = P.list_banks(found)
        self.src_info.configure(
            text=f"U redu — našao sam {len(banks)} banaka u mapi {found.name}.",
            foreground=OK)
        if not self.dst.get():
            parent = Path(d).parent
            self.dst.set(str(parent / (Path(d).name.replace(".SET", "") + "_POPRAVLJENO.SET")))

    def _pick_dst(self) -> None:
        d = filedialog.askdirectory(title="Gdje snimiti rezultat")
        if d:
            self.dst.set(d)

    def _on_job_change(self) -> None:
        writes = dict((k, w) for k, _t, _d, w in JOBS)[self.job.get()]
        state = "normal" if writes else "disabled"
        self.dst_entry.configure(state=state)
        colour = ACC if writes else DIM
        self.step3.configure(foreground=colour)
        for child in self.c3.winfo_children():
            for sub in getattr(child, "winfo_children", lambda: [])():
                try:
                    sub.configure(state=state)
                except tk.TclError:
                    pass

    def _start(self) -> None:
        if self.busy:
            return
        src = self.src.get().strip()
        if not src:
            messagebox.showwarning(TITLE, "Prvo izaberi mapu sa stilovima.")
            return
        if P.find_style_folder(src) is None:
            messagebox.showerror(TITLE, "U toj mapi nema nijednog .STY fajla.\n\n"
                                        "Izaberi mapu koja se zove nešto.SET, ili "
                                        "mapu STYLE koja je unutra.")
            return
        job = self.job.get()
        dst = self.dst.get().strip()
        if job != "check":
            if not dst:
                messagebox.showwarning(TITLE, "Reci mi gdje da snimim rezultat.")
                return
            if Path(dst).resolve() == Path(src).resolve():
                messagebox.showerror(TITLE, "Rezultat ne smije ići u istu mapu kao original.")
                return
            if Path(dst).exists() and any(Path(dst).iterdir()):
                if not messagebox.askyesno(TITLE, f"Mapa već postoji:\n{dst}\n\n"
                                                  "Nastaviti i pisati u nju?"):
                    return

        self.busy = True
        self.go.configure(state="disabled", text="RADIM...")
        self.open_btn.configure(state="disabled")
        self.bar["value"] = 0
        self._write("", "")
        threading.Thread(target=self._work, args=(job, src, dst), daemon=True).start()

    def _work(self, job: str, src: str, dst: str) -> None:
        def prog(f: float, m: str) -> None:
            self.q.put(("p", max(0.0, min(1.0, f)), m))
        try:
            if job == "check":
                r = P.diagnose(src, prog)
            elif job == "convert":
                r = P.convert_only(src, dst, prog)
            else:
                r = P.repair(src, dst, prog)
            self.q.put(("done", r, ""))
        except Exception:
            self.q.put(("fail", traceback.format_exc(), ""))

    def _drain(self) -> None:
        try:
            while True:
                kind, a, b = self.q.get_nowait()
                if kind == "p":
                    self.bar["value"] = a * 100
                    self.status.configure(text=b)
                elif kind == "done":
                    self._finish(a)
                elif kind == "fail":
                    self.busy = False
                    self.go.configure(state="normal", text="URADI")
                    self.status.configure(text="Greška.")
                    self._write("Nešto je puklo.", a, ERR)
        except queue.Empty:
            pass
        self.root.after(80, self._drain)

    def _finish(self, r: P.JobResult) -> None:
        self.busy = False
        self.result = r
        self.go.configure(state="normal", text="URADI")
        self.bar["value"] = 100
        self.status.configure(text="Gotovo.")
        colour = ERR if r.error or r.failed else OK
        self._write(r.headline(), "\n".join(r.plain_lines()), colour)
        if r.out_dir and Path(r.out_dir).exists():
            self.open_btn.configure(state="normal")

    def _write(self, head: str, body: str, colour: str = FG) -> None:
        self.headline.configure(text=head, foreground=colour)
        self.out.configure(state="normal")
        self.out.delete("1.0", "end")
        self.out.insert("1.0", body)
        self.out.configure(state="disabled")

    def _open_out(self) -> None:
        if not self.result or not self.result.out_dir:
            return
        d = self.result.out_dir
        try:
            if sys.platform.startswith("win"):
                os.startfile(d)  # type: ignore[attr-defined]
            elif sys.platform == "darwin":
                subprocess.Popen(["open", d])
            else:
                subprocess.Popen(["xdg-open", d])
        except Exception as exc:
            messagebox.showerror(TITLE, f"Ne mogu otvoriti mapu:\n{exc}")

    def _save_report(self) -> None:
        if not self.result:
            messagebox.showinfo(TITLE, "Nema još izvještaja — prvo pokreni posao.")
            return
        f = filedialog.asksaveasfilename(defaultextension=".txt",
                                         initialfile="izvjestaj.txt",
                                         filetypes=[("Tekst", "*.txt")])
        if not f:
            return
        r = self.result
        lines = [TITLE, "=" * 60, r.headline(), ""] + r.plain_lines() + ["", "Po bankama:"]
        for b in r.banks:
            lines.append(f"  {b.name:<16} stilova {b.styles:>4}  "
                         f"zvukovi {b.invalid_before}->{b.invalid_after}  "
                         f"izmjena {b.changes}" + (f"  GREŠKA {b.error}" if b.error else ""))
        Path(f).write_text("\n".join(lines), encoding="utf-8")
        messagebox.showinfo(TITLE, f"Snimljeno:\n{f}")


def main() -> int:
    root = tk.Tk()
    App(root)
    root.mainloop()
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
