"""Polyphony / voice-budget simulator for the Korg Pa800.

Hard fact (Owner's Manual p. 24 and p. 338): the Pa800 tone generator provides
**120 voices / 120 oscillators**, and a single program may use up to 16
oscillators per note.  An RX program in the factory catalogue uses 5-8
oscillators, so voice consumption is:

        voices(note) = oscillators(program)

This module replays a MIDI file and reports, per tick, how many oscillators
would actually be allocated, so a remap plan can be rejected BEFORE it causes
audible voice stealing.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Dict, List, Optional, Tuple

import mido

PA800_MAX_VOICES = 120          # manual p. 24 / p. 338
PA800_MAX_OSC_PER_PROGRAM = 16  # RX architecture

# Oscillator counts proven in PA800_INSTRUMENTI_I_DRUM_KITOVI.pdf
OSC_COUNT_BY_SOUND: Dict[str, int] = {
    "Acous. Bass RX": 7, "Finger Bass RX": 5, "Picked Bass RX": 5,
    "FunkSlap Bass RX": 7, "SlapFing Bass RX": 5, "SlapPick Bass RX": 5,
    "Clean Guitar RX1": 7, "Clean Funk RX2": 8,
    "Strings Ens. RX": 8, "Concert Str.RX": 8, "Scat Voices RX": 8,
    "Banjo RX": 6,
}
DEFAULT_OSC_RX = 6      # conservative mean for an unlisted RX program
DEFAULT_OSC_DNC = 4
DEFAULT_OSC_PLAIN = 2   # typical stereo program (L/R oscillator pair)
DEFAULT_OSC_DRUMKIT = 1  # per struck key; multi-layer keys are counted below


def osc_count(sound_name: str, is_rx: bool = False, is_dnc: bool = False,
              is_drum: bool = False) -> int:
    if sound_name in OSC_COUNT_BY_SOUND:
        return OSC_COUNT_BY_SOUND[sound_name]
    if is_drum:
        return DEFAULT_OSC_DRUMKIT
    if is_rx:
        return DEFAULT_OSC_RX
    if is_dnc:
        return DEFAULT_OSC_DNC
    return DEFAULT_OSC_PLAIN


@dataclass
class VoiceReport:
    peak: int = 0
    peak_tick: int = 0
    over_budget_ticks: int = 0
    total_ticks: int = 0
    per_channel_peak: Dict[int, int] = field(default_factory=dict)
    timeline_top: List[Tuple[int, int]] = field(default_factory=list)

    @property
    def headroom(self) -> int:
        return PA800_MAX_VOICES - self.peak

    @property
    def over_budget_pct(self) -> float:
        return 100.0 * self.over_budget_ticks / self.total_ticks if self.total_ticks else 0.0

    def verdict(self) -> str:
        if self.peak <= PA800_MAX_VOICES * 0.75:
            return "OK"
        if self.peak <= PA800_MAX_VOICES:
            return "TIGHT"
        return "VOICE STEALING"


def simulate(path: str, osc_per_channel: Dict[int, int],
             release_ticks: int = 0) -> VoiceReport:
    """Replay the file and track simultaneous oscillator allocation.

    `osc_per_channel` maps a MIDI channel to the oscillator count of the sound
    assigned to it by the remap plan.  `release_ticks` optionally models the
    amplifier release tail, during which voices are still allocated.
    """
    mid = mido.MidiFile(path)
    events: List[Tuple[int, int, int]] = []  # (tick, delta_voices, channel)
    for track in mid.tracks:
        tick = 0
        for msg in track:
            tick += msg.time
            if msg.type == "note_on" and msg.velocity > 0:
                n = osc_per_channel.get(msg.channel, DEFAULT_OSC_PLAIN)
                events.append((tick, n, msg.channel))
            elif msg.type == "note_off" or (msg.type == "note_on" and msg.velocity == 0):
                n = osc_per_channel.get(msg.channel, DEFAULT_OSC_PLAIN)
                events.append((tick + release_ticks, -n, msg.channel))
    events.sort(key=lambda e: (e[0], e[1]))

    rep = VoiceReport()
    cur = 0
    per_ch: Dict[int, int] = {}
    last_tick = 0
    for tick, delta, ch in events:
        if tick > last_tick:
            span = tick - last_tick
            rep.total_ticks += span
            if cur > PA800_MAX_VOICES:
                rep.over_budget_ticks += span
            last_tick = tick
        cur += delta
        per_ch[ch] = per_ch.get(ch, 0) + delta
        rep.per_channel_peak[ch] = max(rep.per_channel_peak.get(ch, 0), per_ch[ch])
        if cur > rep.peak:
            rep.peak, rep.peak_tick = cur, tick
        rep.timeline_top.append((tick, cur))
    rep.timeline_top = sorted(rep.timeline_top, key=lambda x: -x[1])[:5]
    return rep
