"""Proven PA800 CBarc/OC31 codec and conservative container helpers.

The compressor/decompressor is a direct Python translation of the PA800
Librarian CBarc routines recovered in the project evidence.
"""
from __future__ import annotations
from dataclasses import dataclass
from pathlib import Path

class VerificationError(ValueError):
    pass


def _be32(data: bytes, offset: int) -> int:
    if offset < 0 or offset + 4 > len(data):
        raise VerificationError(f"BE32 outside buffer at {offset:#x}")
    return int.from_bytes(data[offset:offset + 4], "big")


def _barc_decompress(stream: bytes, capacity: int) -> bytes:
    """Translate CBarc.m_ifnBDeCompress (0x060007DE) exactly."""
    source = 0
    output = bytearray()

    def take_byte() -> int:
        nonlocal source
        if source >= len(stream):
            raise VerificationError("truncated CBarc byte")
        value = stream[source]
        source += 1
        return value

    def take_be16() -> int:
        return (take_byte() << 8) | take_byte()

    def check_capacity(count: int) -> None:
        if count < 0 or len(output) + count > capacity:
            raise VerificationError("CBarc output exceeds declared size")

    while source < len(stream):
        control = take_byte()

        if control < 16:
            if control >= 2:
                count = control + 2
            elif control == 0:
                count = take_byte() + 18
            else:
                count = take_be16()
                if count == 0:
                    break

            check_capacity(count)
            if source + count > len(stream):
                raise VerificationError("truncated CBarc literal")
            output.extend(stream[source:source + count])
            source += count
            continue

        if control >= 64:
            control = (control << 8) | take_byte()
            count = (control >> 13) + 1
            match = len(output) - ((control >> 2) & 0x7FF) - 1
        elif control >= 32:
            count = control & 0x1F
            if count >= 2:
                count += 2
            elif count == 0:
                count = take_byte() + 34
            else:
                count = take_be16()
            match = len(output) - (take_be16() >> 2) - 1
        else:
            count = control & 0x07
            if count >= 2:
                count += 2
            elif count == 0:
                count = take_byte() + 10
            else:
                count = take_be16()
            match = len(output) - (take_be16() >> 2) - 16385
            if control & 0x08:
                match -= 16384

        check_capacity(count)
        if match < 0:
            raise VerificationError("CBarc match precedes output buffer")
        for _ in range(count):
            if match >= len(output):
                raise VerificationError("invalid CBarc overlapping match")
            output.append(output[match])
            match += 1

        trailing = stream[source - 1] & 0x03
        check_capacity(trailing)
        if source + trailing > len(stream):
            raise VerificationError("truncated CBarc trailing literal")
        output.extend(stream[source:source + trailing])
        source += trailing

    if source != len(stream):
        raise VerificationError(
            f"CBarc left {len(stream) - source} compressed bytes unread"
        )
    if len(output) != capacity:
        raise VerificationError(
            f"CBarc produced {len(output)} bytes, expected {capacity}"
        )
    return bytes(output)


def _barc_literal_compress(data: bytes) -> bytes:
    """Emit a valid CBarc stream using only the proven Tag-1 literal form.

    CBarc.m_vfnWriteTag1 uses control byte 0x01 followed by a BE16 literal
    length for long runs. A zero length terminates the stream. This encoder is
    intentionally non-optimal but avoids every unproven match-finder detail.
    """
    output = bytearray()
    position = 0
    remaining = len(data)
    while remaining > 0xFFFF:
        count = 0xFFFC
        output.extend(b"\x01\xFF\xFC")
        output.extend(data[position:position + count])
        position += count
        remaining -= count

    if remaining:
        if 4 <= remaining < 18:
            output.append(remaining - 2)
        elif 18 <= remaining < 272:
            output.extend((0x00, remaining - 18))
        else:
            # The original writer reaches this branch for 272..65535.
            # Counts 1..3 are not normally emitted, but the decoder's proven
            # long-literal form remains unambiguous for them as well.
            output.append(0x01)
            output.extend(remaining.to_bytes(2, "big"))
        output.extend(data[position:position + remaining])
    output.extend(b"\x01\x00\x00")
    return bytes(output)


def _barc_korg_compress(data: bytes) -> bytes:
    """Translate CBarc.m_ifnBCompress (0x060007DD) and its tag writers."""

    def index_at(position: int) -> int:
        value = (((data[position + 2] << 6) ^ data[position + 1]) << 5)
        value ^= data[position]
        return ((value * 33) >> 5) & 0x3FFF

    output = bytearray()

    def write_tag1(start: int, count: int) -> int:
        while count > 0xFFFF:
            output.extend(b"\x01\xFF\xFC")
            output.extend(data[start:start + 0xFFFC])
            start += 0xFFFC
            count -= 0xFFFC
        if count < 18:
            output.append(count - 2)
        elif count < 272:
            output.extend((0, count - 18))
        else:
            output.append(1)
            output.extend(count.to_bytes(2, "big"))
        output.extend(data[start:start + count])
        return start + count

    def write_tag2(distance: int, length: int) -> None:
        packed = ((length - 1) << 13) | ((distance - 1) << 2)
        output.extend(packed.to_bytes(2, "big"))

    def write_tag3(distance: int, length: int) -> None:
        distance -= 1
        if length < 34:
            output.append(0x20 | (length - 2))
        elif length < 290:
            output.extend((0x20, length - 34))
        else:
            output.append(0x21)
            output.extend(length.to_bytes(2, "big"))
        output.extend((distance << 2).to_bytes(2, "big"))

    def write_tag4(distance: int, length: int) -> None:
        distance -= 16385
        control = 0x10
        if distance >= 16384:
            distance -= 16384
            control |= 0x08
        if length < 10:
            output.append(control | (length - 2))
        elif length < 266:
            output.extend((control, length - 10))
        else:
            output.append(control | 0x01)
            output.extend(length.to_bytes(2, "big"))
        output.extend((distance << 2).to_bytes(2, "big"))

    table: list[int | None] = [None] * 16384
    current = 0
    literal_start = 0
    end = len(data)
    search_end = end - 13

    if len(data) > 17:
        for _ in range(4):
            table[index_at(current)] = current
            current += 1

        while current < search_end:
            table_index = index_at(current)
            previous = table[table_index]
            table[table_index] = current
            matched = False

            if previous is not None:
                distance = current - previous
                if (
                    distance <= 49152
                    and (distance <= 2048 or data[previous + 3] == data[current + 3])
                    and data[previous:previous + 3] == data[current:current + 3]
                ):
                    pending = current - literal_start
                    if pending:
                        if pending < 4:
                            if not output:
                                raise VerificationError(
                                    "CBarc trailing literal has no prior match tag"
                                )
                            output[-1] |= pending
                            output.extend(data[literal_start:current])
                            literal_start = current
                        else:
                            literal_start = write_tag1(literal_start, pending)

                    match_start = current
                    candidate = previous + 3
                    current += 3
                    while (
                        current < end
                        and current - match_start < 0xFFFF
                        and data[candidate] == data[current]
                    ):
                        candidate += 1
                        current += 1
                    length = current - match_start

                    if length >= 9:
                        if distance <= 16384:
                            write_tag3(distance, length)
                        else:
                            write_tag4(distance, length)
                    elif distance <= 2048:
                        write_tag2(distance, length)
                    elif distance <= 16384:
                        write_tag3(distance, length)
                    else:
                        write_tag4(distance, length)

                    literal_start = match_start + 1
                    if length > 49151:
                        literal_start = current - 49151
                    while literal_start < current:
                        if literal_start + 2 < end:
                            table[index_at(literal_start)] = literal_start
                        literal_start += 1
                    matched = True

            current += 0 if matched else 1

    remaining = end - literal_start
    if remaining:
        if remaining < 4:
            output.append(1)
            output.extend(remaining.to_bytes(2, "big"))
            output.extend(data[literal_start:])
        else:
            write_tag1(literal_start, remaining)
    output.extend(b"\x01\x00\x00")
    return bytes(output)


def _oc31_encode(data: bytes) -> bytes:
    checksum = 0
    for value in data:
        checksum ^= value
    return (
        b"OC31"
        + len(data).to_bytes(4, "little")
        + _barc_literal_compress(data)
        + bytes([checksum])
    )


def _oc31_encode_korg(data: bytes) -> bytes:
    """Emit OC31 using the translated Librarian CBarc match finder."""
    checksum = 0
    for value in data:
        checksum ^= value
    return (
        b"OC31"
        + len(data).to_bytes(4, "little")
        + _barc_korg_compress(data)
        + bytes([checksum])
    )



class CodecError(VerificationError):
    """Public alias used by the editor."""


@dataclass
class Node:
    offset: int
    ident: int
    version: int
    release: int
    flags: int
    length: int
    end: int

    @property
    def header(self) -> bytes:
        return bytes((self.ident, self.version, self.release, self.flags)) + self.length.to_bytes(4, "big")


def walk_children(data: bytes | bytearray, offset: int = 0) -> list[Node]:
    """Walk 8-byte-header children under *offset*, validating every boundary."""
    if offset < 0 or offset + 8 > len(data):
        raise CodecError("node header outside buffer")
    end = offset + 8 + _be32(data, offset + 4)
    if end > len(data):
        raise CodecError("node exceeds buffer")
    out: list[Node] = []
    pos = offset + 8
    while pos < end:
        if pos + 8 > end:
            raise CodecError("truncated child header")
        length = _be32(data, pos + 4)
        child_end = pos + 8 + length
        if child_end > end:
            raise CodecError("child exceeds parent")
        out.append(Node(pos, data[pos], data[pos+1], data[pos+2], data[pos+3], length, child_end))
        pos = child_end
    if pos != end:
        raise CodecError("child traversal did not end at parent")
    return out


def decode_oc(raw: bytes) -> tuple[bytes, str]:
    """Decode an OC31/OC32 resource and verify its XOR checksum."""
    if len(raw) < 9 or raw[:4] not in (b"OC31", b"OC32"):
        raise CodecError("resource is not OC31/OC32")
    size = int.from_bytes(raw[4:8], "little")
    decoded = _barc_decompress(raw[8:-1], size)
    checksum = 0
    for value in decoded:
        checksum ^= value
    if checksum != raw[-1]:
        raise CodecError("OC31/OC32 checksum mismatch")
    return decoded, raw[:4].decode("ascii")


def encode_oc(decoded: bytes | bytearray, magic: str = "OC31") -> bytes:
    """Encode with the translated native match finder and verify the result."""
    if magic not in ("OC31", "OC32"):
        raise CodecError(f"unsupported resource wrapper {magic}")
    data = bytes(decoded)
    checksum = 0
    for value in data:
        checksum ^= value
    raw = magic.encode("ascii") + len(data).to_bytes(4, "little") + _barc_korg_compress(data) + bytes((checksum,))
    check, _ = decode_oc(raw)
    if check != data:
        raise CodecError("internal OC encoder round-trip failed")
    return raw


def split_oc20_pages(raw: bytes) -> list[bytes]:
    """Split a factory-bank OC20 stream at page headers."""
    starts: list[int] = []
    pos = 0
    while True:
        pos = raw.find(b"OC20", pos)
        if pos < 0:
            break
        starts.append(pos)
        pos += 4
    if not starts or starts[0] != 0:
        raise CodecError("not an OC20 factory stream")
    return [raw[start:(starts[i+1] if i+1 < len(starts) else len(raw))] for i, start in enumerate(starts)]


def decode_oc20_page(raw: bytes) -> bytes:
    """Decode one OC20 page (same token grammar as OC31, no trailing XOR)."""
    if len(raw) < 8 or raw[:4] != b"OC20":
        raise CodecError("invalid OC20 page")
    size = int.from_bytes(raw[4:8], "little")
    # Factory pages may carry a short opaque trailer after the CBarc stop tag.
    # Find that boundary conservatively; 64 bytes covers every proven page.
    stream = raw[8:]
    for trim in range(0, min(64, len(stream)) + 1):
        candidate = stream[:len(stream)-trim] if trim else stream
        try:
            return _barc_decompress(candidate, size)
        except VerificationError:
            pass
    raise CodecError("OC20 page has no valid CBarc boundary")


def decode_oc20_file(raw: bytes) -> bytes:
    return b"".join(decode_oc20_page(page) for page in split_oc20_pages(raw))
