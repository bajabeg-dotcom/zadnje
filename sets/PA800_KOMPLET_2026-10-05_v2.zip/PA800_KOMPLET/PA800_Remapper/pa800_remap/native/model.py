"""Editable native PA800 Style-bank model (fixed-width semantic edits)."""
from __future__ import annotations
from dataclasses import dataclass, field
from pathlib import Path
from typing import Iterable

from .codec import CodecError, Node, decode_oc, decode_oc20_file, encode_oc, walk_children, _be32
from .events import EventError, mutate_note_on_velocities, parse_pattern_stream

ROLES = ("Drum", "Percussion", "Bass", "Acc1", "Acc2", "Acc3", "Acc4", "Acc5")
ELEMENT_NAMES = (
    "Variation 1", "Variation 2", "Variation 3", "Variation 4",
    "Intro 1", "Intro 2", "Fill 1", "Fill 2", "Ending 1",
    "Ending 2", "Break", "Intro 3", "Ending 3",
    "Element 14", "Element 15",
)


class ModelError(ValueError):
    pass


def _signed(value: int) -> int:
    return value - 256 if value >= 128 else value


def _raw_signed(value: int) -> int:
    if not -128 <= value <= 127:
        raise ModelError("signed value outside -128..127")
    return value & 0xFF


def _clip(value: int, low: int, high: int, field_name: str) -> int:
    value = int(value)
    if not low <= value <= high:
        raise ModelError(f"{field_name}: expected {low}..{high}, got {value}")
    return value


@dataclass
class OuterChild:
    index: int
    node: Node
    original: bytes
    resource: "CompressedResource | None" = None

    def build(self) -> bytes:
        payload = self.resource.encoded() if self.resource is not None else self.original[8:]
        return self.original[:4] + len(payload).to_bytes(4, "big") + payload


@dataclass
class CompressedResource:
    ident: int
    decoded: bytearray
    magic: str
    original_decoded: bytes

    @classmethod
    def from_raw(cls, ident: int, raw: bytes) -> "CompressedResource":
        decoded, magic = decode_oc(raw)
        return cls(ident, bytearray(decoded), magic, decoded)

    @property
    def dirty(self) -> bool:
        return bytes(self.decoded) != self.original_decoded

    def encoded(self) -> bytes:
        return encode_oc(self.decoded, self.magic) if self.dirty else self.original_raw

    # Set by Bank.load to preserve unmodified resources byte-for-byte.
    original_raw: bytes = field(default=b"", repr=False)


@dataclass
class TrackSettings:
    expression: int
    msb: int
    lsb: int
    program: int
    key_low: int
    key_high: int
    rx_noise: int
    humanize: int
    capo: int
    ntt_ntr_packed: int
    guitar_string_low: int | None = None

    @property
    def selector(self) -> tuple[int, int, int]:
        return self.msb, self.lsb, self.program


class TrackDataView:
    """TrackData v4/v5 view: 8×6 TrackInfo + 8×3 extras + packed bytes.

    Column-major geometry (evidence: `INIT_STY_OUT` matched pairs, annex
    V-1.7 in RULES_STYLE_OPTIMIZER.md):
        48 = 8×6 TrackInfo                          (v2, legacy/pa1x)
        80 = 48 + 8×u1[3] + 8×ntt                   (v4, Pa800)
        88 = 80 + 8×u3                              (v5, Pa3X)
        96 = 88 + 8×u4                              (v5, Pa4X / PA700 / PA1000)
    The u4 column (bytes 88..95) is all-zero in 1275/1275 reference
    elements; it is preserved on read/write but never interpreted.
    """
    LENGTHS = (48, 80, 88, 96)

    def __init__(self, data: bytearray, start: int, length: int):
        if length not in self.LENGTHS:
            raise ModelError(f"unsupported TrackData length {length}")
        self.data, self.start, self.length = data, start, length

    def get(self, track: int) -> TrackSettings:
        _clip(track, 0, 7, "track")
        p = self.start + track * 6
        q = self.start + 48 + track * 3
        extras = (self.data[q], self.data[q+1], self.data[q+2]) if self.length >= 80 else (0, 0, 0)
        packed = self.data[self.start + 72 + track] if self.length >= 80 else 0
        return TrackSettings(
            self.data[p], self.data[p+1], self.data[p+2], self.data[p+3],
            self.data[p+4], self.data[p+5], extras[0], extras[1], extras[2], packed,
            self.data[self.start + 80 + track] if self.length >= 88 else None,
        )

    def set(self, track: int, values: TrackSettings) -> None:
        _clip(track, 0, 7, "track")
        fields = (
            (values.expression, 0, 127, "Expression"), (values.msb, 0, 127, "MSB"),
            (values.lsb, 0, 127, "LSB"), (values.program, 0, 127, "Program"),
            (values.key_low, 0, 127, "Key Low"), (values.key_high, 0, 127, "Key High"),
            # These three fields are semantic bytes; converted PA3X Styles can
            # retain high-bit flags, so preserve the full native byte range.
            (values.rx_noise, 0, 255, "RX Noise"), (values.humanize, 0, 255, "Humanize"),
            (values.capo, 0, 255, "Capo"), (values.ntt_ntr_packed, 0, 255, "NTT/NTR packed"),
        )
        checked = [_clip(*item) for item in fields]
        if checked[4] > checked[5]:
            raise ModelError("Key Low must not exceed Key High")
        p = self.start + track * 6
        q = self.start + 48 + track * 3
        self.data[p:p+6] = bytes(checked[:6])
        if self.length >= 80:
            self.data[q:q+3] = bytes(checked[6:9])
            self.data[self.start + 72 + track] = checked[9]
        if self.length >= 88 and values.guitar_string_low is not None:
            self.data[self.start + 80 + track] = _clip(values.guitar_string_low, 0, 127, "Guitar String Low")
        # The u4 column (96 only, bytes 88..95) is untouched here: no modeled
        # field maps to it, so in-place edits preserve it byte for byte.


@dataclass
class ElementView:
    name: str
    index: int
    node: Node
    track_data: TrackDataView
    cv_nodes: list[Node]


@dataclass
class MixerSettings:
    volume: int
    pan: int
    fx_main: int
    fx_aux1: int
    fx_aux2: int
    detune: int
    octave: int
    pb_sensitivity: int
    input_trim: int
    eq_high: int
    eq_mid: int
    eq_low: int
    key_range_on: int


class CompanionView:
    """Proven type-09 style companion fields for Drum..Acc5."""
    MIXER_START = 217
    MIXER_STRIDE = 37

    def __init__(self, resource: CompressedResource):
        self.resource = resource
        self.data = resource.decoded
        self.layout = "flat"
        self.mixer_positions: list[int] = []
        self.common_positions: list[list[int]] = []
        self.key_range_positions: list[int] | None = None
        if self.data[:4] == bytes.fromhex("00 01 00 08"):
            if len(self.data) < self.MIXER_START + 8 * self.MIXER_STRIDE:
                raise ModelError("type-09 PerformanceData is too short")
            performance_length = _be32(self.data, 4)
            self.common_offset = 8 + performance_length
            if self.common_offset + 8 > len(self.data):
                raise ModelError("type-09 CommonInfo boundary is invalid")
            common_tracks = self.common_offset + 73
            if common_tracks + 8 * 18 > len(self.data):
                raise ModelError("type-09 track EQ records are incomplete")
            self.mixer_positions = [self.MIXER_START + i * self.MIXER_STRIDE for i in range(8)]
            self.common_positions = [[common_tracks + i * 18] for i in range(8)]
            self.key_range_positions = [39 + i for i in range(8)]
        else:
            # Older USER-bank companion: root/id1/id2/id5 then eight id9
            # track chunks. Each chunk contains the same proven 37-byte mixer
            # record and eight 22-byte Common/EQ frames.
            self.layout = "legacy"
            try:
                root = walk_children(self.data)
                wrapper = next(n for n in root if n.ident == 1)
                style_node = next(n for n in walk_children(self.data, wrapper.offset) if n.ident == 2)
                track_container = next(n for n in walk_children(self.data, style_node.offset) if n.ident == 5)
                track_nodes = [n for n in walk_children(self.data, track_container.offset) if n.ident == 9]
            except (StopIteration, CodecError) as exc:
                raise ModelError("unrecognized type-09 hierarchy") from exc
            if len(track_nodes) != 8:
                raise ModelError("legacy type-09 does not contain eight track chunks")
            for node in track_nodes:
                payload = node.offset + 8
                if node.length < 242:
                    raise ModelError("legacy type-09 track chunk is too short")
                self.mixer_positions.append(payload + 5)
                self.common_positions.append([payload + 65 + i * 22 for i in range(8)])

    def get(self, track: int) -> MixerSettings:
        _clip(track, 0, 7, "track")
        p = self.mixer_positions[track]
        q = self.common_positions[track][0]
        d = self.data
        return MixerSettings(
            d[p+11], d[p+12] - 64, d[p+8], d[p+26], d[p+27], d[p+13] - 64,
            _signed(d[p+14]), d[p+35],
            (d[q+13] - 64) if self.layout == "legacy" else _signed(d[q+13]),
            _signed(d[q+14]),
            _signed(d[q+15]), _signed(d[q+16]),
            d[self.key_range_positions[track]] if self.key_range_positions else 1,
        )

    def set(self, track: int, values: MixerSettings) -> None:
        _clip(track, 0, 7, "track")
        p = self.mixer_positions[track]
        d = self.data
        d[p+11] = _clip(values.volume, 0, 127, "Volume")
        d[p+12] = _clip(values.pan + 64, 0, 127, "Pan")
        d[p+8] = _clip(values.fx_main, 0, 127, "FX Main")
        d[p+26] = _clip(values.fx_aux1, 0, 127, "FX Aux 1")
        d[p+27] = _clip(values.fx_aux2, 0, 127, "FX Aux 2")
        d[p+13] = _clip(values.detune + 64, 0, 127, "Detune")
        d[p+14] = _raw_signed(_clip(values.octave, -24, 24, "Octave transpose"))
        d[p+35] = _clip(values.pb_sensitivity, 0, 24, "PB sensitivity")
        trim_value = _clip(values.input_trim, -64 if self.layout == "legacy" else -99, 63 if self.layout == "legacy" else 28, "Input Trim")
        trim = (trim_value + 64) if self.layout == "legacy" else _raw_signed(trim_value)
        eq_high = _raw_signed(_clip(values.eq_high, -18, 18, "EQ High"))
        eq_mid = _raw_signed(_clip(values.eq_mid, -18, 18, "EQ Mid"))
        eq_low = _raw_signed(_clip(values.eq_low, -18, 18, "EQ Low"))
        for q in self.common_positions[track]:
            d[q+13], d[q+14], d[q+15], d[q+16] = trim, eq_high, eq_mid, eq_low
        if self.key_range_positions:
            d[self.key_range_positions[track]] = _clip(values.key_range_on, 0, 1, "Key Range On")


class StyleResource:
    def __init__(self, resource: CompressedResource, ordinal: int):
        self.resource, self.ordinal = resource, ordinal
        self.data = resource.decoded
        root = walk_children(self.data)
        if len(root) < 2 or root[0].ident != 1 or root[1].ident != 2:
            raise ModelError("type-06 lacks StyleInfo/PatternData")
        style_info = self.data[root[0].offset + 8:root[0].end]
        name_len = style_info[0] if style_info else 0
        self.name = bytes(style_info[1:1+name_len]).decode("latin-1", "replace").rstrip("\x00 ") or f"Style {ordinal+1}"
        self.pattern_pool = root[1]
        element_nodes = [node for node in root if node.ident == 3]
        indices = self._element_indices(style_info, len(element_nodes), self.data[1])
        self.elements: list[ElementView] = []
        for sequence, node in enumerate(element_nodes):
            children = walk_children(self.data, node.offset)
            if len(children) < 2:
                raise ModelError("Style Element lacks TrackData")
            td = children[1]
            track_data = TrackDataView(self.data, td.offset + 8, td.length)
            element_index = indices[sequence] if sequence < len(indices) else sequence
            label = ELEMENT_NAMES[element_index] if element_index < len(ELEMENT_NAMES) else f"Element {element_index+1}"
            self.elements.append(ElementView(label, element_index, node, track_data, children[2:]))

    @staticmethod
    def _element_indices(info: bytes | bytearray, count: int, style_version: int) -> list[int]:
        # v4 stores the BE16 presence mask exactly three bytes after the name.
        # v5 keeps a release-specific mirror at the end of StyleInfo. Avoid a
        # sliding-window search: overlapping bytes can have the same popcount
        # and produce a shifted, musically wrong element map.
        name_end = 1 + (info[0] if info else 0)
        positions = [name_end + 3]
        if style_version >= 5:
            positions.insert(0, len(info) - 2)
        for pos in positions:
            if 0 <= pos <= len(info) - 2:
                value = int.from_bytes(info[pos:pos+2], "big")
                if value.bit_count() == count:
                    return [i for i in range(16) if value & (1 << i)]
        return list(range(count))

    def pattern_role_map(self) -> dict[int, set[int]]:
        pool = walk_children(self.data, self.pattern_pool.offset)
        if not pool or pool[0].ident != 1:
            raise ModelError("PatternData lacks PatternInfo")
        info = self.data[pool[0].offset + 8:pool[0].end]
        if len(info) < 4 or (len(info)-4) % 2:
            raise ModelError("invalid PatternInfo")
        pattern_count = int.from_bytes(info[0:2], "big")
        association_count = int.from_bytes(info[2:4], "big")
        indices = [int.from_bytes(info[p:p+2], "big") for p in range(4, len(info), 2)]
        if pattern_count != len(pool)-1 or association_count != len(indices):
            raise ModelError("PatternInfo counts mismatch")
        cursor = 0
        result: dict[int, set[int]] = {i: set() for i in range(1, pattern_count+1)}
        for element in self.elements:
            for cv in element.cv_nodes:
                start = cv.offset + 8
                stream_len = _be32(self.data, start + 4)
                tail = start + 8 + stream_len
                if tail >= cv.end:
                    raise ModelError("CV reference tail outside object")
                count = self.data[tail]
                if tail + 1 + count*2 != cv.end:
                    raise ModelError("CV reference tail length mismatch")
                for i in range(count):
                    if cursor >= len(indices):
                        raise ModelError("Pattern association underflow")
                    pattern_index = indices[cursor]
                    cursor += 1
                    track = self.data[tail + 1 + i*2 + 1]
                    if not 1 <= pattern_index <= pattern_count or not 0 <= track <= 7:
                        raise ModelError("invalid Pattern association")
                    result[pattern_index].add(track)
        if cursor != len(indices):
            raise ModelError("unused Pattern associations")
        return result

    def validate_events(self) -> tuple[int, int]:
        patterns = walk_children(self.data, self.pattern_pool.offset)[1:]
        events = 0
        for pattern in patterns:
            start = pattern.offset + 8
            duration = _be32(self.data, start)
            length = _be32(self.data, start + 4)
            stream = self.data[start + 8:start + 8 + length]
            events += len(parse_pattern_stream(stream, duration))
        return len(patterns), events

    def optimize_velocity(self, roles: set[int], strength: int = 35) -> dict[str, int]:
        strength = _clip(strength, 0, 100, "strength")
        role_map = self.pattern_role_map()
        patterns = walk_children(self.data, self.pattern_pool.offset)[1:]
        changed = skipped = touched = 0
        for index, pattern in enumerate(patterns, start=1):
            active = role_map.get(index, set()) & roles
            if not active:
                continue
            # Pattern types are role-separated by native references. A Drum
            # pattern may be shared by Drum/Perc; process it only once.
            role = 0 if 0 in active else min(active)
            start = pattern.offset + 8
            duration = _be32(self.data, start)
            length = _be32(self.data, start + 4)
            raw = bytearray(self.data[start + 8:start + 8 + length])
            transform = _zone_transform(role, strength)
            c, s = mutate_note_on_velocities(raw, duration, transform)
            if c:
                self.data[start + 8:start + 8 + length] = raw
                touched += 1
            changed += c
            skipped += s
        return {"patterns": touched, "changed": changed, "skipped": skipped}


def _zone_transform(role: int, strength: int):
    bass_zones = ((1, 22), (23, 52), (53, 93), (94, 113), (114, 127))
    snare = ((1, 25), (26, 46), (47, 67), (68, 88), (89, 109), (110, 127))
    closed_hat = ((1, 67), (68, 86), (87, 105), (106, 127))
    two_layer_hat = ((1, 67), (68, 127))

    def choose(pitch: int, velocity: int) -> tuple[int, int]:
        if role == 2:
            if pitch >= 96:  # Picked Bass RX noise map C7..G9: retain dynamics
                return 1, 127
            zones = bass_zones
        elif role in (0, 1):
            if pitch in (38, 40):
                zones = snare
            elif pitch == 42:
                zones = closed_hat
            elif pitch in (44, 46):
                zones = two_layer_hat
            else:
                return 1, 127
        else:
            return 1, 127
        for low, high in zones:
            if low <= velocity <= high:
                return low, high
        return 1, 127

    def transform(pitch: int, velocity: int) -> int:
        low, high = choose(pitch, velocity)
        center = (low + high) / 2.0
        value = round(velocity * (100-strength) / 100.0 + center * strength / 100.0)
        return max(low, min(high, value))
    return transform


@dataclass
class StyleEntry:
    ordinal: int
    style: StyleResource
    companion: CompanionView | None


class NativeStyleBank:
    """One direct USER .STY bank or read-only OC20 factory reference bank."""
    def __init__(self):
        self.path: Path | None = None
        self.original = b""
        self.logical = b""
        self.editable = True
        self.children: list[OuterChild] = []
        self.entries: list[StyleEntry] = []
        self.warnings: list[str] = []

    @classmethod
    def load(cls, path: str | Path) -> "NativeStyleBank":
        self = cls()
        self.path = Path(path)
        self.original = self.path.read_bytes()
        if self.original.startswith(b"OC20"):
            self.logical = decode_oc20_file(self.original)
            self.editable = False
            self.warnings.append("Factory OC20 bank opened as read-only reference; export is disabled.")
        else:
            self.logical = self.original
        if len(self.logical) < 8 or self.logical[:4] != bytes.fromhex("01 00 01 14"):
            raise ModelError("not a PA800 native Style container")
        if _be32(self.logical, 4) != len(self.logical)-8:
            raise ModelError("root size does not match file size")
        nodes = walk_children(self.logical)
        style_resources: list[CompressedResource] = []
        companion_resources: list[CompressedResource] = []
        for i, node in enumerate(nodes):
            raw_node = self.logical[node.offset:node.end]
            outer = OuterChild(i, node, raw_node)
            if node.ident in (6, 9):
                payload = raw_node[8:]
                if payload[:4] in (b"OC31", b"OC32"):
                    resource = CompressedResource.from_raw(node.ident, payload)
                    resource.original_raw = payload
                    outer.resource = resource
                    (style_resources if node.ident == 6 else companion_resources).append(resource)
                elif not self.editable and ((node.ident == 6 and payload[:2] == b"\x01\x04") or
                                            (node.ident == 9 and payload[:2] == b"\x00\x01")):
                    # OC20 factory wrapping decompresses the complete outer
                    # bank, so its type-06/type-09 children are already plain.
                    resource = CompressedResource(node.ident, bytearray(payload), "", payload, payload)
                    outer.resource = resource
                    (style_resources if node.ident == 6 else companion_resources).append(resource)
            self.children.append(outer)
        for ordinal, resource in enumerate(style_resources):
            style = StyleResource(resource, ordinal)
            companion = None
            if ordinal < len(companion_resources):
                try:
                    companion = CompanionView(companion_resources[ordinal])
                except ModelError as exc:
                    self.warnings.append(f"{style.name}: type-09 is preserved but not editable ({exc}).")
            self.entries.append(StyleEntry(ordinal, style, companion))
        if not self.entries:
            raise ModelError("container has no decodable type-06 Style resources")
        if len(companion_resources) != len(style_resources):
            self.warnings.append("Type-06/type-09 counts differ; unmatched resources will be preserved.")
        return self

    @property
    def dirty(self) -> bool:
        return any(child.resource and child.resource.dirty for child in self.children)

    def snapshot(self) -> list[bytes | None]:
        return [bytes(child.resource.decoded) if child.resource else None for child in self.children]

    def restore(self, snapshot: list[bytes | None]) -> None:
        if len(snapshot) != len(self.children):
            raise ModelError("snapshot does not match this bank")
        for child, data in zip(self.children, snapshot):
            if child.resource is not None and data is not None:
                child.resource.decoded[:] = data

    def set_rx_presets(self, style_indices: Iterable[int], *, drum: bool, bass: bool,
                       all_elements: bool = True, element_index: int = 0) -> int:
        if not self.editable:
            raise ModelError("factory OC20 references are read-only")
        changed = 0
        for index in style_indices:
            entry = self.entries[index]
            elements = entry.style.elements if all_elements else [entry.style.elements[element_index]]
            for element in elements:
                if drum:
                    values = element.track_data.get(0)
                    target = (120, 0, 4)  # Pa800 manual: Pop Std. Kit RX
                    if values.selector != target:
                        values.msb, values.lsb, values.program = target
                        element.track_data.set(0, values); changed += 1
                if bass:
                    values = element.track_data.get(2)
                    # Reverse-evidence convention: UI/program listing 34 is
                    # stored as native Program byte 33 in TrackData.
                    target = (121, 10, 33)
                    if values.selector != target:
                        values.msb, values.lsb, values.program = target
                        element.track_data.set(2, values); changed += 1
        return changed

    def optimize_velocity(self, style_indices: Iterable[int], roles: set[int], strength: int) -> dict[str, int]:
        totals = {"styles": 0, "patterns": 0, "changed": 0, "skipped": 0}
        for index in style_indices:
            result = self.entries[index].style.optimize_velocity(roles, strength)
            totals["styles"] += 1
            for key in ("patterns", "changed", "skipped"):
                totals[key] += result[key]
        return totals

    def build(self) -> bytes:
        if not self.editable:
            raise ModelError("factory OC20 references are read-only")
        built: list[bytes] = []
        offsets: list[int] = []
        position = 8
        fe_child: OuterChild | None = None
        for child in self.children:
            if child.node.ident == 0xFE:
                fe_child = child
                continue
            node_bytes = child.build()
            if child.node.ident in (5, 6, 9):
                offsets.append(position)
            built.append(node_bytes)
            position += len(node_bytes)
        if fe_child is not None:
            payload = b"KBEG" + b"".join(value.to_bytes(4, "big") for value in offsets) + b"KEND" + len(offsets).to_bytes(4, "big")
            fe_bytes = fe_child.original[:4] + len(payload).to_bytes(4, "big") + payload
            built.append(fe_bytes)
        body = b"".join(built)
        return self.logical[:4] + len(body).to_bytes(4, "big") + body

    def export(self, path: str | Path) -> dict[str, int]:
        output = self.build()
        target = Path(path)
        target.write_bytes(output)
        # Full reopen is the transactional acceptance gate.
        reopened = NativeStyleBank.load(target)
        if len(reopened.entries) != len(self.entries):
            target.unlink(missing_ok=True)
            raise ModelError("export verification failed: Style count changed")
        checks = patterns = events = 0
        for entry in reopened.entries:
            p, e = entry.style.validate_events()
            patterns += p; events += e; checks += 1
        return {"bytes": len(output), "styles": checks, "patterns": patterns, "events": events}
