"""Vendored Korg Pa800 native .STY codec.

Source: PA800_Native_Style_Studio v1.1 (pa800_editor), built in the user's
earlier Style-creation session and validated there against 7 banks /
224 slots / 21,868 Patterns / 2,321,078 native events with a byte-identity
re-open test.  Imported here unchanged so the Style Optimizer and the
factory extractor read exactly the same bytes that tool wrote.
"""
from .model import NativeStyleBank, StyleResource, ROLES, ELEMENT_NAMES, ModelError  # noqa: F401
