"""PA800 native Pattern event framing and confidence-gated velocity mutation.

The parser is iterative and memoized. It preserves original byte framing; edits
replace only the seven payload bits of proven Note-On velocity bytes, so Pattern,
pool and resource sizes do not change.
"""
from __future__ import annotations
from dataclasses import dataclass
from typing import Callable


class EventError(ValueError):
    pass


@dataclass(frozen=True)
class Event:
    tick: int
    opcode: int
    data: tuple[int, ...]
    raw_positions: tuple[int, ...]
    mode: str
    channel: int | None = None
    meta_type: int | None = None

    @property
    def pitch(self) -> int | None:
        return self.data[0] if self.opcode in (0, 1) and self.data else None

    @property
    def velocity(self) -> int | None:
        return self.data[1] if self.opcode in (0, 1) and len(self.data) > 1 else None

    @property
    def velocity_position(self) -> int | None:
        return self.raw_positions[1] if self.opcode == 1 and len(self.raw_positions) > 1 else None


@dataclass(frozen=True)
class _State:
    pos: int
    last_base: int
    channel: int
    tick: int


def _delta(stream: bytes | bytearray, position: int) -> tuple[int, int]:
    value = 0
    while position < len(stream) and stream[position] & 0x80:
        value = (value << 7) | (stream[position] & 0x7F)
        position += 1
    return value, position


def _event_candidates(stream: bytes | bytearray, state: _State, duration: int) -> list[tuple[_State, Event]]:
    delta, p = _delta(stream, state.pos)
    tick = state.tick + delta
    if tick > duration or p >= len(stream):
        return []
    raw_opcode = stream[p]
    canonical: list[tuple[_State, Event]] = []
    exceptional: list[tuple[_State, Event]] = []
    allowed = {0, 1, 3, 6, 9, 0x40, 0x41, 0x43, 0x46, 0x49}

    def add(event: Event, next_state: _State, final_byte: int) -> None:
        # In canonical PA800 framing the last MIDI data byte carries bit 7.
        # Eleven proven corpus events use the fixed-width clear-final form;
        # keep those as lower-priority backtracking candidates.
        target = canonical if final_byte & 0x80 else exceptional
        target.append((next_state, event))

    # Explicit status, including channel-bearing 0x40|opcode framing.
    if raw_opcode in allowed:
        base = raw_opcode & 0x0F
        data_start = p + 1
        channel = state.channel
        mode = "explicit"
        valid = True
        if raw_opcode & 0x40:
            if data_start < len(stream) and stream[data_start] <= 0x0F:
                channel = stream[data_start]
                data_start += 1
                mode = "channel"
            elif data_start < len(stream) and 0x71 <= stream[data_start] <= 0x78:
                # Rare proven form: first data byte itself terminates the
                # opcode/channel state. Keep it byte-identical.
                mode = "opcode-final"
            else:
                valid = False
        if valid and base in (0, 1, 3, 6) and data_start + 2 <= len(stream):
            raw = stream[data_start:data_start + 2]
            if raw[0] < 0x80:
                event = Event(tick, base, tuple(v & 0x7F for v in raw),
                              (data_start, data_start + 1), mode, channel)
                add(event, _State(data_start + 2, base, channel, tick), raw[-1])
        elif valid and base == 9 and data_start + 3 <= len(stream):
            meta = stream[data_start] & 0x7F
            length = ((stream[data_start + 1] & 0x7F) << 7) | (stream[data_start + 2] & 0x7F)
            end = data_start + 3 + length
            if end <= len(stream):
                event = Event(tick, 9, tuple(stream[data_start + 3:end]),
                              tuple(range(data_start + 3, end)), "meta", channel, meta)
                canonical.append((_State(end, 9, channel, tick), event))

    # Running status: first clear byte is data[0] of the prior MIDI opcode.
    if state.last_base in (0, 1, 3, 6) and p + 2 <= len(stream) and stream[p] < 0x80:
        raw = stream[p:p + 2]
        event = Event(tick, state.last_base, tuple(v & 0x7F for v in raw),
                      (p, p + 1), "running", state.channel)
        add(event, _State(p + 2, state.last_base, state.channel, tick), raw[-1])

    # Running status with an explicit channel byte.
    if (state.last_base in (0, 1, 3, 6) and raw_opcode <= 0x0F and
            p + 3 <= len(stream) and stream[p + 1] < 0x80):
        raw = stream[p + 1:p + 3]
        event = Event(tick, state.last_base, tuple(v & 0x7F for v in raw),
                      (p + 1, p + 2), "running-channel", raw_opcode)
        add(event, _State(p + 3, state.last_base, raw_opcode, tick), raw[-1])
    # Converted Guitar-Mode streams use long runs of ``05 xx`` where xx is
    # a clear final data byte and the following high byte is the next delta.
    # Trying that as a channel prefix first causes combinatorial backtracking.
    # Prefer the stateful two-byte interpretation; exact EOT/tick validation
    # still rejects it if a stream genuinely uses channel 5.
    preferred = [item for item in exceptional
                 if raw_opcode == 5 and item[1].mode == "running"]
    rest = [item for item in exceptional if item not in preferred]
    return preferred + canonical + rest


def parse_pattern_stream(stream: bytes | bytearray, duration: int) -> list[Event]:
    """Parse a complete native Pattern stream without Python recursion."""
    start = _State(0, 1, 0, 0)  # proven initial implicit Note-On state
    stack: list[tuple[_State, list[tuple[_State, Event]], int]] = [
        (start, _event_candidates(stream, start, duration), 0)
    ]
    path: list[Event] = []
    dead: set[_State] = set()
    while stack:
        state, candidates, index = stack[-1]
        if state.pos == len(stream):
            if (state.tick == duration and path and path[-1].opcode == 9 and
                    path[-1].meta_type == 0x2F):
                return list(path)
            dead.add(state)
            stack.pop()
            if path:
                path.pop()
            continue
        if index >= len(candidates):
            dead.add(state)
            stack.pop()
            if path:
                path.pop()
            continue
        next_state, event = candidates[index]
        stack[-1] = (state, candidates, index + 1)
        if next_state in dead:
            continue
        path.append(event)
        stack.append((next_state, _event_candidates(stream, next_state, duration), 0))
    raise EventError(f"unresolved PA800 Pattern framing ({len(stream)} bytes, {duration} ticks)")


def mutate_note_on_velocities(stream: bytearray, duration: int,
                              transform: Callable[[int, int], int], *,
                              canonical_only: bool = True) -> tuple[int, int]:
    """Mutate Note-On velocities in place; return ``(changed, skipped)``."""
    events = parse_pattern_stream(stream, duration)
    changed = skipped = 0
    for event in events:
        pos = event.velocity_position
        if pos is None or event.velocity is None or event.pitch is None or event.velocity == 0:
            continue
        if canonical_only and not (stream[pos] & 0x80):
            skipped += 1
            continue
        value = max(1, min(127, int(transform(event.pitch, event.velocity))))
        if value != event.velocity:
            stream[pos] = (stream[pos] & 0x80) | value
            changed += 1
    parse_pattern_stream(stream, duration)
    return changed, skipped
