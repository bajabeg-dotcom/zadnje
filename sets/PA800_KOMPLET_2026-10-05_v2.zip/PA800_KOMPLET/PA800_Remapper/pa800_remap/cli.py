"""Command line interface for the Pa800 remapper."""

from __future__ import annotations

import argparse
import sys
from pathlib import Path

from .remap import RemapBeforeOptimizeForbidden, remap_file, save_report
from .rules import Profile
from .sounddb import autoload
from .trackparams import FactoryProfileSet


def main(argv=None) -> int:
    p = argparse.ArgumentParser(prog="pa800-remap",
                                description="Full Korg Pa800 sound remap (M-series rules)")
    p.add_argument("input", help="optimized MIDI file")
    p.add_argument("-o", "--output", help="output MIDI file")
    p.add_argument("-l", "--sound-list", help="PA800_FACTORY_SOUND_LIST_CC00_CC32_PC.txt")
    p.add_argument("-p", "--profile", default=Profile.SAFE.value,
                   choices=[x.value for x in Profile])
    p.add_argument("--articulated", action="store_true",
                   help="articulation layer present -> RX allowed (M-000.1)")
    p.add_argument("--not-optimized", action="store_true",
                   help="declare the song is NOT optimized (will be refused, M-000.3)")
    p.add_argument("--drum-kit", help="drum kit name from the sound list")
    p.add_argument("--mix-init", action="store_true", help="write CC7/CC10 init block (M-043)")
    p.add_argument("--dry-run", action="store_true")
    p.add_argument("--no-autofix", action="store_true", help="iskljuci K-seriju")
    p.add_argument("--no-factory-params", action="store_true",
                   help="ne upisuj CC7/10/11/91/93 iz Factory profila (K-09)")
    p.add_argument("--no-velocity", action="store_true", help="ne diraj velocity (K-08)")
    p.add_argument("--no-key-range", action="store_true", help="ne primjenjuj Key Range (K-01)")
    p.add_argument("--factory-profiles", help="JSON sa izmjerenim Factory profilima")
    p.add_argument("--report", action="store_true", help="write .report.txt / .report.json")
    a = p.parse_args(argv)

    db = autoload()
    if a.sound_list:
        n = db.load_factory_list(a.sound_list)
        print(f"sound list: +{n} bindings ({db.stats['total']} total)")

    fps = FactoryProfileSet()
    if a.factory_profiles:
        k = fps.load(a.factory_profiles)
        print(f"factory profiles: {k} uloga ucitano iz {a.factory_profiles}")
    else:
        print("factory profiles: PROVISIONAL (nisu jos izvuceni iz Factory Styles)")

    out = a.output or str(Path(a.input).with_name(Path(a.input).stem + "_PA800.mid"))
    kit = db.find(a.drum_kit) if a.drum_kit else None
    if a.drum_kit and kit is None:
        print(f"!! drum kit '{a.drum_kit}' not found in the database", file=sys.stderr)
        return 2

    try:
        res = remap_file(a.input, out, db, profile=Profile(a.profile),
                         articulated=a.articulated, optimized=not a.not_optimized,
                         drum_kit=kit, write_mix_init=a.mix_init, dry_run=a.dry_run,
                         run_autofix=not a.no_autofix,
                         factory_params=not a.no_factory_params,
                         velocity_envelope=not a.no_velocity,
                         key_range=not a.no_key_range,
                         factory_profiles=fps)
    except RemapBeforeOptimizeForbidden as e:
        print(f"BLOCKED (M-000.3): {e}", file=sys.stderr)
        return 3

    print(res.report_text())
    if a.report:
        t, j = save_report(res, res.output_path or a.input)
        print(f"\nreport: {t}\n        {j}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
