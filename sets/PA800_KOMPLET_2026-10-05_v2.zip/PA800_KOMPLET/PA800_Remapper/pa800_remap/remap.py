"""MIDI remapping engine — applies the M-series rules to a Standard MIDI File."""

from __future__ import annotations

import json
from dataclasses import dataclass, field
from pathlib import Path
from typing import Dict, List, Optional, Tuple

import mido

from .autofix import AutofixReport, autofix
from .rules import NOISE_ZONE, Decision, MappingEngine, Profile
from .sounddb import DRUM_MSB, TONAL_MSB, Sound, SoundDB
from .trackparams import FactoryProfileSet, Role, TrackProfile, role_from_pc

DRUM_CHANNEL = 9  # MIDI channel 10, zero-based (rule M-020)


class RemapBeforeOptimizeForbidden(RuntimeError):
    """Rule M-000.3."""


@dataclass
class ChannelInfo:
    channel: int
    track_index: int
    first_tick: int
    program: int = 0
    cc00: Optional[int] = None
    cc32: Optional[int] = None
    note_count: int = 0
    noise_notes: int = 0
    has_dnc_cc: bool = False


@dataclass
class RemapResult:
    decisions: List[Decision] = field(default_factory=list)
    verification: Dict[str, object] = field(default_factory=dict)
    output_path: Optional[str] = None
    profile_used: str = ""
    db_source: str = ""
    autofix: Optional[AutofixReport] = None
    track_profiles: Dict[int, dict] = field(default_factory=dict)

    def report_dict(self) -> dict:
        return {
            "profile_used": self.profile_used,
            "sound_database": self.db_source,
            "changes": [d.as_dict() for d in self.decisions],
            "track_parameters": self.track_profiles,
            "autofix": self.autofix.to_dict() if self.autofix else None,
            "verification": self.verification,
        }

    def report_text(self) -> str:
        lines = [
            "PA800 REMAP REPORT",
            "=" * 72,
            f"Profile : {self.profile_used}",
            f"Sound DB: {self.db_source}",
            "",
            f"{'Trk':>3} {'Ch':>3}  {'before':<14} {'after':<14} {'rule':<8} name",
            "-" * 72,
        ]
        for d in self.decisions:
            before = f"{d.before_cc00 if d.before_cc00 is not None else '-'}." \
                     f"{d.before_cc32 if d.before_cc32 is not None else '-'}.{d.before_pc}"
            lines.append(f"{d.track_index:>3} {d.channel+1:>3}  {before:<14} "
                         f"{d.sound.address:<14} {d.rule_id:<8} {d.sound.name}")
            for w in d.warnings:
                lines.append(f"{'':>8}! {w}")
        if self.track_profiles:
            lines += ["", "FACTORY TRACK PARAMETERS (F-02 .. F-13)", "-" * 72,
                      f"{'Ch':>3} {'role':<11} {'CC7':>4}{'CC10':>5}{'CC11':>5}"
                      f"{'CC91':>5}{'CC93':>5}  {'key range':<12} {'vel env':<14} evidence"]
            for ch, p in sorted(self.track_profiles.items()):
                v = p["velocity"]
                lines.append(
                    f"{ch+1:>3} {p['role']:<11} {p['volume']:>4}{p['pan']:>5}"
                    f"{p['expression']:>5}{p['reverb_send']:>5}{p['chorus_send']:>5}  "
                    f"{str(p['key_low'])+'..'+str(p['key_high']):<12} "
                    f"{str(v['floor'])+'/'+str(v['median'])+'/'+str(v['ceiling']):<14} "
                    f"{p['evidence']}")
        if self.autofix:
            lines += ["", self.autofix.text()]
        lines += ["", "VERIFICATION (M-050 .. M-055)", "-" * 72]
        for k, v in self.verification.items():
            lines.append(f"  {k:<28} {v}")
        return "\n".join(lines)


# --------------------------------------------------------------------------
def scan(mid: mido.MidiFile) -> Dict[Tuple[int, int], ChannelInfo]:
    """Collect per (track, channel) state: current program, banks, note stats."""
    info: Dict[Tuple[int, int], ChannelInfo] = {}
    for ti, track in enumerate(mid.tracks):
        tick = 0
        pending_cc00: Dict[int, int] = {}
        pending_cc32: Dict[int, int] = {}
        for msg in track:
            tick += msg.time
            ch = getattr(msg, "channel", None)
            if ch is None:
                continue
            key = (ti, ch)
            if msg.type == "control_change":
                if msg.control == 0:
                    pending_cc00[ch] = msg.value
                elif msg.control == 32:
                    pending_cc32[ch] = msg.value
                elif msg.control in (1, 2, 11, 16, 17, 18, 19):
                    if key in info:
                        info[key].has_dnc_cc = True
            elif msg.type == "program_change":
                ci = info.setdefault(key, ChannelInfo(ch, ti, tick))
                ci.program = msg.program
                ci.cc00 = pending_cc00.get(ch, ci.cc00)
                ci.cc32 = pending_cc32.get(ch, ci.cc32)
            elif msg.type == "note_on" and msg.velocity > 0:
                ci = info.setdefault(key, ChannelInfo(ch, ti, tick))
                ci.note_count += 1
                if NOISE_ZONE[0] <= msg.note <= NOISE_ZONE[1]:
                    ci.noise_notes += 1
                if ci.cc00 is None:
                    ci.cc00 = pending_cc00.get(ch)
                if ci.cc32 is None:
                    ci.cc32 = pending_cc32.get(ch)
    return {k: v for k, v in info.items() if v.note_count > 0}


def _count_notes(mid: mido.MidiFile) -> int:
    return sum(1 for tr in mid.tracks for m in tr
               if m.type == "note_on" and m.velocity > 0)


def _onsets(mid: mido.MidiFile) -> List[int]:
    """Absolute tick of every Note-On — the rhythmic fingerprint of the song.

    The remap and the K-series fixes may change pitch, velocity, note length
    and may append housekeeping events, but they must NEVER move an onset.
    """
    out: List[int] = []
    for tr in mid.tracks:
        t = 0
        for m in tr:
            t += m.time
            if m.type == "note_on" and m.velocity > 0:
                out.append(t)
    return sorted(out)


def remap_file(
    input_path: str | Path,
    output_path: str | Path,
    db: SoundDB,
    profile: Profile = Profile.SAFE,
    articulated: bool = False,
    optimized: bool = True,
    drum_kit: Optional[Sound] = None,
    custom: Optional[Dict[int, Sound]] = None,
    write_mix_init: bool = False,
    dry_run: bool = False,
    run_autofix: bool = True,
    factory_params: bool = True,
    velocity_envelope: bool = True,
    key_range: bool = True,
    factory_profiles: Optional[FactoryProfileSet] = None,
) -> RemapResult:
    """Apply the full Pa800 sound remap to a MIDI file."""
    if not optimized:
        raise RemapBeforeOptimizeForbidden(
            "M-000.3: the remap stage must run after optimization.")

    mid = mido.MidiFile(str(input_path))
    notes_before = _count_notes(mid)
    onsets_before = _onsets(mid)

    engine = MappingEngine(db, profile=profile, articulated=articulated,
                           custom=custom, drum_kit=drum_kit)
    channels = scan(mid)
    result = RemapResult(profile_used=engine.effective_profile().value, db_source=db.source)

    plan: Dict[Tuple[int, int], Optional[Sound]] = {}

    for (ti, ch), ci in sorted(channels.items()):
        if ch == DRUM_CHANNEL:
            kit, rule_id, warn = engine.choose_drum()
            if kit is None:
                plan[(ti, ch)] = None
                result.decisions.append(Decision(
                    ch, ti, ci.program, ci.cc00, ci.cc32,
                    Sound("(unchanged drum channel)", DRUM_MSB, ci.cc32 or 0, ci.program),
                    rule_id, "drum channel left untouched", warn))
            else:
                plan[(ti, ch)] = kit
                result.decisions.append(Decision(
                    ch, ti, ci.program, ci.cc00, ci.cc32, kit, rule_id,
                    "drum kit assigned in CC00=0 space", warn))
            continue

        sound, rule_id, reason, warn = engine.choose(ci.program, ch)
        if ci.noise_notes and not sound.is_rx:
            warn = warn + [f"ORPHAN_NOISE_KEYS: {ci.noise_notes} note(s) in C7..G9 "
                           f"but target is not RX (M-033)"]
        plan[(ti, ch)] = sound
        result.decisions.append(Decision(ch, ti, ci.program, ci.cc00, ci.cc32,
                                         sound, rule_id, reason, warn))

    # ---- K-serija: logical self-healing, driven by the factory track model --
    fps = factory_profiles or FactoryProfileSet()
    chan_profiles: Dict[int, TrackProfile] = {}
    rx_targets: Dict[int, bool] = {}
    for (ti, ch), ci in channels.items():
        role = role_from_pc(ci.program, ch)
        prof = fps.get(role)
        snd = plan.get((ti, ch))
        # The C7..G9 noise zone is an OSC5 feature of the BASS and GUITAR RX
        # programs (catalogue: OSC5 RX_NOISE, key zone C7..G9).  It is NOT a
        # general RX property, so strings/voices RX do not get the exemption.
        noise_capable = (snd is not None and snd.is_rx
                         and role in (Role.BASS, Role.GUITAR))
        prof.allow_noise_zone = noise_capable
        rx_targets[ch] = noise_capable
        chan_profiles[ch] = prof
    result.track_profiles = {ch: p.to_dict() for ch, p in chan_profiles.items()}

    if run_autofix:
        rep = AutofixReport()
        rep.profile_source = fps.source
        result.autofix = autofix(
            mid, chan_profiles, rx_targets=rx_targets,
            write_factory_params=factory_params,
            apply_velocity_envelope=velocity_envelope,
            apply_key_range=key_range, report=rep)

    if not dry_run:
        _apply(mid, plan, channels, write_mix_init)
        Path(output_path).parent.mkdir(parents=True, exist_ok=True)
        mid.save(str(output_path))
        result.output_path = str(output_path)

    notes_after = _count_notes(mid)
    onsets_after = _onsets(mid)
    tonal_bad = sum(1 for d in result.decisions
                    if d.channel != DRUM_CHANNEL and d.sound.cc00 == DRUM_MSB
                    and d.sound.name != "(unchanged drum channel)")
    drum_bad = sum(1 for d in result.decisions
                   if d.channel == DRUM_CHANNEL and d.sound.cc00 == TONAL_MSB)

    result.verification = {
        "M-050 channels with full triple": f"{len([d for d in result.decisions if d.sound.name != '(unchanged drum channel)'])}"
                                           f"/{len(result.decisions)}",
        "M-051 unresolved PCs": len(engine.unresolved),
        "M-052 tonal/drum space violations": tonal_bad + drum_bad,
        "M-053 note count delta": notes_after - notes_before,
        "M-054 onset positions moved": sum(1 for a, b in zip(onsets_before, onsets_after) if a != b) + abs(len(onsets_after) - len(onsets_before)),
        "M-055 decisions with rule id": f"{sum(1 for d in result.decisions if d.rule_id)}"
                                        f"/{len(result.decisions)}",
        "warnings": sum(len(d.warnings) for d in result.decisions),
    }
    return result


def _apply(mid: mido.MidiFile, plan: Dict[Tuple[int, int], Optional[Sound]],
           channels: Dict[Tuple[int, int], ChannelInfo], write_mix_init: bool) -> None:
    """Rewrite bank/program events (rules M-040, M-042)."""
    for ti, track in enumerate(mid.tracks):
        targets = {ch: s for (t, ch), s in plan.items() if t == ti and s is not None}
        if not targets:
            continue

        # --- M-040: drop existing bank-select / program-change for mapped channels
        cleaned: List[mido.Message] = []
        carry = 0
        for msg in track:
            drop = False
            ch = getattr(msg, "channel", None)
            if ch in targets:
                if msg.type == "program_change":
                    drop = True
                elif msg.type == "control_change" and msg.control in (0, 32):
                    drop = True
            if drop:
                carry += msg.time
            else:
                if carry:
                    msg = msg.copy(time=msg.time + carry)
                    carry = 0
                cleaned.append(msg)
        if carry and cleaned:
            cleaned[-1] = cleaned[-1].copy(time=cleaned[-1].time + carry)

        # --- M-042: insert the bank/PC block at the head of the track
        header: List[mido.Message] = []
        for ch, s in sorted(targets.items()):
            header.append(mido.Message("control_change", channel=ch, control=0, value=s.cc00, time=0))
            header.append(mido.Message("control_change", channel=ch, control=32, value=s.cc32, time=0))
            header.append(mido.Message("program_change", channel=ch, program=s.pc, time=0))
            if write_mix_init:  # M-043, opt-in only
                header.append(mido.Message("control_change", channel=ch, control=7, value=100, time=0))
                header.append(mido.Message("control_change", channel=ch, control=10, value=64, time=0))

        track.clear()
        track.extend(header)
        track.extend(cleaned)


def save_report(result: RemapResult, base_path: str | Path) -> Tuple[str, str]:
    base = Path(base_path)
    txt = base.with_suffix(".report.txt")
    js = base.with_suffix(".report.json")
    txt.write_text(result.report_text(), encoding="utf-8")
    js.write_text(json.dumps(result.report_dict(), indent=2, ensure_ascii=False), encoding="utf-8")
    return str(txt), str(js)
