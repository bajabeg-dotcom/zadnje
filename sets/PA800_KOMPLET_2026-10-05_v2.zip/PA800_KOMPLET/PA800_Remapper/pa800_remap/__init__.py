"""PA800 Remapper — full sound remap for Korg Pa800 (post-optimization stage).

Implements the M-series mapping rules documented in RULES_MAPIRANJE_PA800.md.
"""

__version__ = "1.0.0"
APP_NAME = "Korg Pa800 — Full Sound Remapper"
