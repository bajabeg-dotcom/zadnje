"""High-level jobs for the Pa800 Style Doctor.

This is the whole feature set as plain functions.  No Tkinter, no printing,
no global state: the GUI, the CLI and the tests all call the same three
entry points.

    diagnose(folder)              -> JobResult   (reads only, writes nothing)
    repair(folder, out_folder)    -> JobResult   (the one-button fix)
    convert_only(folder, out)     -> JobResult   (Pa3X/Pa4X -> Pa800 format only)

Every job reports progress through an optional callback::

    def progress(fraction: float, message: str) -> None

and every job is non-destructive: the source folder is never written to.
"""
from __future__ import annotations

import json
import shutil
import traceback
from dataclasses import dataclass, field
from pathlib import Path
from typing import Callable, Iterable

from .native import NativeStyleBank
from .native.codec import walk_children, _be32
from .native.model import parse_pattern_stream
from .styleopt import optimize_style_bank, VOICE_CEILING
from .trackparams import FactoryProfileSet
from .v5to4 import convert_style, enforce_pa800_limits, ConvertReport

ROOT = Path(__file__).resolve().parents[1]
DATA = ROOT / "data"

Progress = Callable[[float, str], None]


# ----------------------------------------------------------------- helpers
def _noop(fraction: float, message: str) -> None:
    return None


def load_valid_selectors() -> set[tuple[int, int, int]]:
    path = DATA / "valid_selectors.json"
    if not path.exists():
        return set()
    return {tuple(x) for x in json.loads(path.read_text())}


def _has_styles(folder: Path) -> bool:
    """True if the folder holds at least one .STY file.

    Case matters on Linux and on some USB filesystems, and real Korg media
    carries both `USER01.STY` and `Pa3x--PA800.sty`, so both are accepted.
    """
    try:
        return any(f.suffix.lower() == ".sty" and f.is_file()
                   for f in folder.iterdir())
    except OSError:
        return False


def find_style_folder(path: str | Path) -> Path | None:
    """Accept a .SET folder, a STYLE folder, or a parent holding either."""
    p = Path(path)
    if not p.exists():
        return None
    if p.is_file():
        p = p.parent
    if p.name.upper() == "STYLE" and _has_styles(p):
        return p
    direct = p / "STYLE"
    if direct.is_dir() and _has_styles(direct):
        return direct
    if _has_styles(p):
        return p
    for child in sorted(p.iterdir()):
        if child.is_dir():
            inner = child / "STYLE"
            if inner.is_dir() and _has_styles(inner):
                return inner
    return None


def list_banks(style_dir: Path) -> list[Path]:
    """Every .STY in the folder, whatever the case of the extension."""
    files = [f for f in style_dir.iterdir()
             if f.is_file() and f.suffix.lower() == ".sty"]
    return sorted(files, key=lambda f: f.name.upper())


def _notes_of(style) -> list[tuple]:
    out = []
    for pat in walk_children(style.data, style.pattern_pool.offset)[1:]:
        s = pat.offset + 8
        duration = _be32(style.data, s)
        length = _be32(style.data, s + 4)
        for ev in parse_pattern_stream(style.data[s + 8:s + 8 + length], duration):
            out.append((getattr(ev, "tick", None), getattr(ev, "opcode", None),
                        getattr(ev, "note", None), getattr(ev, "velocity", None)))
    return out


def _scan_bank(path: Path, selectors: set) -> dict:
    """Read-only measurement of one bank."""
    bank = NativeStyleBank.load(path)
    info = {"styles": 0, "lanes": 0, "invalid": 0, "v5": 0, "v5_names": [],
            "over_poly": [], "editable": bank.editable}
    for entry in bank.entries:
        style = entry.style
        info["styles"] += 1
        if style.data[1] == 5:
            info["v5"] += 1
            info["v5_names"].append(style.name)
        for element in style.elements:
            for t in range(8):
                v = element.track_data.get(t)
                info["lanes"] += 1
                if selectors and (v.msb, v.lsb, v.program) not in selectors:
                    info["invalid"] += 1
    return info


# ------------------------------------------------------------------ result
@dataclass
class BankResult:
    name: str = ""
    styles: int = 0
    lanes: int = 0
    invalid_before: int = 0
    invalid_after: int = 0
    v5_converted: int = 0
    limits_fixed: int = 0
    changes: int = 0
    by_rule: dict = field(default_factory=dict)
    notes_moved: int = 0
    read_only: bool = False
    error: str = ""


@dataclass
class JobResult:
    kind: str = ""
    source: str = ""
    out_dir: str = ""
    banks: list[BankResult] = field(default_factory=list)
    v5_names: list[str] = field(default_factory=list)
    over_poly: list[tuple] = field(default_factory=list)
    dropped_v5_data: int = 0
    error: str = ""

    # --- totals -------------------------------------------------------
    @property
    def styles(self) -> int:
        return sum(b.styles for b in self.banks)

    @property
    def lanes(self) -> int:
        return sum(b.lanes for b in self.banks)

    @property
    def invalid_before(self) -> int:
        return sum(b.invalid_before for b in self.banks)

    @property
    def invalid_after(self) -> int:
        return sum(b.invalid_after for b in self.banks)

    @property
    def v5_converted(self) -> int:
        return sum(b.v5_converted for b in self.banks)

    @property
    def limits_fixed(self) -> int:
        return sum(b.limits_fixed for b in self.banks)

    @property
    def changes(self) -> int:
        return sum(b.changes for b in self.banks)

    @property
    def notes_moved(self) -> int:
        return sum(b.notes_moved for b in self.banks)

    @property
    def failed(self) -> list[BankResult]:
        return [b for b in self.banks if b.error]

    def pct_before(self) -> float:
        return 100.0 * self.invalid_before / self.lanes if self.lanes else 0.0

    def pct_after(self) -> float:
        return 100.0 * self.invalid_after / self.lanes if self.lanes else 0.0

    # --- plain-language summary --------------------------------------
    def headline(self) -> str:
        if self.error:
            return "Nije uspjelo."
        if self.kind == "diagnose":
            if not self.invalid_before and not self.v5_converted:
                return "Sve izgleda ispravno."
            return f"Našao sam {self.invalid_before} pogrešnih zvukova u {self.styles} stilova."
        if self.failed:
            return f"Gotovo, ali {len(self.failed)} banaka nije prošlo."
        return f"Gotovo. {self.styles} stilova je popravljeno."

    def plain_lines(self) -> list[str]:
        """Human sentences, no jargon, for the result panel."""
        L: list[str] = []
        if self.error:
            return [self.error]
        L.append(f"Banaka: {len(self.banks)}        Stilova: {self.styles}")
        if self.kind == "diagnose":
            L.append("")
            L.append(f"Pogrešno postavljenih zvukova: {self.invalid_before} "
                     f"od {self.lanes}  ({self.pct_before():.1f} %)")
            if self.v5_names:
                L.append(f"Stilova u Pa3X/Pa4X formatu koje Pa800 ne može svirati: "
                         f"{len(self.v5_names)}")
            if self.over_poly:
                L.append(f"Stilova koji traže više od {VOICE_CEILING} glasova: "
                         f"{len(self.over_poly)}")
            L.append("")
            L.append("Ništa nije promijenjeno — ovo je bila samo provjera.")
            return L
        L.append("")
        L.append(f"Pogrešni zvukovi:  {self.invalid_before}  ->  {self.invalid_after}"
                 f"   ({self.pct_before():.1f} %  ->  {self.pct_after():.2f} %)")
        if self.v5_converted:
            L.append(f"Pa3X/Pa4X stilova prebačeno u Pa800 format: {self.v5_converted}")
        if self.limits_fixed:
            L.append(f"Stilova svedeno na Pa800 granicu od 13 elemenata: "
                     f"{self.limits_fixed}")
        L.append(f"Ukupno izmjena: {self.changes}")
        L.append(f"Nota pomjereno pri promjeni formata: {self.notes_moved}   "
                 f"{'(nijedna)' if not self.notes_moved else '(PAŽNJA)'}")
        L.append("Jačine udara (velocity) se namjerno doteruju — note i njihov "
                 "raspored ostaju isti.")
        if self.dropped_v5_data:
            L.append("")
            L.append(f"Napomena: kod {self.dropped_v5_data} traka odbačen je podatak "
                     "koji postoji samo na novijim modelima. Note nisu dirane, "
                     "ali te stilove prvo preslušaj.")
        if self.failed:
            L.append("")
            L.append("Nisu prošle ove banke:")
            for b in self.failed:
                L.append(f"   {b.name}: {b.error}")
        L.append("")
        L.append(f"Spremljeno u: {self.out_dir}")
        return L


# -------------------------------------------------------------------- jobs
def diagnose(folder: str | Path, progress: Progress | None = None) -> JobResult:
    """Read the folder and report what is wrong.  Writes nothing, anywhere."""
    progress = progress or _noop
    res = JobResult(kind="diagnose", source=str(folder))
    style_dir = find_style_folder(folder)
    if style_dir is None:
        res.error = ("U toj mapi nema stilova. Izaberi mapu koja se zove .SET "
                     "ili mapu STYLE u kojoj su .STY fajlovi.")
        return res
    res.source = str(style_dir)
    selectors = load_valid_selectors()
    banks = list_banks(style_dir)
    if not banks:
        res.error = "Mapa je prazna — nema nijednog .STY fajla."
        return res
    for i, path in enumerate(banks):
        progress(i / len(banks), f"Pregledam {path.name}")
        br = BankResult(name=path.name)
        try:
            info = _scan_bank(path, selectors)
            br.styles = info["styles"]
            br.lanes = info["lanes"]
            br.invalid_before = br.invalid_after = info["invalid"]
            br.v5_converted = 0
            br.read_only = not info["editable"]
            res.v5_names.extend(info["v5_names"])
        except Exception as exc:
            br.error = str(exc)
        res.banks.append(br)
    progress(1.0, "Gotovo.")
    return res


def repair(folder: str | Path, out_folder: str | Path,
           progress: Progress | None = None,
           *, convert_pa3x: bool = True,
           run_optimizer: bool = True,
           fix_sounds: bool = True,
           mixer: bool = True,
           velocity: bool = True,
           key_range: bool = True,
           tolerance: int = 12) -> JobResult:
    """The one-button fix: copy the SET, convert Pa3X styles, run the S-series.

    The source folder is never modified.  Everything lands in *out_folder*.
    """
    progress = progress or _noop
    res = JobResult(kind="repair", source=str(folder))
    style_dir = find_style_folder(folder)
    if style_dir is None:
        res.error = ("U toj mapi nema stilova. Izaberi mapu koja se zove .SET "
                     "ili mapu STYLE u kojoj su .STY fajlovi.")
        return res
    res.source = str(style_dir)
    banks = list_banks(style_dir)
    if not banks:
        res.error = "Mapa je prazna — nema nijednog .STY fajla."
        return res

    out_root = Path(out_folder)
    out_style = out_root / "STYLE"
    out_style.mkdir(parents=True, exist_ok=True)
    res.out_dir = str(out_root)

    selectors = load_valid_selectors()
    profiles = FactoryProfileSet()
    fp = DATA / "factory_profiles.json"
    if fp.exists():
        try:
            profiles.load(fp)
        except Exception:
            profiles = FactoryProfileSet()

    steps = len(banks) * 2 + 1
    done = 0
    for path in banks:
        br = BankResult(name=path.name)
        rep_lim = ConvertReport()
        target = out_style / path.name
        try:
            done += 1
            progress(done / steps, f"Pregledam {path.name}")
            before = _scan_bank(path, selectors)
            br.styles = before["styles"]
            br.lanes = before["lanes"]
            br.invalid_before = before["invalid"]
            br.read_only = not before["editable"]

            shutil.copy2(path, target)

            # --- step 1: Pa3X (v5) -> Pa800 (v4) --------------------------
            if convert_pa3x and before["v5"]:
                bank = NativeStyleBank.load(target)
                rep = ConvertReport()
                # Key by POSITION, never by name: banks legitimately contain
                # several styles with the same name (e.g. two "Begin"), and a
                # name-keyed dict silently compares the wrong pair -- which is
                # exactly what produced a phantom "1 note moved" report.
                pre_notes: dict[int, list] = {}
                for i, entry in enumerate(bank.entries):
                    if entry.style.data[1] != 5:
                        continue
                    pre_notes[i] = _notes_of(entry.style)
                    new = convert_style(entry.style.data, rep)
                    entry.style.data[:] = new
                    br.v5_converted += 1
                bank.export(target)
                res.dropped_v5_data += rep.nonzero_tail
                check = NativeStyleBank.load(target)
                for i, entry in enumerate(check.entries):
                    want = pre_notes.get(i)
                    if want is not None and _notes_of(entry.style) != want:
                        br.notes_moved += 1

            # --- step 1b: Pa800 Style Element limits ----------------------
            # Converter output is often version 4 with correct geometry but
            # 14-15 Style Elements.  The hardware export and all 339 genuine
            # user styles cap at 13 with len(elements) == popcount(mask).
            bank = NativeStyleBank.load(target)
            touched = False
            for entry in bank.entries:
                fixed = enforce_pa800_limits(bytes(entry.style.data), rep_lim)
                if fixed is not None:
                    entry.style.data[:] = fixed
                    br.limits_fixed += 1
                    touched = True
            if touched:
                bank.export(target)

            # --- step 2: the S-series -------------------------------------
            done += 1
            if run_optimizer:
                progress(done / steps, f"Popravljam {path.name}")
                report = optimize_style_bank(
                    target, target, profiles=profiles, apply=True,
                    mixer=mixer, expression=mixer, velocity=velocity,
                    key_range=key_range, humanize=True, fix_sounds=fix_sounds,
                    tolerance=tolerance)
                br.changes = report.total
                br.by_rule = report.by_rule()
                for peak in report.poly_peaks:
                    if peak and peak[-1] > VOICE_CEILING:
                        res.over_poly.append((path.name,) + tuple(peak))
            else:
                progress(done / steps, f"Preskačem popravku za {path.name}")

            after = _scan_bank(target, selectors)
            br.invalid_after = after["invalid"]
            res.v5_names.extend(after["v5_names"])
        except Exception as exc:
            br.error = f"{type(exc).__name__}: {exc}"
            if target.exists() and br.changes == 0:
                # leave the plain copy so the user still has the bank
                pass
        res.banks.append(br)

    progress(1.0, "Gotovo.")
    return res


def convert_only(folder: str | Path, out_folder: str | Path,
                 progress: Progress | None = None) -> JobResult:
    """Only change Pa3X styles into Pa800 format.  Touches nothing else."""
    progress = progress or _noop
    res = repair(folder, out_folder, progress,
                 convert_pa3x=True, run_optimizer=False)
    res.kind = "convert"
    return res
