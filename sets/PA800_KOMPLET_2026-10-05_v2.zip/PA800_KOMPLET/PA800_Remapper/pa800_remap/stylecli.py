"""Command line for the Pa800 STYLE OPTIMIZER (S-series).

    python -m pa800_remap.stylecli BANK.STY                    # dry run
    python -m pa800_remap.stylecli BANK.STY -o OUT.STY --apply
    python -m pa800_remap.stylecli BANK.STY --json report.json
"""
from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path

from .styleopt import optimize_style_bank, VOICE_CEILING
from .trackparams import FactoryProfileSet

DEFAULT_PROFILES = Path(__file__).resolve().parents[1] / "data" / "factory_profiles.json"


def main(argv=None) -> int:
    ap = argparse.ArgumentParser(
        prog="pa800-style-optimizer",
        description="Primjenjuje tvornicku logiku (F/K serija) na native Pa800 Style banku.")
    ap.add_argument("bank", help="putanja do .STY banke (USER/FAVORITE za upis)")
    ap.add_argument("-o", "--out", help="izlazna banka (podrazumijevano: upis u mjestu)")
    ap.add_argument("--apply", action="store_true",
                    help="stvarno upisi izmjene (bez ovoga je dry-run)")
    ap.add_argument("--factory-profiles", default=str(DEFAULT_PROFILES),
                    help="izmjereni tvornicki profili (JSON)")
    ap.add_argument("--no-mixer", action="store_true", help="preskoci S-02")
    ap.add_argument("--no-expression", action="store_true", help="preskoci S-03")
    ap.add_argument("--no-velocity", action="store_true", help="preskoci S-04")
    ap.add_argument("--no-key-range", action="store_true", help="preskoci S-05")
    ap.add_argument("--no-fix-sounds", action="store_true",
                    help="preskoci S-10 (popravku nevazecih Bank LSB iz Pa3X)")
    ap.add_argument("--tolerance", type=int, default=12,
                    help="tolerancija kad nema izmjerenog pojasa (default 12)")
    ap.add_argument("--style", type=int, action="append",
                    help="obradi samo ovaj indeks stila (moze vise puta)")
    ap.add_argument("--json", help="snimi izvjestaj kao JSON")
    ap.add_argument("--limit", type=int, default=6, help="primjera po pravilu u ispisu")
    args = ap.parse_args(argv)

    profiles = FactoryProfileSet()
    p = Path(args.factory_profiles)
    if p.exists():
        n = profiles.load(p)
        print(f"factory profiles: {n} uloga ucitano iz {p}", file=sys.stderr)
    else:
        print("UPOZORENJE: nema izmjerenih profila, koriste se PROVISIONAL vrijednosti",
              file=sys.stderr)

    rep = optimize_style_bank(
        args.bank, args.out, profiles=profiles, apply=args.apply,
        mixer=not args.no_mixer, expression=not args.no_expression,
        velocity=not args.no_velocity, key_range=not args.no_key_range,
        fix_sounds=not args.no_fix_sounds,
        tolerance=args.tolerance, style_indices=args.style,
    )
    print(rep.text(limit=args.limit))

    over = [x for x in rep.poly_peaks if x[2] > VOICE_CEILING]
    if over:
        print(f"\nPAZNJA: {len(over)} stilova prelazi {VOICE_CEILING} glasova "
              f"- na instrumentu ce doci do kradje glasova.")

    if args.json:
        Path(args.json).write_text(json.dumps({
            "bank": rep.bank, "applied": rep.applied,
            "profile_source": rep.profile_source,
            "styles": rep.styles, "elements": rep.elements, "lanes": rep.lanes,
            "patterns": rep.patterns, "events": rep.events,
            "velocities_changed": rep.velocities_changed,
            "by_rule": rep.by_rule(), "total_changes": rep.total,
            "lane_roles": rep.lane_roles,
            "polyphony_peaks": rep.poly_peaks,
            "findings": rep.findings[:200],
            "changes": [vars(c) for c in rep.changes[:2000]],
            "export": rep.export,
        }, indent=2, ensure_ascii=False), encoding="utf-8")
        print(f"\nJSON izvjestaj -> {args.json}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
