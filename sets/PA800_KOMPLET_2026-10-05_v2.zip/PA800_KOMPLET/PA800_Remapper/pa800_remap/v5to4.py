"""V-series — PA3X/Pa4X (inner v5) -> Pa800 (inner v4) STYLE downgrade.

Evidence
--------
The user supplied `INIT_STY_OUT.zip`: the same 7 Init style banks rendered
into every Korg PA family (legacy / pa1x / pa3x / pa4x / pa800 / transition).
That gives 97 *matched pairs* of byte-level identical musical content in both
v5 and v4 form, which is exactly the controlled before/after evidence the
cross-model problem needed.

Measured on those 97 pairs (annex V-1.6 for Pa3X, V-1.7 for Pa4X):

  root version byte      5 -> 4
  StyleInfo   (ident 1)  34 -> 32 bytes   : drop the trailing 2 bytes
  PatternData (ident 2)  unchanged, byte for byte (40374 B in the fixture)
  StyleElement(ident 3)  each 8 bytes shorter:
       ElementInfo  28 -> 28  bytes 0..27 preserved byte for byte.
                              (V-1.1 claimed "byte 27: 3 -> 2"; V-1.8
                              overturned that with hardware evidence —
                              byte 27 is per-element CONTENT and must
                              survive a conversion untouched.)
       TrackData    88 -> 80  v5[:80] == v4 exactly, and the dropped
                              trailing 8 bytes are all zero in 93/97

Pa4X input (same fixture, `pa4x/` family) additionally measures, over
85 matched styles / 1113 matched elements:

  ElementInfo  44 -> 28   bytes 0..27 byte-identical to the Pa3X 28-byte
                          ElementInfo in 1113/1113 cases; the trailing 16
                          bytes are the constant new-gen marker
                          00 00 0A 00 00 00 00 00 00 00 00 00 00 00 00 01
                          (1455/1455 elements) and are dropped.
  TrackData    96 -> 80   bytes 0..87 byte-identical to the Pa3X 88-byte
                          TrackData in 1275/1275 cases; the extra u4 column
                          (bytes 88..95) is all zero in 1275/1275 cases and
                          is dropped together with the u3 column.
  child headers          the node *release* byte tracks the geometry:
                          ElementInfo len 26: rel 0 · 28: rel 1 · 44: rel 3
                          TrackData    len 48: rel 0 · 80: rel 2 · 88: rel 3
                                                                      96: rel 4
                          so 44->28 must also stamp rel 3 -> 1, and
                          96->80 must stamp rel 4 -> 2 (the blanket 3 -> 2
                          rule of `_hdr` is not enough for Pa4X input).

Everything else (StyleInfo, PatternData, CV nodes and their headers, the
element list itself) is byte-identical between the pa4x and pa3x renders.

So the downgrade is a *truncation*, not a re-encoding: nothing musical is
invented and nothing musical is lost.  The dropped TrackData columns are the
v5 extension blocks; when they are not all zero the style carries v5-only
per-track data, which is counted in the report and dropped (the Pa800 has no
field for it).  The constant ElementInfo marker carries no musical data.

What this does NOT do
---------------------
* It does not remap sound selectors.  Run the S-series (S-10 / S-12) after.
* It does not reduce Pa3X's extra Style Elements (Pa3X has 4 fills, the Pa800
  has 3).  Elements beyond what the Pa800 addresses are left in place; the
  Pa800 simply never selects them.
* Guitar Mode 2 tracks cannot be represented on the Pa800 at all.
"""
from __future__ import annotations

from dataclasses import dataclass, field
from pathlib import Path
from typing import List

from .native import NativeStyleBank
from .native.codec import walk_children

EI_LEN = 28
EI_V5_LENGTHS = (28, 44)   # Pa3X writes 28, Pa4X/PA700/PA1000 write 44
EI_V5_TAIL = 16            # constant new-gen marker appended by the 44-byte form
TD_V5 = 88
TD_V5_LENGTHS = (88, 96)   # Pa3X writes 88, Pa4X/PA700/PA1000 write 96
TD_V4 = 80
STYLEINFO_DROP = 2         # 18-byte tail -> 16-byte tail
PA800_MAX_ELEMENTS = 13    # Pa3X writes 15; the Pa800 addresses 13

# Child-node header release byte, measured on the INIT_STY_OUT fixture
# (85 matched styles, all banks): it encodes the payload geometry, so it must
# be normalised together with the payload length.
EI_RELEASE = {26: 0, 28: 1, 44: 3}
TD_RELEASE = {48: 0, 80: 2, 88: 3, 96: 4}


@dataclass
class ConvertReport:
    styles_total: int = 0
    styles_converted: int = 0
    styles_already_v4: int = 0
    styles_refused: int = 0
    elements: int = 0
    tracks: int = 0
    nonzero_tail: int = 0
    elements_dropped: int = 0
    assoc_dropped: int = 0
    ei_tails_dropped: int = 0      # ElementInfo 44 -> 28 truncations (Pa4X input)
    u4_nonzero: int = 0            # Pa4X u4 column (bytes 88..95) with data
    notes: List[str] = field(default_factory=list)


def _hdr(src: bytes, node, payload: bytes) -> bytes:
    """Re-emit a node, stamping the v4 minor version into its header tag.

    Every node header is [ident, 00, minor, 08].  The minor version is
    therefore repeated on each node, not stored once -- which is why the
    root byte and 13 element bytes all had to change from 3 to 2.
    """
    tag = bytearray(src[node.offset:node.offset + 4])
    if tag[2] == 3:
        tag[2] = 2
    return bytes(tag) + len(payload).to_bytes(4, "big") + payload


def _read_mask(data: bytes, nodes) -> int | None:
    """16-bit Style Element content bitmap, 3 bytes after the Pascal name."""
    for n in nodes:
        if n.ident != 1:
            continue
        p = data[n.offset + 8:n.end]
        if not p:
            return None
        m = 1 + p[0] + 3
        if m + 2 <= len(p):
            return int.from_bytes(p[m:m + 2], "big")
    return None


def _cv_count(data: bytes, node) -> int:
    """Associations this StyleElement consumes from the PatternInfo list.

    Each Chord Variation node ends with a reference tail:
        [4B duration][4B stream_len][stream][count u8][count x 2B (?, track)]
    and `count` is exactly how many association indices that CV consumes.
    This is the same quantity `parse_cv` in the user's `korf_parse_style.py`
    reads as `nmap`, and the same one `pattern_role_map()` already walks.

    Earlier guesses -- CV-node count, and `cv_mask` popcount -- both describe
    how many CVs exist, not how many (CV, track) references they hold, which
    is why they under-counted by roughly 6x.
    """
    total = 0
    for cv in walk_children(data, node.offset)[2:]:
        start = cv.offset + 8
        stream_len = int.from_bytes(data[start + 4:start + 8], "big")
        tail = start + 8 + stream_len
        if tail >= cv.end:
            raise ValueError("CV reference tail outside object")
        total += data[tail]
    return total


def _trim_pattern_info(data: bytes, node, keep: int, rep: ConvertReport) -> bytes:
    kids = walk_children(data, node.offset)
    out = b""
    for i, k in enumerate(kids):
        payload = data[k.offset + 8:k.end]
        if i == 0 and len(payload) >= 4:
            n_assoc = int.from_bytes(payload[2:4], "big")
            if keep < n_assoc:
                payload = (payload[:2] + keep.to_bytes(2, "big")
                           + payload[4:4 + keep * 2]
                           + payload[4 + n_assoc * 2:])
                rep.assoc_dropped += n_assoc - keep
        out += _hdr(data, k, payload)
    return out


def _child(data: bytes, node, payload: bytes) -> bytes:
    """Re-emit a child node header, normalising the release byte with the
    payload length (measured map: EI_RELEASE / TD_RELEASE)."""
    tag = bytearray(data[node.offset:node.offset + 4])
    table = EI_RELEASE if tag[0] == 1 else TD_RELEASE if tag[0] == 2 else None
    if table is not None and len(payload) in table:
        tag[2] = table[len(payload)]
    return bytes(tag) + len(payload).to_bytes(4, "big") + payload


def _convert_element(data: bytes, node, rep: ConvertReport) -> bytes:
    """Rebuild one StyleElement (ident 3) child from v5 to v4."""
    kids = walk_children(data, node.offset)
    out = b""
    for k in kids:
        payload = data[k.offset + 8:k.end]
        if k is kids[0] and len(payload) in EI_V5_LENGTHS:
            # ElementInfo.  Pa4X/PA700/PA1000 append a 16-byte new-gen
            # marker (constant across the whole fixture); drop it.
            # Byte 27 is PRESERVED, never stamped: it is per-element
            # content, not a version marker (annex V-1.8 in
            # RULES_STYLE_OPTIMIZER.md).  The V-1.1 rule "3 -> 2" only
            # reproduced the INIT pa800 renderer's own normalisation;
            # the user's hardware export and all genuine Pa800 styles
            # carry 3 on Variation elements.
            if len(payload) == EI_LEN + EI_V5_TAIL:
                rep.ei_tails_dropped += 1
                payload = payload[:EI_LEN]
            out += _child(data, k, payload)
            continue
        if k is kids[1] and len(payload) in TD_V5_LENGTHS:
            # TrackData 88/96 -> 80: truncate the u3 (and u4) column(s).
            if len(payload) == TD_V5 + 8 and any(payload[TD_V5:]):
                rep.u4_nonzero += 1
            tail = payload[TD_V4:]
            if any(tail):
                rep.nonzero_tail += 1
            payload = payload[:TD_V4]
            rep.tracks += 8
            out += _child(data, k, payload)
            continue
        out += _hdr(data, k, payload)
    rep.elements += 1
    return out


def convert_style(data: bytes, rep: ConvertReport) -> bytes | None:
    """Return v4 bytes for one STYLE resource, or None if it is not v5."""
    if len(data) < 8 or data[1] != 5:
        return None
    nodes = walk_children(data)
    elems = [n for n in nodes if n.ident == 3]

    # Which Style Elements survive is decided by the StyleInfo CONTENT BITMAP,
    # not by position.  Ground truth: in the user's 339 genuine Pa800 styles
    # the invariant  len(elements) == popcount(mask)  holds 339/339, and the
    # count never exceeds 13.  An earlier rule ("keep the first 13, mask to
    # 0x1FFF") reproduced the Init fixture but broke that invariant on real
    # material (14 of 21 converted styles were wrong), so it is replaced.
    mask = _read_mask(data, nodes)
    keep_assoc = None
    drop: set[int] = set()
    new_mask = mask
    if mask is not None and elems:
        set_bits = [i for i in range(len(elems)) if mask >> i & 1]
        if len(set_bits) > PA800_MAX_ELEMENTS:
            # Pa800 addresses at most 13; clear the surplus high bits too.
            for i in set_bits[PA800_MAX_ELEMENTS:]:
                new_mask &= ~(1 << i)
            set_bits = set_bits[:PA800_MAX_ELEMENTS]
        keepset = set(set_bits)
        drop = {id(n) for i, n in enumerate(elems) if i not in keepset}
        rep.elements_dropped += len(drop)
        keep_assoc = sum(_cv_count(data, n)
                         for i, n in enumerate(elems) if i in keepset)
    out = b""
    for node in nodes:
        if id(node) in drop:
            continue
        payload = data[node.offset + 8:node.end]
        if node.ident == 1:                       # StyleInfo
            payload = payload[:len(payload) - STYLEINFO_DROP]
            if new_mask is not None and new_mask != mask and payload:
                m = 1 + payload[0] + 3
                if m + 2 <= len(payload):
                    b = bytearray(payload)
                    b[m:m + 2] = new_mask.to_bytes(2, "big")
                    payload = bytes(b)
        elif node.ident == 2 and keep_assoc is not None:
            # PatternData: its PatternInfo child holds one 2-byte Chord
            # Variation association index per element/CV, consumed in element
            # order.  Dropping the two Pa3X-only elements therefore drops
            # their indices, which sit at the end of that list.
            payload = _trim_pattern_info(data, node, keep_assoc, rep)
        elif node.ident == 3:                     # StyleElement
            payload = _convert_element(data, node, rep)
        out += _hdr(data, node, payload)
    head = bytearray(data[:8])
    head[1] = 4
    head[4:8] = len(out).to_bytes(4, "big")
    return bytes(head) + out


def enforce_pa800_limits(data: bytes, rep: ConvertReport) -> bytes | None:
    """Make an ALREADY-v4 style obey the Pa800 Style Element limits.

    Converter output in the wild (e.g. `Prvi.STY`) is version 4 with correct
    28/80 geometry yet carries 14 or 15 Style Elements.  Every one of the
    user's 339 genuine Pa800 styles, and the hardware export
    `NEWNAME.SET/STYLE/USER01.STY`, has at most 13 and satisfies
    `len(elements) == popcount(mask)`.  This pass enforces exactly that, and
    nothing else: version, StyleInfo length and TrackData are untouched,
    so it is safe to run on any v4 input.

    Returns None when the style already complies (caller should skip).
    """
    if len(data) < 8 or data[1] != 4:
        return None
    nodes = walk_children(data)
    elems = [n for n in nodes if n.ident == 3]
    mask = _read_mask(data, nodes)
    if mask is None or not elems:
        return None

    n_el = len(elems)
    pc = bin(mask).count("1")

    # IMPORTANT: in an already-dense v4 style the j-th stored element is the
    # j-th SET BIT, not bit j.  (A compliant style has 10 elements and a mask
    # like 0x6ccf whose set bits are scattered.)  Index==bit only holds for
    # v5 input, where all 15 slots are materialised -- which is why the
    # v5->v4 path may use it and this one may not.
    if n_el == pc and n_el <= PA800_MAX_ELEMENTS:
        return None                                  # already compliant
    if n_el != pc:
        return None                                  # inconsistent: do not guess
    if n_el <= PA800_MAX_ELEMENTS:
        return None

    # Too many elements: keep the first 13 in storage order and clear the
    # bits of the surplus ones, which are the highest set bits.
    set_bits = [i for i in range(16) if mask >> i & 1]
    new_mask = mask
    for i in set_bits[PA800_MAX_ELEMENTS:]:
        new_mask &= ~(1 << i)
    keep = set(range(PA800_MAX_ELEMENTS))
    drop = {id(node) for j, node in enumerate(elems) if j not in keep}
    rep.elements_dropped += len(drop)
    keep_assoc = sum(_cv_count(data, node)
                     for j, node in enumerate(elems) if j in keep)

    out = b""
    for node in nodes:
        if id(node) in drop:
            continue
        payload = data[node.offset + 8:node.end]
        if node.ident == 1 and payload:
            m = 1 + payload[0] + 3
            if m + 2 <= len(payload):
                b = bytearray(payload)
                b[m:m + 2] = new_mask.to_bytes(2, "big")
                payload = bytes(b)
        elif node.ident == 2:
            payload = _trim_pattern_info(data, node, keep_assoc, rep)
        out += _hdr(data, node, payload)
    head = bytearray(data[:8])
    head[4:8] = len(out).to_bytes(4, "big")
    return bytes(head) + out


def convert_bank(src: str | Path, dst: str | Path) -> ConvertReport:
    """Downgrade every v5 STYLE in a bank; v4 styles pass through untouched."""
    rep = ConvertReport()
    bank = NativeStyleBank.load(str(src))
    for entry in bank.entries:
        rep.styles_total += 1
        style = entry.style
        if style.data[1] != 5:
            rep.styles_already_v4 += 1
            continue
        new = convert_style(style.data, rep)
        if new is None:
            rep.styles_refused += 1
            continue
        # In-place: the StyleResource shares this bytearray with the
        # CompressedResource, so a rebind (style.data = new) would leave
        # export() re-encoding the ORIGINAL v5 bytes.
        style.data[:] = new
        rep.styles_converted += 1
        rep.notes.append(style.name)
    bank.export(str(dst))
    return rep
