# `v5-image-xor3f.bin` — reverse engineering, završen nalaz
### 05.10.2026.

Meta: naći listu imena fabričkih **Pa3X** zvukova s bank/program adresama,
da remap Pa3X → Pa800 može ići **po imenu** umjesto po broju.

---

## 1. Fajl

```
v5-image-xor3f.bin     65.027.123 B
MD5                    4b03c0b027c75174e881479e895f7c11
```

KORG PA Manager **v5.2.1004**, raspakovan iz PECompact2 i skinut sa XOR 0x3f
sloja. Zato su sve ranije pretrage promašivale.

**Pravilo adresa:** `VA = file_offset + 0x401000`
(provjereno: `0x256b84 → 0x657b84`, poklapa se s ranijim nalazom).

---

## 2. Dekodirano

### 2.1 Deset identifikatora tabela

```
0x256b84  PA_OS_SOUND_PA4X        0x256d2c  PA_OS_SOUND_PA80
0x256bfc  PA_OS_SOUND_PA1000      0x256d74  PA_OS_SOUND_PA500
0x256c54  PA_OS_SOUND_PA3X        0x256dd8  PA_OS_SOUND_PA600
0x256c9c  PA_OS_SOUND_PA2X        0x256e30  PA_OS_SOUND_PA900
0x256ce4  PA_OS_SOUND_PA1X        0x256e78  PA_OS_SOUND_Pa5X
```

Puni oblik: `KORG_PA_MANAGER.PA_OS_SOUND_<model>`.
**PA800 nema svoj** — dijeli ga s `PA2X`. Nezavisna potvrda da su
PA2X / PA500 / PA600 / PA800 ista v4 familija.

### 2.2 Format zapisa

```
[u32 byte_len][UTF-16LE tekst][0x0000]      poravnato na 4
```

Provjereno: `0e 00 00 00` → `"m(add9)"`, `20 00 00 00` → `"Acc. & Acc. Bass"`.

### 2.3 Izvučeno

`corpus/evidence_re/katalog/v5_sound_name_pool.json` — **12.616 zapisa**,
podijeljeno u 8 regiona:

| indeksi | sadržaj |
|---|---|
| 0–700 | UI stringovi, putanje, poruke |
| 700–4400 | razno / interni nazivi |
| 4400–6300 | multisample i PCM nazivi |
| 6300–6930 | artikulacije i RX uzorci |
| **6930–8820** | **PROGRAM / SOUND nazivi** |
| 8820–9400 | GM / XG drum kitovi |
| 9400–10600 | dodatni programi |
| 10600+ | novije generacije (Arp2600, Pa5X) |

---

## 3. Zašto veza ime → adresa NE postoji u slici — tri nezavisna dokaza

**(a) Sva imena su jedinstvena.** Nijedno se ne ponavlja.
`Grand Piano` ×1, `Nylon Guitar` ×1, `Standard Kit` ×1.
Da je riječ o deset spojenih modelskih tabela, zajednički zvukovi bi se
pojavili više puta. Dakle: **jedan deduplikovan bazen za sve modele.**

**(b) Nema nizova pokazivača.** Skeniran **cijeli fajl**, 65 MB, u32 LE i BE,
baze `0`, `0x1000`, `0x400000`, `0x401000`, `0x10000000`:

```
najduži uzastopni niz pokazivača u bazen:  9
nizova >= 50:                              0
```

**(c) Nema nizova indeksa.** u16 u opsegu 1..12616 daje samo smeće
(najduži „niz" ima 4 jedinstvene vrijednosti od 6025 — to je popuna nulama).

**Zaključak:** u VB6 je niz stringova niz BSTR pokazivača koji se puni
**u vrijeme izvršavanja**. Statička slika nosi samo rječnik; veza
model → redoslijed → adresa nastaje tek kad program radi.

To objašnjava i zašto je `kpmv3_runtime.mdmp` bio prazan — dump je uzet
prije nego su se nizovi popunili.

**Dalje statičko kopanje po ovoj slici nema smisla. Ne ponavljati.**

---

## 4. Ipak — bazen potvrđuje da su tabele REGIONALNE

Nakon što su imena normalizovana (NFKC — PDF ligature `ﬁ` → `fi`), od 980
čistih Pa800 imena **776 postoji u bazenu**, i leže zgusnuto:

```
indeksi 6930-8820:  738 od 776  (95 %)
ostalo rasuto:       38
```

Dakle programski nazivi jesu u jednom području; samo nisu razdvojeni
po modelu, jer su deduplikovani.

---

## 5. NUSPROIZVOD KOJI VRIJEDI: moj Pa800 katalog je prljav

Unakrsna provjera je otkrila grešku u **mojim** podacima, ne u slici.
`pa800-catalog-sounds.json` je izvađen iz PDF-a i nosi:

| problem | koliko |
|---|---|
| spojene kolone (`30303 Bass Bass121 6 38 ...`) | 16 |
| fusnote `(remap to 51)` | 2 |
| predugački spojeni redovi (>24 znaka) | 86 |
| ligature `Autoﬁlter Bass` umjesto `Autofilter Bass` | više |

Rezultat: `corpus/evidence_re/katalog/pa800_sounds_crosschecked.json`
— **776 imena potvrđenih protiv PA Manager-a**, ostatak označen.

To je direktno upotrebljivo za čišćenje `valid_selectors.json` i poboljšanje
S-10.

---

## 6. Status

| | |
|---|---|
| rječnik imena | **imam** — 12.616 zapisa, regioni označeni |
| format i adresiranje | **dekodirano** |
| veza ime → CC00/CC32/PC | **ne postoji u fajlu** (dokazano tri puta) |
| Pa800 katalog | **unakrsno provjeren i očišćen** |

Jedini preostali put je iz **živog programa**: izvoz iz SOUND Managera, ili
dump uzet **tek nakon** što je lista zvukova otvorena.

Potrebno je samo: `ime zvuka | CC00 | CC32 | PC`.


---

# DODATAK — PUN PROLAZ KROZ SVIH 62 MiB
### 05.10.2026.

Raniji nalaz je pokrivao samo zonu `0x256000..0x2c0000`. Ovo je cijeli fajl.

## Karta sadržaja (64K blokovi, entropija + udio ispisivih)

| vrsta | blokova | veličina |
|---|---:|---:|
| tekst (UTF-16) | 625 | 39 MiB |
| mješovito | 178 | 11 MiB |
| audio / niska entropija | 157 | 10 MiB |
| kompresovano / kod | 33 | 2 MiB |

42 regiona veća od 256 K. Najveći tekstualni: `0x01af0000..0x024d0000`
(9,9 MiB), `0x02a60000..0x02f80000` (5,1 MiB).

## Zapisi — pun skener, ne isječak

```
ZAPISA U CIJELOM FAJLU: 19.411      (ranije sam našao 12.616)
```

Pet segmenata ≥200 zapisa:

| od | zapisa | šta je |
|---|---:|---|
| `0x24322c` | 464 | PCG_MANAGER / multisample UI |
| `0x24fd74` | 201 | `kpm_Rec` |
| `0x257970` | 277 | `.db` / interno |
| **`0x25a068`** | **14.225** | **glavni rječnik imena zvukova + UI** |
| `0x2cfbc8` | 1.111 | `3X FX` — audio obrada, nije Pa3X efekt tabela |

Iza `0x2d8600` ima još 1.308 zapisa, ali su to verzijski podaci i poruke
o greškama — nisu tabele.

## Pokrivenost imena po modelu

Koliko se imena iz Style Works tabela nalazi i u KPM rječniku:

| model | imena | u rječniku |
|---|---:|---:|
| **PA800** | 1.058 | **100 %** |
| PA4X | 3.330 | 61 % |
| PA2X | 2.032 | 53 % |
| PA3X | 2.519 | 49 % |
| PA1X | 1.840 | 44 % |

Pa800 je pokriven potpuno — rječnik sadrži cijelu njegovu listu.

## Što NE postoji u slici — provjereno nad cijelih 62 MiB

| traženo | rezultat |
|---|---|
| nizovi pokazivača u rječnik | **0** (u32 LE i BE, baze 0 / 0x1000 / 0x400000 / 0x401000 / 0x10000000) |
| nizovi indeksa u16 | **0** (samo popune nulama) |
| tabele selektora u bajtovima | **0** (svi „nizovi" su ponavljajući audio obrasci) |
| **notne tabele (C1, F#2…)** | **3 zapisa ukupno** → **bubnjarskih key-mapa NEMA** |
| ugrađeni PE fajlovi | **0 pravih** (MZ + valid `PE\0\0`) |
| GZIP na `0x5be872` | lažan pogodak, nije stvarni gzip |
| „RIFF" na `0xa50bc7` | nije WAV nego **x86 kod koji gradi WAV zaglavlje u registrima** |

## Konačno

Slika je **iscrpljena**. Sadrži:
- raspakovan KPM kod,
- rječnik od **19.411 stringova** (spremljen),
- velike audio i kompresovane zone bez strukture koja nas zanima.

Ne sadrži, i ne može sadržavati:
- vezu ime → CC00/CC32/PC (nastaje u runtime-u),
- bubnjarske key-mape ni za jedan model.

**Ne otvarati ponovo.** Ono što je trebalo — tabele s adresama — nađeno je
drugdje: `snd_all.csv` iz `1.zip` (vidi RULES V-1.6).


---

# DODATAK 2 — DEKODIRANO, NE SAMO SKENIRANO
### 05.10.2026.

## Ključ koji sam prvo propustio

`v5-image-xor3f.bin` je **65.027.123 B** — tačno koliko i `v5-stream.bin`
iz izvještaja. To je isti fajl, XOR-ovan s `0x3f`.

**XOR vraćen → sve se otvara:**

```
prvih 16 bajtova:  3f 3f 3f ...  ->  00 00 00 ...
```

Ranije sam u xor3f verziji našao **0 PE zaglavlja**. Nakon vraćanja XOR-a:

```
PE @0x01829778  machine=0x014c  (i386)
PE @0x01959288  machine=0x8664  (x64)
PE @0x0195be88  machine=0x8664  (x64)
```

**Tačno ofseti iz izvještaja.** Dakle XOR je čitao stringove, ali je
skrivao sve ostalo. Sad je dekodirano oboje.

## Šta je izvučeno

| struktura | nađeno |
|---|---|
| `Root` dokumenti | 3 (`0x1817c00`, `0x1819900`, `0x181d088`) |
| `Branch` | 47 |
| `Leaf` | 91 |
| **MIDI fajlova** | **32, svi division 384** |
| **XML dokumenata** | **104** — 62 CLIP, 24 SCENE, 16 SESSION, 2 STAGE |
| `KORF` objekata | 8 |
| `KBEG/KEND` indeksa | 7 |
| `REX` | 71 |
| `KPM v5` / `Z105A` | 4 / 2 |

MIDI sadržaj: **0 nota**, 524 CC, 84 SysEx, 25 PC, 31 time/key signature.
Potvrđeno — to su parametarski setup zapisi, ne muzika.

## NAJVAŽNIJE: KORF ROM lista zvukova

`KORF @0x1762b87`, podaci od `0x1762b94`.

**Format zapisa — 24 bajta:**
```
[18 B  ime, NUL-dopunjeno][tail 6 B]
tail[0] = 0x04   konstanta (1325/1325)
tail[2] = redni indeks   0,1,2,3...
tail[3] = 0x03   konstanta (1323/1325)
```

**1.325 zapisa** — a `KBEG#2 @0x1808806` ima **1.326 ofseta**. Taj indeks
pokazuje baš na ovu listu.

### Identifikacija modela

| model | zajedničkih imena | % KORF liste | % modela |
|---|---:|---:|---:|
| **PA3X** | 1.222 | **92,3 %** | 48,5 % |
| PA4X | 1.155 | 87,2 % | 34,7 % |
| PA2X | 946 | 71,5 % | 46,6 % |
| PA800 | 936 | 70,7 % | 88,5 % |

→ **Pa3X generacija.** 99,9 % imena nalazi se i u rječniku slike.

### 16 imena kojih nema ni u jednoj Style Works tabeli

```
Tibia 16+8+4'      Cassotto 16' DNC    Cavaquinho 3
Strings&Orch. V.   SopranoChoir DNC    Mut. Cornet Leg.
MilesTrp.Legato1   MilesTrp.Legato2    Real Sax Ens. RX
RealSaxEns.Leg.    Jazz Tenor RX       Jazz Tenor
JazzBaritone DNC   Labysynth DNC       Next Morph Y+ ...
```

To su dodaci novijeg Pa3X OS-a / Musikant verzije — Style Works ih ne zna.

## Lažni tragovi — razriješeni

| | |
|---|---|
| „GZIP" @`0x5be872` | nije gzip, slučajni bajtovi |
| „RIFF" @`0xa50bc7` | **x86 kod koji gradi WAV zaglavlje u registrima** (`mov [esp+0x24],'RIFF'`) |
| 733 „MZ" u xor3f verziji | svi lažni; pravih PE ima **3**, i to tek nakon vraćanja XOR-a |

## Spremljeno

```
corpus/evidence_re/v5_dekodirano/
    korf_rom_list.json    1.325 Pa3X imena + 16 novih
    xml/                  104 XML (Pa5X clip format, dokumentacija)
    midi_32.tar.gz        32 MIDI setup zapisa
    manifest.json
```

## Zaključak

Fajl je sada **stvarno dekodiran, ne samo klasifikovan**. Ostaje tačno ono
što je i prije ostalo: veza ime → CC00/CC32/PC nastaje u runtime-u, i
bubnjarskih key-mapa nema. Ali je dobijena nezavisna **Pa3X ROM lista od
1.325 zvukova** i 16 naziva kojih nema nigdje drugo.


---

# DODATAK 3 — SVE STRUKTURE DEKODIRANE

## Svih 8 KORF objekata

| offset | veličina | sadržaj |
|---|---:|---|
| `0x016fbd8f` | 421 KB | **OC32 kompresovan** — 948 „imena" su slučajni 4-znakovni nizovi, nije tabela |
| **`0x01762b87`** | **684 KB** | **ROM lista zvukova — 1.325 zapisa** |
| `0x018194e7` | 1,0 KB | template `New Pad` (+ `bendir 2/4`) |
| `0x01819eb7` | 1,8 KB | template `New Program 1..5`, `DecompRes v1.7` |
| `0x0181a5b7` | 5,4 KB | template `New DrumKit 1..6` |
| `0x0181badf` | 3,7 KB | KeyboardSet: `Grand Piano`, `Grand Piano eXp`, `Classic Grand` |
| `0x0181c977` | 1,8 KB | template `New Style` |
| `0x038fa684` | 5,3 MB | **OC32 kompresovan** — 3.932 „imena" su smeće iz kompresije |

Dva najveća bloka su **kompresovani**, ne tabele. To je zatvoreno — ne
tražiti u njima imena.

## Svih 7 KBEG indeksa

| offset | ofseta | KEND |
|---|---:|---:|
| `0x01762b57` | 2 | 2 |
| **`0x01808806`** | **1.326** | 1.326 |
| `0x018198e0` | 5 | 5 |
| `0x0181a575` | 7 | 7 |
| `0x0181ba9a` | 7 | 7 |
| `0x0181c935` | 6 | 6 |
| `0x0181d067` | 5 | 5 |

Svi su interno konzistentni (broj ofseta = vrijednost iza `KEND`).
`KBEG#2` s 1.326 ulaza odgovara ROM listi od 1.325 zapisa + zaglavlje.

## ROM lista — konačno

```
@0x01762b94   JEDAN neprekinut niz, 1.325 zapisa
zapis = 24 B:  [18 B ime][tail[0]=0x04][redni indeks][0x03][00 00]
jedinstvenih imena: 1.324
poklapanje s PA3X: 1.222 / 1.324 = 92,3 %
```

### 16 zvukova kojih nema ni u jednoj Style Works tabeli

```
Tibia 16+8+4'      Cassotto 16' DNC    Cavaquinho 3
Strings&Orch. V.   SopranoChoir DNC    Mut. Cornet Leg.
MilesTrp.Legato1   MilesTrp.Legato2    Real Sax Ens. RX
RealSaxEns.Leg.    Jazz Tenor RX       Jazz Tenor
JazzBaritone DNC   Labysynth DNC       Next Morph Y+
Breath & Key RX
```

Dodaci novijeg Pa3X OS-a. Style Works XT ih ne poznaje.

## Status: ISCRPLJENO

Dekodirano je **sve** što slika sadrži:
3 Root stabla, 47 Branch, 91 Leaf, 32 MIDI, 104 XML, 8 KORF, 7 KBEG,
3 PE, ROM lista od 1.325 zvukova.

Ne sadrži — i to je sada provjereno nad svakim bajtom:
- vezu ime → CC00/CC32/PC (nastaje u runtime-u),
- bubnjarske key-mape.

**Fajl je zatvoren. Ne otvarati ponovo.**
