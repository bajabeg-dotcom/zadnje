# FACTORY PARITY (F-serija) + LOGIČKI AUTO-FIX (K-serija)
**Verzija:** F/K-1.0 · **Datum:** 2026-10-03 · **Implementirano i testirano u `PA800_Remapper`**

---

## 0. Princip

> **Track nije zvuk. Track je kompletan parametarski otisak.**
> Cilj: ono što izađe iz optimizatora mora biti **identično tvorničkom** u svakom pogledu —
> zvuk, nivo, ekspresija, pan, FX send, key range, velocity kriva, trigger, tension.
>
> I drugo: **logična pravila saniraju MIDI sama, prije nego remap uopšte počne.**
> Key Range nije kozmetika — on je pravilo koje automatski popravlja fajl.

---

## 1. F-SERIJA — šta čini „engine mapping" jednog tracka

Za svaki `(Style, Element, CV, Track)` iz tvorničkog materijala vadi se puni otisak:

| ID | Parametar | MIDI nosilac | Status dokaza |
|---|---|---|---|
| **F-01** | Sound adresa | CC00 / CC32 / PC | ✅ dokazano (sound lista, 1003 bindinga) |
| **F-02** | **Volume** | CC7 | 🔶 vadi se iz Factory Styles |
| **F-03** | **Expression** | CC11 | 🔶 vadi se iz Factory Styles |
| **F-04** | Pan | CC10 | 🔶 vadi se iz Factory Styles |
| **F-05** | **FX send** (Reverb / Chorus-Mod) | CC91 / CC93 | 🔶 vadi se; tip FX-a iz Performance objekata |
| **F-06** | FX tip po tracku (4 procesora, 125 tipova) | — (native) | 🔶 iz `KORG_PA800_FULL_EDITOR_DATA_v1.zip` / Performance |
| **F-07** | Oktava / detune | — (native) | 🔶 |
| **F-08** | **Key Range** (bottom/top) + **Wrap Around** | — (native) | ✅ koncept potvrđen; granice po ulozi se mjere |
| **F-09** | NTT / NTR | — (native) | ⚠️ NTT CLOSED · **NTR 2/4 KEEP OPEN** → čuva se numerički, ne imenuje se |
| **F-10** | Trigger / TrackMode · Humanize GTR | — (native) | ✅ **CLOSED**: 0=Off, 1=Retrigger, 2=Repitch · Humanize GTR 0..25 |
| **F-11** | Tension | — (native) | ✅ **CLOSED_SEMANTIC** |
| **F-12** | **Velocity kriva po instrumentu** | velocity | 🔶 **FV00: 268 envelope profila već postoji** |
| **F-13** | Polifonijski strop / gustoća | — | 🔶 **CP00: 20 967 opservacija / 8 929 profila** |

> Status `CLOSED` / `KEEP OPEN` nisu moja procjena nego prepis iz tvog
> `PA800_CROSS_EVIDENCE_TRIANGULATION_2026-09-22.md`.

### 1.1 Odakle se vadi (ekstrakcija — sljedeći korak)

| Izvor na tvom Driveu | Daje |
|---|---|
| `PA800_FACTORY_STYLES_PATTERNS_PADS_REFERENCE.zip` (6,9 MB) | F-02…F-05, F-08, F-13 po ulozi i žanru |
| `STYLE.zip` (2,5 MB) | kontrolni uzorak |
| CP00 `factory_context_profiles.json` (8 929 profila) | F-13, kontekst Element/CV |
| FV00 `factory_velocity_envelopes.json` (268 profila) | **F-12 velocity krive** |
| `KORG_PA800_FULL_EDITOR_DATA_v1.zip` | F-06 FX tipovi |
| `PA800_INSTRUMENTI_I_DRUM_KITOVI.pdf` | F-08 key zone po zvuku, velocity switch pointi |

### 1.2 ⚠️ Poštena napomena o trenutnom stanju

Program **već radi sa punim F-modelom**, ali su brojčane vrijednosti trenutno
označene **`PROVISIONAL`** — to su muzički razumne pretpostavke po ulozi,
**nisu izmjerene**. Svaki izvještaj to eksplicitno ispiše.

Čim se pokrene ekstraktor, učita se JSON i status prelazi u `FACTORY_MEASURED`:

```bat
run.bat song.mid --factory-profiles factory_profiles.json
```
ili u GUI-ju: kartica **„2b · Factory parity"** → *Izmjereni Factory profili (.json)*.

**Ništa se ne predstavlja kao dokazano dok nije izmjereno.** To je cijela poenta projekta.

### 1.3 Trenutni PROVISIONAL model po ulozi

| Uloga | CC7 | CC10 | CC11 | CC91 | CC93 | Key Range | Velocity env (min/med/max) | Max polif. |
|---|---|---|---|---|---|---|---|---|
| DRUM | 110 | 64 | 127 | 25 | 0 | 27..87 *(bez wrap-a)* | 8 / 92 / 127 | 10 |
| BASS | 112 | 64 | 127 | 12 | 0 | 24..67 | 20 / 95 / 127 | 1 |
| GUITAR | 100 | 54 | 127 | 28 | 12 | 40..88 | 24 / 84 / 127 | 6 |
| PIANO | 104 | 64 | 127 | 32 | 0 | 21..108 | 12 / 80 / 127 | 10 |
| ACCORDION | 102 | 64 | 127 | 26 | 8 | 41..93 | 30 / 88 / 127 | 6 |
| ORGAN | 100 | 64 | 127 | 24 | 0 | 36..96 | 64 / 100 / 127 | 8 |
| STRINGS | 94 | 64 | 127 | 44 | 10 | 36..96 | 28 / 76 / 120 | 5 |
| PAD | 84 | 64 | 127 | 52 | 20 | 36..96 | 30 / 70 / 110 | 5 |
| BRASS | 100 | 70 | 127 | 30 | 0 | 41..89 | 32 / 92 / 127 | 5 |
| REED | 100 | 58 | 127 | 32 | 0 | 45..93 | 30 / 88 / 127 | 3 |
| LEAD | 104 | 64 | 127 | 30 | 0 | 48..100 | 40 / 96 / 127 | 2 |

Velocity se **ne gazi** nego **monotono preseli** u envelopu — relativna dinamika
sviranja ostaje netaknuta, mijenja se samo prozor. (Orgulje: pod 64, jer orgulja
nema velocity dinamiku — to je muzička, ne tehnička odluka.)

---

## 2. K-SERIJA — pravila koja sama popravljaju MIDI

Sve je **implementirano i testirano**. Ništa se ne briše tiho; sve se broji i pripisuje pravilu.

| ID | Pravilo | Šta konkretno radi | Status |
|---|---|---|---|
| **K-01** | **Key Range + Wrap Around** | nota van opsega uloge se **presavije po oktavama** u opseg (čuva se tonski rod!), ne odsiječe se | ✅ |
| **K-01b** | Key Range nerješiv | ako ni poslije wrap-a ne staje → clamp + prijava | ✅ |
| **K-02** | **RX noise zona C7..G9** | zaštićena od transpozicije **samo** ako je cilj bass/guitar RX (OSC5); inače se označi | ✅ |
| **K-03** | Zaglavljene note | nedostaje Note-Off → zatvara se na kraju tracka | ✅ |
| **K-04** | Nulte dužine | nota kraća od 1/64 → produžena na minimalni gate | ✅ |
| **K-05** | Dupli Note-On | ista visina već zvuči → ubacuje se legalan Note-Off (retrigger) | ✅ |
| **K-06** | Siroče Note-Off | uklanja se | ✅ |
| **K-07** | `Note-On vel=0` | normalizuje se u pravi Note-Off | ✅ |
| **K-08** | **Velocity kriva** | monotono useljavanje u Factory envelopu instrumenta | ✅ |
| **K-09** | **Factory parametri** | nedostaju CC7/CC10/CC11/CC91/CC93 → upisuju se iz profila uloge | ✅ |
| **K-10** | Ekspresija na nuli | CC11=0 → 1 (track koji „nestane") | ✅ |
| **K-11** | Pitch bend | vraća se u centar na kraju | ✅ |
| **K-12** | Damper | CC64 ostavljen pritisnut → otpušta se | ✅ |
| **K-13** | **GS/XG SysEx** | briše se — gazi Pa800 bank select | ✅ |
| **K-14** | Melodija na kanalu 10 | samo prijava, nikad automatsko premještanje | ✅ |
| **K-15** | Polifonija iznad stropa | prijava po kanalu i ulozi | ✅ |

### 2.1 Zašto baš Wrap Around, a ne clamp

Clamp (odsijecanje na granicu) **uništava harmoniju** — svih 5 nota izvan opsega
padne na isti ton. Wrap po oktavama **čuva tonski rod** i zvuči muzički.
To je i tvorničko ponašanje Pa800 Style tracka (Wrap Around parametar).

Izmjereno na testu:
```
ch2 BASS 24..67 :  20 → 32    19 → 31    72 → 60
ch5 STRINGS 36..96: 30 → 42   33 → 45
```
Tonski rodovi očuvani: G#0→G#1, D#0→D#1, C4→C3, F#1→F#2, A1→A2.

---

## 3. Dokaz da radi — stvarni izlaz na namjerno „prljavom" MIDI-ju

Ulaz je imao: GS SysEx, bas notu na C7, zaglavljenu notu, notu nulte dužine,
dupli Note-On, siroče Note-Off, `vel=0`, damper ostavljen, pitch bend van centra.

```
FACTORY TRACK PARAMETERS (F-02 .. F-13)
 Ch role       CC7 CC10 CC11 CC91 CC93  key range   vel env      evidence
  2 BASS       112   64  127   12    0  24..67      20/95/127    PROVISIONAL
  5 STRINGS     94   64  127   44   10  36..96      28/76/120    PROVISIONAL

AUTO-FIX (K-serija)
  K-02  RX noise zona C7..G9 zasticena / oznacena          2
        · ch2 nota 96 RX noise - zasticena od transpozicije
        · ch5 nota 108 (nije RX cilj) -> ostavljena, oznacena
  K-03  Zaglavljene note zatvorene                         1
  K-04  Note nulte duzine produzene                        1
  K-05  Dupli Note-On -> legalan retrigger                 1
  K-06  Siroce Note-Off uklonjene                          1
  K-07  Note-On vel=0 normalizovan u Note-Off              1
  K-08  Velocity useljen u Factory envelopu                7
  K-09  Nedostajuci CC7/10/11/91/93 upisani               10
  K-11  Pitch bend vracen u centar                         1
  K-12  Damper CC64 otpusten na kraju                      1
  K-13  GS/XG/GM-reset SysEx uklonjen                      1
  ukupno                                                  27

VERIFICATION
  M-053 note count delta        0
  M-054 onset positions moved   0        ← ritmika netaknuta, dokazano
  M-052 space violations        0
```

**Ključno:** `M-054 onset positions moved = 0`. K-serija mijenja visinu, velocity,
dužinu i kontrolere — ali **nijedan onset se ne pomjera.** Ritmika ostaje sveta.

---

## 4. Šta slijedi (ekstraktor — da PROVISIONAL postane IZMJERENO)

| Korak | Zadatak | Izlaz |
|---|---|---|
| **E1** | Raspakovati Factory Styles korpus, parsirati na `(Style, Element, CV, Track)` | `CORPUS_MANIFEST.json` |
| **E2** | Izmjeriti F-02…F-05 (CC7/10/11/91/93) — medijan i raspon po ulozi **i po žanru** | `factory_profiles.json` |
| **E3** | Izvući F-12 velocity envelope (iskoristiti postojećih 268 FV00 profila) | isto |
| **E4** | Izvući F-08 Key Range iz stvarnog opsega nota po ulozi (p1/p99) | isto |
| **E5** | Izvući F-13 polifonijski strop (p95 istovremenih nota po ulozi) | isto |
| **E6** | F-06 FX tipovi iz Performance/Editor podataka | `factory_fx_map.json` |
| **E7** | Regresija: pustiti remapper **na tvornički stil** — izmjena mora biti ≈ 0 | `PARITY_REPORT.md` |

**E7 je najjači mogući test paritета:** ako alat na tvorničkom materijalu ne mijenja
ništa, znači da njegov model *jeste* tvornički model. Ako mijenja — model je pogrešan
i tačno vidimo gdje.

---

## 5. Kako se koristi već sada

```bat
:: puni lanac: auto-fix + factory parametri + key range + velocity + remap
run.bat song.mid -o song_PA800.mid -p RX_READY --articulated ^
        -l pa800_remap\data\PA800_FACTORY_SOUND_LIST_CC00_CC32_PC.txt --report

:: kad ekstraktor završi:
run.bat song.mid --factory-profiles factory_profiles.json --report

:: selektivno gašenje
run.bat song.mid --no-key-range --no-velocity
run.bat song.mid --no-autofix
```

U GUI-ju: kartica **„2b · Factory parity (F) + Auto-fix (K)"** — četiri prekidača
i polje za učitavanje izmjerenih profila. Izvještaj prikazuje punu F-tabelu po
kanalu, K-nalaze i verifikaciju.
