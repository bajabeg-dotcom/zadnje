# Pa800 Doktor za stilove

Popravlja Korg Pa800 stilove. **Tvoji originali se nikad ne mijenjaju** —
rezultat uvijek ide u novu mapu.

---

## Kako se pokreće

1. Dvoklik na **`POKRENI.bat`**

To je sve. Ništa se ne instalira.

Ako ti kaže da nema Pythona: skini ga sa <https://www.python.org/downloads/>
i na **prvom ekranu instalacije čekiraj "Add Python to PATH"**. Onda ponovo
klikni `POKRENI.bat`.

Ako nisi siguran da li Python radi, klikni **`PROVJERI_PYTHON.bat`** — reći
će ti tačno šta fali.

---

## Kako se koristi

Prozor te vodi kroz tri koraka.

**1. Gdje su tvoji stilovi?**
Klikni "Izaberi mapu..." i pokaži na mapu koja se zove nešto **`.SET`**
(onu koju prebacuješ na USB). Program sam nađe `STYLE` mapu unutra i javi
ti koliko je banaka našao.

**2. Šta hoćeš da uradim?**

| Izbor | Šta radi |
|---|---|
| **Samo provjeri** | Ništa ne mijenja i ništa ne snima. Samo ti kaže šta ne valja. |
| **Popravi sve** *(preporučeno)* | Sređuje pogrešne zvukove, jačine i bubnjeve, i prebacuje Pa3X/Pa4X stilove u Pa800 oblik. |
| **Samo prebaci Pa3X/Pa4X stilove** | Mijenja isključivo format. Zvukove i jačine ne dira. |

Ako ne znaš šta da biraš — prvo **Samo provjeri**, da vidiš stanje, pa onda
**Popravi sve**.

**3. Gdje da snimim rezultat?**
Popuni se samo. Tu nastaje nova `.SET` mapa koju prebaciš na USB i učitaš
u Pa800.

Onda klikni **URADI**.

---

## Šta ti kaže na kraju

```
Pogrešni zvukovi:  26486  ->  10   (74.3 %  ->  0.03 %)
Pa3X stilova prebačeno u Pa800 format: 21
Pomjerenih nota: 0   (tvoja muzika je netaknuta)
```

**"Pomjerenih nota: 0"** je ono najvažnije — znači da nijedna nota nije
dirana. Mijenjaju se samo postavke zvuka, nikad sama muzika.

Dugme **"Snimi izvještaj"** ti napravi tekstualni fajl sa detaljima po
bankama, ako hoćeš da provjeriš.

---

## Šta treba preslušati

Program popravlja ono što se sigurno može popraviti, ali tri stvari i dalje
traže tvoje uho:

- **Bubnjevi iz Pa3X stilova.** Mijenja se adresa kita, ali ne i raspored
  tipki — Pa3X i Pa800 nemaju iste bubnjeve na istim tipkama.
- **Zamjena bubanj-kitova.** Kad neki kit ne postoji na Pa800, bira se
  najbliži po pokrivenosti tipki. To je jedino pravilo koje *mijenja* zvuk,
  a ne samo popravlja.
- **Guitar Mode 2.** Ne može se prenijeti — Pa800 ima samo GM1.

---

## Za one koji hoće detalje

- `RULES_STYLE_OPTIMIZER.md` — sva pravila sa dokazima, uključujući
  dodatak **V-1.1** (Pa3X → Pa800 konverzija, dekodirana iz 97 uparenih
  stilova), dodatak **V-1.7** (Pa4X/PA700/PA1000: ElementInfo 44 → 28
  i TrackData 96 → 80, isto na 97 uparenih stilova), **V-1.8** (bajt 27
  je sadržaj, ne verzija) i **V-1.9** (S-14 za Pa4X izvore, iz firmvera)
- `RULES_DEFAULT_FORUMI_I_PA3X.md` — pravila iz uputstava i foruma
- `NALAZ_DOKAZI_ZIP_I_VISE_MODELA.md` — tabela 12 modela i geometrije
- `python tools/test_v5to4.py` — ponovo dokazuje Pa3X konverziju
  (93/97, razlika samo na bajtu 27 koji se sada čuva — V-1.8)
- `python tools/test_v5to4_pa4x.py` — ponovo dokazuje Pa4X konverziju
  (93/97 + 97/97 identično Pa3X putu)
- `python tools/test_v5to4_real_matrix.py` — provjera na pravim Style
  Works fajlovima (Pa4X i PA700 meta, 18 narodnjaka)

Program je podijeljen tako da se sve može koristiti i bez prozora:

```python
from pa800_remap import pipeline

pipeline.diagnose("D:/MOJ.SET")                     # samo cita
pipeline.repair("D:/MOJ.SET", "D:/MOJ_CIST.SET")    # popravlja
pipeline.convert_only("D:/MOJ.SET", "D:/MOJ_V4.SET")
```

Treba samo Python 3 i tkinter. Nema vanjskih biblioteka.
