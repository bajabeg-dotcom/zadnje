# Nalaz: `Dokazi.zip` + PDF dokazi — i da, ima ozbiljno gradivo za više modela
### 03.10.2026.

---

## 1. Kratko: šta si dostavio

`Dokazi.zip` (392 KB) nije dokumentacija — to je **cijeli drugi toolkit**:

| Fajl | Veličina | Šta je |
|---|---|---|
| `korg_sty_tool.py` | 107 KB | glavni STY alat |
| `korg_pa_manager_v5_gui.py` | 47 KB | objedinjeni GUI |
| `korg_pa_converter.py` | 40 KB | **cross-model konverter, 12 modela** |
| `korg_pa_optimizer.py` | 32 KB | zajednički optimizacijski engine |
| `korg_pa_manager_gui.py` | 31 KB | manager GUI |
| `korg_pa_database.py` | 24 KB | baza |
| `korg_pa_editors.py` | 20 KB | editori |
| `korg_pa_style_optimizer.py` | 18 KB | Style optimizator |
| `korg_pa_song_optimizer.py` | 15 KB | Song optimizator |
| `PA800_OS_RE_REPORT.md` | 7,5 KB | **reverse engineering cijelog OS-a** |
| `pa800_resource_catalog.json` | 32 KB | katalog resursa |

Plus PDF-ovi koje sam ranije površno prešao, a koji su ogromni:

| PDF | Strana | Znakova |
|---|---|---|
| `MASTER_SVE_DOKAZI` | **335** | 877.526 |
| `REVERSE_ENGINEERING_MAIN` | 87 | 242.324 |
| `PA800_INSTRUMENTI_I_DRUM_KITOVI` | 89 | 314.269 |
| `STY_PERFORMANCE_SOUND_BKP_TEHNICKI_DOSJE` | 7 | 16.059 |

Priznajem: rekao sam ti da priručnika nema, i prešao preko ovoga prebrzo.
Priručnika zaista nema, **ali ovi PDF-ovi pokrivaju više nego priručnik** —
jer sadrže ono što u priručniku ne piše: bajtove.

---

## 2. DA — ima ozbiljno gradivo za više modela

`korg_pa_converter.py` nosi `MODEL_REGISTRY` sa **12 Korg PA modela** i
njihovim tačnim geometrijama. Ovo je najvrjednija stvar u paketu:

| Model | Inner ver. | ElementInfo | TrackData | STS layout | Porodica |
|---|---|---|---|---|---|
| PA80 | v2 | 27 | 48 | legacy two-child | legacy |
| PA1X | v2 | 27 | 48 | legacy two-child | legacy |
| PA2X | v4 | 28 | 80 | legacy two-child | legacy |
| PA500 | v4 | 28 | 80 | legacy two-child | legacy |
| PA600 | v4 | 28 | 80 | legacy two-child | legacy |
| **PA800** | **v4** | **28** | **80** | legacy two-child | legacy |
| PA3X | v5 | 28 | 88 | nested new-gen | nested |
| PA3XLE | v5 | 28 | 88 | nested new-gen | nested |
| PA900 | v5 | 28 | 88 | nested new-gen | nested |
| PA4X | v5 | **44** | 88 | nested new-gen | nested |
| PA700 | v5 | 44 | **96** | nested new-gen | nested |
| PA1000 | v5 | 44 | 96 | nested new-gen | nested |

Pravila konverzije koja alat tvrdi da ima dokazana:

- **v4 ↔ v5 je dokazano** (EI/TD resize).
- **v2 → v4/v5 je fail-closed** — odbija izmisliti bajt `ElementInfo` koji
  v2 nema. Isto i obrnuto: v4/v5 → v2 odbija bacati NTT/NTR bajtove.
  To je ispravno ponašanje i slaže se sa mojim pravilom "ništa se ne izmišlja".

**Praktična posljedica za nas:** moj Style Optimizer već čita `TrackData`
dužine 48 / 80 / 88, dakle **v2, v4 i PA3X v5 geometriju**. Nedostaje samo
96 (PA700/PA1000). Uz mali dodatak, S-serija bi radila na **10 od 12 modela**.

---

## 3. Testirao sam tvoj materijal protiv te tabele — i nalaz je krupan

Detekcija po stvarnoj geometriji, ne po imenu fajla:

| Korpus | v2 (27/48) | v4 (28/80) | v5 (28/88) |
|---|---|---|---|
| **Pa800 tvornički** | **330** | 79 | 0 |
| Tvoje USER/FAVORITE | 4 | 335 | 0 |
| **Pa3xStyle Wrhunski** | 0 | **430** | **21** |
| Moj očišćeni SET | 4 | 335 | 0 |

### Tri stvari koje ovo otkriva

**(a) Pa800 tvornička biblioteka je većinom naslijeđena.** 330 od 409
tvorničkih stilova su **v2 geometrija (PA80/PA1X)**, a samo 79 je prava v4.
Korg je pri izradi Pa800 prenio stari i-Series/Pa80 materijal kakav jeste.
To objašnjava zašto su `NTT/NTR packed` vrijednosti tako rijetke i
jednostavne — većina stilova je iz ere prije bogatog NTT-a.

**(b) "Pa3xStyle Wrhunski" je POLOVIČNO konvertovan.** 430 od 451 stilova
je **već prebačeno u v4 (Pa800) geometriju** — neko je uradio strukturnu
konverziju. Ali adrese zvukova su ostale Pa3x (`LSB 64/65`), što sam izmjerio
ranije: **74,3 % traka pokazuje na nepostojeći zvuk.**

To je tačno ono što forumi opisuju: kontejner se konvertuje, zvuk ne.
Konverzija je stala na pola.

**(c) 21 stil je ostao prava PA3X v5 geometrija — oni se fizički ne mogu
svirati na Pa800.** Evo tačno kojih:

| Banka | Slot | Ime |
|---|---|---|
| USER04 | 34 | KadBiLjudiBili G |
| USER04 | 36 | Sinan - Sudbina |
| USER05 | 2 | Djani-Daj mi mal |
| USER05 | 11 | Sreco pojavi se |
| USER05 | 20 | Nisam te ponizio |
| USER05 | 33 | Lexington-Donesi |
| USER07 | 34 | Seka - Poludela |
| USER07 | 40 | Stoja - Splav Cm |
| USER08 | 8 | Reci sve zelje |
| USER08 | 25 | Stoja - Da,Da,Da |
| USER08 | 27 | Manastirska Hm |
| USER08 | 30 | Ceca - Bivsi |
| USER08 | 39 | Dosao sam Kemal |
| USER09 | 15 | Sladjana |
| USER09 | 16 | Ne kuni je majko |
| USER10 | 2 | Disko-Riff 110 |
| USER10 | 5 | Disko-Bongo EXP |
| USER12 | 30 | Vahde EXP7 |
| USER12 | 32 | Sirtaki EXP7 |
| USER12 | 33 | Dvojka Nikola 7 |
| USER12 | 38 | Rock Disko-EXP7 |

Za ovih 21 postoji dokazan put: **v5 → v4 resize** iz `korg_pa_converter.py`,
pa onda moj S-10 za adrese zvuka. To je kompletan lanac.

**(d) Moj očišćeni SET nije pomjerio geometriju** — 4 v2 + 335 v4, identično
ulazu. Dobra vijest: optimizacija nije dirala format.

---

## 4. Reverse engineering cijelog OS-a — ovo nisam imao

`PA800_OS_RE_REPORT.md` opisuje rastavljanje **zvaničnog Pa800 OS v2.02 PKG-a
(134 MB)** sa Korgovog servera:

- 746 OC20 stranica, 94 logička fajla, KORF/KBEG/KEND indeks
- 13 PCG/KMP instrumenata, **3 STY banke (148 stilova)**, 3 drum kit fajla
- GUI resurs 4,26 MB (Delphi VCL-like), 7 jezika
- Zadnja 4 MB = `MZX10` firmware updater

**148 stilova iz OS-a su korpus koji ja nisam mjerio** — moj korpus je imao
435 stilova iz Style banaka. Ovih 148 (Easy Listening 48, World 49,
Jazz/Big Band 51) bi proširilo bazu na **583 stila**.

---

## 5. Nalaz koji me direktno ispravlja — drum velocity layeri

Ovo je najvažnije praktično. OS RE izvještaj daje **velocity layer prekidače
po tipki**:

**Pop Std. Kit RX (120.0.4)**

| Tipka | Instrument | Slojeva | Velocity prekidač |
|---|---|---|---|
| 36 | Kick | 1 | — |
| 38 | Snare | 2 | **80** |
| 42 | Closed Hat | 1 | — |
| 46 | Open Hat | 2 | **90** |
| 48 | Tom 1 | 2 | 85 |
| 50 | Tom 2 | 2 | 85 |
| 49 | Crash | 2 | 80 |
| 51 | Ride | 2 | 80 |
| 57 | Crash 2 | 2 | 85 |

**Jazz Kit** — snare prekidač na **70** (niži), crash na 75.

### Problem u mom pravilu S-04

Moje pravilo preseljava velocity u izmjerenu tvorničku envelopu. Za DRUM sam
izmjerio `floor 33 / median 89 / ceiling 127`. **Medijana 89 je iznad snare
prekidača na 80.**

To znači: moj S-04 može preseliti snare udarac sa 78 na 85 — i time
**prebaciti koji se sample uopšte okida**. Tiši snare postane glasni snare.
Zvuk se mijenja kvalitativno, ne samo u jačini.

U očišćenom SET-u je 273.161 nota preseljeno. Dio toga su bubnjevi koji su
mogli preskočiti prag sloja. **To treba popraviti prije nego što pustiš SET
ozbiljno u rad.**

Ispravka je jasna i sad imam brojeve za nju: velocity remap na drum trakama
mora biti **monoton unutar sloja** — nikad ne smije preći prag 70/75/80/85/90
za tu tipku. Zanimljivo, `korg_pa_optimizer.py` iz tvog paketa već ima
`PA800_DRUM_KIT_LAYERS` upravo za to.

---

## 6. Šta predlažem dalje, poredano po koristi

1. **Popraviti S-04 na drum trakama** da poštuje layer pragove, pa
   **ponovo izgraditi SET**. Ovo je jedino što bih uradio prije slušanja.
2. **Preuzeti 148 stilova iz OS PKG-a** i proširiti mjerenje sa 435 na 583
   stila — tačniji profili besplatno.
3. **Konvertovati onih 21 v5 stila** (v5→v4 resize + S-10), čime
   "Pa3xStyle Wrhunski" postaje 100 % upotrebljiv na Pa800.
4. **Proširiti S-seriju na TrackData 96** → pokriva svih 12 modela.
5. Spojiti dva alata: tvoj `korg_pa_converter.py` zna modele, moj
   `styleopt.py` zna tvorničke profile. Zajedno su potpuni.

---

## 7. Iskreno o preklapanju

Tvoj `korg_pa_style_optimizer.py` i moj `styleopt.py` rade sličan posao.
Razlika:

- **Tvoj** ima cross-model konverziju, žanrovske preference instrumenata,
  drum layer tabele, RX/DNC trigger remap, FX routing.
- **Moj** ima profile **izmjerene na 4.264.484 tvornička događaja**,
  holdout test (86,3 %), validaciju adresa zvuka protiv 1060 važećih
  selektora, i diferencijalni dokaz da nijedna nota nije pomjerena.

Nema smisla da postoje dva. Predlažem da moje izmjerene profile i validator
adresa ubacim u tvoj engine, a zadržim svoj dokazni lanac. Reci da krenem.
