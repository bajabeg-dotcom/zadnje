# PRAVILA REMAPIRANJA ZA KORG Pa800 (M-serija)
**Verzija:** M-1.0 · **Datum:** 2026-10-03 · **Mjesto u pipeline-u:** **POSLJE** optimizacije (Faza 5), kao zadnji korak prije isporuke songa

---

## 0. Pozicija u lancu i preduslovi

```
[SMF ulaz] → analyze → optimize (artikulacije/noise/groove) → ►► REMAP ◄◄ → verify → [Pa800 song]
```

| ID | Preduslov | Ponašanje ako nije ispunjen |
|---|---|---|
| **M-000.1** | Song je prošao optimizaciju (artikulacijski sloj upisan) | Remap se izvršava u profilu `SAFE` (bez RX zvukova) |
| **M-000.2** | Učitan je `PA800_FACTORY_SOUND_LIST_CC00_CC32_PC.txt` (1003 bindinga) | Radi se na ugrađenoj bazi (GM baseline + verifikovani RX/DNC), drum kitovi se **ne diraju** |
| **M-000.3** | Remap se nikada ne izvršava prije optimizacije | Hard guard — `RemapBeforeOptimizeForbidden` |

> **Razlog za M-000.1:** RX zvukovi dijele velocity opseg na artikulacijske OSC slojeve (npr. *Finger Bass RX*: 1-22 GLISS · 23-52 STOP · 53-113 WORKING · 114-127 HARMONIC). Ako song nije prethodno artikulacijski obrađen, mapiranje na RX **proizvodi pogrešnu artikulaciju**, ne bolji zvuk. Zato je RX mapiranje uslovljeno.

---

## 1. Adresni model (dokazano)

**Izvor:** `PA800_FACTORY_SOUND_LIST_CC00_CC32_PC.txt` — zaglavlje: *"Program Change numbering: 0-127 · Unique sound bindings: 1003"*

| ID | Pravilo | Dokaz |
|---|---|---|
| **M-001** | Pa800 zvuk je trojka **(CC00 = Bank MSB, CC32 = Bank LSB, PC = Program Change)**. Sva tri se emituju zajedno. | Struktura kataloga |
| **M-002** | Redoslijed emitovanja je obavezan: **CC#0 → CC#32 → Program Change**, svi na istom ticku, **prije prvog Note-On** na tom kanalu. | MIDI bank-select standard; Pa800 prihvata PC tek nakon bank para |
| **M-003** | **CC00 = 121** → melodijski/tonalni set (GM-kompatibilan prostor). **CC00 = 0** → Drum kit prostor (npr. `Jungle Kit 0.10.11`). | Katalog: svi tonalni zapisi imaju 121; drum zapisi 0 |
| **M-004** | **CC32 = 0** je uvijek GM-ekvivalent (ime završava na `GM`). **CC32 = k > 0** su Pa800 varijante **iste GM porodice** na istom PC. | Katalog: `AcousticPiano GM 121.0.0`, `Ac. Piano Wide 121.1.0`, `Grand Piano 121.3.0`, `Grand Piano RX 121.10.0` — svi PC=0 |
| **M-005** | PC numeracija je **0-127** (ne 1-128). Konverzija iz 1-based izvora je obavezna i logovana. | Zaglavlje kataloga |

**Posljedica (ključna):** svaki GM program `n` ima garantovani Pa800 pandan na `(121, 0, n)`, a nadogradnja na bolji zvuk je **kretanje po CC32 unutar istog PC**. To je osnova cijelog remappera i razlog zašto nema „slijepih" mapiranja.

---

## 2. Profili remapiranja

| Profil | Šta radi | Kada |
|---|---|---|
| `GM_BASELINE` | Sve na `(121, 0, PC)` — čisti GM ekvivalent | Maksimalna sigurnost, kontrolni test |
| `SAFE` | GM baseline + kurirani ne-RX upgrade (npr. `Grand Piano 121.3.0` umjesto `AcousticPiano GM`) | **Default** kad song nije optimizovan |
| `STANDARD` | SAFE + DNC zvukovi + stereo/wide varijante | Song optimizovan, bez RX zahtjeva |
| `RX_READY` | STANDARD + RX zvukovi na Bass/Guitar/Strings/Voices | **Samo** ako je artikulacijski sloj dokazano upisan (M-000.1) |
| `CUSTOM` | Korisnička tabela mapiranja (CSV), override nad svim | Ručna kontrola |

---

## 3. Pravila izbora zvuka (M-01x)

| ID | Pravilo | Obrazloženje / dokaz |
|---|---|---|
| **M-010** | Izbor se traži **unutar istog PC** (iste GM porodice). Prelazak na drugi PC je zabranjen osim preko `CUSTOM` tabele. | M-004; sprječava promjenu instrumenta |
| **M-011** | Prioritet unutar PC-a (profil `STANDARD`): kurirani izbor → stereo/wide varijanta → `GM` baseline. | Katalog imenovanje (`Wide`, `Stereo`, `Dark`) |
| **M-012** | `RX` zvuk se bira **samo** u profilu `RX_READY` **i** ako track ima artikulacijski sloj. | Velocity-layer arhitektura RX zvukova (I-REG) |
| **M-013** | `DNC` zvuk se bira samo ako u tracku postoje DNC kontroleri (CC putanje); inače se tretira kao običan zvuk. | DNC = Defined Nuance Control, 23 zvuka |
| **M-014** | Ako PC nije pronađen u bazi → fallback `(121, 0, PC)` + upis u `UNRESOLVED` log. Nikad tiha greška. | M-002 garancija |
| **M-015** | Zvuk sa `V.` u imenu (Valve/rotary varijante organa) ne bira se automatski — zahtijeva eksplicitan izbor. | Specifično ponašanje rotary/percussion kontrola |

### 3.1 Kurirana RX/DNC tabela (verifikovane adrese iz tvoje evidencije)

| Zvuk | CC00 | CC32 | PC | Izvor dokaza |
|---|---|---|---|---|
| Grand Piano RX | 121 | 10 | 0 | Sound list |
| Bright Piano RX | 121 | 5 | 1 | Sound list |
| Tine E.Piano RX | 121 | 18 | 4 | Sound list |
| EP+Damper1 DNC | 121 | 25 | 4 | Sound list |
| EP+Damper2 DNC | 121 | 26 | 4 | Sound list |
| Harpsi KeyOff RX | 121 | 3 | 6 | Sound list |
| Harpsi 16' RX | 121 | 5 | 6 | Sound list |
| Clav Wah RX | 121 | 2 | 7 | Sound list |
| Clav RX | 121 | 5 | 7 | Sound list |
| Synth Clav RX | 121 | 6 | 7 | Sound list |
| Jimmy Organ DNC | 121 | 13 | 18 | Sound list |
| Clean Funk RX2 | 121 | 11 | 28 | Katalog instrumenata (8 OSC) |
| Clean Guitar RX1 | 121 | 14 | 28 | Katalog instrumenata (7 OSC, HW verified partial) |
| Acous. Bass RX | 121 | 7 | 32 | Katalog instrumenata (7 OSC) |
| Finger Bass RX | 121 | 13 | 33 | Katalog instrumenata (5 OSC, HW observed) |
| Picked Bass RX | 121 | 10 | 34 | Katalog instrumenata (5 OSC, HW exact OSC1-4) |
| FunkSlap Bass RX | 121 | 3 | 36 | Katalog instrumenata (7 OSC) |
| SlapFing Bass RX | 121 | 4 | 36 | Katalog instrumenata (5 OSC) |
| SlapPick Bass RX | 121 | 5 | 36 | Katalog instrumenata (5 OSC) |
| Strings Ens. RX | 121 | 22 | 48 | Katalog instrumenata (8 OSC) |
| Concert Str.RX | 121 | 23 | 48 | Katalog instrumenata (8 OSC) |
| Scat Voices RX | 121 | 19 | 52 | Katalog instrumenata (8 OSC) |
| Banjo RX | 121 | 4 | 105 | Katalog instrumenata (6 OSC) |

---

## 4. Drum kanal (M-02x)

| ID | Pravilo |
|---|---|
| **M-020** | MIDI kanal **10** (index 9) je drum kanal. Mapira se **isključivo** u prostor `CC00 = 0`. |
| **M-021** | Drum kit se ne mijenja ako nije učitan puni sound list (M-000.2) — bez dokazane adrese nema zapisa. |
| **M-022** | Nakon izbora kita **obavezna je provjera per-key pokrivenosti**: svaka korištena nota mora postojati u mapi tog kita (I-REG, 51 kit adresa sa per-key dokazom, 2003 per-key zapisa). Nepokrivena nota → upozorenje + prijedlog zamjenske tipke. |
| **M-023** | Drum tipke se **ne transponuju** pri remapu (arranger ne transponuje Drum/Perc — potvrđeno PA800-002). |
| **M-024** | Ako song koristi RX drum kit (21 postoji), velocity slojevi se **ne diraju** — oni su rezultat optimizacije, ne remapa. |

---

## 5. Kanali i track role (M-03x)

| ID | Pravilo | Dokaz |
|---|---|---|
| **M-030** | Song zadržava postojeću raspodjelu kanala; remap ne premješta kanale osim ako nije uključen `channel_normalize`. | Sprječava razbijanje aranžmana |
| **M-031** | Gtr track zahtijeva eksplicitan `Track Type = Gtr`; obična gitarska dionica na običnom kanalu **nije** Gtr track. | PA800-004 |
| **M-032** | Kontrolne oktave Guitar Mode-a i RX noise zona **C7..G9** se pri remapu **ne tretiraju kao melodijske note** i ne smiju biti transponovane ni filtrirane. | Katalog: OSC 5 `RX_NOISE` key zona C7..G9 |
| **M-033** | Ako ciljni zvuk **nije** RX, a u tracku postoje note u C7..G9 (noise zona) → upozorenje `ORPHAN_NOISE_KEYS`, note se označavaju, ne brišu automatski. | M-012 |

---

## 6. Emitovanje i konflikti (M-04x)

| ID | Pravilo |
|---|---|
| **M-040** | Postojeći CC#0 / CC#32 / PC događaji u tracku se **zamjenjuju**, ne dupliraju. |
| **M-041** | Promjena zvuka usred tracka dozvoljena je samo na granici fraze (pauza ≥ 1/8) — inače se pomjera na prvu takvu granicu. |
| **M-042** | Bank/PC blok se upisuje na tick prvog događaja kanala, **prije** svih CC i Note-On poruka na istom ticku. |
| **M-043** | Opcioni `init blok` (Volume CC7, Pan CC10, Reverb CC91, Chorus CC93) upisuje se samo ako je eksplicitno uključen; default **isključen** — remap dira zvukove, ne mix. |

---

## 7. Verifikacija (M-05x) — remap nije gotov bez ovoga

| ID | Provjera | Prolaz |
|---|---|---|
| **M-050** | Svaki kanal sa notama ima potpunu (CC00, CC32, PC) trojku | 100 % |
| **M-051** | Svaka trojka postoji u sound listi / kuriranoj bazi | 100 %, `UNRESOLVED = 0` |
| **M-052** | Nijedan tonalni kanal ne koristi `CC00 = 0`, nijedan drum kanal ne koristi `CC00 = 121` | 100 % |
| **M-053** | Broj nota prije i poslije remapa je identičan (remap ne briše muziku) | Δ = 0 |
| **M-054** | Timing nepromijenjen (remap ne dira ritmiku) | Δ ticks = 0 |
| **M-055** | Generisan `REMAP_REPORT` sa `rule_id` za svaku izmjenu | obavezno |

---

## 8. Format izvještaja

```json
{
  "track": 3, "channel": 2, "role": "Bass",
  "before": {"cc00": 0,   "cc32": 0,  "pc": 33, "name": "GM Electric Bass (finger)"},
  "after":  {"cc00": 121, "cc32": 13, "pc": 33, "name": "Finger Bass RX"},
  "rule": "M-012", "profile": "RX_READY",
  "evidence": "I_REG#FingerBassRX (121.13.33, 5 OSC, HARDWARE_OBSERVED_PARTIAL)",
  "warnings": []
}
```
