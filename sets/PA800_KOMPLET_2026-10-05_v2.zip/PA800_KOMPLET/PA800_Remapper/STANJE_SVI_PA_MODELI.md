# Korg Pa arranžeri — šta je riješeno, šta fali
### 05.10.2026. · sistematski pregled svih modela

---

## 1. ZVUKOVI — univerzalna remap matrica

Izvor: **Style Works XT Universal** `.SND` tabele iz `snd_all.csv`
(62.181 red, 71 instrument, 9 proizvođača).

**Čitanje kolona (bitno — zamijenjene su):**
```
CC00 (MSB) = kolona 'type'
CC32 (LSB) = kolona 'pc'
PC         = kolona 'msb'
```
Potvrđeno na hardveru: `120.0.15` = Techno Kit 3 (bubanj traka),
`121.13.33` = Finger Bass RX (bas traka) u tvom `Modern Ballad`.

### Tabele koje IMAM

| model | zvukova | izvor |
|---|---:|---|
| PA80 | 984 | `rom_PA80.SND` |
| PA1X | 1.841 | `rom_PA1x.SND` |
| PA2X | 2.033 | `rom_PA2x.SND` |
| **PA800** | **1.058** | PA2X ∩ dokazani Pa800 selektori |
| PA3X | 2.522 | `rom_PA3x.SND` |
| PA4X | 3.332 | `rom_PA4x.SND` |

Plus i3 / i30 / i40 (starija i-serija).

### Matrica pokrivenosti — svih 30 smjerova

`data/korg_pa_remap_matrix.json`

| iz \ u | PA80 | PA1X | PA2X | PA800 | PA3X | PA4X |
|---|---:|---:|---:|---:|---:|---:|
| **PA80** | — | 99,6 | 96,2 | 79,3 | 96,7 | 99,9 |
| **PA1X** | 95,2 | — | 97,8 | 55,8 | 97,9 | 99,9 |
| **PA2X** | 90,4 | 95,5 | — | 62,1 | 100 | 100 |
| **PA800** | 81,9 | 91,4 | 100 | — | 100 | 100 |
| **PA3X** | 89,0 | 94,8 | 99,1 | **58,4** | — | 100 |
| **PA4X** | 95,3 | 96,6 | 98,2 | **67,3** | 98,7 | — |

**Čita se ovako:** nagore (ka novijem) je gotovo savršeno. Nadolje ka
**Pa800 je usko grlo** — on ima samo 1.058 zvukova, pa 30–45 % zvukova
novijih modela nema parnjaka.

Metoda: prvo tačno ime, pa najbliže ime unutar iste kategorije
(prag sličnosti 0,55), pa ništa.

---

## 2. ŠTA FALI — po prioritetu

### 2.1 Tabele zvukova kojih nema

| model | generacija | zamjena koju mogu koristiti |
|---|---|---|
| **PA3XLE** | Z107A | PA3X (ista generacija, vrlo blizak ROM) |
| **PA900** | Z104A | PA3X — **nepotvrđeno** |
| **PA600** | Z103A | PA3X — **nepotvrđeno** |
| **PA300** | Z106A | PA600 — **nepotvrđeno** |
| **PA500** | — | PA2X — **nepotvrđeno** |
| **PA700** | — | PA4X — **nepotvrđeno** |
| **PA1000** | — | PA4X — **nepotvrđeno** |
| **Pa5X** | clip arhitektura | nema osnove |

Za prva dva-tri je zamjena razumna; dalje je nagađanje i ne bih je pustio
bez provjere.

### 2.2 Format — rupe u kodeku

| stavka | stanje |
|---|---|
| TrackData 48 / 80 / 88 | **čitam** |
| **TrackData 96** (PA4X/PA700/PA1000) | **čitam i konvertujem — V-1.7, 05.10.** (93/97 na INIT parovima; 18/18 na pravom materijalu) |
| ElementInfo 26/27/28 | čitam |
| **ElementInfo 44** (PA4X/PA700/PA1000) | **dekodirano — V-1.7**: 44 = 28 + konstantan marker od 16 B |
| bajt 27 ElementInfo | **sadržaj, ne verzija — V-1.8**: konverter ga čuva (ispravka V-1.1) |
| v2 ↔ v4 ↔ v5 | riješeno |
| granica 13 elemenata | riješeno (S-13) |

Napomena (05.10., poslije V-1.7/V-1.8): dokazano na INIT renderima
(93/97) i na PRAVOM materijalu: `Pa4x--Pa4X.sty` (EI miješan 44/28) i
`Pa4x--Pa700.sty` (44/96, prvi pravi PA700-formatni fajl u rukama) —
18/18 konvertovano, interno konzistentno, izlaz iz oba izvora identičan.
Fajl kreiran NA samom PA700/PA1000 instrumentu još nije viđen.

NOVI OTVORENI PROBLEM: `Pa700--Pa4X.sty` (izvor PA700) — 7 od 64 OC31
resursa pada na CBarc dekompresiji ("match precedes output buffer",
"produced X expected Y"). Izgleda da PA700-izvorne arhive koriste
varijantu CBarc enkodiranja. Sljedeći RE trag.

### 2.3 Što se NE može riješiti

| | razlog |
|---|---|
| **STS (ID-09) među generacijama** | PA Manager to sam odbija: *„STS Version NOT Compatible"* |
| **Guitar Mode 2 → Pa800** | Pa800 je GM1 |
| **4. fill na Pa800** | Pa800 ima 3 |
| **Pa5X clip format** | druga arhitektura (XML CLIP/SESSION/SCENE) |

### 2.4 Bubnjevi — najveći preostali muzički problem

Zamjenjujem **adresu kita** (S-12, 77 adresa), ali **ne i raspored
tipki**. Pa3X i Pa800 nemaju iste bubnjeve na istim tipkama. To je ono
što se prvo čuje kao pogrešno.

Za to bi trebale per-key mape obje generacije. Za Pa800 ih imam
(8.320 redova, 65 kitova). **Za Pa3X ih nemam.**

---

## 3. Redoslijed koji bih predložio

1. ~~**Ugraditi S-14** (remap po imenu) ispred S-10~~ — **URADJENO**
   (u `styleopt.py`, pokrece se prije S-10; OUT setovi su s time sagrađeni).
2. ~~**TrackData 96** — otvara PA700/PA1000~~ — **URADJENO 05.10. (V-1.7)**:
   citanje i konverzija, 93/97 bajt-u-bajt na INIT parovima, identicno
   Pa3X putu 97/97. Test: `tools/test_v5to4_pa4x.py`.
3. ~~**ElementInfo 44 → 28** — otvara Pa4X kao izvor~~ — **URADJENO 05.10.
   (V-1.7)**: 44 = 28 + konstantni marker; Dejanovih 26 stilova sada moze
   kao izvor.
4. Bubnjarske per-key mape za Pa3X — traži novi izvor. **(sledece na redu)**
5. Testirati na stvarnim PA700/PA1000 fajlovima čim se domognu nekog.

---

## 4. Datoteke

```
data/korg_pa_sound_tables.json     6 modela, imena po adresi
data/korg_pa_remap_matrix.json     30 smjerova, remap po imenu
data/pa3x_to_pa800_by_name.json    Pa3X -> Pa800 (S-14)
data/pa4x_to_pa800_by_name.json    Pa4X -> Pa800 (S-14, V-1.9: iz firmvera!)
data/pa800_drum_kits.json          65 kitova, 8.320 redova po tipkama
data/drum_kit_substitution.json    77 adresa (S-12)
```

**V-1.9 (05.10.):** S-14 sada radi i za Pa4X izvore — tabela imena iz Pa4X
FIRMVERA (2059 zvukova iz `pa4x-kod.zip`, hardverski izvor, jači od Style
Works .SND). Pokrivenost 83 %. Na pravim narodnjacima: 65,4 % -> 0,05 %
pogrešnih zvukova. Time je „Pa4X kao izvor" potpuno funkcionalan.
