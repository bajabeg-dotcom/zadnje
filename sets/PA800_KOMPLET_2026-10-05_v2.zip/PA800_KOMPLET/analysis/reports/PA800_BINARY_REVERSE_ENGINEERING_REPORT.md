# PA800 BINARY REVERSE ENGINEERING REPORT

## 1. File identification

| file | size | sha256 (8) | entropy | strings A/U | header |
|---|---:|---|---:|---|---|
| NEWNAME_USER01_hw | 12070 | `1d115dd5` | 7.3797 | 188/1 | `01 00 01 14 00 00 2f 1e` |
| InitPx02_pa3x | 257357 | `a4427bc3` | 7.2576 | 2746/66 | `01 00 01 14 00 03 ed 45` |
| InitPx02_pa800 | 248191 | `9e552fde` | 7.2723 | 2646/66 | `01 00 01 14 00 03 c9 77` |

## 2. Header

**NEWNAME_USER01_hw**
```
bytes : 01 00 01 14 00 00 2f 1e 02 00 00 18 00 00 00 0c
ascii : ....../.........
```

**InitPx02_pa3x**
```
bytes : 01 00 01 14 00 03 ed 45 02 00 00 18 00 00 00 0c
ascii : .......E........
```

**InitPx02_pa800**
```
bytes : 01 00 01 14 00 03 c9 77 02 00 00 18 00 00 00 0c
ascii : .......w........
```

## 3. Binary structure (CANDIDATES)

**NEWNAME_USER01_hw** — length 1, offset 3, count 18, fixed-record runs 0

**InitPx02_pa3x** — length 1, offset 40, count 0, fixed-record runs 11
  - run @ 0x24 stride 24 × 26 — ['The Avalon', '6/8 R & B', "Groovin'"]
  - run @ 0x10e6 stride 28 × 9 — ['7C)\x08ÐH\x03þ\x82üA\r%9}<-9|`<"9}<49}', "<.9}<-9}<'9|\x03<ä\x01;Ú(9|\x03CØ", '9}<$9}<29}<$9}<09}<.9}<=9|%S']
  - run @ 0x307ec stride 28 × 8 — ['UL \x0e"T\x03$â\x01*î$"T\x03,ÒÎ', 'U,&"T\x03,ÑÀ', ',*"T\x03,Öè']
  - run @ 0x398c stride 8 × 8 — ["'4y</4x`", '|,4x\x83\x94"4', 'x"&à\'4x\x1b']

**InitPx02_pa800** — length 1, offset 40, count 0, fixed-record runs 11
  - run @ 0x24 stride 24 × 26 — ['The Avalon', '6/8 R & B', "Groovin'"]
  - run @ 0x10de stride 28 × 9 — ['7C)\x08ÐH\x03þ\x82üA\r%9}<-9|`<"9}<49}', "<.9}<-9}<'9|\x03<ä\x01;Ú(9|\x03CØ", '9}<$9}<29}<$9}<09}<.9}<=9|%S']
  - run @ 0x3071c stride 28 × 8 — ['UL \x0e"T\x03$â\x01*î$"T\x03,ÒÎ', 'U,&"T\x03,ÑÀ', ',*"T\x03,Öè']
  - run @ 0x3984 stride 8 × 8 — ["'4y</4x`", '|,4x\x83\x94"4', 'x"&à\'4x\x1b']

## 4. Offset map

**InitPx02_pa3x**
```
0x00000024-0x00000294  record run (stride 24, n=26)   HYPOTHESIS
0x000010e6-0x000011e2  record run (stride 28, n=9)   HYPOTHESIS
0x00001cee-0x00001d0e  record run (stride 4, n=8)   HYPOTHESIS
0x00001e70-0x00001e94  record run (stride 4, n=9)   HYPOTHESIS
0x0000398c-0x000039cc  record run (stride 8, n=8)   HYPOTHESIS
0x000039da-0x00003a0a  record run (stride 6, n=8)   HYPOTHESIS
0x0000dd5b-0x0000dd7b  record run (stride 4, n=8)   HYPOTHESIS
0x00022aeb-0x00022b2b  record run (stride 8, n=8)   HYPOTHESIS
0x0002c089-0x0002c0a9  record run (stride 4, n=8)   HYPOTHESIS
0x00030789-0x000307b9  record run (stride 6, n=8)   HYPOTHESIS
```

**InitPx02_pa800**
```
0x00000024-0x00000294  record run (stride 24, n=26)   HYPOTHESIS
0x000010de-0x000011da  record run (stride 28, n=9)   HYPOTHESIS
0x00001ce6-0x00001d06  record run (stride 4, n=8)   HYPOTHESIS
0x00001e68-0x00001e8c  record run (stride 4, n=9)   HYPOTHESIS
0x00003984-0x000039c4  record run (stride 8, n=8)   HYPOTHESIS
0x000039d2-0x00003a02  record run (stride 6, n=8)   HYPOTHESIS
0x0000dd10-0x0000dd30  record run (stride 4, n=8)   HYPOTHESIS
0x00022a49-0x00022a89  record run (stride 8, n=8)   HYPOTHESIS
0x0002bfcb-0x0002bfeb  record run (stride 4, n=8)   HYPOTHESIS
0x000306b9-0x000306e9  record run (stride 6, n=8)   HYPOTHESIS
```

## 5. MIDI regions

- **NEWNAME_USER01_hw**: SMF files 0, MIDI-like regions 0
- **InitPx02_pa3x**: SMF files 0, MIDI-like regions 5
- **InitPx02_pa800**: SMF files 0, MIDI-like regions 9

## 6. Sound candidates

| offset | enc | value | meaning | conf | status |
|---|---|---|---|---:|---|
| `TrackData cols 1-3` | u8 x3 | MSB/LSB/PC | sound selector triple; Pa800 factory uses MSB 120/121 and LSB 0..35 only | 0.96 | **VERIFIED** |

## 7. Velocity candidates

| offset | enc | value | meaning | conf | status |
|---|---|---|---|---:|---|
| `Note-On byte 2` | u8 (0x80 | v) | 1..127 | velocity byte in the Pattern stream: high bit ALWAYS set, velocity is the low 7 bits | 0.95 | **VERIFIED** |
| `-` | - | none | velocity has NO raw .STY offset: the STYLE resource is OC-compressed on disk | 0.9 | **VERIFIED** |

## 8. Style candidates

| offset | enc | value | meaning | conf | status |
|---|---|---|---|---:|---|
| `0x00` | bytes | [ident,00,minor,08] | style node header: 4 tag bytes then u32be payload length | 0.99 | **VERIFIED** |
| `0x01` | u8 | 5=Pa3X 4=Pa800 2=Pa1X | style format version at root byte 1 | 0.99 | **VERIFIED** |
| `+0x00` | pascal | len+ASCII | StyleInfo begins with a Pascal-style name (1 length byte + chars) | 0.98 | **VERIFIED** |
| `1+len(name)+3` | u16be | e.g. 0x1fff | style element content bitmap; popcount == number of stored elements | 0.99 | **VERIFIED** |
| `-` | - | 13 | Pa800 addresses at most 13 style elements | 0.95 | **VERIFIED** |
| `0x24` | fixed record (24 B) | directory | bank resource directory: 24-byte records, 2 per style (kind 0x02 and 0x07) | 0.93 | **VERIFIED** |
| `+0..+23` | struct | name/kind/bank/index | [0..17] name + NUL + optional '*' marker, [18] kind, [19] bank id, [20] style index, [21..23] tail | 0.9 | **VERIFIED** |
| `-` | - | none | velocity has NO raw .STY offset: the STYLE resource is OC-compressed on disk | 0.9 | **VERIFIED** |
| `-` | - | 2 patterns | directory records appear as 'all kind-2 then all kind-7' (24 banks) or as (2,7) pairs per style (23 banks); 2 banks match neither | 0.0 | **UNKNOWN** |

## 9. Checksum candidates

- **EXP001_pa3x_vs_pa800**: 21 field(s) reproduced by a known algorithm
  - `0x2ce` = xor8 over 0x0..0x3c97f → **VERIFIED**
  - `0x2d5` = xor8 over 0x0..0x3c97f → **VERIFIED**
  - `0x2d6` = xor8 over 0x0..0x3c97f → **VERIFIED**
  - `0x2e0` = xor8 over 0x0..0x3c97f → **VERIFIED**
  - `0x2e2` = xor8 over 0x0..0x3c97f → **VERIFIED**
  - `0x2e4` = xor8 over 0x0..0x3c97f → **VERIFIED**

## 10. Unknown regions

- **NEWNAME_USER01_hw**: null density 0.0457, entropy 7.196–7.404 per block; regions not covered by a detected record run remain UNKNOWN.
- **InitPx02_pa3x**: null density 0.0735, entropy 6.279–7.351 per block; regions not covered by a detected record run remain UNKNOWN.
- **InitPx02_pa800**: null density 0.0715, entropy 6.283–7.375 per block; regions not covered by a detected record run remain UNKNOWN.

## 11. Confirmed findings

- `0x00` bytes — style node header: 4 tag bytes then u32be payload length (evidence: re-emitting every node with this layout reproduces 93/97 matched pairs byte-exact, hardware export NEWNAME_USER01 parses with no residue)
- `0x04` u32be — node payload length follows the 4 tag bytes (evidence: 93/97 byte-exact reconstruction, every node boundary closes exactly)
- `0x01` u8 — style format version at root byte 1 (evidence: 97 matched pairs differ here 5 vs 4, hardware export reads 4)
- `tag[2]` u8 — minor version is repeated in EVERY node header tag, not stored once (evidence: setting only the root left 14 byte mismatches; stamping every tag fixed all)
- `+0x00` pascal — StyleInfo begins with a Pascal-style name (1 length byte + chars) (evidence: name length byte verified on 1058 styles across 4 SETs)
- `1+len(name)+3` u16be — style element content bitmap; popcount == number of stored elements (evidence: invariant holds 339/339 in the user's genuine Pa800 styles, hardware export: 13 elements, mask 0x1fff, popcount 13, full-out matrix: 7..15 elements, popcount matches every time)
- `-` - — Pa800 addresses at most 13 style elements (evidence: 339/339 user styles <=13, hardware export =13, Pa3X sources carry 15)
- `-` column-major — TrackData is COLUMN-major, which is why truncation to 80 is the correct v5->v4 step (evidence: derived from the user's parse_style_tracks, explains all observed lengths 48/80/88/96, v5[:80] reproduces 93/97 pairs byte-exact)
- `+0x1b` u8 — ElementInfo byte 27 is the minor version stamp (evidence: 93/97 pairs differ exactly here)
- `+0x00/+0x02` u16be — PatternInfo: u16be pattern count, u16be association count, then count x u16be indices (evidence: pattern count == number of sibling pattern nodes on every style tested, association count == sum of CV reference-tail counts)
- `end of CV node` struct — each Chord Variation ends with the list of pattern associations it consumes (evidence: tail length check closes exactly on every CV node in 1058 styles)
- `TrackData cols 1-3` u8 x3 — sound selector triple; Pa800 factory uses MSB 120/121 and LSB 0..35 only (evidence: 45,240 factory lanes: MSB121 LSB 0..35, MSB120; never 64/65, hardware export: 0 of 104 lanes outside that set)
- `0x24` fixed record (24 B) — bank resource directory: 24-byte records, 2 per style (kind 0x02 and 0x07) (evidence: engine found it unaided via fixed_record_runs, records == 2 x style count on 67 of 72 banks across 5 SETs, distinct style indices == style count on all 67, names match the decoded style names)
- `+0..+23` struct — [0..17] name + NUL + optional '*' marker, [18] kind, [19] bank id, [20] style index, [21..23] tail (evidence: the '*' after the NUL explains why decoded names carry a trailing asterisk, kind is always 0x02 or 0x07, exactly one of each per style)
- `+0x13` u8 — byte 19 is the BANK ID: USER01->0x11, USER02->0x12, USER03->0x13 ... (evidence: sequential across 38 banks, strictly following the bank filename, RETRACTION: first read as a 'flag correlated with record ordering'. That correlation was an artefact of the sample and is withdrawn.)
- `Note-On byte 2` u8 (0x80 | v) — velocity byte in the Pattern stream: high bit ALWAYS set, velocity is the low 7 bits (evidence: 197.326 / 197.326 Note-On events across 4 banks satisfy raw & 0x7F == velocity, high bit set in 197.326 / 197.326 cases, no exception, each candidate carries style, pattern, lane, tick and pitch)
- `-` - — velocity has NO raw .STY offset: the STYLE resource is OC-compressed on disk (evidence: a hex edit cannot reach it; only decode -> edit -> re-encode works, this is why ONE_CHANGE_VELOCITY must come from the instrument, not a hex editor)

## 12. Hypotheses

## 13. Recommended next experiments

- **ONE_CHANGE_VELOCITY.SET** — promijeni velocity JEDNE note u Style Record. Zbog OC kompresije hex editor tu ne pomaze; samo izvoz s instrumenta zatvara dokaz.
- **BASELINE_REPEAT.SET** — isti stil snimljen bez izmjene (determinizam, timestamp, checksum).
- **ONE_CHANGE_SOUND / VOLUME / PAN / TEMPO / DRUMKIT .SET** — po jedan parametar.
- Za `dir_ordering`: dvije banke iz ISTOG SET-a, jedna 'grouped' jedna 'interleaved'. Nijedan bajt u zaglavlju ih ne razdvaja, pa treba par napravljen namjerno.
- Uslov za sve: isti stil, isto mjesto u banci, sve ostalo netaknuto. EXP001 je bez toga dao 241.106 promijenjenih bajtova.

## Appendix — multi-file correlation

```
{
 "EXP001_pa3x_vs_pa800": {
  "changed": 58,
  "unique_to_this": 58,
  "unique_offsets": [
   "0x6",
   "0x7",
   "0x29b",
   "0x2a0",
   "0x2a1",
   "0x2a7",
   "0x2ac",
   "0x2ad",
   "0x2b0",
   "0x2b5",
   "0x2c4",
   "0x2ca",
   "0x2cd",
   "0x2ce",
   "0x2cf",
   "0x2d0",
   "0x2d1",
   "0x2d2",
   "0x2d3",
   "0x2d4",
   "0x2d5",
   "0x2d6",
   "0x2d7",
   "0x2d8",
   "0x2da",
   "0x2db",
   "0x1e80",
   "0x1e81",
   "0x1e82",
   "0x1e83",
   "0x1e87",
   "0x1e88",
   "0x1e89",
   "0x1e8a",
   "0x1e8b",
   "0x1e8c",
   "0x1e8d",
   "0x1e8e",
   "0x1e8f",
   "0x1e90",
   "0x1e91",
   "0x1e92",
   "0x8075",
   "0x8076",
   "0x8077",
   "0x8078",
   "0x8079",
   "0x807a",
   "0x807b",
   "0x807c",
   "0x807d",
   "0x807e",
   "0x807f",
   "0x8080",
   "0x8081",
   "0x8082",
   "0x8083",
   "0x8084"
  ]
 },
 "_shared_by_all": []
}
```