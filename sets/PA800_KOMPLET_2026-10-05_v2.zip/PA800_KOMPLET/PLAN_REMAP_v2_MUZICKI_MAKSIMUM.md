# REVIZIJA I PLAN v2 — „Da li je ovo muzički dovoljno dobro?"
**Pogled: senior developer + muzičar** · Datum: 2026-10-03 · Predmet: `PA800_Remapper v1.0`

---

## 0. Kratak odgovor

**Nije.** v1 je **tehnički ispravan, ali muzički naivan.**
Radi tačno ono što sam mu rekao — prevede GM Program Change u Pa800 adresu i provjeri da nije pokvario fajl. Ali **ne donosi nijednu muzičku odluku.** A remap *jeste* muzička odluka.

Ispod je dokaz da to nije mišljenje nego mjerljiva činjenica, pa onda plan v2.

---

## 1. DOKAZ ZAŠTO v1 NIJE DOVOLJAN — izmjereno, ne pretpostavljeno

### 1.1 Tvrda činjenica o mašini
**Korg Pa800: 120 glasova / 120 oscilatora**, do **16 oscilatora po programu**
(Owner's Manual str. 24 i 338; Korg HI Synthesis / EDS, RX tehnologija).

A iz **tvog** kataloga (`PA800_INSTRUMENTI_I_DRUM_KITOVI.pdf`):

| Zvuk | OSC |
|---|---|
| Strings Ens. RX / Concert Str.RX / Scat Voices RX / Clean Funk RX2 | **8** |
| Clean Guitar RX1 / Acous. Bass RX / FunkSlap Bass RX | **7** |
| Banjo RX | 6 |
| Finger / Picked / SlapFing / SlapPick Bass RX | 5 |

**Potrošnja glasova = broj oscilatora × broj istovremenih nota.** Ne postoji „RX je besplatan".

### 1.2 Simulacija na realnom balkanskom aranžmanu
Testni song: klavir (4 note), gudači (4), bas (1), **gitara strum 6 žica**, harmonika (3), bubnjevi (3) — dakle *skroman* aranžman, samo dva akorda.

Napisao sam simulator (`pa800_remap/polyphony.py`) i pustio ga:

| Scenarij | peak OSC | + Style (8 trackova, ~35) | Verdikt |
|---|---|---|---|
| A) sve obični stereo zvukovi (2 OSC) | 39 | 74 / 120 | OK |
| **B) RX_READY kako ga v1 dodjeljuje** | **110** | **145 / 120** | 🔴 **VOICE STEALING** |
| C) ciljani RX (samo bas + gitara) | 78 | 113 / 120 | 🟠 TIGHT |
| B) + release rep (sustain) | 220 | 255 / 120 | 🔴 **KATASTROFA** |

> **Muzička posljedica:** note se **sijeku usred trajanja** — pad nestane, bas „proguta" notu, činela se prekine. Live, to je kraj priče.
> **v1 u profilu `RX_READY` upravo to radi**, i nema nijedan mehanizam da to spriječi. To je najteža greška u v1.

### 1.3 Drugi dokaz — harmonika (najvažniji zvuk u tvom repertoaru)
Iz tvoje sound liste, PC 21 ima **20+ varijanti**, i to su varijante **različitog štimanja**:

```
Akordeon 121.2.21        Musette 1 121.3.21        Musette 2 121.4.21
Fisa 16,8' 121.6.21      Fisa 16,4' 121.7.21       Fisa Master 121.8.21
Cassotto 121.9.21        Cassotto 16' 121.12.21
Cassotto Or.Tune 121.13.21     Cassotto NorTune 121.14.21     ← OT vs NT = ŠTIM
Acc.Clarinet OT 121.19.21      Acc. Clarinet NT 121.20.21
Acc. Piccolo OT 121.21.21      Acc. Piccolo NT 121.22.21
Arabic Accordion 121.10.21     2/3 Voices Musette 121.16/17.21
Detune Accordion 121.15.21     French Musette 121.18.21     Sweet Musette 121.11.21
```

`OT` = **Original Tune**, `NT` = **Normal Tune**. **v1 slijepo bira „Akordeon".**
Muzički: pogrešan izbor znači da harmonika **štima protiv benda** ili da sevdalinka zvuči kao francuski valcer. To je razlika između „radi" i „može na svirku".

### 1.4 Treći dokaz — noise zona nije upozorenje nego nota
I-REG: svaki bass/guitar RX ima **OSC 5 = RX_NOISE, key zona C7..G9**. v1 samo ispiše `ORPHAN_NOISE_KEYS`. Ali muzički:
- ako cilj **nije** RX → te note sviraju **melodijski zvuk 3 oktave previsoko** = škripa u aranžmanu
- ako cilj **jeste** RX, a note fale → gitara izgubi *trzaj, prst po žici, dead note* = plastika

v1 ne generiše, ne premješta i ne briše ništa. Dakle: ne rješava.

---

## 2. KOMPLETNA LISTA MUZIČKIH PROPUSTA v1

| # | Propust | Zašto je muzički bitno | Status u v1 |
|---|---|---|---|
| **G1** | Nema budžeta polifonije | note se sijeku (dokaz §1.2) | ❌ nema |
| **G2** | PC bajt se uzima kao identitet instrumenta | MIDI sa neta/DAW-a ima pogrešan PC; muzičar prepoznaje ulogu po **sadržaju** (registar, polifonija, trajanje, ritmička funkcija) | ❌ slijepo vjeruje |
| **G3** | Nema provjere opsega protiv key zone | dionica izlazi iz zone → noise/prazno | ⚠️ samo warning |
| **G4** | Nema idioma/žanra (harmonika, klarinet, truba, oriental) | pogrešan štim i karakter (§1.3) | ❌ nema |
| **G5** | Velocity se ne rekalibrira na novi zvuk | isti vel = druga dinamika i **drugi OSC sloj** → druga artikulacija | ❌ nema |
| **G6** | Nema balansa nivoa nakon zamjene | Grand Piano RX je osjetno glasniji od GM klavira → aranžman se raspadne | ❌ namjerno isključeno (M-043) |
| **G7** | FX rutiranje se ne dira | gitara bez REMS amp simulacije, zbor bez hall-a = suho i mrtvo (4 FX procesora, 125 tipova) | ❌ nema |
| **G8** | Drum remap je na nivou kita, ne tipke | GM mapa ≠ Pa800 kit mapa → nestanu tomovi/perkusija | ⚠️ samo izbor kita |
| **G9** | Nema layer/split prijedloga | aranžer bi slojio (strings+pad, piano+pad); 1:1 mapiranje gubi aranžman | ❌ nema |
| **G10** | Kontroleri se ne remapiraju | DNC zvukovi traže specifične CC putanje; CC11/CC1/CC64 znače različito po zvuku | ❌ prolaze netaknuti |
| **G11** | Nema slušne validacije | remap bez slušanja = pogađanje | ❌ nema |
| **G12** | GS/XG sysex iz stranih MIDI-ja se ne čisti | zbuni Pa800, pregazi bank select | ❌ nema |
| **G13** | Nema STS / Performance izlaza | song zvuči dobro, ali keyboard dionica uživo ne prati | ❌ nema |

---

## 3. PLAN v2 — „MUSICALLY-AWARE REMAP"

### 3.1 Nova arhitektura — remap postaje 7-stepeni lanac, ne jedna tabela

```
  MIDI (optimizovan)
        │
  ①  CLEAN        strip GS/XG sysex, normalizuj PC/bank, 1-based→0-based      [MX-0]
        │
  ②  SENSE        detekcija uloge iz SADRŽAJA, ne iz PC bajta                 [MX-1]
        │          registar · polifonija · trajanja · ritmička funkcija
        │          · intervalni sadržaj · pozicija u frazi
        │
  ③  IDIOM        žanrovski profil (Balkan/Narodna/Sevdah/Oriental/Zabavna)   [MX-2]
        │          → kandidat-lista zvukova po ulozi, sa pravilom štima
        │
  ④  FIT          opseg vs key zona · oktava · velocity rekalibracija         [MX-3, MX-5]
        │
  ⑤  BUDGET       simulacija 120 glasova; ako pukne → degradacija RX→plain    [MX-4]
        │          po prioritetu uloge (solo > bas > gitara > pad)
        │
  ⑥  MIX          nivoi, pan, FX rutiranje, drum per-key mapa                 [MX-6, MX-7, MX-8]
        │
  ⑦  EMIT+PROVE   MIDI + STS/Performance + izvještaj + slušni protokol        [MX-9..MX-11]
```

### 3.2 Nove familije pravila

#### MX-1 · Detekcija uloge iz sadržaja (zamjenjuje slijepo povjerenje u PC)
| Uloga | Detekcijski potpis (mjerljiv) |
|---|---|
| `BASS` | medijan visine < C3, polifonija ≈ 1, note na dobama, mali intervalni skokovi |
| `LEAD/SOLO` | polifonija = 1, visok registar, duge note + ornamenti, melodijski kontur |
| `PAD/STRINGS` | polifonija ≥ 3, duge note (≥ 1 takt), mali pokret, overlap > 70 % |
| `COMP/CHORD` | polifonija 3-5, ritmički ponovljeno, kratke note |
| `GUITAR STRUM` | 4-6 nota u ≤ 30 ms, ponovljeni obrasci, inverzije po žicama |
| `ARPEGGIO` | polifonija 1 ali akordski tonovi u nizu |
| `DRUM/PERC` | kanal 10 ili neharmonski sadržaj |
| `FX/NOISE` | note u C7..G9, bez harmonske funkcije |

> Svaka detekcija vraća **confidence**; ispod praga → traži potvrdu korisnika, ne pogađa.

#### MX-2 · Idiom paketi (ovo je ono što v1 nema, a tebi najviše treba)
`balkan_narodna` · `sevdah` · `oriental` · `zabavna/pop` · `latino` · `neutral`

Primjer izvoda iz `balkan_narodna` (sve adrese dokazane iz tvoje sound liste):

| Uloga | 1. izbor | 2. izbor | Napomena |
|---|---|---|---|
| Harmonika vodeća | `3 Voices Musette 121.17.21` | `Musette 1 121.3.21` | širi musette tremolo |
| Harmonika prateća | `Cassotto 121.9.21` | `Fisa 16,8' 121.6.21` | topliji, ne „guta" solo |
| Harmonika oriental | `Arabic Accordion 121.10.21` | `Cassotto Or.Tune 121.13.21` | **štim OT** |
| Klarinet (akordeonski) | `Acc.Clarinet OT 121.19.21` | `Acc. Clarinet NT 121.20.21` | OT/NT mora pratiti izbor harmonike |
| Bas (narodni) | `Finger Bass RX 121.13.33` | `Acous. Bass RX 121.7.32` | RX samo ako budžet dozvoli |
| Gitara prateća | `Clean Guitar RX1 121.14.28` | GM clean 121.0.27 | strum detekcija obavezna |
| Gudači | `Strings Ens. RX 121.22.48` | `Concert Str.RX 121.23.48` | **8 OSC — prvi kandidat za degradaciju** |

**Pravilo konzistencije štima (MX-2.9):** ako je bilo koji zvuk u songu `OT`, svi zvukovi iz iste porodice moraju biti `OT`. Miješanje OT/NT = song štima sam protiv sebe. Ovo je pravilo koje muzičar zna, a softver bez njega pravi neupotrebljiv rezultat.

#### MX-3 · Opseg i oktava
- Izračunaj `[min_note, max_note]` po tracku → uporedi sa key zonom ciljnog zvuka iz I-REG.
- Ako izlazi: predloži oktavnu transpoziciju **tracka** (ne nota), ili drugi zvuk.
- **Nikad** ne transponuj drum/perc (PA800-002) i nikad kontrolne oktave Guitar Mode-a.

#### MX-4 · Budžet glasova (najvažnija novina)
- Simulator (već napisan: `polyphony.py`) računa peak OSC po ticku.
- Rezerva: `song_peak + style_reserve ≤ 120`, gdje je `style_reserve` mjeren iz Factory Styles (realno 30-45).
- Ako se probije → **degradacija po prioritetu uloge**:
  `SOLO/LEAD` (zadnji se dira) > `BASS` > `GUITAR` > `COMP` > `PAD/STRINGS` (prvi se degradira)
- Degradacija ide: RX (8 OSC) → RX (5 OSC) → plain stereo (2) → mono (1).
- Izvještaj mora reći **koliko je glasova spašeno i na čiju štetu**.

#### MX-5 · Velocity rekalibracija
- Za svaki ciljni zvuk iz I-REG znamo switch pointe (npr. `26/47/68/89/110` za Pop Std. Kit RX snare; `1-22/23-52/53-113/114-127` za Finger Bass RX).
- Postojeće velocity vrijednosti se **premapiraju na slojeve ciljnog zvuka**, uz očuvanje relativne dinamike (monotona, po dijelovima linearna transformacija).
- Bez ovoga, remap mijenja artikulaciju nasumično.

#### MX-6 · Balans nivoa (dokazom, ne uhom)
- Referentni nivoi se **mjere iz Factory Styles**: prosječna track volume (CC7) i velocity medijan po porodici zvuka i po žanru.
- Remap primjenjuje **razliku** između izvorne i ciljne porodice, ograničeno na ±12 koraka CC7, logovano sa `rule_id`.
- Opt-out ostaje, ali default postaje **uključen** (suprotno v1).

#### MX-7 · FX rutiranje
- 4 stereo FX procesora (A/B style, C/D keyboard), 125 tipova.
- Mapa „porodica zvuka → tipičan FX" se **izvodi iz tvornički Performance/Style objekata** (postoji u `PA800_Manager_Web_v0.2_NATIVE_SET_FORENSICS` i `KORG_PA800_FULL_EDITOR_DATA_v1.zip`).
- Bez dokaza → ne diramo (ostaje otvoreno, ali eksplicitno).

#### MX-8 · Drum per-key remap
- Koristi **51 kit adresu + 2003 per-key zapisa** iz tvoje evidencije.
- Za svaku korištenu tipku: postoji li u ciljnom kitu? → ako ne, zamjenska tipka iste funkcije (kick→kick, rim→rim), nikad tiho brisanje.
- RX kitovi: velocity slojevi se **ne diraju** (rezultat optimizacije).

#### MX-9 · Layer / split prijedlozi
- Ako je uloga `PAD` i budžet dozvoljava → prijedlog sloja (npr. strings + warm pad), uz jasan prikaz cijene u glasovima.
- Uvijek **prijedlog**, nikad automatski.

#### MX-10 · Remap kontrolera
- Po ciljnom zvuku: koje CC su smislene (DNC CC putanje, CC11 ekspresija, CC64 damper, modulacija).
- Besmisleni kontroleri se **ne brišu nego označe**.

#### MX-11 · Validacija — tehnička **i** muzička
| Test | Prolaz |
|---|---|
| Nota/timing delta | 0 |
| Peak glasova + style rezerva | ≤ 120 |
| Note izvan key zone cilja | 0 |
| Konzistencija štima (OT/NT) | 100 % |
| Neriješeni PC | 0 |
| Drum tipke bez pokrića | 0 |
| **Regresija na Factory Styles** | remap tvorničkog materijala mijenja ≤ ε |
| **Demo re-prediction** | sakrij artikulaciju → rekonstruiši → precision/recall po OSC zoni |
| **Slijepi A/B slušni test** | protokol sa listom od 8 kriterija (vidi §5) |
| **Hardverski test na PA800** | učitavanje + sviranje = jedini konačni dokaz |

---

## 4. ŠTA MI TREBA DA BIH OVO URADIO SA DOKAZIMA (ne pogađanjem)

| # | Treba mi | Odakle | Zašto |
|---|---|---|---|
| 1 | **Raspakovan `PA800_FACTORY_STYLES_PATTERNS_PADS_REFERENCE.zip`** | Drive | referentni nivoi (MX-6), style voice reserve (MX-4), FX mapa (MX-7) |
| 2 | **`demo_midis.zip`** | Drive | artikulacijski potpisi, noise obrasci (MX-1, MX-5) |
| 3 | **Puna sound lista `.txt`** | Drive | svih 1003 bindinga + drum kitovi |
| 4 | **Per-key drum evidencija** (51 kit / 2003 reda) | `07_PA800_NATIVE_SET_OS202_FORENSICS` | MX-8 |
| 5 | **Owner's + Advanced Edit manual** | *nedostaje na Driveu* | citiranje stranica, FX i Performance semantika |
| 6 | **2-3 tvoja stvarna songa** (prije/poslije) | ti | kalibracija idioma i slušni test |
| 7 | **Tvoj odgovor: koji žanr je primarni** | ti | koji idiom paket gradimo prvi |

---

## 5. Slušni protokol (8 kriterija, slijepi A/B)

1. Da li se ijedna nota **siječe** (voice stealing)?
2. Da li harmonika **štima** sa basom i gitarom?
3. Da li je solo iznad pratnje (balans), bez „guranja"?
4. Da li gitara ima **trzaj i dead-note** (noise sloj) ili zvuči kao sintisajzer?
5. Da li bas mijenja artikulaciju sa dinamikom (gliss/stop/harmonic) ili je ravan?
6. Da li drum zvuči kao kit ili kao skup uzoraka (velocity slojevi)?
7. Da li ima prostora (FX) ili je suho?
8. Da li bi ovo pustio na svirci bez ručne korekcije? **← jedini kriterij koji stvarno broji**

---

## 6. Redoslijed rada (prijedlog)

| Korak | Isporuka | Ovisi o |
|---|---|---|
| **P1** | Faza 0 iz glavnog plana: raspakivanje + `CORPUS_MANIFEST.json` | — |
| **P2** | `I_REG_v1.json` (svi zvukovi + OSC + key/vel zone + drum per-key) | P1 |
| **P3** | **MX-4 budžet glasova** ugrađen u postojeći remapper (najbrži veliki dobitak) | P2 |
| **P4** | **MX-1 detekcija uloge** + **MX-3 opseg** | P2 |
| **P5** | **MX-2 idiom paket `balkan_narodna`** + pravilo štima | P2 + tvoj input |
| **P6** | **MX-5 velocity** + **MX-8 drum per-key** | P2, demo korpus |
| **P7** | **MX-6 balans** + **MX-7 FX** (iz Factory Styles) | P1 |
| **P8** | GUI v2 + validacija + slušni protokol | sve |

---

## 7. Zaključak — iskreno

v1 je **dobar temelj i tačan alat za ono što radi**: adresni model je dokazan, pravila su zapisana, verifikacija radi, ništa se ne kvari. Ali on je **prevodilac, a ne aranžer.**

Razlika između v1 i v2:
- **v1 odgovara na pitanje:** „koja je Pa800 adresa za ovaj GM program?"
- **v2 odgovara na pitanje:** „koji zvuk bi *muzičar* stavio ovdje, da li Pa800 to može odsvirati bez sječenja nota, i da li će štimati sa ostatkom benda?"

Drugo pitanje je ono pravo. I na njega se **može** odgovoriti sa dokazima — svi izvori već postoje na tvom Driveu, osim manuala i tvojih stvarnih songova za kalibraciju.
