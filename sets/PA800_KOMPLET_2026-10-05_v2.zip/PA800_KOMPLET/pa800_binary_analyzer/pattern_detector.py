"""Repeating sequences and stride discovery."""
from __future__ import annotations

import collections


def repeated_blocks(data: bytes, size: int = 16, min_hits: int = 4) -> list[dict]:
    seen = collections.Counter()
    for off in range(0, len(data) - size, size):
        seen[data[off:off + size]] += 1
    out = [{"bytes": k.hex(" ")[:47], "count": v}
           for k, v in seen.most_common(20) if v >= min_hits]
    return out


def stride_histogram(offsets: list[int], limit: int = 20) -> list[tuple[int, int]]:
    d = collections.Counter(b - a for a, b in zip(offsets, offsets[1:]))
    return d.most_common(limit)


def constant_columns(data: bytes, start: int, stride: int, count: int) -> dict:
    """Which byte positions inside a fixed record never change?"""
    cols = collections.defaultdict(set)
    for i in range(count):
        rec = data[start + i * stride:start + (i + 1) * stride]
        if len(rec) < stride:
            break
        for j, b in enumerate(rec):
            cols[j].add(b)
    const = {j: next(iter(v)) for j, v in cols.items() if len(v) == 1}
    varying = sorted(j for j, v in cols.items() if len(v) > 1)
    return {"constant": const, "varying": varying,
            "distinct_per_col": {j: len(v) for j, v in cols.items()}}
