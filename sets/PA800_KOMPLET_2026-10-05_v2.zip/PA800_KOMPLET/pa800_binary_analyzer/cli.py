#!/usr/bin/env python3
"""CLI:  analyze | diff | structure | midi | candidates | experiment | report"""
from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

from pa800_binary_analyzer import analyzer, hex_view, report_generator   # noqa: E402
from pa800_binary_analyzer import binary_reader as br                    # noqa: E402
from pa800_binary_analyzer import structure_detector as sd               # noqa: E402
from pa800_binary_analyzer.database import EvidenceDB                    # noqa: E402

OUT = "analysis"


def j(x): print(json.dumps(x, indent=1, ensure_ascii=False)[:20000])


def main(argv=None):
    ap = argparse.ArgumentParser(prog="pa800-re")
    sub = ap.add_subparsers(dest="cmd", required=True)
    for c in ("analyze", "structure", "midi", "candidates"):
        s = sub.add_parser(c); s.add_argument("file")
    d = sub.add_parser("diff"); d.add_argument("a"); d.add_argument("b")
    d.add_argument("--gap", type=int, default=8)
    e = sub.add_parser("experiment"); e.add_argument("base"); e.add_argument("mod")
    e.add_argument("--name", default="EXP001")
    h = sub.add_parser("hex"); h.add_argument("file")
    h.add_argument("--off", type=lambda x: int(x, 0), default=0)
    h.add_argument("--len", type=int, default=512)
    sub.add_parser("report")
    a = ap.parse_args(argv)

    if a.cmd == "analyze":
        r = analyzer.analyze(a.file, OUT)
        print(f"original untouched: {r['original_untouched']}")
        j(r["identification"])
    elif a.cmd == "structure":
        j(analyzer.structure(br.load(a.file)))
    elif a.cmd == "midi":
        j(analyzer.midi(br.load(a.file)))
    elif a.cmd == "candidates":
        b = br.load(a.file)
        j({"length": [vars(c) for c in sd.length_candidates(b.data)[:20]],
           "offset": [vars(c) for c in sd.offset_candidates(b.data)[:20]],
           "count": [vars(c) for c in sd.count_candidates(b.data)[:20]]})
    elif a.cmd == "hex":
        print(hex_view.dump(br.load(a.file).data, a.off, a.len))
    elif a.cmd == "diff":
        from pa800_binary_analyzer import diff_engine
        x, y = br.load(a.a), br.load(a.b)
        j(diff_engine.summary(x.data, y.data, a.gap))
    elif a.cmd == "experiment":
        j(analyzer.experiment(a.base, a.mod, a.name, OUT))
    elif a.cmd == "report":
        db = EvidenceDB(Path(OUT) / "PA800_BINARY_EVIDENCE.json")
        p = report_generator.build({}, {}, {}, db.entries, [], 
                                   Path(OUT) / "reports" / "REPORT.md")
        print("written", p)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
