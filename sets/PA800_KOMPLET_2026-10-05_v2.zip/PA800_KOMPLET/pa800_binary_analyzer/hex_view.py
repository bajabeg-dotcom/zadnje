"""Hex dump with selectable word width and endianness."""
from __future__ import annotations

from .binary_reader import read, ENCODINGS


def dump(data: bytes, start: int = 0, length: int = 256, width: int = 16) -> str:
    lines = ["OFFSET       HEX BYTES" + " " * (width * 3 - 9) + "ASCII"]
    end = min(len(data), start + length)
    for off in range(start, end, width):
        chunk = data[off:off + width]
        hx = " ".join(f"{b:02x}" for b in chunk).ljust(width * 3 - 1)
        txt = "".join(chr(b) if 32 <= b < 127 else "." for b in chunk)
        lines.append(f"{off:08x}     {hx}    {txt}")
    return "\n".join(lines)


def words(data: bytes, start: int, count: int, enc: str) -> str:
    """Same region decoded as 16/32-bit words, LE and BE, side by side."""
    n = {"u16le": 2, "u16be": 2, "u32le": 4, "u32be": 4, "u8": 1}[enc]
    out = [f"{enc} @ {start:#x}"]
    row = []
    for i in range(count):
        v = read(data, start + i * n, enc)
        if v is None:
            break
        row.append(f"{v:>10}")
        if len(row) == 8:
            out.append(" ".join(row)); row = []
    if row:
        out.append(" ".join(row))
    return "\n".join(out)


def all_encodings(data: bytes, off: int) -> str:
    """Every reading of one offset -- the spec forbids assuming endianness."""
    lines = [f"offset {off:#x}  bytes {data[off:off+4].hex(' ')}"]
    for e in ENCODINGS:
        v = read(data, off, e)
        lines.append(f"   {e:<6} = {v}")
    return "\n".join(lines)
