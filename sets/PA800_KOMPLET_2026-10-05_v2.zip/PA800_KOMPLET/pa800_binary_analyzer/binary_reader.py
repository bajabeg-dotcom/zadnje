"""Read-only loader and primitive decoders.

The original file is NEVER opened for writing, anywhere in this package.
`Blob.data` is an immutable `bytes`; every helper returns new objects.
"""
from __future__ import annotations

import hashlib
import math
import re
from dataclasses import dataclass, field
from pathlib import Path

# --------------------------------------------------------------------- types
ENCODINGS = ("u8", "u16le", "u16be", "u32le", "u32be", "i8", "i16le", "i16be")


@dataclass
class Blob:
    path: Path
    data: bytes
    md5: str
    sha1: str
    sha256: str

    @property
    def size(self) -> int:
        return len(self.data)


def load(path: str | Path) -> Blob:
    p = Path(path)
    raw = p.read_bytes()                      # read-only, always
    return Blob(p, raw,
                hashlib.md5(raw).hexdigest(),
                hashlib.sha1(raw).hexdigest(),
                hashlib.sha256(raw).hexdigest())


def verify_untouched(blob: Blob) -> bool:
    """Re-hash the file on disk and compare with the hash taken at load."""
    return hashlib.sha256(blob.path.read_bytes()).hexdigest() == blob.sha256


# ------------------------------------------------------------------ decoders
def read(data: bytes, off: int, enc: str) -> int | None:
    n = {"u8": 1, "i8": 1, "u16le": 2, "u16be": 2, "i16le": 2, "i16be": 2,
         "u32le": 4, "u32be": 4}[enc]
    if off < 0 or off + n > len(data):
        return None
    chunk = data[off:off + n]
    signed = enc.startswith("i")
    order = "big" if enc.endswith("be") else "little"
    return int.from_bytes(chunk, order, signed=signed)


def decode_all(data: bytes, off: int) -> dict[str, int | None]:
    """Every interpretation of the bytes at `off`, so nothing is assumed."""
    return {e: read(data, off, e) for e in ENCODINGS}


# ------------------------------------------------------------------ measures
def entropy(buf: bytes) -> float:
    if not buf:
        return 0.0
    counts = [0] * 256
    for b in buf:
        counts[b] += 1
    n = len(buf)
    h = 0.0
    for c in counts:
        if c:
            p = c / n
            h -= p * math.log2(p)
    return h


def entropy_blocks(data: bytes, block: int = 4096) -> list[tuple[int, float, float]]:
    """(offset, entropy, null_density) per block."""
    out = []
    for off in range(0, len(data), block):
        b = data[off:off + block]
        if not b:
            continue
        out.append((off, entropy(b), b.count(0) / len(b)))
    return out


# ------------------------------------------------------------------- strings
_ASCII = re.compile(rb"[\x20-\x7e]{4,}")
_UTF16 = re.compile(rb"(?:[\x20-\x7e]\x00){4,}")


def ascii_strings(data: bytes, minlen: int = 4) -> list[tuple[int, str]]:
    return [(m.start(), m.group().decode("latin-1"))
            for m in _ASCII.finditer(data) if len(m.group()) >= minlen]


def utf16_strings(data: bytes, minlen: int = 4) -> list[tuple[int, str]]:
    out = []
    for m in _UTF16.finditer(data):
        s = m.group().decode("utf-16-le", "replace")
        if len(s) >= minlen:
            out.append((m.start(), s))
    return out


def null_density(data: bytes) -> float:
    return data.count(0) / len(data) if data else 0.0


def repeating_runs(data: bytes, minlen: int = 16) -> list[tuple[int, int, int]]:
    """(offset, length, byte) for runs of one repeated byte."""
    out = []
    i = 0
    n = len(data)
    while i < n:
        j = i
        while j + 1 < n and data[j + 1] == data[i]:
            j += 1
        if j - i + 1 >= minlen:
            out.append((i, j - i + 1, data[i]))
        i = j + 1
    return out
