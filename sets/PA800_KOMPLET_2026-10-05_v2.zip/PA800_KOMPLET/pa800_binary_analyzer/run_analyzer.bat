@echo off
chcp 65001 >nul
title PA800 Binary Reverse Engineering
cd /d "%~dp0.."
set "PY="
where py >nul 2>&1 && set "PY=py -3"
if not defined PY where python >nul 2>&1 && set "PY=python"
if not defined PY (
    echo Python 3 nije pronadjen. Instaliraj ga sa python.org i cekiraj "Add Python to PATH".
    pause & exit /b 1
)
if "%~1"=="" (
    echo.
    echo   PA800 Binary RE — upotreba:
    echo     run_analyzer.bat analyze    fajl.STY
    echo     run_analyzer.bat structure  fajl.STY
    echo     run_analyzer.bat midi       fajl.STY
    echo     run_analyzer.bat diff       A.STY B.STY
    echo     run_analyzer.bat experiment A.STY B.STY --name EXP001
    echo     run_analyzer.bat hex        fajl.STY --off 0 --len 512
    echo.
    pause & exit /b 0
)
%PY% -m pa800_binary_analyzer.cli %*
pause
