"""Try to reproduce a stored value with a known checksum over some region."""
from __future__ import annotations

import binascii
from .binary_reader import read

CRC8_POLY = 0x07


def crc8(buf: bytes) -> int:
    c = 0
    for b in buf:
        c ^= b
        for _ in range(8):
            c = ((c << 1) ^ CRC8_POLY) & 0xFF if c & 0x80 else (c << 1) & 0xFF
    return c


def crc16_ccitt(buf: bytes) -> int:
    c = 0xFFFF
    for b in buf:
        c ^= b << 8
        for _ in range(8):
            c = ((c << 1) ^ 0x1021) & 0xFFFF if c & 0x8000 else (c << 1) & 0xFFFF
    return c


def sum8(buf): return sum(buf) & 0xFF
def sum16(buf): return sum(buf) & 0xFFFF
def xor8(buf):
    x = 0
    for b in buf:
        x ^= b
    return x


ALGOS = {
    "crc8": (crc8, 1), "xor8": (xor8, 1), "sum8": (sum8, 1),
    "sum16": (sum16, 2), "crc16_ccitt": (crc16_ccitt, 2),
    "crc32": (lambda b: binascii.crc32(b) & 0xFFFFFFFF, 4),
}


def test_field(data: bytes, field_off: int, regions: list[tuple[int, int]]) -> list[dict]:
    """Does any algorithm over any candidate region reproduce the stored value?"""
    hits = []
    for name, (fn, width) in ALGOS.items():
        enc = {1: "u8", 2: "u16be", 4: "u32be"}[width]
        stored = read(data, field_off, enc)
        stored_le = read(data, field_off, {1: "u8", 2: "u16le", 4: "u32le"}[width])
        for (a, b) in regions:
            if a >= b or b > len(data):
                continue
            got = fn(data[a:b])
            if got == stored:
                hits.append({"algo": name, "endian": "be/u8", "region": [hex(a), hex(b)],
                             "value": got, "status": "VERIFIED"})
            elif got == stored_le:
                hits.append({"algo": name, "endian": "le", "region": [hex(a), hex(b)],
                             "value": got, "status": "VERIFIED"})
    return hits


def scan_for_checksum(data: bytes, changed_offsets: list[int]) -> list[dict]:
    """If a far-away byte moved when one parameter changed, it may be a checksum.

    We test each changed offset as a possible checksum field over the whole
    file and over the region before it.
    """
    out = []
    for off in changed_offsets[:64]:
        regions = [(0, off), (0, len(data)), (max(0, off - 4096), off)]
        hits = test_field(data, off, regions)
        if hits:
            out.append({"offset": hex(off), "hits": hits})
    return out
