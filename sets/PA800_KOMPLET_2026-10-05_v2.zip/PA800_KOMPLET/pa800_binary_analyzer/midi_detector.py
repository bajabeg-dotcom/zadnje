"""MIDI / SMF detection, plus MIDI-LIKE event streams that are not SMF.

The spec forbids only grepping for 'MThd': Korg stores event streams in its
own container, so we also score regions by how well they parse as a
delta-time + status-byte stream.
"""
from __future__ import annotations

import re
from dataclasses import dataclass


@dataclass
class SmfFile:
    offset: int
    length: int
    fmt: int
    tracks: int
    division: int


def find_smf(data: bytes) -> list[SmfFile]:
    out = []
    for m in re.finditer(b"MThd", data):
        o = m.start()
        if int.from_bytes(data[o + 4:o + 8], "big") != 6:
            continue
        fmt = int.from_bytes(data[o + 8:o + 10], "big")
        trk = int.from_bytes(data[o + 10:o + 12], "big")
        div = int.from_bytes(data[o + 12:o + 14], "big")
        if fmt > 2 or trk == 0 or trk > 256:
            continue
        p = o + 14
        end = p
        while data[p:p + 4] == b"MTrk":
            ln = int.from_bytes(data[p + 4:p + 8], "big")
            if ln > len(data):
                break
            p += 8 + ln
            end = p
        out.append(SmfFile(o, end - o, fmt, trk, div))
    return out


def _vlq(data: bytes, p: int) -> tuple[int, int] | None:
    v = 0
    for _ in range(4):
        if p >= len(data):
            return None
        b = data[p]; p += 1
        v = (v << 7) | (b & 0x7F)
        if not b & 0x80:
            return v, p
    return None


EVENT_LEN = {0x8: 2, 0x9: 2, 0xA: 2, 0xB: 2, 0xC: 1, 0xD: 1, 0xE: 2}


def score_midi_like(data: bytes, start: int, maxlen: int = 4096) -> dict:
    """Parse as <vlq delta><status><data> and report how far it gets."""
    p = start
    end = min(len(data), start + maxlen)
    events = 0
    kinds = {}
    running = None
    while p < end:
        r = _vlq(data, p)
        if r is None:
            break
        delta, p = r
        if p >= end:
            break
        b = data[p]
        if b & 0x80:
            status = b; p += 1
            running = status
        else:
            status = running
            if status is None:
                break
        hi = status >> 4
        if hi not in EVENT_LEN:
            break
        n = EVENT_LEN[hi]
        if p + n > end:
            break
        p += n
        events += 1
        kinds[hi] = kinds.get(hi, 0) + 1
    return {"start": hex(start), "events": events, "consumed": p - start,
            "kinds": {hex(k): v for k, v in kinds.items()}}


def scan_midi_like(data: bytes, step: int = 4096, min_events: int = 24) -> list[dict]:
    out = []
    for off in range(0, len(data) - 64, step):
        s = score_midi_like(data, off)
        if s["events"] >= min_events:
            out.append(s)
    return out
