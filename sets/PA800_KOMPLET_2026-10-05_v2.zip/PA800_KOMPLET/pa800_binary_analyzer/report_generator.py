"""Markdown report with the mandated sections and status labels."""
from __future__ import annotations

import json
from pathlib import Path

ORDER = ("VERIFIED", "HIGH", "MEDIUM", "LOW", "UNKNOWN")


def build(analyses: dict, experiments: dict, correlation: dict,
          db_entries: list[dict], missing: list[str],
          out: str | Path = "PA800_BINARY_REVERSE_ENGINEERING_REPORT.md") -> Path:
    L = ["# PA800 BINARY REVERSE ENGINEERING REPORT", ""]

    L += ["## 1. File identification", ""]
    L += ["| file | size | sha256 (8) | entropy | strings A/U | header |",
          "|---|---:|---|---:|---|---|"]
    for name, a in analyses.items():
        i = a["identification"]
        L.append(f"| {name} | {i['size']} | `{i['sha256'][:8]}` | "
                 f"{i['entropy_overall']} | {i['ascii_strings']}/{i['utf16_strings']} | "
                 f"`{i['header_bytes'][:23]}` |")

    L += ["", "## 2. Header", ""]
    for name, a in analyses.items():
        i = a["identification"]
        L += [f"**{name}**", "```",
              f"bytes : {i['header_bytes']}",
              f"ascii : {i['header_ascii']}", "```", ""]

    L += ["## 3. Binary structure (CANDIDATES)", ""]
    for name, a in analyses.items():
        s = a["structure"]
        L += [f"**{name}** — length {len(s['length_candidates'])}, "
              f"offset {len(s['offset_candidates'])}, count {len(s['count_candidates'])}, "
              f"fixed-record runs {len(s['fixed_record_runs'])}"]
        for r in s["fixed_record_runs"][:4]:
            L.append(f"  - run @ {hex(r['offset'])} stride {r['stride']} "
                     f"× {r['records']} — {r['sample'][:3]}")
        L.append("")

    L += ["## 4. Offset map", ""]
    for name, a in analyses.items():
        runs = a["structure"]["fixed_record_runs"]
        if not runs:
            continue
        L += [f"**{name}**", "```"]
        for r in sorted(runs, key=lambda x: x["offset"])[:10]:
            end = r["offset"] + r["records"] * r["stride"]
            L.append(f"{r['offset']:#010x}-{end:#010x}  record run "
                     f"(stride {r['stride']}, n={r['records']})   HYPOTHESIS")
        L += ["```", ""]

    L += ["## 5. MIDI regions", ""]
    for name, a in analyses.items():
        m = a["midi"]
        L.append(f"- **{name}**: SMF files {len(m['smf_files'])}, "
                 f"MIDI-like regions {len(m['midi_like_regions'])}")
        for s in m["smf_files"][:4]:
            L.append(f"  - SMF @ {s['offset_hex']} len {s['length']} "
                     f"fmt {s['fmt']} tracks {s['tracks']} division {s['division']}")
    L.append("")

    for num, title, key in ((6, "Sound candidates", "sound"),
                            (7, "Velocity candidates", "velocity"),
                            (8, "Style candidates", "style")):
        L += [f"## {num}. {title}", ""]
        rows = [e for e in db_entries if key in e["meaning"].lower()]
        if rows:
            L += ["| offset | enc | value | meaning | conf | status |",
                  "|---|---|---|---|---:|---|"]
            for e in rows:
                L.append(f"| `{e['offset']}` | {e['encoding']} | {e['value']} | "
                         f"{e['meaning']} | {e['confidence']} | **{e['status']}** |")
        else:
            L.append("UNKNOWN — insufficient evidence. "
                     "See section 13 for the experiment that would isolate it.")
        L.append("")

    L += ["## 9. Checksum candidates", ""]
    any_ck = False
    for name, r in experiments.items():
        cc = r.get("checksum_candidates") or []
        if cc:
            any_ck = True
            L.append(f"- **{name}**: {len(cc)} field(s) reproduced by a known algorithm")
            for c in cc[:6]:
                for h in c["hits"][:2]:
                    L.append(f"  - `{c['offset']}` = {h['algo']} over "
                             f"{h['region'][0]}..{h['region'][1]} → **{h['status']}**")
    if not any_ck:
        L.append("UNKNOWN — no stored value was reproduced by CRC8/16/32, sum or XOR "
                 "over the regions tested. Either there is no checksum, or it covers "
                 "a region we have not isolated.")
    L.append("")

    L += ["## 10. Unknown regions", ""]
    for name, a in analyses.items():
        i = a["identification"]
        L.append(f"- **{name}**: null density {i['null_density']}, "
                 f"entropy {i['entropy_min']}–{i['entropy_max']} per block; "
                 f"regions not covered by a detected record run remain UNKNOWN.")
    L.append("")

    L += ["## 11. Confirmed findings", ""]
    ver = [e for e in db_entries if e["status"] == "VERIFIED"]
    if ver:
        for e in ver:
            L.append(f"- `{e['offset']}` {e['encoding']} — {e['meaning']} "
                     f"(evidence: {', '.join(e['evidence'])})")
    else:
        L.append("None yet at VERIFIED level from controlled experiments.")
    L.append("")

    L += ["## 12. Hypotheses", ""]
    for st in ("HIGH", "MEDIUM", "LOW"):
        rows = [e for e in db_entries if e["status"] == st]
        if rows:
            L.append(f"**{st}**")
            for e in rows:
                L.append(f"- `{e['offset']}` {e['encoding']} — {e['meaning']} "
                         f"(conf {e['confidence']})")
            L.append("")

    L += ["## 13. Recommended next experiments", ""]
    if missing:
        for m in missing:
            L.append(f"- {m}")
    else:
        L.append("- none outstanding")
    L.append("")

    if correlation:
        L += ["## Appendix — multi-file correlation", "",
              "```", json.dumps(correlation, indent=1)[:4000], "```"]

    p = Path(out)
    p.write_text("\n".join(L), encoding="utf-8")
    return p
