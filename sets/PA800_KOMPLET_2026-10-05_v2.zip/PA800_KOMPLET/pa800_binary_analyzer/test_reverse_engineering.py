#!/usr/bin/env python3
"""Test suite required by the spec (section 26)."""
from __future__ import annotations

import hashlib
import sys
import tempfile
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from pa800_binary_analyzer import (binary_reader as br, diff_engine, hex_view,
                                   midi_detector as md, checksum_detector as ck,
                                   structure_detector as sd, analyzer)
from pa800_binary_analyzer.database import EvidenceDB

OK = []


def check(name, cond):
    OK.append((name, bool(cond)))
    print(f"  [{'PASS' if cond else 'FAIL'}] {name}")


def main():
    tmp = Path(tempfile.mkdtemp())
    f = tmp / "sample.bin"
    body = bytes(range(256)) * 4 + b"MThd\x00\x00\x00\x06\x00\x00\x00\x01\x01\x80" + b"MTrk\x00\x00\x00\x04\x00\x90\x3c\x40"
    f.write_bytes(body)
    before = hashlib.sha256(f.read_bytes()).hexdigest()

    b = br.load(f)
    check("load + hashes", b.sha256 == before and b.size == len(body))
    check("original untouched after load", br.verify_untouched(b))

    check("u16le decode", br.read(b"\x01\x02", 0, "u16le") == 0x0201)
    check("u16be decode", br.read(b"\x01\x02", 0, "u16be") == 0x0102)
    check("u32le decode", br.read(b"\x01\x00\x00\x00", 0, "u32le") == 1)
    check("u32be decode", br.read(b"\x00\x00\x00\x01", 0, "u32be") == 1)
    check("i8 signed", br.read(b"\xff", 0, "i8") == -1)

    x = bytearray(body); x[10] = (x[10] + 1) & 0xFF
    ch = diff_engine.byte_diff(body, bytes(x))
    check("diff finds one change", len(ch) == 1 and ch[0].offset == 10)
    check("diff delta", ch[0].delta == 1)
    regs = diff_engine.group(ch)
    check("diff grouping", len(regs) == 1)

    smf = md.find_smf(body)
    check("MIDI SMF detected", len(smf) == 1 and smf[0].division == 384)
    check("MIDI-like scorer runs", md.score_midi_like(body, 0)["events"] >= 0)

    data = b"\x01\x02\x03\x04"
    cs = ck.crc32 if hasattr(ck, "crc32") else None
    import binascii
    probe = bytes([binascii.crc32(data) & 0xFF])
    check("checksum algos present", set(ck.ALGOS) >= {"crc8", "crc32", "xor8"})
    check("xor8 correct", ck.xor8(b"\x0f\xf0") == 0xFF)

    runs = sd.fixed_record_runs(b"NAME\x00\x00\x00\x00" * 20, min_records=8)
    check("fixed record runs", any(r["records"] >= 8 for r in runs))

    hx = hex_view.dump(body, 0, 32)
    check("hex dump format", "OFFSET" in hx and "00000000" in hx)

    dbp = tmp / "ev.json"
    db = EvidenceDB(dbp)
    db.add("t", "STY", 0x10, 2, "u16be", 5, "test_sound", ["EXP001"], 0.9, "HIGH")
    db.save()
    check("evidence db round-trip", EvidenceDB(dbp).entries[0]["status"] == "HIGH")
    try:
        db.add("bad", "STY", 0, 1, "u8", 0, "x", [], 0.1, "NOPE"); bad = False
    except ValueError:
        bad = True
    check("evidence db rejects bad status", bad)

    r = analyzer.analyze(f, tmp / "analysis")
    check("analyze produces identification", r["identification"]["size"] == len(body))
    check("analyze leaves original untouched",
          hashlib.sha256(f.read_bytes()).hexdigest() == before)
    check("report generator importable", __import__(
        "pa800_binary_analyzer.report_generator", fromlist=["build"]) is not None)

    n = sum(1 for _, v in OK if v)
    print(f"\n{n}/{len(OK)} PASS")
    return 0 if n == len(OK) else 1


if __name__ == "__main__":
    raise SystemExit(main())
