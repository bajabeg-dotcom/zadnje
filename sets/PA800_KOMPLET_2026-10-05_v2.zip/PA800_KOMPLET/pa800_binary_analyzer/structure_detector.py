"""Header / length / offset / count candidate detection.

Everything produced here is a CANDIDATE.  Nothing is called a field until a
controlled experiment confirms it.
"""
from __future__ import annotations

from dataclasses import dataclass
from .binary_reader import read, ENCODINGS


@dataclass
class Candidate:
    offset: int
    encoding: str
    raw: int
    role: str          # length_candidate | offset_candidate | count_candidate
    note: str = ""
    target: int | None = None


def length_candidates(data: bytes, limit: int = 4096) -> list[Candidate]:
    """A value that equals (filesize - off - k) for small k looks like a length."""
    out = []
    n = len(data)
    for off in range(0, min(limit, n - 4)):
        for enc in ("u32be", "u32le"):
            v = read(data, off, enc)
            if v is None or v == 0 or v > n:
                continue
            for k in (0, 4, 8, 12):
                if v == n - off - k:
                    out.append(Candidate(off, enc, v, "length_candidate",
                                         f"filesize - offset - {k}"))
                    break
    return out


def offset_candidates(data: bytes, limit: int = 65536, stride: int = 4) -> list[Candidate]:
    """Values that point inside the file AND land on a plausible boundary."""
    out = []
    n = len(data)
    for off in range(0, min(limit, n - 4), stride):
        for enc in ("u32be", "u32le"):
            v = read(data, off, enc)
            if v is None or not (16 <= v < n):
                continue
            tgt = data[v:v + 4]
            if len(tgt) == 4 and (tgt.isalpha() or tgt[0] in (0, 1, 2, 3, 4, 5)):
                out.append(Candidate(off, enc, v, "offset_candidate",
                                     f"target={tgt.hex(' ')}", target=v))
    return out


def count_candidates(data: bytes, limit: int = 4096) -> list[Candidate]:
    """Small values followed by that many fixed-size records."""
    out = []
    for off in range(0, min(limit, len(data) - 8)):
        for enc in ("u16be", "u16le"):
            v = read(data, off, enc)
            if v is None or not (2 <= v <= 4096):
                continue
            for rec in (2, 4, 6, 8, 12, 16, 24, 28, 32):
                end = off + 2 + v * rec
                if end <= len(data) and end >= len(data) - 64:
                    out.append(Candidate(off, enc, v, "count_candidate",
                                         f"{v} records of {rec} B reaches EOF"))
                    break
    return out


def fixed_record_runs(data: bytes, min_records: int = 8,
                      strides=(4, 6, 8, 12, 16, 20, 24, 28, 32, 36, 40, 48, 64)) -> list[dict]:
    """Find runs where a printable name field repeats at a constant stride."""
    found = []
    n = len(data)
    for stride in strides:
        off = 0
        while off < n - stride * min_records:
            # a record starts with >=3 printable bytes
            if not all(32 <= b < 127 for b in data[off:off + 3]):
                off += 1
                continue
            k = 0
            while off + (k + 1) * stride <= n:
                chunk = data[off + k * stride:off + k * stride + 3]
                if not all(32 <= b < 127 for b in chunk):
                    break
                k += 1
            if k >= min_records:
                names = []
                for i in range(min(k, 2048)):
                    raw = data[off + i * stride:off + i * stride + stride]
                    nm = raw.split(b"\x00")[0]
                    try:
                        names.append(nm.decode("latin-1"))
                    except Exception:
                        names.append("")
                found.append({"offset": off, "stride": stride, "records": k,
                              "first": names[0] if names else "",
                              "last": names[-1] if names else "",
                              "names": names})
                off += k * stride
            else:
                off += 1
    # keep the longest non-overlapping runs
    found.sort(key=lambda f: -f["records"] * f["stride"])
    kept, used = [], []
    for f in found:
        a, b = f["offset"], f["offset"] + f["records"] * f["stride"]
        if any(not (b <= x or a >= y) for x, y in used):
            continue
        used.append((a, b))
        kept.append(f)
    return kept


def magic_candidates(data: bytes) -> list[dict]:
    """First bytes and any 4-byte ASCII tag near the start."""
    out = [{"offset": 0, "bytes": data[:8].hex(" "),
            "ascii": "".join(chr(b) if 32 <= b < 127 else "." for b in data[:8])}]
    for off in range(0, min(4096, len(data) - 4)):
        tag = data[off:off + 4]
        if tag.isalpha() and tag.isupper():
            out.append({"offset": off, "tag": tag.decode(), "bytes": tag.hex(" ")})
    return out[:40]


# --------------------------------------------------------------- STY directory
# Discovered by this engine (not assumed): a .STY bank opens with a resource
# directory of 24-byte records at 0x24.
#
#   [0..17]  name field: ASCII name, NUL, then optional marker byte ('*')
#   [18]     resource kind   (observed: 0x02 and 0x07, two per style)
#   [19]     BANK ID         USER01 -> 0x11, USER02 -> 0x12, USER03 -> 0x13 ...
#                            Observed 0x11..0x1f across 38 banks, strictly
#                            following the bank filename.  An earlier reading
#                            of this byte as a "flag correlated with record
#                            ordering" was WRONG and is retracted: the
#                            correlation was an artefact of which banks
#                            happened to be examined first.
#   [20]     style index
#   [21..23] trailing        (observed 00 00 00 / 00 03 00 / 00 02 00)
#
# TWO ORDERINGS exist and a parser must handle both:
#   grouped     : all kind-0x02 records, then all kind-0x07
#   interleaved : style0/kind2, style0/kind7, style1/kind2, ...
DIR_START = 0x24
DIR_STRIDE = 24


def find_directory_start(data: bytes, search: int = 4096) -> int | None:
    """Locate the directory instead of assuming 0x24.

    0x24 held for the first banks examined but failed on 25 of 38 -- the
    offset moves with the bank header.  We scan for the first position where
    TWO consecutive 24-byte records both validate.
    """
    for o in range(0, min(search, len(data) - 2 * DIR_STRIDE)):
        ok = True
        for k in (0, 1):
            r = data[o + k * DIR_STRIDE:o + (k + 1) * DIR_STRIDE]
            if len(r) < DIR_STRIDE or r[18] not in (0x02, 0x07) \
               or not (0x10 <= r[19] <= 0x3f):
                ok = False
                break
        if ok and any(32 <= c < 127 for c in data[o:o + 12]):
            return o
    return None


def sty_directory(data: bytes, n_styles: int | None = None) -> dict:
    """Parse the bank resource directory.  Returns records + detected ordering."""
    start = find_directory_start(data)
    if start is None:
        return {"start": None, "records": 0, "ordering": "unknown",
                "distinct_indices": 0, "kinds": [], "flags": [],
                "consistent_two_per_style": False, "entries": []}
    recs = []
    i = 0
    while True:
        o = start + i * DIR_STRIDE
        if o + DIR_STRIDE > len(data):
            break
        r = data[o:o + DIR_STRIDE]
        kind, flag, idx = r[18], r[19], r[20]
        if kind not in (0x02, 0x07) or not (0x10 <= flag <= 0x3f):
            break
        name = r[:18].split(b"\x00")[0].decode("latin-1", "replace")
        marker = r[:18].split(b"\x00")
        suffix = marker[1].decode("latin-1", "replace").strip("\x00") if len(marker) > 1 else ""
        recs.append({"offset": o, "name": name, "suffix": suffix,
                     "kind": kind, "bank_id": flag, "index": idx,
                     "tail": r[21:].hex(" ")})
        i += 1
    kinds = [r["kind"] for r in recs]
    ordering = "unknown"
    if recs:
        if len(kinds) >= 2 and kinds[0] == kinds[1]:
            ordering = "grouped"
        elif len(kinds) >= 2 and kinds[0] != kinds[1]:
            ordering = "interleaved"
    styles = sorted({r["index"] for r in recs})
    return {"start": hex(start), "stride": DIR_STRIDE,
            "records": len(recs), "ordering": ordering,
            "distinct_indices": len(styles),
            "kinds": sorted(set(kinds)), "bank_ids": sorted({r["bank_id"] for r in recs}),
            "consistent_two_per_style": len(recs) == 2 * len(styles) if styles else False,
            "entries": recs}
