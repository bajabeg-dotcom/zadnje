"""Byte-level differ with region grouping and change classification."""
from __future__ import annotations

from dataclasses import dataclass, field


@dataclass
class ByteChange:
    offset: int
    before: int
    after: int

    @property
    def delta(self) -> int:
        return self.after - self.before


@dataclass
class Region:
    start: int
    end: int
    changes: list[ByteChange] = field(default_factory=list)
    kind: str = "unknown"

    @property
    def length(self) -> int:
        return self.end - self.start


def byte_diff(a: bytes, b: bytes) -> list[ByteChange]:
    n = min(len(a), len(b))
    return [ByteChange(i, a[i], b[i]) for i in range(n) if a[i] != b[i]]


def group(changes: list[ByteChange], gap: int = 8) -> list[Region]:
    """Adjacent changes (within `gap` bytes) become one region."""
    if not changes:
        return []
    regs: list[Region] = []
    cur = Region(changes[0].offset, changes[0].offset + 1, [changes[0]])
    for c in changes[1:]:
        if c.offset - cur.end <= gap:
            cur.end = c.offset + 1
            cur.changes.append(c)
        else:
            regs.append(cur)
            cur = Region(c.offset, c.offset + 1, [c])
    regs.append(cur)
    return regs


def classify(regs: list[Region], size_a: int, size_b: int) -> list[Region]:
    """Label regions without asserting meaning.

    The spec is explicit: if one parameter change moves 20 locations, do not
    assume they are all that parameter.  So we only separate structurally
    distinguishable classes and leave the rest `unknown`.
    """
    for r in regs:
        if r.length == 1:
            r.kind = "single_byte"
        elif r.length in (2, 4):
            r.kind = "word_candidate"
        elif all(c.delta == regs[0].changes[0].delta for c in r.changes):
            r.kind = "uniform_shift"
        else:
            r.kind = "block"
    if size_a != size_b:
        for r in regs:
            if r.kind == "block" and r.length > 64:
                r.kind = "relocation_candidate"
    return regs


def summary(a: bytes, b: bytes, gap: int = 8) -> dict:
    ch = byte_diff(a, b)
    regs = classify(group(ch, gap), len(a), len(b))
    return {
        "size_a": len(a), "size_b": len(b),
        "same_size": len(a) == len(b),
        "changed_bytes": len(ch),
        "regions": len(regs),
        "region_list": [
            {"start": hex(r.start), "end": hex(r.end), "len": r.length,
             "kind": r.kind,
             "changes": [{"off": hex(c.offset), "before": c.before,
                          "after": c.after, "delta": c.delta}
                         for c in r.changes[:16]]}
            for r in regs],
    }
