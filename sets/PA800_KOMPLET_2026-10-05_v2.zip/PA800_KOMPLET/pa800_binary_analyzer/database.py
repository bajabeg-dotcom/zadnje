"""Evidence database -- every claim carries offset, encoding and provenance."""
from __future__ import annotations

import json
from pathlib import Path

STATUSES = ("VERIFIED", "HIGH", "MEDIUM", "LOW", "UNKNOWN")


class EvidenceDB:
    def __init__(self, path: str | Path = "PA800_BINARY_EVIDENCE.json"):
        self.path = Path(path)
        self.entries: list[dict] = []
        if self.path.exists():
            try:
                self.entries = json.loads(self.path.read_text())
            except Exception:
                self.entries = []

    def add(self, name, file_type, offset, length, encoding, value,
            meaning, evidence, confidence, status):
        if status not in STATUSES:
            raise ValueError(f"status must be one of {STATUSES}")
        self.entries.append({
            "name": name, "file_type": file_type,
            "offset": offset if isinstance(offset, str) else hex(offset),
            "length": length, "encoding": encoding, "value": value,
            "meaning": meaning, "evidence": list(evidence),
            "confidence": round(float(confidence), 3), "status": status})

    def by_status(self, status): return [e for e in self.entries if e["status"] == status]

    def save(self):
        self.path.write_text(json.dumps(self.entries, indent=1, ensure_ascii=False))
        return self.path
