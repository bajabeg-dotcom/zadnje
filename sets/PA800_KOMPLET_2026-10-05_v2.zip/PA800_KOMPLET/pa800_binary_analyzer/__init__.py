"""PA800 binary reverse-engineering engine.  Read-only, evidence-first."""
__version__ = "0.1.0"
