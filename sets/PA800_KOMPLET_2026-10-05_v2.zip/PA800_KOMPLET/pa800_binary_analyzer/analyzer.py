"""Orchestration: identification, structure, experiments, workspace layout."""
from __future__ import annotations

import json
import shutil
from dataclasses import asdict
from pathlib import Path

from . import binary_reader as br
from . import hex_view, diff_engine, structure_detector as sd
from . import midi_detector as md, pattern_detector as pd, checksum_detector as ck
from .database import EvidenceDB

DIRS = ("original", "hex", "diff", "reports", "structures", "hypotheses", "experiments")


def workspace(root: str | Path) -> Path:
    r = Path(root)
    for d in DIRS:
        (r / d).mkdir(parents=True, exist_ok=True)
    return r


def identify(blob: br.Blob) -> dict:
    eb = br.entropy_blocks(blob.data)
    a = br.ascii_strings(blob.data)
    u = br.utf16_strings(blob.data)
    return {
        "file": str(blob.path), "size": blob.size,
        "md5": blob.md5, "sha1": blob.sha1, "sha256": blob.sha256,
        "entropy_overall": round(br.entropy(blob.data), 4),
        "entropy_min": round(min(e for _, e, _ in eb), 3) if eb else 0,
        "entropy_max": round(max(e for _, e, _ in eb), 3) if eb else 0,
        "null_density": round(br.null_density(blob.data), 4),
        "ascii_strings": len(a), "utf16_strings": len(u),
        "ascii_sample": [s for _, s in a[:12]],
        "header_bytes": blob.data[:16].hex(" "),
        "header_ascii": "".join(chr(b) if 32 <= b < 127 else "." for b in blob.data[:16]),
        "magic_candidates": sd.magic_candidates(blob.data)[:12],
        "repeating_runs": len(br.repeating_runs(blob.data)),
    }


def structure(blob: br.Blob) -> dict:
    d = blob.data
    return {
        "length_candidates": [vars(c) for c in sd.length_candidates(d)[:40]],
        "offset_candidates": [vars(c) for c in sd.offset_candidates(d)[:40]],
        "count_candidates": [vars(c) for c in sd.count_candidates(d)[:40]],
        "fixed_record_runs": [{k: v for k, v in r.items() if k != "names"} |
                              {"sample": r["names"][:6]}
                              for r in sd.fixed_record_runs(d)[:12]],
    }


def midi(blob: br.Blob) -> dict:
    smf = md.find_smf(blob.data)
    return {
        "smf_files": [asdict(s) | {"offset_hex": hex(s.offset)} for s in smf],
        "midi_like_regions": md.scan_midi_like(blob.data)[:20],
    }


def analyze(path: str | Path, out_root: str | Path = "analysis") -> dict:
    blob = br.load(path)
    root = workspace(out_root)
    # Keep an untouched copy, never the original.  The name is prefixed with
    # the content hash: two different files may share a basename (e.g. the
    # pa3x and pa800 builds of InitPx02.STY), and the first version of this
    # code silently overwrote one with the other -- destroying provenance.
    copy = root / "original" / f"{blob.sha256[:8]}_{blob.path.name}"
    if not copy.exists():
        shutil.copy2(blob.path, copy)
    rep = {"identification": identify(blob),
           "structure": structure(blob),
           "midi": midi(blob),
           "patterns": {"repeated_blocks": pd.repeated_blocks(blob.data)}}
    (root / "hex" / f"{blob.path.name}.hex.txt").write_text(
        hex_view.dump(blob.data, 0, 2048))
    (root / "structures" / f"{blob.path.name}.json").write_text(
        json.dumps(rep, indent=1, ensure_ascii=False))
    rep["original_untouched"] = br.verify_untouched(blob)
    return rep


def experiment(base: str | Path, mod: str | Path, name: str,
               out_root: str | Path = "analysis") -> dict:
    """Controlled A/B: base vs one-change file."""
    a, b = br.load(base), br.load(mod)
    root = workspace(out_root)
    exp = root / "experiments" / name
    exp.mkdir(parents=True, exist_ok=True)
    res = diff_engine.summary(a.data, b.data)
    changed = [c.offset for c in diff_engine.byte_diff(a.data, b.data)]
    res["checksum_candidates"] = ck.scan_for_checksum(b.data, changed)
    res["inputs"] = {"base": {"file": str(a.path), "sha256": a.sha256, "size": a.size},
                     "mod": {"file": str(b.path), "sha256": b.sha256, "size": b.size}}
    res["originals_untouched"] = br.verify_untouched(a) and br.verify_untouched(b)
    (exp / "diff.json").write_text(json.dumps(res, indent=1, ensure_ascii=False))
    return res


def correlate(experiments: dict[str, dict]) -> dict:
    """Which offsets move in SOME experiments but not others.

    An offset that changes only in the 'sound' experiments and never in
    'volume'/'pan'/'tempo' is a candidate for that parameter -- but only a
    CANDIDATE, per the spec.
    """
    sets = {}
    for name, res in experiments.items():
        offs = set()
        for r in res.get("region_list", []):
            for c in r["changes"]:
                offs.add(int(c["off"], 16))
        sets[name] = offs
    out = {}
    for name, offs in sets.items():
        others = set().union(*[s for n, s in sets.items() if n != name]) if len(sets) > 1 else set()
        unique = sorted(offs - others)
        out[name] = {"changed": len(offs), "unique_to_this": len(unique),
                     "unique_offsets": [hex(x) for x in unique[:64]]}
    shared = set.intersection(*sets.values()) if len(sets) > 1 else set()
    out["_shared_by_all"] = [hex(x) for x in sorted(shared)[:64]]
    return out
