"""Velocity candidates with full context (spec section 16).

The spec forbids calling any byte in 1..127 a velocity.  A candidate is only
listed when we can name the event it belongs to, its tick, its lane and the
absolute file offset of the byte -- so the claim is falsifiable by a single
controlled edit.
"""
from __future__ import annotations

import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "PA800_Remapper"))

from pa800_remap.native import NativeStyleBank                     # noqa: E402
from pa800_remap.native.codec import walk_children, _be32          # noqa: E402
from pa800_remap.native.events import parse_pattern_stream         # noqa: E402


def candidates(path: str, limit: int = 40) -> dict:
    bank = NativeStyleBank.load(path)
    out, total, with_pos = [], 0, 0
    for si, entry in enumerate(bank.entries):
        st = entry.style
        try:
            roles = st.pattern_role_map()
        except Exception:
            roles = {}
        pats = walk_children(st.data, st.pattern_pool.offset)[1:]
        for pi, pat in enumerate(pats, start=1):
            s = pat.offset + 8
            dur = _be32(st.data, s)
            ln = _be32(st.data, s + 4)
            stream_at = s + 8
            for ev in parse_pattern_stream(st.data[stream_at:stream_at + ln], dur):
                if ev.opcode != 1:
                    continue
                total += 1
                vp = ev.velocity_position
                if vp is None:
                    continue
                with_pos += 1
                if len(out) < limit:
                    out.append({
                        "style": st.name, "style_index": si,
                        "pattern": pi,
                        "offset_in_resource": hex(stream_at + vp),
                        "raw": st.data[stream_at + vp],
                        "value": ev.velocity,
                        "event": "Note-On (opcode 1)",
                        "pitch": ev.pitch,
                        "tick": ev.tick,
                        "tracks": sorted(roles.get(pi, [])),
                        "confidence": 0.80,
                        "status": "HIGH",
                    })
    return {"file": path, "note_on_events": total,
            "with_velocity_position": with_pos,
            "candidates": out,
            "caveat": "Position is inside the DECODED resource, not the raw .STY "
                      "file: the STYLE resource is OC-compressed on disk, so a "
                      "raw-file offset does not exist until the resource is "
                      "decoded. Proving velocity therefore needs a controlled "
                      "ONE_CHANGE_VELOCITY export, not a hex edit."}
