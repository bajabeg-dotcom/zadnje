#!/usr/bin/env python3
"""Structural diff of PA1X vs PA800 STY resources: type-06 / type-09 / KORF."""
from __future__ import annotations

from pathlib import Path
import struct
import sys
from collections import Counter

sys.path.insert(0, r"C:\Users\Baja\Desktop\BAJA MUSIC\Baja_Music_PA_Manager_V1_WORKING\pa800_native")
from oc31_codec import decode_oc31  # type: ignore

PA1X_STY = Path(r"C:\Users\Baja\Desktop\Pantic Pa1X.SET\STYLE")
PA800_STY = Path(r"C:\Users\Baja\Desktop\BAJA MUSIC\extracted_files_oc20_lzss\STARTUP\ALL\STYLE")
PA3X_STY = Path(r"C:\Users\Baja\AppData\Local\Temp\opencode\pa3x_extract\BRMA NOVI.SET\STYLE")


def parse_bank(data: bytes) -> dict:
    kend = data.find(b"KEND")
    kbeg = data.find(b"KBEG")
    korf = data.find(b"KORF")
    count = struct.unpack(">I", data[kend + 4 : kend + 8])[0]
    # production formula
    kbeg_calc = kend - 4 - 4 * count
    start = kbeg_calc + 4
    offsets = [struct.unpack(">I", data[start + 4 * i : start + 4 * i + 4])[0] for i in range(count)]
    resources = []
    for i, o in enumerate(offsets):
        end = offsets[i + 1] if i + 1 < count else kbeg
        if o + 8 > len(data):
            resources.append({"i": i, "bad": o})
            continue
        hdr = data[o : o + 4]
        sz = struct.unpack(">I", data[o + 4 : o + 8])[0]
        payload = data[o + 8 : o + 8 + sz]
        rec = {
            "i": i,
            "off": o,
            "hdr": hdr,
            "kind": hdr[0],
            "b1": hdr[1],
            "b2": hdr[2],
            "b3": hdr[3],
            "size": sz,
            "codec": payload[:4] if len(payload) >= 4 else b"",
            "payload_head": payload[:24],
        }
        if payload.startswith(b"OC31"):
            try:
                dec = decode_oc31(payload)
                rec["dec"] = dec
                rec["dec_len"] = len(dec)
                rec["dec_head"] = dec[:48]
            except Exception as e:
                rec["dec_err"] = str(e)
        resources.append(rec)
    # KORF records: start after 8-byte header, 24-byte records until first resource or KBEG
    korf_region = data[korf : offsets[0]] if offsets else data[korf:kbeg]
    korf_names = []
    body = korf_region[8:]  # skip KORF + 4
    # try from +4
    for base_label, base in [("after8", korf_region[8:]), ("after4", korf_region[4:]), ("after12", korf_region[12:])]:
        names = []
        for i in range(0, len(base) - 23, 24):
            rec = base[i : i + 24]
            nm = rec[5:21]
            if all(32 <= b < 127 or b == 0 for b in nm) and nm[0] != 0:
                s = nm.split(b"\x00")[0].decode("ascii", "replace").strip()
                if len(s) >= 2:
                    names.append(s)
        if base_label == "after8":
            korf_names = names
        print(f"    KORF names[{base_label}]={len(names)} sample={names[:4]}")
    return {
        "size": len(data),
        "magic": data[:4],
        "kend_ptr": struct.unpack(">I", data[4:8])[0],
        "f8": data[8:12],
        "f12": data[16:23] if korf >= 16 else b"",
        "korf": korf,
        "kbeg": kbeg,
        "kend": kend,
        "count": count,
        "kbeg_calc": kbeg_calc,
        "offsets": offsets,
        "resources": resources,
        "korf_names": korf_names,
        "prefix": data[:offsets[0]] if offsets else data[:korf],
    }


def summarize(label: str, bank: dict) -> None:
    print(f"\n==== {label} ====")
    print(f"size={bank['size']} magic={bank['magic'].hex(' ')} count={bank['count']} korf@{bank['korf']} kbeg@{bank['kbeg']}(calc {bank['kbeg_calc']}) kend@{bank['kend']}")
    print(f"f8={bank['f8'].hex(' ')} prefix_len={len(bank['prefix'])}")
    kinds = Counter()
    hdr_variants = Counter()
    for r in bank["resources"]:
        if "bad" in r:
            print(" BAD", r)
            continue
        kinds[r["kind"]] += 1
        hdr_variants[(r["kind"], r["b1"], r["b2"], r["b3"])] += 1
        if "dec_err" in r:
            print(f"  dec_err res{r['i']}: {r['dec_err']}")
    print("kinds", dict(kinds))
    print("hdr variants (kind,b1,b2,b3):", dict(hdr_variants))
    print("korf_names", len(bank["korf_names"]), bank["korf_names"][:8])
    # show first type06 and type09
    for want in (6, 9):
        for r in bank["resources"]:
            if r.get("kind") == want and "dec" in r:
                print(
                    f"  sample type{want:02d} res{r['i']}: hdr={r['hdr'].hex(' ')} size={r['size']} "
                    f"dec_len={r['dec_len']} dec_head={r['dec_head'].hex(' ')}"
                )
                break


def compare(a: dict, b: dict, la: str, lb: str) -> None:
    print(f"\n---- COMPARE {la} vs {lb} ----")
    # resource count / kind pattern
    ka = Counter(r.get("kind") for r in a["resources"] if "bad" not in r)
    kb = Counter(r.get("kind") for r in b["resources"] if "bad" not in r)
    print("kind", dict(ka), "vs", dict(kb))
    ha = Counter((r.get("kind"), r.get("b1"), r.get("b2"), r.get("b3")) for r in a["resources"] if "bad" not in r)
    hb = Counter((r.get("kind"), r.get("b1"), r.get("b2"), r.get("b3")) for r in b["resources"] if "bad" not in r)
    print("hdrA", dict(ha))
    print("hdrB", dict(hb))
    # type09 size compare distribution
    for kind in (6, 9):
        sa = [r["size"] for r in a["resources"] if r.get("kind") == kind]
        sb = [r["size"] for r in b["resources"] if r.get("kind") == kind]
        print(f"type{kind:02d} sizes A({len(sa)})={sa[:12]} ... B({len(sb)})={sb[:12]}")
        da = [r.get("dec_len") for r in a["resources"] if r.get("kind") == kind and "dec" in r]
        db = [r.get("dec_len") for r in b["resources"] if r.get("kind") == kind and "dec" in r]
        print(f"type{kind:02d} dec_len A({len(da)})={da[:12]} ... B({len(db)})={db[:12]}")
    # header identity of type-09: b2 seems version 02 vs 03
    print("prefix A", a["prefix"][:32].hex(" "))
    print("prefix B", b["prefix"][:32].hex(" "))


def deep_type09(a: dict, b: dict) -> None:
    """Compare type-09 decompressed structure (companion/STS)."""
    t9a = [r for r in a["resources"] if r.get("kind") == 9 and "dec" in r]
    t9b = [r for r in b["resources"] if r.get("kind") == 9 and "dec" in r]
    print(f"\ntype09 count A={len(t9a)} B={len(t9b)}")
    if not t9a or not t9b:
        return
    # pairwise first N
    n = min(3, len(t9a), len(t9b))
    for i in range(n):
        da, db = t9a[i]["dec"], t9b[i]["dec"]
        print(f"  pair{i}: len {len(da)} vs {len(db)} delta={len(db)-len(da)}")
        # find common prefix
        cp = 0
        while cp < min(len(da), len(db)) and da[cp] == db[cp]:
            cp += 1
        print(f"    common_prefix={cp}")
        if cp < min(len(da), len(db)):
            print(f"    A[{cp}:{cp+16}]={da[cp:cp+16].hex(' ')}")
            print(f"    B[{cp}:{cp+16}]={db[cp:cp+16].hex(' ')}")
        # structure: look for nested length-delimited children
        print(f"    A head48={da[:48].hex(' ')}")
        print(f"    B head48={db[:48].hex(' ')}")


def deep_type06(a: dict, b: dict) -> None:
    t6a = [r for r in a["resources"] if r.get("kind") == 6 and "dec" in r]
    t6b = [r for r in b["resources"] if r.get("kind") == 6 and "dec" in r]
    print(f"\ntype06 count A={len(t6a)} B={len(t6b)}")
    if not t6a or not t6b:
        return
    da, db = t6a[0]["dec"], t6b[0]["dec"]
    print(f"  first: len {len(da)} vs {len(db)}")
    print(f"  A head64={da[:64].hex(' ')}")
    print(f"  B head64={db[:64].hex(' ')}")
    # element counts via known geometry? just show byte histogram of first 64
    # look at PatternInfo-like fields: after common header
    cp = 0
    while cp < min(len(da), len(db)) and da[cp] == db[cp]:
        cp += 1
    print(f"  common_prefix={cp}")


def main() -> None:
    samples = {
        "PA1X_LIVE": PA1X_STY / "BANK01_LIVE.STY",
        "PA1X_USER02": PA1X_STY / "USER02.STY",
        "PA1X_USER03": PA1X_STY / "USER03.STY",
        "PA800_BANK01": PA800_STY / "BANK01.STY",
        "PA800_USER01": PA800_STY / "USER01.sty",
        "PA3X_USER01": PA3X_STY / "USER01.STY",
    }
    banks = {}
    for label, path in samples.items():
        if not path.exists():
            print("MISSING", path)
            continue
        bank = parse_bank(path.read_bytes())
        banks[label] = bank
        summarize(label, bank)

    if "PA1X_LIVE" in banks and "PA800_BANK01" in banks:
        compare(banks["PA1X_LIVE"], banks["PA800_BANK01"], "PA1X_LIVE", "PA800_BANK01")
        deep_type09(banks["PA1X_LIVE"], banks["PA800_BANK01"])
        deep_type06(banks["PA1X_LIVE"], banks["PA800_BANK01"])
    if "PA3X_USER01" in banks and "PA800_USER01" in banks:
        compare(banks["PA3X_USER01"], banks["PA800_USER01"], "PA3X_USER01", "PA800_USER01")
        deep_type09(banks["PA3X_USER01"], banks["PA800_USER01"])
        deep_type06(banks["PA3X_USER01"], banks["PA800_USER01"])
    if "PA1X_LIVE" in banks and "PA3X_USER01" in banks:
        compare(banks["PA1X_LIVE"], banks["PA3X_USER01"], "PA1X_LIVE", "PA3X_USER01")


if __name__ == "__main__":
    main()
