# PA800 katalog — jedinstveni modul i izvozi (v2.02)

Ovaj folder sadrzi **jedan samo-odrzivi Python modul** (`pa800_catalog.py`) i
**izvezene kataloge** koji na jednom mjestu drze sve dokazne podatke iz
postojeceg Pa800 OS/Resources v2.02 istrazivanja u
`E:\Pa800_os_res_v202_EXTRACTED\`. Podaci nisu ponovno izvodjeni iz `.pkg`
arhive; sve je preuzeto iz vec postojedih izvornih datoteka.

- Verzija kataloga: `1.0.0` (`CATALOG_VERSION` u modulu)
- Izvor: `E:\Pa800_os_res_v202_EXTRACTED` (19 provenance datoteka)
- Modul: samo standardna biblioteka (`json`, `gzip`, `hashlib`, `csv`,
  `re`, `argparse`, `pathlib`, `os`, `sys`) — bez trecih strana.

---

## 1. Sto katalog sadrzi

| Sekcija | Sadrzaj | Broj |
| --- | --- | ---: |
| `sounds` | Factory Sound liste s bank/program adresama | **1068** |
| `oscillators` | Per-OSC multisample evidencija za RX/DNC zvukove | **294** |
| `velocity_layers` | OSC velocity/key prozori po zvuku | **307** |
| `drum_kits` | Drum kitovi (adresa, dokumentovane tipke, opazena dinamika) | **65** |
| `drum_key_map` | Per-key redovi (128 tipki po kitu) | **8320** |
| `factory_velocity_references` | Opazene velocity distribucije iz factory korpusa | **2472** |
| `rx_dnc` | RX identiteti / DNC identiteti / RX drum kitovi | **44 / 23 / 21** |
| `articulations` | Guitar + bass articulacije, noise, preseti, DNC CC mapa | **19 grupa** |
| `factory_styles` | Native STY bankovi + factory korpus labelle | **18 bankova / 252 labelle** |
| `provenance` | Per izvorna datoteka: putanja, velicina, sha256, sta je uzeto | **19 datoteka** |

### Kljucni brojevi

```
Sounds (factory lista)               : 1068
  od toga proven                     : 1068
OSC zapisi (multisample evidencija)  : 294
OSC zapisi proven                    : 0
Velocity/key prozori                 : 307
  od toga proven (hardware-observed) : 62
Zvukova s velocity prozorima         : 44
Drum kitova                          : 65
Drum key map unosa                   : 8320
Dokumentovanih drum tipki            : 13
RX zvukova                           : 44
DNC zvukova                          : 23
DNC zvukova s trigger mapom          : 23
RX drum kitova                       : 21
Articulation grupa                   : 19
Factory velocity referenci           : 2472
  od toga po zvuku (binding)         : 469
  od toga po drum keyju              : 2003
Factory style bankova                : 18
Factory style_name kandidata         : 34381
Factory style labela (korpus)        : 252
Factory style program change         : 395140
Factory style note event             : 270628
Provenance datoteka                  : 19
```

### Zvuk koji korisnik trazi

```
$ python pa800_catalog.py show 121.005.026
{
  "sound": {
    "index": 309,
    "name": "Soft Jazz Guitar",
    "cc00": 121, "cc32": 5, "pc": 26,
    "address": "121.005.026",
    "address_short": "121.5.26",
    "bank": "Guitar",
    "proven": true
  },
  "velocity_layers": [],
  "oscillators": [],
  "rx_dnc_triggers": null
}
```

`Soft Jazz Guitar` je **PROVEN** zapis iz factory Sound liste. Nema OSC
velocity prozora, nema per-OSC multisample evidencije i nema RX/DNC trigger
mape u izvorima — prazne liste znace "nema dokaza u katalogu", ne "nema
slojeva na uredjaju". "Soft Jazz Guitar" nije RX ni DNC Sound, pa ovaj
katalog za njega ne tvrdi nikakvu velocity zonu.

---

## 2. PROVEN vs INFERRED polja

Svaki zapis nosi `"proven"` (bool) i `"proven_note"` (objasnjenje). Pravilo:
`proven: true` samo tamo gdje izvor sam nosi status opazanja.

### PROVEN (`proven: true`)

| Polje / sekcija | Zasto je proven |
| --- | --- |
| `sounds` (svih 1068: naziv, cc00, cc32, pc, bank) | Direktan izvod iz `PA800_SOUND_LIST.json`, koji je izvod iz sluzbenog Owners Manual PDF-a. |
| 62 od 307 `velocity_layers` | RX registry prozori s `confidence == "hardware-observed"` (Finger/Picked/SlapFing/SlapPick Bass RX i Clean Guitar RX1–RX6). |
| `drum_kits[].documented_keys` i layer brojevi tih tipki (13 tipki, kit `Pop Std. Kit RX`) | `RX_OSCILLATOR_REGISTRY_v3.json` → `drum_key_layer_evidence`, koji se poklapa sa sekcijom 7.3 projektnog dokumenta. |
| `provenance[].sha256`, `size_bytes`, `path` | Izracunato iz stvarnih datoteka (provjerava `verify`). |

### INFERRED (`proven: false` + `proven_note`)

| Polje / sekcija | Zasto NIJE proven |
| --- | --- |
| 245 od 307 `velocity_layers` | `confidence == "hardware-inferred"` ili zapis bez `confidence` polja (`binding` + `switch_points` varijanta). |
| `oscillators` (svih 294) | Exact-unique-name join na projektnu OSC tabelu, **ne** native PCG byte-binding dokaz. `possible_internal_switch` i `articulation_guess` su kandidati. |
| `rx_dnc.dnc_sounds[].dnc_trigger_map` | `detail_status == "TRIGGER_MAP_INFERRED"`. Hard rule iz izvora: trigger mapa se ne izvodi iz RX/DNC sufiksa. |
| `rx_dnc.rx_sounds` detalji | `detail_status == "IDENTITY_ONLY"` za vecinu; identitet je factory-verified, detalji nisu. |
| `rx_dnc.rx_drum_kits[].factory_corpus_*` | Factory korpus je korisnicki Style Works izvoz, ne raw native STY dokaz. Jedan kit ima `address_conflict`. |
| `drum_kits` (svi) i `drum_key_map` | Sample imena su `unknown`; `total_kit_layers` je `unknown`; `complete: false`. Opazena MIDI dinamika (min/max) **nije** granica layera. |
| `factory_styles.banks[].style_name_candidates` (34381) | Sirovi sken native STY byte-podrucja: sadrzi odrezane varijante istog imena (`"Standard 8 Beat"`, `"tandard 8 Beat"`, ...). Nije potvrdjena lista stilova. |
| `factory_styles.factory_corpus` | Korisnicki izvoz iz klavijature kroz Style Works (`E:\Split Factory Styles.zip`), nije raw native STY dokaz. |
| `factory_velocity_references` (2472) | Opazene distribucije; `trigger_threshold_status == "NOT_INFERRED_FROM_DISTRIBUTION"`. |
| `articulations` | Projektni engine rule setovi (guitar/bass), nisu izmjereni native Pa800 parametri. `dnc_cc_map` je projektna konvencija. |
| `factory_support` / `factory_corpus_support_grade` | Naslijedjeni status iz izvora, nije nezavisno mjerenje. |

Nijedno polje nije izmisljeno: gdje izvor kaze `unknown`, u katalogu je
`null` ili `"unknown"`, uz `proven: false` i napomenu.

---

## 3. Datoteke

### Obavezni izvozi

| Datoteka | Velicina | Sadrzaj |
| --- | ---: | --- |
| `pa800-catalog-sounds.json` | 394.790 B | 1068 Soundova s adresama (PROVEN). |
| `pa800-catalog-oscillators.json` | 62.041 B | 294 OSC zapisa, kompaktna projekcija; puna polja u `*_full.json.gz`. |
| `pa800-catalog-velocity.json` | 141.116 B | 307 velocity/key prozora s per-zapis `proven`. |
| `pa800-catalog-drumkits.json` | 179.408 B | 65 kitova + kompaktni key map (samo tipke s dokazom). |

### Dodatni izvozi (da je katalog potpun bez `E:`)

| Datoteka | Velicina | Sadrzaj |
| --- | ---: | --- |
| `pa800-catalog-rx-dnc.json` | 60.197 B | RX/DNC identiteti, trigger mape, hard rules. |
| `pa800-catalog-articulations.json` | 20.323 B | Guitar/bass articulacije, noise, preseti, DNC CC mapa. |
| `pa800-catalog-styles.json` | 494.654 B | 18 STY bankova + factory korpus. |
| `pa800-catalog-factory-refs.json` | 396.416 B | 2472 opazene distribucije (projekcija; histogrami u gz). |
| `pa800-catalog-provenance.json` | 7.371 B | **Obavezni** provenance (putanja, velicina, sha256, sta je uzeto). |
| `pa800-catalog-cache.json.gz` | 409.629 B | Kompletan katalog za offline rad (`load_catalog`). |

Svi obavezni izvozi su ispod ~3 MB. Nijedan nije morao biti rezan, pa nije
napravljen ni jedan dodatni `*_full.json.gz` za njih; `_full.json.gz` izvozi
postoje samo tamo gdje glavni JSON namjerno nosi kompaktnu projekciju:

- `pa800-catalog-oscillators_full.json.gz` — 5.010 B (sva OSC polja)
- `pa800-catalog-drumkits_full.json.gz` — 287.252 B (svih 128 tipki po kitu
  + pune factory reference s histogramima)

### Format kompaktnog drum key mapa

Da `pa800-catalog-drumkits.json` ostane ispod granice, `key_map` je u
tag-obliku (dokumentovano u polju `key_map_format`):

| Tag | Znaci |
| --- | --- |
| `k` | MIDI key |
| `n` | ime note |
| `l` | broj layera (`null` = unknown) |
| `o` | opazeni note-on brojevi |
| `s` | switch pragovi; `;` izmedju tipki, `,` unutar tipke |
| `v` | `[[vel_min, vel_max], ...]`; `-1` = unknown |

Sadrzi samo tipke s dokazom (layer broj ili opazeni note-on). Modul to
transparentno prosiruje natrag u puni oblik preko `ExpandedKeyMap`, pa
`drum_key_info()` radi identicno nad cacheom i nad izvozom.

---

## 4. Kako se regenerise

Modul prvo trazi lokalni cache (`pa800-catalog-cache.json.gz` pored modula ili
u `--cache-dir`), pa tek onda cita `E:` izvore. Jasnu gresku dize samo kad
nema ni cachea ni izvora.

### Export (pise sve izvoze + cache)

```powershell
cd C:\Users\Baja\Desktop\prism-uploads\analysis
$env:PYTHONIOENCODING="utf-8"
python pa800_catalog.py export --out "C:\Users\Baja\Desktop\prism-uploads\analysis"
```

Izlaz (stvaran, 2026-10-02):

```
sounds              394,790 B  ...\pa800-catalog-sounds.json
oscillators          62,041 B  ...\pa800-catalog-oscillators.json
oscillators_full      5,010 B  ...\pa800-catalog-oscillators_full.json.gz
velocity            141,116 B  ...\pa800-catalog-velocity.json
drumkits            179,408 B  ...\pa800-catalog-drumkits.json
drumkits_full       287,252 B  ...\pa800-catalog-drumkits_full.json.gz
rx_dnc               60,197 B  ...\pa800-catalog-rx-dnc.json
articulations        20,323 B  ...\pa800-catalog-articulations.json
styles              494,654 B  ...\pa800-catalog-styles.json
provenance            7,371 B  ...\pa800-catalog-provenance.json
factory_refs        396,416 B  ...\pa800-catalog-factory-refs.json
cache               409,629 B  ...\pa800-catalog-cache.json.gz
```

> Napomena: `export` koristi `load_catalog()`, pa ako cache vec postoji on ga
> **ne** gradi ponovno iz izvora. Kad se modul ili izvori promijene, prvo
> obrisi cache ili pokreni `verify`:
>
> ```powershell
> Remove-Item "pa800-catalog-cache.json.gz" -Force
> python pa800_catalog.py export --out .
> ```

### Provjera da cache odgovara izvorima

```powershell
python pa800_catalog.py verify
```

Izlaz (zadnji redovi):

```
[OK ] factory_references: E:\Pa800_os_res_v202_EXTRACTED\...\FACTORY_SOUND_REFERENCES.json
[OK ] styleworks_summary: E:\Pa800_os_res_v202_EXTRACTED\...\SUMMARY.json
[OK ] pkg_manifest: E:\Pa800_os_res_v202_EXTRACTED\manifest.json
[OK ] pkg_summary: E:\Pa800_os_res_v202_EXTRACTED\SUMMARY.txt
[OK ] pkg_source_info: E:\Pa800_os_res_v202_EXTRACTED\SOURCE_INFO.txt
all_match: True
verify exit=0
```

### Brojevi, pretraga i prikaz

```powershell
python pa800_catalog.py stats
python pa800_catalog.py search "El Piano" --limit 8
python pa800_catalog.py show 121.005.026
```

Izlaz `search`:

```
   121.003.004  SOUND        60's E. Piano   E.Piano
   121.002.000  SOUND        Ac. Piano Dark Piano
   121.001.000  SOUND        Ac. Piano Wide Piano
   121.000.000  SOUND        AcousticPiano GM Piano
   121.023.004  SOUND        Bell E. Piano 1
   121.024.004  SOUND        Bell E. Piano 2
   121.000.001  SOUND        Bright Piano GM Piano
   121.001.001  SOUND        Bright PianoWide Piano
```

### Testovi

```powershell
python -m unittest test_pa800_catalog -v
```

Rezultat: **50 testova, svi prolaze** (`Ran 50 tests ... OK`).

### Rad bez `E:` izvora

Modul se moze kopirati zajedno s `pa800-catalog-cache.json.gz` na drugu masinu:

```powershell
python pa800_catalog.py stats          # radi iz cachea
python pa800_catalog.py search "Jazz"  # radi iz cachea
```

Kad nema ni cachea ni izvora:

```powershell
$env:PA800_SOURCE_DIR = "C:\nema\pa800"
python pa800_catalog.py stats
```

```
GRESKA: Nema Pa800 kataloga: cache ...\pa800-catalog-cache.json.gz ne postoji,
a izvori nisu dostupni.
Nedostaju izvorne datoteke Pa800 kataloga:
  - C:\nema\pa800\PA800_SOUND_LIST.json
  - C:\nema\pa800\RX_OSCILLATOR_REGISTRY_v3.json
  ...
Rjesenje: pokreni 'python pa800_catalog.py export --out DIR' tamo gdje su izvori
dostupni, pa kopiraj pa800-catalog-cache.json.gz pored modula; ili postavi
PA800_SOURCE_DIR na mapu s izvorima.
```

Exit kod je `2`.

---

## 5. API modula

```python
import pa800_catalog as pc

cat = pc.load_catalog()                     # cache ili E: izvori
pc.sound_lookup("Soft Jazz Guitar")         # ime, indeks ili adresa
pc.sound_lookup("121.005.026")              # -> dict sa proven=True
pc.find_sound("Jazz Guitar", limit=25)      # substring preko imena/adrese/banke
pc.oscillators_for_sound("Finger Bass RX")  # per-OSC multisample evidencija
pc.velocity_layers_for_sound("Clean Guitar RX1")
pc.drum_key_info("Pop Std. Kit RX", 38)     # ili "120.0.4" / "F#2"
pc.rx_triggers_for_sound("Jazz Guitar DNC")
pc.export_catalog("izlaz/")                 # -> {ime: Path}
```

`load_catalog(cache_dir=None)` vraca dict sa sekcijama: `sounds`,
`oscillators`, `velocity_layers`, `drum_kits`, `drum_key_map`,
`factory_velocity_references`, `rx_dnc`, `articulations`, `factory_styles`,
`provenance` (+ `stats`, `catalog_version`, `generated_from`).

Adrese su normalizovane na oblik `CC00.CC32.PC` s tri znamenke
(`121.005.026`, `120.000.004`); `address_short` cuva nepaddingovanu varijantu
(`121.5.26`, `120.0.4`). Lookup prihvata oba oblika.

---

## 6. Provenance

Puni strojno-citljivi zapis s `taken` objasnjenjem je u
`pa800-catalog-provenance.json`. Sazetak (velicina u bajtovima, sha256):

| Kljuc | Putanja (u `E:\Pa800_os_res_v202_EXTRACTED\`) | Velicina | sha256 |
| --- | --- | ---: | --- |
| `sound_list` | `PA800_SOUND_LIST.json` | 147.898 | `fa5b5083…3eb223` |
| `rx_registry` | `RX_OSCILLATOR_REGISTRY_v3.json` | 93.786 | `a206ff4d…baaaf8` |
| `rx_capabilities` | `RX_SOUND_CAPABILITIES_v1.json` | 170.362 | `cad451e7…1d4e14` |
| `special_registry` | `PA800_FACTORY_SPECIAL_REGISTRY_v2.json` | 42.004 | `4165076c…fc1930` |
| `hardware_osc_profiles` | `PA800_HARDWARE_VERIFIED_OSC_PROFILES.json` | 55.965 | `2a15f1d1…ebb892` |
| `native_osc_catalog` | `NATIVE_OSCILLATOR_CATALOG_v1.json` | 6.158.048 | `ebf138f0…0268ec` |
| `native_style_catalog` | `NATIVE_STYLE_CATALOG_v1.json` | 799.428 | `b4861320…a3cd06` |
| `drum_audit` | `PA800_DRUM_AUDIT.json` | 3.422.688 | `521890c3…a5d481` |
| `drum_kit_summary` | `PA800_DRUM_KIT_SUMMARY.csv` | 5.328 | `0aecff73…f050ab` |
| `drum_map_audit` | `PA800_DRUM_MAP_AUDIT.csv` | 720.568 | `9f07090e…510b3f` |
| `guitar_engine_rules` | `PA800_GUITAR_ENGINE_RULES.json` | 6.495 | `0f8bee6a…14bf05` |
| `bass_engine_rules` | `PA800_BASS_ENGINE_RULES.json` | 4.950 | `26314ed2…2d0a83` |
| `guitar_articulation_rules` | `PA800_GUITAR_ARTICULATION_RULES.json` | 2.256 | `8886ba2f…19cb7f` |
| `pcg_effects` | `PA800_PCG_EFFECTS.json` | 18.053 | `21728229…d2a7ed` |
| `factory_references` | `factory_style_lab_output\styleworks_factory_reference_v1\FACTORY_SOUND_REFERENCES.json` | 2.931.132 | `d02f57ba…fb9709` |
| `styleworks_summary` | `factory_style_lab_output\styleworks_factory_reference_v1\SUMMARY.json` | 1.146 | `33e1f1d8…0fa873` |
| `pkg_manifest` | `manifest.json` | 314.039 | `63203c96…07e2a7` |
| `pkg_summary` | `SUMMARY.txt` | 484 | `278098a9…f8e638` |
| `pkg_source_info` | `SOURCE_INFO.txt` | 128 | `2cf3b1c9…095a42` |

Izvorni `Pa800_os_res_v202.pkg`: 134.050.105 bajtova,
sha256 `a9ebc57de09463363ecf0b1ba5ec9c2e96ca43444bcd6c22cb7e16c93d099054`
(iz `SOURCE_INFO.txt` / `SUMMARY.txt`).

---

## 7. Sto ostaje nepoznato

1. **Per-OSC velocity zone za 400+ ne-RX zvukova.** Factory Sound lista daje
   adresu, ali ne i broj slojeva ni velocity granice. Za `Soft Jazz Guitar`
   (121.005.026) nema nikakvog OSC prozora u izvorima.
2. **245 od 307 velocity prozora nije hardware-potvrdjeno.** Pokrivenost je
   62/307 (20,2%); 34 od 44 RX zvukova nema potvrdjene velocity/key zone.
3. **Dist. Guitar RX1/RX2.** Visoki-dinamicki problem korisnika nije razrijesen:
   profil nije potvrdjen, `possible_internal_switch 114` je kandidat, a
   1003-instrument atlas se ne slaze s master OSC tabelom. Automatsko
   dodjeljivanje ostaje iskljuceno.
4. **Drum sample mapa.** 0 od 8320 redova ima ime sempla; `total_kit_layers` je
   `unknown` za svih 65 kitova; `complete: false`; samo 13 tipki ima
   dokumentovan broj layera. Opazena MIDI dinamika min/max nije granica layera.
5. **Factory style imena.** 34381 "kandidata" je sirovi sken; ne postoji
   potvrdjena lista imena stilova u ovim izvorima (252 labelle iz korpusa su
   korisnicki izvoz, ne native dokaz).
6. **Native byte-binding.** OSC evidencija je exact-unique-name join, ne
   potvrdjeno citanje PCG bajtova. `native_write_ready` je `false` u izvorima.
7. **Jedan address conflict** medju RX drum kitovima (17 unique adresa,
   1 konflikt) i PDF concatenation artefakti u imenima kitova
   (`PDF_CONCATENATION_REMAP_NOT_APPLIED`, remap nije primijenjen).
8. **`NATIVE_OSCILLATOR_CATALOG_v1.json`:** 13653 PCG programa, ali samo 31
   razrijesen (`NATIVE_KMP_ONLY`, 0,2%). Ostatak je `UNRESOLVED` i nije usao u
   `oscillators` sekciju.

---

## 8. Ogranicenja ovog posla

- Nijedna postojeda datoteka u `analysis\` ni na `E:\` nije mijenjana ni
  obrisana. Napravljene su samo nove datoteke navedene u ovom dokumentu.
- Podaci nisu ponovno izvodjeni iz `.pkg`; koristeni su samo postojedi izvodi.
- Polja koja izvor oznacava kao `unknown` ostaju `unknown`/`null`, bez
  popunjavanja procjenama.
