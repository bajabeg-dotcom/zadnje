import os
import struct
import sys
import json
import glob
import traceback

STYLE_ELEMENT_NAMES = [
    "Intro1", "Intro2", "Fill1", "Fill2", "Ending1", "Ending2",
    "Break", "Intro3", "Ending3", "Fill3", "Fill4",
]

CHORD_NAMES = [
    "maj", "6", "M7", "M7b5", "sus", "sus2", "M7sus", "m",
    "m6", "m7", "m7b5", "mM7", "7", "7b5", "7sus", "dim",
    "dimM7", "maj#5", "7#5", "M7#5", "1+5", "1+8", "b5", "dim7",
]

ACC_TRACK = ["Drum", "Perc", "Bass", "Acc1", "Acc2", "Acc3", "Acc4", "Acc5"]

LEAF = 0x08


class Reader:
    def __init__(self, data, be=True):
        self.data = data
        self.pos = 0
        self.be = be

    def remaining(self):
        return len(self.data) - self.pos

    def u8(self):
        if self.pos >= len(self.data):
            raise EOFError(f"u8@{self.pos}/{len(self.data)}")
        v = self.data[self.pos]
        self.pos += 1
        return v

    def u16(self):
        if self.pos + 2 > len(self.data):
            raise EOFError(f"u16@{self.pos}")
        v = struct.unpack_from(">H" if self.be else "<H", self.data, self.pos)[0]
        self.pos += 2
        return v

    def i16(self):
        if self.pos + 2 > len(self.data):
            raise EOFError(f"i16@{self.pos}")
        v = struct.unpack_from(">h" if self.be else "<h", self.data, self.pos)[0]
        self.pos += 2
        return v

    def u32(self):
        if self.pos + 4 > len(self.data):
            raise EOFError(f"u32@{self.pos}")
        v = struct.unpack_from(">I" if self.be else "<I", self.data, self.pos)[0]
        self.pos += 4
        return v

    def bytes(self, n):
        if self.pos + n > len(self.data):
            raise EOFError(f"bytes({n})@{self.pos}")
        v = self.data[self.pos:self.pos + n]
        self.pos += n
        return v


def read_header(r):
    cid = r.u32()
    size = r.u32()
    return {
        "id": cid,
        "type": (cid >> 24) & 0xFF,
        "major": (cid >> 16) & 0xFF,
        "minor": (cid >> 8) & 0xFF,
        "flags": cid & 0xFF,
        "size": size,
        "leaf": bool(cid & LEAF),
    }


def parse_style_info(r, minor, size_budget):
    info = {}
    nlen = r.u8()
    if nlen > 64:
        raise ValueError(f"nameLen {nlen}")
    info["name"] = r.bytes(nlen).decode("ascii", "replace")
    if size_budget is not None and r.pos >= size_budget:
        info["truncated"] = True
        return info
    info["unknown111"] = r.i16()
    info["unknown3"] = r.u8()
    info["enabled"] = r.u16()
    if size_budget is not None and r.pos >= size_budget:
        info["with_data"] = info["enabled"]
        info["truncated"] = True
        return info
    info["u6"] = r.u8()
    info["u7_14"] = list(r.bytes(8))
    info["u15"] = r.u8()
    info["u16"] = r.u8()
    if minor > 2:
        info["with_data"] = r.u16()
    else:
        info["with_data"] = info["enabled"]
    info["left"] = r.remaining()
    return info


def parse_chord_table(r):
    n = r.u8()
    if n not in (22, 24):
        raise ValueError(f"chordTable n={n}")
    raw = [r.u8() for _ in range(n)]
    if n == 22:
        raw = raw + [raw[13], raw[15]]
    return dict(zip(CHORD_NAMES, raw))


def decode_midi_events(r, data_length):
    events = []
    end = r.pos + data_length
    if end > len(r.data):
        raise ValueError(f"events end {end} > {len(r.data)}")
    while r.pos < end:
        et = r.u8()
        if et & 0x80:
            total = 0
            while et & 0x80:
                total = (total << 7) | (et & 0x7F)
                et = r.u8()
            events.append(("delta", total))
        unknown = None
        if et & 0x40:
            et &= ~0x40
            unknown = r.u8()
        if et in (0, 1, 3, 12, 13):
            v1 = r.u8()
            v2 = r.u8()
            if not (v2 & 0x80):
                raise ValueError(f"v2 high bit @{r.pos}: {v2:#x}")
            v2 &= 0x7F
            nm = {0: "off", 1: "on", 3: "cc", 12: "rxoff", 13: "rxon"}[et]
            ev = [nm, v1, v2]
            if unknown is not None:
                ev.append(unknown)
            events.append(tuple(ev))
        elif et == 5:
            v1 = r.u8()
            if not (v1 & 0x80):
                raise ValueError("at high bit")
            events.append(("at", v1 & 0x7F))
        elif et == 6:
            b1 = r.u8()
            b2 = r.u8()
            if b1 & 0x80:
                raise ValueError("bend b1")
            combined = ((b2 & 0x7F) << 7) | b1
            events.append(("bend", combined - 8192))
        elif et == 9:
            meta_type = r.u8()
            b1 = r.u8()
            b2 = r.u8()
            mlen = (b1 << 7) | (b2 & 0x7F)
            mdata = r.bytes(mlen) if mlen else b""
            events.append(("meta", meta_type, mdata.hex()))
            if meta_type == 0x2F:
                break
        else:
            raise ValueError(f"evt {et:#x} @{r.pos}")
    return events


def parse_se_info(r, major, minor):
    info = {"cv_mask": r.u8()}
    if major == 0:
        info["ntt"] = r.u8()
    ts = r.u8()
    info["ts"] = f"{ts >> 3}/{1 << (ts & 7)}"
    info["chords"] = parse_chord_table(r)
    if (major << 8 | minor) > 0:
        info["cue"] = r.u8()
    if major >= 1:
        if minor >= 2:
            info["u4"] = list(r.bytes(3))
            info["u5"] = list(r.bytes(12))
        if minor >= 3:
            info["u6"] = r.u8()
    info["left"] = r.remaining()
    return info


def parse_style_tracks(r, major, minor):
    tracks = []
    for _ in range(8):
        expr = r.u8()
        msb, lsb, pc = r.u8(), r.u8(), r.u8()
        lo, hi = r.u8(), r.u8()
        tracks.append({"expr": expr, "msb": msb, "lsb": lsb, "pc": pc, "lo": lo, "hi": hi})
    if minor >= 1:
        for t in tracks:
            t["u1"] = list(r.bytes(3))
    if minor >= 2:
        for t in tracks:
            t["ntt"] = r.u8()
    if minor >= 3:
        for t in tracks:
            t["u3"] = r.u8()
    if minor >= 4:
        for t in tracks:
            t["u4"] = r.u8()
    return tracks


def parse_cv(r):
    z = r.u16()
    ts = r.u8()
    u2 = r.u8()
    u3 = r.u8()
    z2 = r.u8()
    dlen = r.u16()
    events = decode_midi_events(r, dlen)
    nmap = r.u8()
    mapping = [(r.u8(), r.u8()) for _ in range(nmap)]
    return {"zero": z, "ts": ts, "events": events, "mapping": mapping, "left": r.remaining()}


def parse_acc_track(r, ttype):
    z = r.u16()
    ts = r.u8()
    track = {"type": ttype, "ts": ts}
    if ttype == 2:
        track["u2"] = r.u8()
        r.u16()
        dlen = r.u16()
        track["events"] = decode_midi_events(r, dlen)
    elif ttype == 3:
        track["u2"] = r.u8()
        track["u3"] = r.u8()
        r.u8()
        dlen = r.u16()
        track["events"] = decode_midi_events(r, dlen)
        track["u4"] = r.u8()
        track["u5"] = r.u8()
    elif ttype == 4:
        track["u2"] = r.u8()
        r.u8()
        r.u8()
        dlen = r.u16()
        track["events"] = decode_midi_events(r, dlen)
        track["u3"] = r.u8()
        track["u4"] = r.u8()
    elif ttype == 5:
        track["u2"] = r.u8()
        r.u8()
        r.u8()
        dlen = r.u16()
        track["events"] = decode_midi_events(r, dlen)
        track["u3"] = r.u8()
        track["u4"] = r.u8()
    else:
        raise ValueError(f"track type {ttype}")
    return track


def parse_track_mapping(r):
    ntracks = r.u16()
    nentries = r.u16()
    idxs = [r.u16() for _ in range(nentries)]
    return {"ntracks": ntracks, "indices": idxs, "left": r.remaining()}


def classify_leaf(h, pr, parent):
    kind = {"id": f"{h['id']:08x}", "size": h["size"]}
    ptype = parent["type"] if parent else None
    try:
        if ptype == 2 and h["type"] == 1:
            kind["kind"] = "track_mapping"
            kind["data"] = parse_track_mapping(pr)
            return kind
        if ptype == 1 and h["type"] == 1:
            kind["kind"] = "style_info"
            kind["data"] = parse_style_info(pr, h["minor"], h["size"])
            return kind
        if ptype == 3 and h["type"] == 1:
            kind["kind"] = "se_info"
            kind["data"] = parse_se_info(pr, h["major"], h["minor"])
            return kind
        if ptype == 3 and h["type"] == 2:
            kind["kind"] = "style_tracks"
            kind["data"] = parse_style_tracks(pr, h["major"], h["minor"])
            return kind
        if ptype == 3 and h["type"] == 3:
            kind["kind"] = "cv"
            kind["data"] = parse_cv(pr)
            return kind
        if ptype == 2 and h["type"] in (2, 3, 4, 5):
            kind["kind"] = "midi_track"
            kind["data"] = parse_acc_track(pr, h["type"])
            return kind
        if h["type"] == 1 and h["major"] == 1:
            kind["kind"] = "se_info"
            kind["data"] = parse_se_info(pr, h["major"], h["minor"])
            return kind
        if h["type"] == 3:
            kind["kind"] = "cv"
            kind["data"] = parse_cv(pr)
            return kind
        if h["type"] in (2, 3, 4, 5):
            kind["kind"] = "midi_track"
            kind["data"] = parse_acc_track(pr, h["type"])
            return kind
        if h["type"] == 1:
            kind["kind"] = "style_info?"
            kind["data"] = parse_style_info(pr, h["minor"], h["size"])
            return kind
    except Exception as e:
        kind["err"] = f"{type(e).__name__}: {e}"
        kind["hex"] = pr.data[pr.pos:pr.pos + 24].hex(" ")
        return kind
    kind["kind"] = "unknown"
    kind["hex"] = pr.data[:32].hex(" ")
    kind["left"] = pr.remaining()
    return kind


def walk(data, depth=0, out=None, parent=None, se_index=None, style=None):
    if out is None:
        out = []
    if se_index is None:
        se_index = {"i": 0}
    r = Reader(data, be=True)
    while r.remaining() >= 8:
        start = r.pos
        try:
            h = read_header(r)
        except EOFError:
            break
        entry = {
            "off": start,
            "abs_off": (parent.get("_abs", 0) + start) if parent else start,
            "id": f"{h['id']:08x}",
            "type": h["type"],
            "ver": f"{h['major']}.{h['minor']}",
            "flags": h["flags"],
            "size": h["size"],
            "leaf": h["leaf"],
            "depth": depth,
            "parent_type": parent["type"] if parent else None,
        }
        if h["size"] > r.remaining():
            entry["error"] = f"size {h['size']} > rem {r.remaining()}"
            out.append(entry)
            break
        payload = r.bytes(h["size"])
        entry["payload_len"] = len(payload)
        out.append(entry)

        if h["leaf"]:
            pr = Reader(payload, be=True)
            entry["kind"] = classify_leaf(h, pr, parent)
        else:
            p = dict(h)
            p["_abs"] = (parent.get("_abs", 0) + start + 8) if parent else (start + 8)
            walk(payload, depth + 1, out, parent=p, se_index=se_index, style=style)
    return out


def summarize(path):
    data = open(path, "rb").read()
    style = {"file": os.path.basename(path), "size": len(data)}
    tree = walk(data, style=style)
    style["n_chunks"] = len(tree)

    def _data(e):
        k = e.get("kind")
        if not isinstance(k, dict):
            return {}
        d = k.get("data")
        return d if isinstance(d, dict) else {}

    def _name(e):
        return _data(e).get("name")

    def _ev(e):
        d = _data(e)
        return len(d.get("events") or []) if e.get("leaf") else None

    for e in tree:
        k = e.get("kind")
        if not isinstance(k, dict):
            continue
        if k.get("kind") == "style_info" and e["parent_type"] == 1:
            style.setdefault("infos", []).append(k.get("data", {}))
        if k.get("kind") == "style_info":
            nm = _name(e)
            if nm and nm not in ("", "\x00") and not style.get("name"):
                style["name"] = nm

    kinds = {}
    errs = []
    for e in tree:
        k = e.get("kind")
        if isinstance(k, dict):
            kn = k.get("kind", "?")
            kinds[kn] = kinds.get(kn, 0) + 1
            if k.get("err"):
                errs.append({"off": e["off"], "id": e["id"], "type": e["type"], "err": k["err"]})
        elif e.get("leaf"):
            kinds["unclassified"] = kinds.get("unclassified", 0) + 1
        else:
            kinds[f"branch_t{e['type']}"] = kinds.get(f"branch_t{e['type']}", 0) + 1
        if e.get("error"):
            errs.append({"off": e["off"], "id": e["id"], "err": e["error"]})

    style["kinds"] = kinds
    style["errors"] = errs[:20]
    style["n_errors"] = len(errs)
    style["tree_summary"] = [
        {
            "d": e["depth"], "off": e["off"], "id": e["id"], "t": e["type"],
            "v": e["ver"], "sz": e["size"],
            "k": (e.get("kind") or {}).get("kind") if isinstance(e.get("kind"), dict) else ("branch" if not e.get("leaf") else "?"),
            "name": _name(e) if e.get("leaf") else None,
            "ev": _ev(e),
        }
        for e in tree if e["depth"] <= 2
    ]
    return style


if __name__ == "__main__":
    args = sys.argv[1:]
    if not args:
        args = sorted(glob.glob(os.path.join(os.path.dirname(os.path.abspath(__file__)), "dec_Initpa01_*.bin")))
        args += sorted(glob.glob(os.path.join(os.path.dirname(os.path.abspath(__file__)), "dec_InitPx03_*.bin")))
    all_results = []
    for p in args:
        try:
            s = summarize(p)
            all_results.append(s)
            print(f"\n=== {s['file']} size={s['size']} chunks={s['n_chunks']} name={s.get('name')!r} ===")
            print(f"kinds: {s['kinds']} errors={s['n_errors']}")
            if s["errors"]:
                for e in s["errors"][:6]:
                    print(f"  ERR {e}")
            for t in s["tree_summary"][:20]:
                extra = ""
                if t.get("name"):
                    extra += f" name={t['name']!r}"
                if t.get("ev") is not None:
                    extra += f" ev={t['ev']}"
                print(f"  [{'  ' * t['d']}] @{t['off']:#06x} {t['id']} t={t['t']} v={t['v']} sz={t['sz']} {t['k']}{extra}")
        except Exception:
            print(f"FAIL {p}")
            traceback.print_exc()
    outp = os.path.join(os.path.dirname(os.path.abspath(args[0])), "korf_style_parse_report.json")
    with open(outp, "w", encoding="utf-8") as f:
        json.dump(all_results, f, indent=1, ensure_ascii=False)
    print(f"\nWrote {outp}")
