# PA800 izvoz NEWNAME.SET — pregled

Datum: 2026-10-02. Ulaz: `prism-uploads/NEWNAME.SET.zip`.
Korisnik navodi da je SET izvezen sa njegovog PA800. Original nije mijenjan.

## Rezultat

- Arhiva ima 41 fajl: 1 STY, 2 PCG, 35 PCM, 1 KMP, 1 GBL i 1 VOC.
- `NEWNAME.SET/STYLE/USER01.STY` ima 12.070 bajtova i stil **Modern Ballad**.
- Oba OC31 resursa prolaze dekodiranje i checksum: STYLE ID-06 i STS ID-09.
- Inner STYLE je v4, sa 13 elemenata geometrije ElementInfo28/TrackData80.
- STS slotovi su **Piano**, **Cornet**, **Brass Band**, **Nylon Guitar**.
- Ukupno 16 keyboard traka: 12 native i 4 USER selectora po postojećem parseru.
- Neutralni STYLE/pattern pool i legacy STS model se uspješno čitaju.
- Repack u memoriji daje 34.386 bajtova i nula promijenjenih dekodiranih resursa.
  Nije napisan novi STY niti je repack učitan na instrument: prihvat izlaza nije dokazan.
- SOUND/PCM/MULTISMP/GLOBAL fajlovi su popisani i hashirani, ali njihova semantika
  i međusobne sound/sample veze nisu provjerene ovim STYLE alatom.

## Upozorenje indeksnog parsera

Tolerantni parser prijavljuje jednu razliku dužine na ID-09 offsetu 11091:
deklarisani payload je 939 bajtova, a indeksni raspon je 947 bajtova.
Razlika je tačno završni osmobajtni FE header
`fe 00 00 18 00 00 00 18`, koji indeksni parser priključuje prethodnom resursu.
Nezavisni strogi parser deklarisanih dužina uspješno parsira cijeli native fajl.
Ovo konkretno upozorenje nije dokaz oštećenja korisnikovog izvoza.

## Šta korisnik radi sljedeće

Ovaj ZIP čuvati netaknut kao **BASELINE**. Ne mijenjati originalne fajlove na računaru.
Sačuvati dva nova izvoza u odvojene foldere, bez prepisivanja postojećeg SET-a:

1. Učitati isti sačuvani stil i ponovo ga sačuvati bez izmjena.
   Poslati kao `BASELINE_REPEAT.SET.zip`.
2. Vratiti početno stanje, izabrati **Modern Ballad**, **STS 1 / Piano**, **Upper1**.
   Promijeniti samo factory zvuk Upper1 na drugi factory zvuk; zapisati izmijenjeni
   STS i sačuvati SET kao `ONE_CHANGE.SET.zip`. Ne mijenjati volume, pan, FX,
   druge trake, naziv stila niti njegovo mjesto u banci.
3. Uz ZIP-ove napisati PA800 OS verziju i tačan naziv zvuka prije i poslije izmjene.
   Ako su dostupni, navesti bank/program brojeve, bez nagađanja njihovog numerisanja.

Trenutni parser čita STS 1 / Upper1 kao native MSB 121, LSB 0, program 25
(sirova vrijednost, ne automatski broj prikazan na instrumentu); volume je 110.
Naziv zvuka treba potvrditi na instrumentu, ne izvoditi ga iz STS naziva Piano.

Ovaj isti-model eksperiment može potvrditi baseline stabilnost i promijenjena
legacy polja. Ne može sam dokazati PA800↔novija generacija selector remap.
Za to ostaje potreban kontrolisani međumodelski par istog STYLE/STS-a.
Faza 3 zato ostaje otvorena, ali imamo prvi korisnikov hardverski baseline kandidat.

## Reprodukcija

```bash
PYTHONDONTWRITEBYTECODE=1 python3 prism-uploads/analysis/pa800_hardware_export_review.py
```

Skripta samo čita arhivu i ispisuje JSON. Ne izvršava kod iz arhive i ne raspakuje je.
Detaljni podaci su u `pa800-hardware-export-review.json`.