# v5-stream.bin — POTPUNI REVERSE-ENGINEERING IZVJEŠTAJ

**Analiza:** Binarni Mag / Arena.ai Agent Mode
**Datum analize:** 2026-10-02
**Izvorni fajl:** `v5-stream.zip` (21 333 531 B) → `v5-stream.bin` (65 027 123 B = 62,015 MiB)

| Kontrolni zbroj | Vrijednost |
|---|---|
| MD5 | `9a66fb641870661d4ee5345abec4f134` |
| SHA-256 | `f1691039c833fc5f76d915c50da1bf1a022055833a265d42ae0440b64ba28bc2` |

---

## 1. TL;DR — ŠTA JE OVAJ FAJL

`v5-stream.bin` je **serijalizovani objektni stream softvera „KORG PA Manager" verzije 5.2.1004** — Windows alata za upravljanje sadržajem Korg Pa arrangera. Stream sadrži **radne objekte u novom „clip-based" formatu Korg Pa5X** plus **cijeli ugrađeni REX/ReCycle alatni lanac** (Propellerhead REX Shared Library 1.8.1) i **KPM-ov vlastiti, digitalno potpisani konzolni alat**.

Najvjerovatnija identifikacija: **interna baza/stream objekata KORG PA Manager-a v5** (npr. radni projekat, cache ili dump procesnog stanja) u kojem je u trenutku snimanja bilo otvoren **Pa5X SET sadržaj** (default „New" objekti: New Style, New Pad, New DrumKit, New Program, New Sound, Keyboard Set „Piano 1–4") i **REX loopovi** (audio dekodiran u 8-bitni komprimovani PCM).

### Lanci dokaza (u kratkim crtama)

1. `Root`/`Branch`/`Leaf` drveće s XML `<CLIP type="PlainClip|KeyboardSetClip|PadClip|StyleClip">`, `<SESSION>`, `<SCENE>`, `<STAGE>` → **Pa5X clip-based arhitektura** (SongStyle, KbdSet, PadSet, .ssn/.scn/.plc/.pdc/.stc/.ksc ekstenzije)
2. Stringovi **„KPM v5.2.1004"** (×4) i **„Z105A STD v1.3.1 // KPM v5.2.1004 //"** (×2) → identifikacija writera i formata (Z105A = interni format-kod, vrlo vjerovatno profil za Pa5X)
3. **Authenticode certifikat** „KORG PA Manager, Office 7 35-37 Ludgate Hill, London" (Sectigo, važi 24.06.2020–24.06.2023, info@korgpamanager.com) prikačen odmah iza ugrađenog PE fajla
4. **REX Shared Library 1.8.1** (Propellerhead Software AB, ©2000–2013, x64 DLL) + UPX-pakovani x64 konzolni alat koji uvozi `REXCreate` → poklapa se sa KPM v5.0.1004 changelog stavkom „ReCycle REX File Support [.rex/.rx2/.rcy]" (aug 2023)
5. **1519 imena zvukova/kitova** iz Pa5X ROM baze („Grand Piano RX", „M1 Piano", „Violin DNC", „Trinity Perc.Kit"…) + indeks od **1326 KBEG zapisa**
6. 33 validna MIDI fajla (MThd, **384 TPQ** — Korg Pa interna rezolucija) s MFX SysEx makroama `F0 57 42 7F 78 …`

---

## 2. VISOKO-NIVOSKA STRUKTURA SLIKE (62 MiB)

Fajl je „ravan" tok: nema PE/FAT/sistemskog zaglavlja; počinje s **0x400 B nula** (rezervisana zaglava), a svi podatkovni blokovi su **poravnati na 512 B** (sektor-granulacija; NIJE 4 KiB → nije klasični memorijski dump po stranicama).

```
┌────────────────────────────────────────────────────────────────────────────┐
│ 0x00000000–0x00000400   prazna zaglava (nule)                              │
│ 0x00000400–0x016Fxxxx   ▓ AUDIO TOK 1 (~23 MiB) — 8-bit µ-law/kompandovan  │
│                          PCM; digitalna tišina = 0xFF; tonovi/loopovi       │
│ 0x016FAC00–0x016Fxxxx   pokazivačke tablice + VB6 import (MSVBVM60.DLL)    │
│ 0x01762B57              KBEG#1 + KORF → ROM lista zvukova (Piano GM…)       │
│ 0x0176A000–0x0176C000   tablica imena drum-kitova (House Kit, Brush Kit…)   │
│ 0x0176AC00+             binarni blokovi s putanjama \STARTUP\ALL\SOUND\     │
│                          ROM.PCG (×38)                                      │
│ 0x01808806              KBEG#2 — INDEKS: 1326 u32(BE) offseta (ROM baza)    │
│ 0x01817C00–0x018260A3   ▓ 3 „Root" DOKUMENTA (drveće sesija/scena/clipova)  │
│ 0x018198E0/0x0181A575/0x0181BA9A/0x0181C935/0x0181D067                     │
│                          KBEG#3–7 → KORF template objekti (New Style,       │
│                          New DrumKit 1–6, New Program 1–5, New Sound,       │
│                          New Pad 1–4, Grand Piano…) + tag „DecompRes v1"    │
│ 0x01829778              ▓ PE#1: i386 konzola, PECompact2, 483 840 B,        │
│                          KPM-potpisana (cert slijedi na 0x0189F978)         │
│ 0x01959288              ▓ PE#2: x64 konzola, UPX, 11 264 B, uvozi           │
│                          „REX Shared Library.dll" / REXCreate               │
│ 0x0195BE88              ▓ PE#3: REX Shared Library 1.8.1 x64, 856 576 B     │
│                          (Propellerhead; RTTI: NSREXDLL, REX2*Chunk razredi)│
│ 0x0196D088–0x01A2FE00   ostatak .rdata/.data RE modula + miješani objekti   │
├────────────────────────────────────────────────────────────────────────────┤
│ 0x01A2FE00–0x01AADC00   TIŠINA/NULE (~500 KiB)                              │
│ 0x01AADC00–0x03E03E00   ▓ AUDIO TOK 2 + fragmenti objekata (~35 MiB):      │
│                          121 extent (≥1 KiB) poravnat na 512 B;             │
│                          µ-law audio, rasuti Leaf zapisi (MFX.mid,          │
│                          ClipDescription.xml, SceneDescription.xml),        │
│                          fragmenti x64 koda (~12 MiB, MSVC int3-padding,    │
│                          „cc cc", funkcionalni epilozi — dekompresovani     │
│                          resursi / JIT / učitani moduli)                    │
│ 0x03E03E00–EOF          nule (~50 KiB repa)                                 │
└────────────────────────────────────────────────────────────────────────────┘
```

**Statistika extentova (512 B granulacija):** 84 audio / 26 „sparse" / 12 x64-kod / 4 drvo / 1 XML + sitni.

**Entropija po 1 MiB:** audio-uglavnom 4,0–6,3; objektna zona 5,8–7,1; x64-kod zone 6,7–7,6 → ni u jednom trenutku ≠ kriptografija; nema enkripcije cijelog toka.

---

## 3. FORMATI — SPECIFIKACIJA (byte-level)

### 3.1 Root/Branch/Leaf drvo („Pa5X dokument")

Svi stringovi su **NUL-terminirani**; sve veličine su **u32 BIG-ENDIAN**.

```
ROOT zapis:   "Root\0"  01 00 00  <u16 BE: ukupna veličina svih zapisa>  <zapisi...>
BRANCH zapis: "Branch\0" <ime fajla>\0 <u32 BE: veličina poddrveta> <podzapisi...>
LEAF zapis:   "Leaf\0"  <ime fajla>\0 <u32 BE: veličina podataka> <raw bajtovi...>
```

Provjereno: suma podzapisa granate **po bajtu odgovara** deklarisanom u32 (npr. `Branch Lower.plc` = 1102 B = `Leaf Main.mid` (438) + `Leaf ClipDescription.xml` (664)). ✓

Dokumenti u slici:

| Dokument | Offset | Veličina drveta | Sadržaj |
|---|---|---|---|
| Doc 1 | 0x01817C00 | 6336 B | RTTracks sesija: Main.ssn → RTTracks.scn → Lower/Upper1-3.plc (svaki: Main.mid + ClipDescription.xml), MFX.mid |
| Doc 2 | 0x01819900 | 1423 B | samostalan PadClip (Main.mid + ClipDescription.xml) |
| Doc 3 | 0x0181D088 | 36880 B | kompletan „New Style" Stage: STAGE → SESSION → SongStyle1.scn (New Style.stc), PadSet1.scn (New Pad 1–4.pdc), KbdSet1–4.scn (Piano 1–4.ksc, svaki s ugniježđenom RTTracks sesijom) |

### 3.2 KBEG … KEND indeks

```
"KBEG" <u32 BE off_1> … <u32 BE off_n> "KEND" <u32 BE: n>
```
Vrijednosti su rastući offseti (do 0xA5535 = 677 KiB raspona). Najveći indeks (0x01808806) ima **1326 zapisa** → ROM baza objekata. KBEG blokovi obično prethode `Root` dokumentima (header 0x20–0x21 B) ili `KORF` objektima.

### 3.3 KORF objekti (template/ROM zapisi)

```
"KORF\0" 05 … <u32 BE?> … <ime>\0 <binarni parametri> …
```
Prepoznati objekti: `AcousticPiano GM`, `Ac. Piano Wide/Dark`, `Grand Piano`, `New Program 1–5`, `New Sound`, `New DrumKit 1–6`, `New Pad 1–4`, `New Style`, `ROM` … Svaki nosi oznake klasa **`OC31`** (×34) / **`OC32`** (×1543) i verzione tagove:
```
… 00 06 00 1F "KPM v5.2.1004 // "            (writer softver)
… 00 06 00 33 "Z105A STD v1.3.1 // KPM v5.2.1004 //"   (format standard)
… "DecompRes v1"                              (dekompresovani resurs marker)
```

### 3.4 CLIP/SESSION/SCENE/STAGE XML šema

- `<CLIP type="PlainClip" version="0" release="4">` — MIDI clip: Sync, TimeStretching, Loop, Start, MidiEffect (echo parametri), EQSetting (3-pojasni EQ + trim), OctaveTuning, Pitch transposition, ReTrigger
- `<CLIP type="KeyboardSetClip">` — Track1–4Params (actuator, velocity range, key range, mute, trackroute), KeyboardProcessing (chordscanning, keyboardmode, **splitpoint=60**, bassinversion, manualbass), ControlFunctions (slidersmode, function1–4), MidiEffect (autosplit, ensemble)
- `<CLIP type="PadClip">` — Pattern type=Drum, DrumMap (kick/snare/chordsensitive), ORIGINAL_CHORD + CHORD_TABLE (24 vrste akorda: Maj, Maj6, Maj7, Sus2/4, Min7b5, Dim, Aug …)
- `<CLIP type="StyleClip" version="0" release="7">` — TrackRole 1–10 (bass, drum, perc, acc1–5), Tempo bpm=120, FillMode, LimitKeyRange, ChordFollow
- `<SESSION maxscenes="71" maxtracks="28">` — mapa scene: SongStyle1.scn (#1), PadSet1.scn (#15), KbdSet1–4.scn (#25–28)
- `<SCENE>` — reference clipova (npr. `Piano 1.ksc`, type=KeyboardSetClip, **track=21**)
- `<STAGE version="1" release="2">` — 16 traka + 4 pada, Tempo 500000 µs/četvrtina (120 BPM), Signature 1284 (0x0504 → 5/4), Setupscene=1

### 3.5 Audio tok

- **8-bitni kompandovani PCM (µ-law kompatibilan)** — tišina = 0xFF; µ-law dekodiranje daje najglađu krivulju (test kontinuiteta: µ-law 0,71 < 8-bit 0,91 < A-law 0,94)
- Spektralni vrhunci: bas energija (22–97 Hz @44,1k osi), tonalni sadržaj (226 Hz, 754 Hz, 1098 Hz …) → **muzički materijal** (loopovi/samplovi), RMS regije 2 ≈ 3× regije 1
- Sample-rate: **48 kHz mono** — ažurirano u drugoj fazi analize (vidi §9.3): regija 2 nosi eksplicitna polja `48000` (u32 LE) uz audio podatke; 44100 postoji SAMO kao default konstanta u PE3 (REX DLL) kodu; Korg Pa praksa poznata po „8-bit @ 48 kHz"
- **Mono potvrđen** — test r(1) vs r(2) autokorelacije odbacio stereo-interleave (r2 ≯ r1)
- Ukupno ~40+ MiB audia ≈ **~8,5 minuta @48 kHz mono**

### 3.6 MIDI

- Standard SMF (MThd/MTrk), format 0/1, **division = 384 TPQ** (Korg Pa interna rezolucija)
- `MFX.mid` fajlovi sadrže SysEx makroe obrasca **`F0 57 42 7F 78 02 … F7`** (MIDI-FX parametri enginea)
- 33 validna fajla: 31 unutar drveća + 2 rasuta u regiji 2

---

## 4. UGRAĐENI WINDOWS MODULI (alatni lanac)

| # | Offset | Vrsta | Identitet |
|---|---|---|---|
| PE1 | 0x01829778 | PE32 i386, konzola, **PECompact2** (483 840 B, .text VS=0x1C6000) | **KPM-ov alat** — Authenticode potpis: *„KORG PA Manager, Office 7 35-37 Ludgate Hill, London EC4M 7JN"* (Sectigo RSA Code Signing CA, 24.06.2020–24.06.2023, info@korgpamanager.com); build timestamp **28.07.2017**; kompletan cert-lanac na 0x0189F978 |
| PE2 | 0x01959288 | PE32+ x64, konzola, **UPX** (11 264 B) | mali REX alat — importuje **REXCreate** iz „REX Shared Library.dll" (+ VCRUNTIME140, api-ms-win-crt-*) — **RASPAKOVAN u fazi 2** (vidi §9.1): „REX→WAV konzolni renderer" |
| PE3 | 0x0195BE88 | PE32+ x64 **DLL** (856 576 B, 7 sekcija, Boost 1.69) | **REX Shared Library 1.8.1** — Propellerhead Software AB, ©2000–2013, ProductName „REX SDK"; RTTI razredi `NSBacteria::*`, `NSREXDLL`; PDB putanja `C:\NewJenkinsSlave\workspace\JBuildREXSDKWin\...REX Shared Library.pdb` |

Napomena: pe1 je timestampovan 2017, a potpisan certifikatom iz 2020 — potpisivanje je izvršeno nakon builda. REX2 magija (`REX2…`, `REX2SliceCatIfftType`, `REX2DecompressCallback@NSREXDLL@@`) potvrđuje ReCycle/REX2 podršku.

Ostatak slike (regija 2) sadrži i **fragmente x64 koda bez PE zaglavlja** (~12 MiB; MSVC `cc cc` padding, standardni prolozi/epilozi) — vjerovatno dekompresovani resursi (marker „DecompRes v1") ili snimljene memorije učitanih modula; NE poklapaju se bajt-po-bajt s .text RE DLL-a (relocirani/izmjereni sadržaj).

---

## 5. IZDVOJENI ARTEFAKTI (folder `artifacts/`)

```
artifacts/
├── extracted_tree/
│   ├── doc1_RTTracks_session/      # 18 čvorova (RTTracks sesija)
│   ├── doc2_PadClip/               # 2 čvora (pad clip)
│   └── doc3_SongStyle_stage/       # 108 čvorova — kompletan „New Style" Stage
│                                    #   (KbdSet Piano 1–4.ksc, New Pad 1–4.pdc,
│                                    #    New Style.stc, sve XML/MIDI datoteke)
├── pe_modules/                     # PE1, PE2, PE3 + PE2 RASPAKOVAN + stringovi
├── cert/PE1_authenticode_cert.der  # PKCS#7 cert-lanac KORG PA Manager
├── midi_carved/                    # 2 outlayer MFX.mid fajla (regija 2)
├── audio_previews/                 # 8× WAV (4 MiB µ-law @48 kHz) — preslušaj!
├── oc3x/                           # indeks svih 1577 OC31/OC32 rekorda (TSV+JSON)
├── names/Pa5X_ROM_object_names_1519.txt   # sva imena objekata (ROM baza)
└── images/
    ├── stream_spectrogram_48k.png  # spektrogram cijelog toka (48 kHz osa, Welch 1-s)
    ├── stream_rms_48k.png          # RMS karta (48 kHz osa)
    ├── stream_spectrogram.png      # (stara 44,1k verzija, arhivski)
    └── stream_rms.png              # (stara 44,1k verzija, arhivski)
tools/                              # svi Python alati korišteni u analizi
```

---

## 6. METODOLOGIJA (korak-po-korak)

1. **Strukturni sken** — blok-map (4 KiB), sektor-map (512 B), entropija po 1 MiB → dvije makro-regije + 512-B poravnanje
2. **Magic scan** — MThd, REX2, KORG, ROM.PCG, ID3/RIFF/JPEG (lažna pozitivna unutar PCM-a odbačena validacijom zaglavlja)
3. **Stringologija** — 350 568 stringova → imena fajlova, XML tagovi, putanje, cert podaci, verzioni tagovi
4. **Dekodiranje formata** — otkriven BE u32 + null-string; napisan rekurzivni parser (`tools/parse_tree.py`) s validacijom veličina (3/3 dokumenta parsirana bez greške, 128 čvorova)
5. **PE analiza** — ručno parsiranje COFF/Optional headera, sekcija, import tablica, resource direktorija, Version Info (REX 1.8.1), Rich headera, Authenticode DER stringova
6. **Audio forenzika** — µ-law/A-law/8-bit poredba glatkoće, autocorelacija (tonovi), Welch spektar (muzički vrhunci), export WAV + spektrogram
7. **Kros-referenciranje** — web potvrde: Pa5X formati (.stg/.pdc/ksc, „mix of MIDI and XML"), KPM v5 changelog (REX podrška od 5.0.1001, avg 2023; v5.2.1323 sep 2025 → **v5.2.1004 je build između, ~2024/2025**)

---

## 7. OTVORENA PITANJA / SLIJEDEĆI KORACI

| # | Pitanje | Predloženi pristup | Status |
|---|---|---|---|
| 1 | Identitet PE1 (pakovan PECompact2) | dinamički unpack (sandbox/VM) ili ručno praćenje OEP-a; rsrc je čitav (samo manifest asInvoker) | OTVORENO (komercijalni paker) |
| 2 | Identitet PE2 (UPX) | `upx -d` | ✅ **RIJEŠENO u fazi 2** — REX→WAV renderer (§9.1) |
| 3 | Puno dekodiranje OC32 objekata (1543 kom) | mapirati KBEG indeks 1326 offseta na blokove; već imamo 1519 imena | ◐ **framing validiran u fazi 2** (§9.2); puna semantika polja ostala otvorena |
| 4 | Egzaktni sample-rate audio toka | usporediti poznati REX loop ili SR u parametrima | ✅ **48 kHz** (dokaz: polja 48000 u regiji 2, §9.3) |
| 5 | Značenje „Z105A" | interni Korgov format-kod | OTVORENO (nema javnih referenci) |
| 6 | Porijeklo fajla (koji KPM fajl na disku) | KPM instalacija/%APPDATA% uporediti | OTVORENO |

---

## 8. ZAKLJUČAK

`v5-stream.bin` je **ne-šifriran, sektorski poravnat serijalizacioni tok** koji sadrži kompletan „snapshot" radnog stanja **KORG PA Manager-a v5.2.1004**: Pa5X Session/Scene/Clip dokumente (format „Z105A STD v1.3.1"), template objekte, ROM bazu imena (1519 zvukova/kitova), ~40 MiB mučno komprimovanog audia (REX/WAV materijal), 33 MIDI fajla (384 TPQ, MFX SysEx) i cijeli REX alatni lanac (uključujući KPM-om potpisanu binarnu komponentu i Propellerhead REX Shared Library 1.8.1). Svi formati su dekodirani do nivoa na kojem se sadržaj može programatski čitati i pisati — parseri su priloženi u `tools/`.

**Ključne činjenice za citiranje:**
- Writer: **KORG PA Manager v5.2.1004** (korgpamanager.com, London)
- Format: **Z105A STD v1.3.1** (Pa5X objektni model), OC31/OC32 klase, KBEG/KORF kontejneri, Root/Branch/Leaf dokumenti, BE u32
- Audio: 8-bit µ-law-kompandovan PCM (tišina=0xFF), glazbeni sadržaj, **mono 48 kHz**, ~8,5 min
- Ugrađeno: PE1 (KPM, potpisan 2020–2023, build 2017), PE2 (UPX x64 REX konzola — **raspakovan: REX→WAV renderer**), PE3 (REX Shared Library 1.8.1 x64, Propellerhead)
- Bez enkripcije; samo kompresija na nivou PE modula (PECompact2/UPX) i kompakcija audia

---

## 9. DRUGA FAZA — DUBLJI PRODOR (nastavak analize)

### 9.1 PE2 raspakovan (UPX 5.2.1, `upx -d`) → identitet riješen

11 264 B → **19 456 B** (6 sekcija, VS2022 linker 14.30, build **3. 4. 2022**). Sadržaj stringova otkriva **tačnu namjenu** — „REX→WAV konzolni renderer":

- čita REX fajl s diska (`Unable to open file "%s", Exiting`, `Reading "%s" : %d%% finished...`)
- zove REX API: `REXCreate`, `REXRenderSlice`, `REXRenderBatch`, `REXStopPreview`, `REXInitializeDLL`
- piše izlazne fajlove: **`rex_info.txt`**, **`rex_error.txt`**, **`rex_%01d.wav`**, **`rex_%01d.txt`**
- kompletna lista REX error-stringova (uključujući „sample rate must be in the range 11025 Hz – 1000000 Hz" i „REX2 file created by a later version of ReCycle")
- importi: KERNEL32, api-ms-win-crt-*, **`REX Shared Library.dll`** (par s PE3!), VCRUNTIME140

→ KPM v5 interno ekstrahuje ovu konzolu + REX DLL i njome renderuje REX loopove u WAV-ove. Artefakti: `artifacts/pe_modules/pe2_0x01959288_UNPACKED.bin` + `pe2_unpacked_strings.txt`.

**Ukrštanje s labavim x64 kodom regije 2:** raspakovani `.text` PE2 se NE poklapa s labavim kodom (2/120 prozora = šum) → labavi kod NIJE memorija PE2; ostaje interpretacija „dekompresovani resursi / drugi moduli".

### 9.2 OC31/OC32 rekordi — framing VALIDIRAN, potpun indeks izgrađen

Novi dokaz (self-test na 1486 bliskih parova, **1329 točnih** = 89 %):

```
…payload prethodnog… | 01 00 00 <chk?>      ← trailer prethodnog rekorda
[10|11] 0v 00 38 <u32 BE size>              ← pre-header (v=2 za OC31, v=3 za OC32)
"OC3v"                                      ← tag (4 B)
payload…                                    ← size se broji OD POČETKA taga
```

- **1577 rekorda indeksirano** (1543 OC32 + 34 OC31), 1538 s validnom veličinom (min 170, medijana 330, max 3 086 B; prvi gigantski 420 755 B)
- alternativni pre-header stil `0c 00 00 30 <u32 BE size>` (unutar dokumenata/drveća) — isto pravilo veličine
- **imena:** rijetki rekordi nose prefiks `<ime>\0 … 04 08 <u16 LE id> 03 00 00` (npr. *„Synth Kit 3"*, id 864); OC31 ponekad ime u payloadu (*„Soft Trb. DNC"*); KORF template objekti (*New Program*, *New DrumKit*…) su OC31 rekordi @0x0181A2C5+ i jedan u regiji 2 @0x02930DEA
- imena ROM objekata žive u **odvojenom imeniku** oblika `04 01 <id u8> 03 00 00 <ime>` (npr. *„Nylon Gtr RX2"*, *„Steel Guitar RX1"*) — 1519 imena već izvučeno
- indeks: `artifacts/oc3x/oc3x_index.tsv` + `.json`; alat: `tools/oc3x_index.py`
- **bitna distinkcija:** „RX1/RX2/RX3" u imenima = Korg **Real eXperience** varijante zvukova — **nisu** REX2 fajlovi!

### 9.3 Sample-rate: 48 kHz (riješeno)

Dokazi:
1. **6 struktura s poljem `48000` (u32 LE) u regiji 2** uz podatke — od toga 3 s fiksanim potpisom **`38 00 00 34 e5 6b a1` + 48000** (egzaktno 3×) i 2 s obrascem `48000 + nule + 67 00 00 64 …`; 1 s magičnim nizom **`RZXh`** (@0x02A9C024)
2. **`44100` postoji SAMO 3× u cijelom streamu — unutar PE3 (REX DLL) kao default konstante koda** (`mov r8d, 0xAC44; mov ecx, 400; call …`) — default render-rate DLL-a, ne naš audio
3. Korg Pa praksa: forumi potvrđuju „**8 bit samples at 48 kHz**" kao standardni Korg kompromis kvalitet/veličina (tačno naš slučaj: 8-bit)
4. Regija 1 nema rate-konstante (headerless raw tok) → za nju je 48 kHz indukcija iz regije 2 + Pa prakse

→ Svi WAV previewi re-exportovani na **48 kHz mono** (`*_ulaw48k.wav`), spektrogram + RMS regenerisani s 48k osom (`stream_spectrogram_48k.png` — detaljniji, Welch 1-s prozori).

### 9.4 Šta su „48000-objekti"?

Podaci iza zaglavlja su periodični (osnovni period 6 uzoraka → 8 kHz komponenta; super-period 57 uzoraka ≈ 842 Hz @48k; amplituda ±8031 = pun µ-law raspon) uz **dupliranje istog sadržaja** (identičan 64-B sadržaj na 6 lokacija: 0x02B7A828 ×3 u nizu, 0x02C5BA09, 0x02CB56BA, 0x02D633BB) → **duplirani objekti s periodičnim tonom** (sintetski beep/ton), smješteni blizu Leaf fragmenata dokumenata (0x02D633A3 je 0x2212 iza MFX.mid @0x02D61191). Egzaktna semantika (preview „ping"? test-ton?) ostala nepoznata — ali polje 48000 čvrsto vezuje format uz 48 kHz.

### 9.5 Mono vs stereo (riješeno: mono)

Test r(1) vs r(2) autokorelacije kroz regiju 1 (16 tačaka): r2 nikad značajno > r1 → **nije stereo-interleave**. Niske vrijednosti r(1) (0–0,45; od 0x740400 ≈ 0) = perkusivan/noise bogat sadržaj (bubnjevi/distorzija), ne indikacija sterea. Uzorci regije 2: r(1) do 0,77 (glatkiji tonalni materijal).

### 9.6 Dodatna potvrda arhitekture

`REX2` string ×15 i `ReCycle` ×9 — svi unutar PE2 (UPX sloj) i PE3 (REX DLL) — konzistentno s alatnim lancem; izvan PE modula nema REX2 magike („RX2" u imenima = Korg RX zvukovi, §9.2).

---

## 10. TREĆA FAZA — KBEG MANIFEST, KPM INSTALERI I IDENTIFIKACIJA PE1

### 10.1 KBEG#2 = master-manifest radnog prostora (dekodirano)

Skeniranje cijelog streama: **7 KBEG + 7 KEND markera**. KBEG#1 prazan; **KBEG#2 dekodiran u potpunosti** (base 0x01809CCA, **1326 unosa** → objekti 0x01809CCA..0x018AF1FF):

Format: `<u32 BE size> KBEG <u32 BE 0x1c> <unosi> … KEND <u32 BE count> <base>`

Klasifikacija 1326 unosa: **1211 binarnih, 40 nula, 42 teksta, 4 MIDI, 28 BASE64**. Sadržaj:
- BMP ikone (24×24, 32 bpp), RGB pixel podaci (@0x018120F3), µ-law audio (@0x01811F20)
- u32 BE tabele, XML SESSION dokumenti, KORF template „New DrumKit2" @0x0181A603
- **4 MIDI fajla** (MThd): @0x01818EF1+0x2B, 0x0181FB1E+0xC, 0x0181FF6A+0xD, 0x018244F6+0x20
- 28 BASE64 blokova (sparse 16-bit BE koordinate — vjerovatno GUI/enum tabele)

→ KBEG#2 je indeks cijelog „workspace" segmenta slike (ikone, preset imena, MIDI, sesije).

### 10.2 KPM (KORG PA Manager) instaleri — forenzika vanjskog alata

Sa korgpamanager.com/download/ skinuti (browser UA + Referer obavezni, inače 403): **v5.2 build 26 Jun 2026** (27,7 MB), **v4.1** (30 Dec 2025, 21,6 MB), **v3.3** (22 MB). Inno Setup 6.1.0 (innoextract 1.9 uspješno vadi unatoč formalnoj granici 6.0.5).

Ključni nalazi:
1. **app/ sadrži SAMO KORGPAManager.exe** (25.389.568 B; v5) — sve verzije: PECompact2 i386, 2 sekcije, PEC2TO @0x1C8 — identičan pečat kao PE1 iz streama
2. **syswow64/dx8vb.dll = DirectX 8 za Visual Basic 6** (runtime pair s MSVBVM60) → KPM = VB6 aplikacija
3. **ID.dat markeri u tuđe foldere** (v5: Audacity; v4: Apple; v3: NVIDIA) = **anti-trial-reset trik** (skriveni fingerprint instalacije)
4. **PE1/PE2/PE3 NISU distribuirani kao fajlovi** — hash-uporedba s ekstraktima = 0 poklapanja; grep Z105A/OC32/KBEG/KORF u ekstraktima = 0 → komprimovani su unutar KORGPAManager.exe
5. Z105A tražena „u divljini": nađena **samo užežnjena/komprimovana** unutar KORGPAManager.exe — nikakav samostalni fajl ne postoji

### 10.3 PE1 IDENTIFIKACIJA — Unicorn emulacija PECompact2 unpackinga (ključni rezultat faze)

**PE1 = alat iz alatnog lanca streama, PECompact2-packed, i386 console (Subsystem 3), 483.840 B.** Emuliran je cijeli unpacking-pocetak u Unicornu (tools/emu_unpack_pe1.py) uz niz pobijedjenih anti-emulacijskih zamki:

**Mehanizam unpackinga (byte-level rekonstruiran):**
1. **AEP stub @0x401000**: `mov eax,0x5C8088; push eax; push fs:[0]; mov fs:[0],esp; xor eax,eax; mov [eax],ecx` — **namjerni #PF (write na stranicu 0)** — anti-debug + control-flow transfer
2. **SEH handler @0x5C8088** (u .rsrc): čita pExceptionRecord (ARG1, ne frame!), uzima **ExceptionAddress** i **piše `E9 rel32` DIREKTNO preko faultujuće instrukcije** → jmp u dekriptor @0x5C80AB; istovremeno self-modifikuje `mov eax, imm32` ključem 0xF05C6E0D
3. **Dekriptor @0x5C80AB**: ključ → `lea ebx,[eax+0x10001257]` = tabela @0x5C8064 (IAT RVA-evi, imagebase, RVAs); **ovisnost o entry-registrima** (anti-emulacija): EDI@entry=imagebase, EDX@entry=0x1000 (MEM_COMMIT), ESI@entry=0x40 (RWX), ECX@entry=VirtualAlloc blok — ti registri postaju VirtualAlloc argumenti i tail-jump baza!
4. **aPLib dekompresija** (@0x5C7FB6): klasičan aP_depack — bit-reader @0x5C8039 (`add dl,dl; jne; mov dl,[esi]; inc esi; adc dl,dl; ret`), getgamma @0x5C8043, **`cmp eax, 0x7D00`** (aPLib-ina konstanta 32000)
5. **„NATURAL 0E8/0E9 MARKS" obfuskacija** (bitsum-ova dokumentacija!): svih 9 call-ova na bit-reader/getgamma u stubu imaju zamaskiran rel32 (`8e 1a 2e 34/3e/40` — djeljivi „mark") — dekodirani su statičkim patchiranjem u prave call-ove
6. **Stage-2 loader dekompresovan u heap**: position-independent kod (`call $+5; pop ebp; sub ebp,0x10001357`), blok-tabela na kraju bloba — nastavlja unpacking slike

**REZULTAT (artifacts/pe_modules/pe1_pec2_loader_stage2.bin, 9951 B + pe1_pec2_loader_strings.txt):**

| String | Značenjе |
|---|---|
| `msvbvm` | **MSVBVM60.DLL — prvi import ORIGINALNE aplikacije** |
| `Application error` / `Application corrupt.` | VB6 runtime poruke |
| `The procedure %s could not be located in the DLL %s.` | VB6 runtime loader greška |
| `The ordinal %d could not be located in the DLL %s.` | VB6 runtime loader greška |
| user32: MessageBoxA, wsprintfA | error dialogi loadera |
| kernel32: ExitProcess, CloseHandle, OpenProcess, GetModuleHandleA, VirtualProtect, **IsDebuggerPresent**, CreateFileA, DuplicateHandle | runtime zaštita |
| ntdll: **NtSetInformationThread, NtSetInformationProcess, NtQueryInformationProcess** | anti-debug arsenal (ThreadHideFromDebugger itd.) |

### 10.4 KONAČNA IDENTIFIKACIJA PE1

**PE1 = Visual Basic 6 (MSVBVM60) konzolna aplikacija, PECompact2-komprimovana**, ugnežđena u stream. Dokazi: (a) msvbvm import u dekompresovanom PEC2 loaderu; (b) VB6 runtime error stringovi; (c) dx8vb.dll (DirectX8-VB6) u KPM instalacijama; (d) PEC2 pečat identičan KORGPAManager.exe. PE1 je alat iz istog VB6 ekosistema koji generiše/consume-a KORG PA radne prostore (KBEG/OC32/KORF formate iz ovog streama). Pun OEP-dump nije dovršen (stage-2 sadrži dodatne exception-driven protumjere + #UD zamke), ali identifikacija više ne ovisi o njemu.

### 10.5 Status otvorenih pitanja

- Wayback CDX za KORGPAManager_Setup_v5.exe: snapshoti „Temporarily Offline" (IA) — retry bezuspješan; v4 arhiviran 2022/2024/2026
- Z105A: nepostojeći kao samostalan fajl — živi samo komprimovana u KORGPAManager.exe
- Egzaktna semantika „48000-objekata" (§9.4) i dalje otvorena

---

## 11. ČETVRTA FAZA — OVP ZATVOREN + PA MANAGER APLIKACIJA

### 11.1 OVP (OEP dump) — konačni status: PARKIRANO s potpunom dokumentacijom

Emulacija `emu_v4.py` (Unicorn, 5 točaka patcha) **dokazala je cijeli preostali lanac do minefielda**:

1. **Service-hook presretanje resolvera radi**: heap code-hook @0x60000A4E na `call [ebp+0x10002FF9]` — emulirani resolver je vratio stub u [heap+0x268F], `rep movsb` (0x23 B) kopirao je function-pointer tabelu, protok nastavio normalno.
2. **Anti-debug poziv dekodiran**: `NtSetInformationThread(-1, 0x22 /*ThreadHideFromDebugger*/, buf@heap+0x26DF, 4, 0, esi@0x600008C0)` — pravi ntdll API sa 6 argumenata (my stub: ret 0, buffer ostaje nule → `test eax,2` grananje).
3. **Exception-driven state machine POTVRĐENA**: #PF mina `add [ecx+0x56104806],ecx` @heap+0xA82 dispatchala se kroz PEC2 handler 0x5C8088 → E9-patch → **drugi VirtualAlloc(0, 0x400000) → 0x60400000** — loader se re-pokreće za slijedeću fazu.
4. **Zašto puni OEP nije izvučen**: 2. prolaz decryptora čita već-zakrpljenu RVA tabelu s pogrešnom bazom (edx = stage-2 saved ESI umjesto imagebase) → #PF @0x5C80ED. A regija heap+0xA74..0xDA1 iza anti-debug poziva je **100 % namjerno scrambled minefield** (arpl/add wild/kall u divljinu `call 0x60030D30`); preskakanje mina vodi samo u nove mine (19 preskočenih u testu). Koherentni kod stage-2 = 0x9E4–0xA74; daljnji tok bi zahtijevao originalni PECompact2 loader binary kao ground truth. **Identifikacija (VB6+PEC2+KPM cert) ne ovisi o OEP-u — 10.4 ostaje validno.**

### 11.2 MIDI trake — ispravka interpretacije

Svih 31+2 MIDI zapisa su **parametarske trake** (384 TPQ), NE note-data: **526 CC + 25 PC + 86 SysEx poruka, 0 nota**. SysEx oblik `F0 57 42 7F 78 02 …` (proizvođač 0x42 = KORG) = MFX/efektni blokovi; PC po kanalu (npr. Lower: PC 48) + CC setup realtime traka. Ovo su setup-dumpovi RTTracks/KbdSet/PadSet objekata.

### 11.3 PA MANAGER — Research Edition (novi deliverable)

`PA-MANAGER.html` — single-file offline web aplikacija (bez eksternih resursa, radi u sandboxed previewu):
- **Dashboard**: 8 statistika, spektrogram + RMS cijelog toka, karta streama
- **Zvukovi**: 1516 imena iz ROM baze, live pretraga
- **OC3x**: svih 1577 zapisa (offset/verzija/stil/veličina/lanac/ID/ime) s filterima
- **Uzorci**: 10 WAV previewa (3 s) carve-iranih direktno iz µ-law toka na 48 kHz — WAV kontejneri su format 7 (G.711), browser ih dekodira bez transkodiranja
- **MIDI**: inspektor svih 33 traka (SysEx hex, CC tablica s barovima, PC) + piano-roll/Web Audio synth za note-bearing zapise
- **Workspace**: KBEG#2 indeks — svih 1326 offseta + statistika koraka
- **Toolchain**: PE1/PE2/PE3 + VB6 forenzika
- **Dokumenti**: puni ovaj izvještaj

Izgrađeno s `work/v5-stream/build_pa_manager.py` (reproducibilno).

### 11.4 PUNI KONVERTER — svi izlazi u fullu

`tools/kpm_full_converter.py` (--pcm16 opcija) — jedna naredba, kompletan konverzijski izvoz:

| Izlaz | Sadržaj | Veličina |
|---|---|---|
| `tok1_full_48k_ulaw.wav` | AUDIO TOK 1 komplet (0x00000400–0x016FAC00), 8,37 min, lossless re-container | 24.094.766 B |
| `tok2_full_48k_ulaw.wav` | AUDIO TOK 2 komplet (0x01AADC00–granica), 12,87 min | 37.052.513 B |
| `pcm16/tok1…tok2…` | 16-bit PCM dekodirane verzije (univerzalne za DAW) | 48,2 / 74,1 MB |
| `midi/*.mid` | svih 33 trake | 315 KB |
| `data/names.txt` + `oc3x_index.csv` + `kbeg2_index.csv` | 1516 + 1577 + 1326 zapisa (UTF-8 BOM) | 129 KB |
| `manifest.json` | SHA256 svih izlaza + granice regija | — |

Sva 4 puna WAV-a uploadana na Google Drive (uz µ-law i PCM16 varijante). Aplikacija PA MANAGER v2 dobiva **Konverter tab**: vlastiti JS store-ZIP writer (MIDI paket), klijentski µ-law→PCM16 dekoder (bit-identičan Python reexport_48k.py — verificirano), CSV/TXT/JSON exporti svih ugrađenih podataka i downloadi svih previewa.

### 11.5 PA MANAGER v3 — implementirane funkcije pravog KPM V5

Prema feature-listi KORG PA Manager-a v5 (korgpamanager.com changelog) implementirani su ekvivalenti (šta se pošteno može izvesti iz stream podataka, bez vlasničkih formata):

| KPM V5 funkcija | Implementacija u PA MANAGER.html |
|---|---|
| SET Manager / KST Manager | **SET Explorer** — drvo cijelog radnog prostora (3 Root dokumenta, KbdSet/PadSet/Style, KORF template objekti, ROM baza, audio tokovi) |
| Search | **🔍 Pretraga** — globalna pretraga kroz zvukove, OC3x, MIDI trake i stablo |
| Sample Manager — WAV Import | **WAV → KORG**: učitaj WAV (PCM 8/16/24-bit, float32, µ-law; mono/stereo; bilo koja frekvencija) → mono miks → resample 48 kHz → auto-trim tišine → normalizacija → µ-law WAV. Enkoder verificiran: round-trip 10000/10000, 99,23% bajt-identično originalnom streamu |
| Sample Manager — preview | waveform prikaz svih previewa + detekcija tišine (0FF) + granice signala |
| Duplicate finder | egzaktni + fuzzy duplikati imena (Levenshtein ≤ 2) + obitelji zvukova |
| MIDI Import/Export + Event editor | MIDI ZIP export + SysEx/CC/PC inspektor (Event List) |
| Memory info | SET statistika po tipovima (Dashboard) |
| REX → WAV | NE implementirano (PE2/PE3 su x64 nativni — dokumentovano u Toolchain) |
| Time Slice / SoundFont | NE implementirano (izvan domene streama) |

µ-law G.711 kvirk: bajtovi 0x7F i 0xFF oba dekodiraju u 0 — enkoder kanonizuje na 0xFF (KORG tišina), čime je round-trip dekod→enkod→dekod gubitak-free (10000/10000).
