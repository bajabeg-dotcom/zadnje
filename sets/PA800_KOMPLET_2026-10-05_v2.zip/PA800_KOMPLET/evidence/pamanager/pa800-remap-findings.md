# PA800 remap zvuka — šta je dokazano, a šta nije

Izvor dokaza: PA Manager par `Dzony 2024.SET` → `Dzony 2024_PA800.SET`
(12 stilova, 35.664 selektora u trakama, 2.623 promenjena selektora).

## Dokazano

1. **Promena postoji i merljiva je**: 2.623 od 35.664 selektora (7,4 %) PA Manager
   menja pri izvozu za PA800; ostali ostaju nepromenjeni.
2. **Aritmetičko pravilo nije univerzalno**: obrazac `LSB−2 / program+1`
   (sa wrap-om na granicama 0/127) pokriva 2.039 + 537 zapisa, ali kada se
   primeni na sve selektore daje **699/3.680 = 19,0 %** poklapanja (fajl USER10).
3. **Remap nije funkcija selektora**: 586 različitih ulaznih trojki
   `(MSB, LSB, program)`, od kojih **443 imaju više od jednog izlaza** u istom setu.
   Isti ulaz se u različitim stilovima prevodi različito.
4. **Učena globalna tabela ne pomaže**: najbolja tačnost **25,1 %**
   (8.958/35.664). Sa pragom pouzdanosti ≥0,95 primenjuje se 2.134 selektora i
   ukupna tačnost je **13,9 %** — dakle ni „sigurni“ ulazi nisu univerzalni.
5. **Zato remap ide po imenu zvuka**, a ne po broju: PA Manager za svaku traku
   nađe zvuk u izvornom modelu i upiše odgovarajući (ili najbliži) zvuk u PA800
   banci. To potvrđuje i V5 slika: tabele `PA_OS_SOUND_<model>` (10 modela,
   `VA 0x657b84+`) i strukture `STYTrack` / `STYTrackKST`.

## Šta je potrebno da bi remap radio tačno

Lista **imena zvukova izvornog modela** (Pa3X/Pa900) uparena sa PA800 listom
(imamo je: 1.068 zvukova u `pa800_catalog.py`).

Stanje izvora:

| Izvor | Rezultat |
|---|---|
| `E:\Pa3X_Operating_System_v163\Pa3X_OS.pkg` | header pročitan (`FD`, dužina tela `0x113F3EA`, oznake `102A`/`STD`, `OC20` na `0xFD05A`), ali PA800 skener ne važi (1 kandidat, 0 stranica) |
| Skeniranje markera u prvih 256 KB | 6.297 pojava `F8/FC/FD/FE/FF` → payload je kompresovan, marker-scan nije gramatika |
| SET-ovi na `D:\` sa `SOUND/*.PCG` | postoje, ali samo USER zvukovi (0,2–0,3 MB), bez factory liste |

Zaključak: tačan remap zahteva **skener Pa3X pkg formata** (F8/FC zapisi + OC20
stranice) ili izvoz factory liste zvukova sa instrumenta.

## Šta alat radi danas (i zašto je to bezbedno)

`korg_sty_tool.py` pri konverziji **ne dira selektore** — ostaju byte-exact, a
izvještaj to eksplicitno kaže. Time se ne pravi nijedna pogrešna zamena zvuka;
korisnik dobija tačan spisak traka koje bi trebalo remapirati ručno ili kroz
PA Manager.

Uz to je isporučena **učena tabela** (`pa800-remap-learned.json`, 4.387 ulaza sa
pouzdanjem i alternativama) kao *opcioni* HEURISTIC sloj za isti set — nikad kao
tvrdnja da je remap tačan.
