# BAJAPA800.SET — konverzija korisnikovog SET-a za PA800

## Izvor

- Ulaz: `C:\Users\Baja\Desktop\Dzony 2024.SET` (12 `.STY`, 149 fajlova, 267 MB)
- Model izvora (auto-detekcija): **Pa3X/Pa3XLE/Pa900 generacija** — svih 12 stilova
  je inner **v5**, ElementInfo **28**, TrackData **88**, `ID-09` **nested**.
- Izlaz: `BAJAPA800.SET` (u workspace folderu `prism-uploads`) — svi `ID-06`
  STYLE resursi konvertovani u PA800 inner **v4** (28/80).

## Šta je urađeno

| Korak | Rezultat |
|---|---|
| STYLE resursi | 451 resurs konvertovan v5 → v4 (TrackData 88 → 80, StyleInfo tail 18 → 16, prazni elementi uklonjeni po content bitmapi) |
| Ne-STYLE resursi | 137 fajlova kopirano **byte-exact** (PCM 99, SOUND 5, PAD 10, SONGBOOK 8, KEYBOARDSET 9, GLOBAL 5, MULTISMP 1) |
| ID-09 / STS | **nije konvertovan** — 451 resurs ostaje byte-exact (zadržan) u glavnoj varijanti |
| Nedekodirani resursi | 0 |
| Prekidači | `--allow-lossy` (potreban jer dio stilova ima nestandardne v5 nastavke) |

## Nezavisna verifikacija

`verify_set_conversion.py` poredi izvor i izlaz po resursu i po elementu
(`BAJAPA800_VERIFICATION.json`):

- 12/12 stilova: **0 problema**;
- STYLE naziv očuvan u svakom resursu;
- pattern pool i svi ne-element root childovi **byte-identični** (muzički sadržaj
  nije mijenjan);
- track selektori (prvih 48 bajtova TrackData) identični po elementu;
- ElementInfo sadržaj identičan;
- promijenjeno je samo ono što verzija zahtijeva: TrackData 88 → 80, StyleInfo
  tail 18 → 16 i uklanjanje elemenata koje izvorni content bitmap označava praznim;
- svi `ID-09` resursi byte-identični.

Verifikacija prolazi i za varijantu bez STS-a.

## Dvije varijante izlaza

| Varijanta | ID-09 | Namjena |
|---|---|---|
| `BAJAPA800.SET` | zadržan byte-exact (nested) | maksimalno očuvanje podataka; STS treba testirati na instrumentu |
| `BAJAPA800_NOSTS.SET` | izbačen (`--sts-mode drop`) | PA800 dobija stilove bez STS zapisa i može primijeniti svoje default STS postavke |

Preporuka: prvo probaj `BAJAPA800_NOSTS.SET` na instrumentu (nema stranih STS
struktura), a `BAJAPA800.SET` čuvaj kao potpuni izvoz podataka. Oba izlaza nose
`hardware_acceptance_confirmed: false`.

## Šta nije konvertovano i zašto

- **ID-09/STS (nested → legacy)**: transformacija nije dokazana. Nezavisni dokaz
  iz PA Manager v3 je poruka i kod koji STS mijenjanje eksplicitno odbijaju
  (`STYMSGSTSVersion = Cannot Copy/Paste STS! STS Version NOT Compatible.`).
- **SOUND / PCG i PCM semplovi**: model-specifični; naša konverzija ih ne dira
  (kopirani su byte-exact). Njihov prelaz između modela nije dokazan.
- **PAD / PERFORMANCE / SONGBOOK / GLOBAL / MULTISMP**: kopirani byte-exact.

## Kako ponoviti

```bash
python korg_set_inspector.py "C:\Users\Baja\Desktop\Dzony 2024.SET" inspect.json
python korg_sty_tool.py validate "C:\Users\Baja\Desktop\Dzony 2024.SET\STYLE\USER01.STY" --target-model PA800
python korg_set_converter.py "C:\Users\Baja\Desktop\Dzony 2024.SET" BAJAPA800.SET \
  --target-model PA800 --allow-lossy --report BAJAPA800_REPORT.json
python verify_set_conversion.py "C:\Users\Baja\Desktop\Dzony 2024.SET" BAJAPA800.SET \
  --report BAJAPA800_VERIFICATION.json
```

Verzija bez STS-a: isto uz `--sts-mode drop --no-copy-other` (stilovi) ili bez
`--no-copy-other` (cijeli SET).

## Izvještaji

- `BAJAPA800_REPORT.json` — po stilu: SHA-256 izvor/izlaz, broj konvertovanih
  resursa, ID-09 status, upozorenja.
- `BAJAPA800_VERIFICATION.json` — poređenje po resursu i elementu.
- `BAJAPA800_NOSTS_VERIFICATION.json` — isto za varijantu bez STS-a.
