# PA800 ID-09 (STS) konverzija nested → legacy — nalazi

Izvor dokaza: PA Manager par `Dzony 2024.SET` → `Dzony 2024_PA800.SET`
(**451 par**: nested `9403 B` → legacy `2873 B`, 1:1 po poziciji).

## Dokazano

1. **Transformacija je čista funkcija**: 451 različitih nested ulaza → tačno po
   jedan legacy izlaz (0 ambiguentnih). Za razliku od remapa zvuka (443/586
   ambiguentnih), ovde pravilo postoji.
2. **Legacy zapis ima dve varijante**, razdvojene po dužini repa iza zadnjeg `5A`:
   - `tail=5`: 395 parova (glavni format), 75,4 % fiksnih bajtova,
   - `tail=172`: 51 par, **97,8 % fiksnih bajtova**.
3. **Profil po bajtu (451 resurs)**: 1.330 bajtova uvek nula, 810 konstantnih
   ne-nula, **733 varijabilna** (25,5 %).
4. **Mixer region**: `legacy[0x8D3 + 10·track]` nosi `volume / pan / FX C / FX D`
   aktivnog nested slota. Dokaz: 4/4 kvarteta se poklapaju u tačno jednom slotu po
   paru (slot 0: 129, slot 1: 165, slot 2: 210, slot 3: 237 od 390 parsiranih).
   Hipoteza da region skalira po slotu (`0x8D3 + 10·(slot·4+track)`) je **odbijena**
   (516/6.240).
5. **Imena sva četiri STS slota** su u legacy zapisu, ASCII, na fiksnim offsetima:
   `slot 0 → 0x89A`, `slot 1 → 0x941`, `slot 3 → 0x9E8`, `slot 2 → 0xA8F`
   (redni broj slota je u bajtu pre imena, iza `5A`), uz oznaku tipa (`DNC`, `DTS`).
6. **Nema prenosa bajtova ni blokova**: 0 verbatim 64-bajtnih blokova, 0 direktnih
   bajt-kopija u prvih 512 bajtova, 0 fiksnih nested pozicija za bilo koji
   varijabilni bajt. Znači: polja se **izračunavaju**, ne kopiraju.
7. **Preostala polja nisu iz ulaznog fajla**: niz `0x21..0x26` postoji u nested
   resursu u **1 od 451** para; `0x4F..0x50`, `0x19..0x1A`, `0x8AA` nemaju
   stabilnu nested poziciju. Ta polja (`0x19`, `0x21–0x26`, `0x4F–0x50`, `0x8AA`)
   su **PA Manager-ova interna dopuna** (`PerformanceData` sloj), a ne konverzija
   ulaznih podataka.

## Konverter (`pa800_id09.py`)

```
legacy = template(varijanta)            # 2.167 / 2.809 fiksnih bajtova
       + mixer region 0x8D3+10*track    # iz aktivnog nested slota
       + imena 4 slota na 0x89A/0x941/0x9E8/0xA8F
```

Mereno na 389 parova: **prosečna razlika 484 bajta, minimum 14 bajta**
(byte-exact 0/389). Rezidual je tačno lokalizovan i dokazano dolazi iz
PA Manager internih polja, ne iz ulaza.

## Praktična posledica za BAJAPA800.SET

Naš glavni konverter **ne dira ID-09** (ostaje byte-exact — nested), a sada je
dokumentovano i zašto je to bezbedno: PA Manager pri izvozu **ne prenosi** sve
nested podatke, nego upisuje jedan legacy zapis sa aktivnim slotom, imenima sva
četiri slota i sopstvenim internim poljima. Zato je naš izlaz (nested ID-09
sačuvan) bogatiji od PA Manager izlaza po podacima, a razlika je u formatu.

Ako je potreban PA800-native STS, `pa800_id09.py` daje template-baziranu
konverziju sa eksplicitno navedenim rezidualom (do 484 B po resursu) — koristi
se samo uz hardverski test.
