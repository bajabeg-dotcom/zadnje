# PA Manager: nastavak remap analize

Datum: 2026-10-02. Analiza je statička; uploadovani EXE nije pokretan.

## Novi provjereni tragovi

- Dva djelimična snapshota pripadaju istom dekodiranom imageu. Svih 12 chunkova prolazi SHA-256 provjeru, a preklopljeni bajtovi su identični.
- U pokrivenom UI rasponu `0x0269E000..0x027A0000` pronađeno je 12 indirektnih poziva virtualnog byte slota `0x7A0`. Četiri pripadaju prethodno analiziranom remap toku. Isti broj slota na različitim objektima nije dokaz istog interfejsa ili iste implementacije.
- Tri replacement globala imaju ukupno 50 direktnih instrukcijskih referenci: 18, 17 i 15. Sve identificirane reference su čitanja. U ovim snapshotima nije pronađen direktni producent tih vrijednosti; indirektni upisi i nepokriveni kod ostaju otvoreni.
- Jump tabela `0x026D0720` bira četiri grupe preko indeksa `0..3`. Svaka grana kopira iste tri globalne vrijednosti u ista polja `0/1/3` kao prethodno analizirani remap tok. To povezuje dva toka, ali ne daje semantička imena grupa.
- Pronađen je konkretan statički lanac: zapis `0x00534478` sadrži adresu `0x00535F57`, a petobajtni near jump na toj adresi vodi na `0x026B6DE0`, remap handler. To je entry 17, brojan od nule, u tabeli 63 uzastopna provjerena jump zapisa. Pointer na početak te tabele nalazi se na `0x00533954`.

## Šta još nije dokazano

Statička native tabela nije automatski runtime vtable. Zato nismo izjednačili njen entry 17, niti neki drugi entry, sa slotom `0x7A0`. Vlasnički interfejs, konkretni callee i upis u STY/STS serializer još nisu razriješeni. MSB/LSB/program značenja replacement komponenti i modelska remap tabela nisu izvedeni.

Ova analiza ne mijenja konverzijska pravila niti zatvara dokaznu fazu. Konverter ostaje fail-closed za nedokazane transformacije.

## Reprodukcija

```bash
python3 prism-uploads/analysis/pa_manager_remap_xref_probe.py
```

Izlaz: `pa-manager-remap-xrefs.json`, sa tačnim instrukcijskim adresama, kontekstom poziva, jump tabelom i native thunk lancem. Disassembly je linearni pregled pokrivenog koda, ne potpun CFG ili runtime trag.

## Sljedeći korak

Pratiti descriptor koji upućuje na native tabelu i razriješiti izgradnju odgovarajućeg interfejsa. Ako djelimični snapshoti ne sadrže potrebni kod, statički rekonstruisati puni inner image iz već uploadovanog `prism-uploads/v3.zip` ili `prism-uploads/KORGPAManager_Setup.exe`. Nema potrebe ponovo tražiti isti upload. Potom povezati producente replacement globala i stvarni serializer; do tada ne uvoditi automatski remap.