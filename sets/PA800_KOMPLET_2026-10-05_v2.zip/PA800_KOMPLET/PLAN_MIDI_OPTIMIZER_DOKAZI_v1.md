# PLAN IZGRADNJE — KORG Pa800 MIDI OPTIMIZER (evidence-driven)
**Verzija plana:** v1.0 · **Datum:** 2026-10-03 · **Status:** PLAN — bez pisanja MIDI mutacija dok faza ne bude zatvorena

---

## 0. Osnovni princip (zlatno pravilo projekta)

> **Nijedno pravilo optimizatora ne ulazi u engine bez dokaza. Svaki dokaz ima izvor, tier i falsifikator.**

Dvije odvojene vrste dokaza, koje se **ne smiju miješati**:

| Korpus | Za šta JEST autoritet | Za šta NIJE autoritet |
|---|---|---|
| **Factory Styles** (tvornički stilovi) | Ritmika, groove, timing grid, velocity envelope po tracku, Element/CV kontekst, NTT/NTR, raspodjela nota po drum tipkama, density/voicing | Artikulacije RX zvuka, noise sloj, engine ponašanje |
| **Demo Songs** (demo MIDI) | **Artikulacije, RX noise, kako engine zaista reaguje** — velocity prelazi između OSC slojeva, upotreba key-zona C7..G9 (noise), CC/aftertouch/pitch-bend gestikulacija, trigger/damper ponašanje, legato/gliss/slide/dead-note logika | **Ritmika — ZABRANJENO**. Demo se ne koristi ni za groove, ni za timing, ni za pattern učenje |
| **Hardverski ekran + native dump** (ROM.KMP, ROM.PCG, SET) | Struktura oscilatora, multisampleovi, adrese CC00.CC32.PC, byte layout | Muzička estetika |
| **Manuali (Owner / Advanced Edit)** | Specifikacija uređaja, Guitar Mode, NTT, Style Element model | Stvarno izmjereno ponašanje |

**Operativno pravilo za Demo Songs:** iz demo fajlova se u registar smije upisati **samo** per-note artikulacijski/kontrolni sloj (velocity vrijednost, key zona, CC/PB/AT u prozoru oko note, trajanje, overlap/legato). **Timing i pozicija u taktu se odbacuju na ulazu u parser** (`strip_rhythm=True`), tako da fizički ne mogu procuriti u groove model.

---

## 1. Inventar dokaza — šta već imam na tvom Driveu

### 1.1 Tier 1 — Native / hardverska evidencija (najjači dokaz)
| Fajl | Veličina | Uloga u projektu |
|---|---|---|
| `PA800_INSTRUMENTI_I_DRUM_KITOVI.pdf` | 12,8 MB | **Master katalog**: 1068 Sound programa, 44 RX, 23 DNC, 21 RX drum kit, per-OSC velocity/key zone, switch L→H, multisample High/Low, trigger/damper, nivo dokaza |
| `PA800_FULL_INSTRUMENTI_KITOVI_RX_DNC_OSCILATORI.md` | 158 KB | Hardverski verifikovani RX/DNC oscilatori + drum kit layeri |
| `PA800_FACTORY_SOUND_LIST_CC00_CC32_PC.txt` | 58 KB | Adresna tabela zvukova (CC00/CC32/PC) |
| `ProgramChange i CC.txt` | — | PC/CC referenca |
| `NATIVE_SET_STATIC_INVENTORY.json` | — | Statični inventar native SET-a |
| `PA800_OS202_HARDVER_I_UZORCI.md` | — | Hardver + uzorci, OS v2.02 |
| `PA800_REVERSE_ENGINEERING_MAIN / MAIN1 / MAIN2 / ZADNJI` (PDF) | — | Byte-level reverse engineering |
| `PA800_CROSS_EVIDENCE_TRIANGULATION_2026-09-22.md` | 5 KB | Status zatvorenosti po stavkama (CLOSED / STRONG_FAMILY / OPEN) |
| `PA800_EVIDENCE_AUTHORITY_RULES.md` | 29 KB | **Postojeći tier model + potvrđene tvrdnje PA800-001..00x** |
| `BRAIN_V7_COMPLETE_EVIDENCE_2.5.0.md` | — | Akumulirana baza dokaza |
| `PA800_PACKAGES_SHA256_2026-09-22.txt` | — | SHA256 lanac integriteta |

### 1.2 Tier 2 — Factory Styles korpus (ritmički autoritet)
| Fajl | Veličina |
|---|---|
| `PA800_FACTORY_STYLES_PATTERNS_PADS_REFERENCE.zip` | 6,9 MB |
| `STYLE.zip` | 2,5 MB |
| `Pa3xStyle Wrhunski.zip` | 8,5 MB (cross-model referenca, Pa3X) |
| `STYLE_TO_USER_PCG_CANDIDATES.json` | 113 KB |
| (iz ranijih dossiera) `Split Factory Styles.zip` → CP00 registry: **20 967** opservacija / **8 929** profila; FV00 registry: **268** velocity profila |

### 1.3 Tier 2b — Demo Songs (artikulacijski / engine autoritet)
| Fajl | Veličina |
|---|---|
| `demo_midis.zip` | 752 KB |

### 1.4 Postojeći kod (za migraciju, ne za copy-paste)
`02_OPTIMIZER_SOURCE/` (`pipeline.py`, `midi_io.py`, `detection.py`, `harmony.py`, `quality.py`, `processors.py`, `realtime.py`, `pa800_sounds.py`, `style_creator.py`, `models.py`, `config.py`, `cli.py`, `gui.py`, `app_service.py`) ·
`Korg_Pa800_MIDI_Optimizer_Pro.zip` · `pa800-midi-optimizer.zip` · `korg_pa800_optimizer_v2.zip` · `PA800_MIDI_RX_Optimizer_V2.zip` · `PA800_Profile_Optimizer_CLEAN_2.8.0.zip` · `PA800_Profile_Optimizer_BAJA_MAX_..._R13_CHECKPOINT.zip` (38 MB) · `KORG_PA800_FULL_EXTRACTION_TOOLKIT_v1.zip` · `KORG_PA800_PCG_SOUND_DRUM_MAPPER_v6_FULL_SYSTEM_MAP.zip`

### 1.5 Šta mi JOŠ treba (gap lista — potvrdi ili dostavi)
1. **Pa800 Owner's Manual (`Pa800-201UM-ENG.pdf`) i Advanced Edit (`Pa800_AE_E.pdf`)** — u dossieru se referenciraju sa SHA256, ali ih ne vidim kao zasebne fajlove na Driveu. Treba mi kopija za citiranje stranica.
2. **Sirovi `Split Factory Styles.zip`** (SHA ffb95cc1…) — ako postoji negdje van ovih zipova, da ne radim re-derivaciju.
3. **Potvrda sadržaja `demo_midis.zip`**: da li su to SMF Type-1 sa punim CC/PB/AT podacima i originalnim Pa800 track rolama, ili već „očišćeni" exporti? (Faza 0 to utvrđuje automatski.)
4. **Hardverski screenshotovi** za preostalih ~34 RX zvuka bez `HARDWARE_OBSERVED` statusa (trenutno: 10 verifikovanih dubokih OSC profila + 5 inferiranih).
5. **Ciljna platforma optimizatora**: CLI + GUI desktop (postojeći `gui.py`) ili web (postoji `PA-MANAGER.html`, `PA800_Manager_Web_v0.2`)? — **otvoreno pitanje za tebe**.

---

## 2. Arhitektura sistema

```
                 ┌─────────────────────────────────────────────┐
                 │            EVIDENCE LAYER (read-only)       │
                 │  ROM.KMP · ROM.PCG · SET · Manuali · PDF    │
                 └───────────────┬─────────────────────────────┘
                                 │
        ┌────────────────────────┼────────────────────────┐
        │                        │                        │
┌───────▼────────┐      ┌────────▼─────────┐     ┌────────▼────────┐
│ FACTORY STYLES │      │   DEMO SONGS     │     │  INSTRUMENT DB  │
│  parser        │      │  parser          │     │  (iz PDF/MD)    │
│  (ritmika OK)  │      │  strip_rhythm=1  │     │  OSC/vel/key    │
└───────┬────────┘      └────────┬─────────┘     └────────┬────────┘
        │                        │                        │
┌───────▼────────┐      ┌────────▼─────────┐     ┌────────▼────────┐
│ R-REG          │      │ A-REG            │     │ I-REG           │
│ Rhythm/Groove  │      │ Articulation/RX  │     │ Instrument      │
│ registry       │      │ Noise registry   │     │ registry        │
└───────┬────────┘      └────────┬─────────┘     └────────┬────────┘
        └────────────────────────┼────────────────────────┘
                                 │
                   ┌─────────────▼──────────────┐
                   │   RULE ENGINE (R1..Rn)     │
                   │  svako pravilo ima:        │
                   │  id · izvor · tier ·       │
                   │  uslov · akcija · test ·   │
                   │  falsifikator · confidence │
                   └─────────────┬──────────────┘
                                 │
                   ┌─────────────▼──────────────┐
                   │  OPTIMIZER PIPELINE        │
                   │  analyze → plan → apply    │
                   │  (dry-run + diff + undo)   │
                   └─────────────┬──────────────┘
                                 │
                   ┌─────────────▼──────────────┐
                   │  VALIDATION HARNESS        │
                   │  A/B render · regresija ·  │
                   │  hardware acceptance test  │
                   └────────────────────────────┘
```

---

## 3. Fazni plan

### FAZA 0 — Inventura i integritet korpusa (1 korak)
**Cilj:** znati tačno šta imam, bez nagađanja.
- Skinuti i raspakovati: `PA800_FACTORY_STYLES_PATTERNS_PADS_REFERENCE.zip`, `STYLE.zip`, `demo_midis.zip`, `KORG_PA800_PCG_SOUND_DRUM_MAPPER_v6…zip`, `02_OPTIMIZER_SOURCE`.
- Za svaki fajl: SHA256, tip, broj trackova, PPQN, broj Note-On, prisustvo CC/PB/AT.
- **Deliverable:** `CORPUS_MANIFEST.json` + `CORPUS_REPORT.md` (tabela svih izvora sa hashem i tierom).
- **Acceptance:** 100 % fajlova klasifikovano u tier; nijedan „unknown".

### FAZA 1 — Instrument Registry (I-REG) iz postojećeg kataloga
**Cilj:** mašinski čitljiva baza svih 1068 zvukova + 21 RX drum kita.
- Parsirati `PA800_INSTRUMENTI_I_DRUM_KITOVI.pdf` + `…RX_DNC_OSCILATORI.md` + `PA800_FACTORY_SOUND_LIST_CC00_CC32_PC.txt` u jedan JSON.
- Shema po zvuku:
```json
{
  "name": "Finger Bass RX",
  "address": {"cc00":121,"cc32":13,"pc":33},
  "family": "BASS",
  "type": "RX",
  "osc_count": 5,
  "evidence": {"catalog":"FACTORY_CATALOG_VERIFIED","detail":"HARDWARE_OBSERVED_PARTIAL"},
  "oscillators": [
    {"idx":1,"role":"HARMONIC","vel":[114,127],"key":["C-1","B6"],"switch":1,
     "ms_high":"E.Bass4 Harmo.(#374)","ms_low":"E.Bass4 Harmo.(#374)",
     "trigger":"Normal","damper":"Normal","proof":"HW_VELOCITY_WINDOW"}
  ]
}
```
- Drum kit: isto, ali ključ je **MIDI tipka** → lista slojeva + switch pointi (npr. Pop Std. Kit RX, D2/E2: 6 slojeva, switch 26/47/68/89/110).
- **Deliverable:** `I_REG_v1.json` + validator + HTML pregled za pretragu.
- **Acceptance:** svaki zapis ima `evidence.detail`; nijedna velocity zona ne preklapa drugu bez eksplicitnog `switch`; sve adrese jedinstvene.

### FAZA 2 — Factory Styles → Rhythm Registry (R-REG) *(samo ritmika)*
**Cilj:** statistički profil kako Korg stvarno piše ritmiku.
- Parser razbija svaki Style na `(Style, Element, CV, Track)` ključ — obavezno, jer bez Element/CV konteksta transfer je zabranjen (PA800-001/002).
- Mjerenja po ključu:
  - velocity histogram + percentili (p10/p50/p90), accent pattern po poziciji u taktu
  - mikro-timing offset u tickovima (push/laid-back) po instrumentu
  - gustoća nota / takt, note length distribucija, overlap ratio
  - drum: koja tipka se koristi na kojoj poziciji + sa kojom velocity → **direktna veza na I-REG drum slojeve**
  - bass/acc: NTT/NTR kontekst se **prenosi, ne izvodi**
- **Deliverable:** `R_REG_v1.json` (profili + broj opservacija po profilu) · `R_REG_COVERAGE.md`.
- **Acceptance:** profil se prihvata samo ako ima **≥ N opservacija** (predlog N=30) i ≥ 2 različita Stylea; ispod toga ide u `weak/` i ne smije generisati pravilo.
- **Zabrana:** Demo Songs se u ovoj fazi **ne učitavaju uopšte** (hard guard u kodu).

### FAZA 3 — Demo Songs → Articulation & RX-Noise Registry (A-REG) *(bez ritmike)*
**Cilj:** dokazati **kako engine zvuka zaista radi** — ovo je srce optimizatora.
- Parser sa `strip_rhythm=True`: iz svakog Note-On zadržava se `(note, velocity, duration_class, overlap_class, CC snapshot, PB, AT, kanal, program)`; **tick pozicija se briše prije upisa u registar**.
- Analize:
  1. **Velocity-layer crossing**: za svaki RX zvuk mapirati koliko demo nota pada u koju OSC velocity zonu iz I-REG → potvrda/opovrgavanje dokumentovanih granica (npr. Finger Bass RX: 1-22 GLISS, 23-52 STOP, 53-113 WORKING, 114-127 HARMONIC).
  2. **RX Noise zone**: koliko se koristi key zona **C7..G9** (OSC 5 kod bass/guitar RX), na kojim mjestima, u kojoj velocity, i u kakvom odnosu prema susjednoj „pravoj" noti → **model generisanja noise sloja**.
  3. **Guitar Mode kontrolne oktave**: detekcija nota koje nisu melodijske nego kontrolne (strum/single-string/arpeggio/RX noise) — po PA800-004 zahtijeva eksplicitni `Track Type=Gtr`.
  4. **Artikulacijski prelazi**: legato/overlap → slide; kratko + nisko vel → dead/mute; gliss obrasci; repeticija iste note.
  5. **DNC kontroleri**: koji CC-ovi se koriste na DNC zvukovima i sa kojom putanjom vrijednosti.
  6. **Damper/trigger ponašanje**: CC64 i retrigger/repitch posljedice.
- **Deliverable:** `A_REG_v1.json` · `ENGINE_BEHAVIOR_REPORT.md` (po zvuku: dokazano / djelimično / nedokazano) · lista **potvrđenih i oborenih** granica iz PDF kataloga.
- **Acceptance:** svaka tvrdnja o engineu nosi broj opservacija i listu demo fajlova; tvrdnja koja je kontradiktorna katalogu ide u `CONFLICT` i **ne postaje pravilo** dok se ne razriješi hardverski.
- **Hard guard:** ako iko pozove R-REG builder sa demo fajlom → exception `RhythmFromDemoForbidden`.

### FAZA 4 — Rule Engine (pravila sa dokazima)
**Cilj:** pretvoriti registre u izvršna, revizibilna pravila.
- Format pravila:
```yaml
id: R-RX-BASS-004
title: "Finger Bass RX — gliss sloj se ne smije aktivirati na downbeatu"
scope: {sound: "Finger Bass RX", track_role: "Bass"}
condition: "velocity <= 22 and beat_position == 1"
action: "raise velocity to >= 53 (WORKING_BASS zone)"
evidence:
  - {src: "I_REG_v1#FingerBassRX.osc4", tier: 1, type: "velocity window"}
  - {src: "A_REG_v1#demo.bass.vel_hist", tier: 2b, n: 412, type: "observed"}
  - {src: "R_REG_v1#bass.downbeat.p10", tier: 2, n: 1877, type: "observed"}
confidence: HIGH
falsifier: "demo nota sa vel<=22 na downbeatu u >5% slučajeva"
default: OFF   # svako pravilo startuje isključeno dok ne prođe harness
```
- Kategorije pravila: `RX-ARTICULATION`, `RX-NOISE`, `DRUM-LAYER`, `VELOCITY-SHAPE`, `GROOVE-TIMING`, `GTR-MODE`, `DNC-CC`, `CHANNEL-MAP`, `SAFETY`.
- **Deliverable:** `RULES/*.yaml` + `RULES_INDEX.md` sa tier/confidence matricom.
- **Acceptance:** 0 pravila bez `evidence` i `falsifier`; svako pravilo ima unit test.

### FAZA 5 — Optimizer Pipeline
- `analyze` → `plan` (lista predloženih izmjena, ništa se ne mijenja) → `apply` (dry-run default) → `diff` → `undo`.
- Svaka izmjena nosi `rule_id` → potpuna sljedivost „zašto je ova nota promijenjena".
- Profili: `SAFE` (samo CLOSED pravila), `STANDARD`, `AGGRESSIVE` (uključuje MEDIUM confidence), `CUSTOM`.
- Ulaz: SMF / Pa800 SNG / Style; izlaz: isto + `OPTIMIZATION_REPORT.html`.
- **Deliverable:** CLI + (po tvom izboru) GUI/web.

### FAZA 6 — Validation Harness
1. **Unit testovi** po pravilu (sintetički MIDI).
2. **Regresija na Factory korpusu**: optimizator pušten na tvornički stil **ne smije ga mijenjati više od ε** — tvornički materijal je po definiciji već „optimalan". To je najjači automatski test ispravnosti.
3. **Demo re-prediction test**: sakriti artikulacijski sloj demo pjesme, pustiti optimizator da ga rekonstruiše, mjeriti podudarnost sa originalom (precision/recall po OSC zoni).
4. **A/B audio render** (ako postoji soundfont/ROM path) + slušni test.
5. **Hardware acceptance**: učitavanje na fizički PA800 — jedini konačni dokaz (trenutno `external-only` u triangulaciji).
- **Deliverable:** `HARNESS_REPORT.md` sa brojkama po pravilu; pravilo prelazi iz `OFF` u `ON` tek kad prođe 1-3.

### FAZA 7 — Dokumentacija i isporuka
- `EVIDENCE_DOSSIER.md` (svaka tvrdnja → izvor → tier → test)
- `USER_MANUAL.md`, `RULES_INDEX.md`, `CHANGELOG.md`, SHA256 manifest
- Upload nazad na Drive u novi folder `08_MIDI_OPTIMIZER_EVIDENCE_BUILD_<datum>`

---

## 4. Matrica „dokaz → pravilo" (kontrola kvaliteta)

| Tier | Izvor | Može generisati pravilo? | Max confidence |
|---|---|---|---|
| 1 | Hardverski ekran / native byte / manual stranica | DA | HIGH |
| 2 | Factory Styles (n ≥ 30, ≥ 2 stila) | DA — **samo ritmika/velocity/groove** | HIGH |
| 2b | Demo Songs (n ≥ 30) | DA — **samo artikulacija/noise/engine** | MEDIUM, HIGH tek uz Tier-1 saglasnost |
| 3 | Literatura / istraživanje | NE sam — samo hipoteza | — |
| 4 | Forumi / praksa | NE | — |

**Eskalacija:** hipoteza (T3/T4) → mora biti potvrđena na T2/T2b sa dovoljno opservacija → pa tek onda pravilo.
**Degradacija:** ako falsifikator okine na novom korpusu → pravilo automatski ide u `OFF` + upis u `CONFLICT_LOG.md`.

---

## 5. Redoslijed izvršavanja (prijedlog)

| # | Faza | Zavisi od | Procjena |
|---|---|---|---|
| 1 | Faza 0 — inventura | — | kratko |
| 2 | Faza 1 — I-REG | 0 | srednje |
| 3 | Faza 3 — A-REG (demo/artikulacije) | 1 | **najvrednije — ide prije ritmike** |
| 4 | Faza 2 — R-REG (factory/ritmika) | 1 | srednje |
| 5 | Faza 4 — pravila | 2,3,4 | srednje |
| 6 | Faza 5 — pipeline | 5 | srednje |
| 7 | Faza 6 — harness | 6 | srednje |
| 8 | Faza 7 — isporuka | 7 | kratko |

> Faza 3 je namjerno ispred Faze 2: tvoj ključni zahtjev je **kako engine radi (artikulacije + noise)**, a to je i najslabije pokriveni dio postojeće evidencije (10/44 RX zvukova hardverski verifikovano).

---

## 6. Rizici i kako ih gasimo

| Rizik | Mitigacija |
|---|---|
| Ritmika iz demo fajlova procuri u model | `strip_rhythm` na nivou parsera + hard exception + test koji to dokazuje |
| Preklapanje velocity zona u I-REG (nekonzistentan PDF) | Validator; konflikt → `CONFLICT`, ne pravilo |
| Mali uzorak → lažno pravilo | Prag n ≥ 30 i ≥ 2 nezavisna izvora |
| Optimizator „pokvari" tvornički materijal | Regresijski test na Factory korpusu (ε prag) |
| Nedostaju manuali za citiranje | Gap lista, tačka 1.5 — tražim fajlove od tebe |
| Nema fizičkog PA800 u petlji | Sve ostaje `dry-run` + undo dok ne bude hardverskog acceptance testa |

---

## 7. Otvorena pitanja za tebe (da ne nagađam)

1. **Platforma:** desktop CLI+GUI (Python, postojeći `gui.py`) ili web app (postoji `PA-MANAGER.html` / `PA800_Manager_Web`)?
2. **Ulazni format koji optimizujemo:** standardni SMF/MIDI fajlovi, Pa800 **SNG**, ili i **STY** stilovi?
3. **Manuali** (`Pa800-201UM-ENG.pdf`, `Pa800_AE_E.pdf`) — imaš li ih negdje da ih uploadam u korpus?
4. **Krećem li odmah u Fazu 0** (skidanje i raspakivanje `demo_midis.zip` + `PA800_FACTORY_STYLES_PATTERNS_PADS_REFERENCE.zip` u workspace i pravljenje `CORPUS_MANIFEST.json`)?
