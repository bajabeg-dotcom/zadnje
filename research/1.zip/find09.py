import sys
sys.path.insert(0, r'C:\Users\Baja\Desktop\Nova mapa')
from pathlib import Path
from setconvert.sty import StyBank
from pa800_native.oc31_codec import decode_oc31

path = sys.argv[1]
data = Path(path).read_bytes()
bank = StyBank.read(data)
print('kinds:', [(i, r.kind) for i, r in enumerate(bank.resources)][:70])
for i, r in enumerate(bank.resources):
    if r.kind != 9:
        continue
    payload = decode_oc31(r.payload) if r.compressed else r.payload
    print('first kind09 res=%d decomp=%d head=%s' % (i, len(payload), payload[:16].hex(' ')))
    break
