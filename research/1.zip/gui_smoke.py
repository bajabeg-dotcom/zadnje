import sys
import time
import traceback
from pathlib import Path

sys.path.insert(0, r"C:\Users\Baja\Desktop\Nova mapa")

from setconvert.gui import App, collect_sty, default_output, identify_text, convert_text

failures = []


def check(label, fn):
    try:
        fn()
        print(f"[ok] {label}")
    except Exception:
        failures.append(label)
        print(f"[FAIL] {label}")
        traceback.print_exc()


def gui_lifecycle():
    app = App()
    app.update_idletasks()
    app.update()
    assert app.log is not None
    app._append("test line OPEN: something\n")
    app._append("Traceback test\n")
    app._set_busy(True)
    app._set_busy(False)
    app._clear_log()
    app._copy_log()
    app.destroy()


def ui_identify():
    app = App()
    app.identify_path.set(
        r"C:\Users\Baja\Desktop\Korg Pa3x Team Serbian.SET"
    )
    app._do_identify()
    deadline = time.time() + 120
    text = ""
    while time.time() < deadline:
        app.update()
        text = app.log.get("1.0", "end")
        if "=== OK ===" in text or "=== ERROR ===" in text:
            break
        time.sleep(0.05)
    time.sleep(0.3)
    app.update()
    app.destroy()
    assert "family:" in text, text[:800]
    assert "ERROR ===" not in text, text[:1500]


def ui_convert_defaults():
    assert default_output(r"C:\tmp\a.STY", "pa1x") == r"C:\tmp\a_pa1x.STY"
    files = collect_sty(Path(r"C:\Users\Baja\Desktop\Korg Pa3x Team Serbian.SET\STYLE"))
    assert files, "no sty found"
    assert len(files) > 1, files


def identify_text_json():
    text = identify_text(
        r"C:\Users\Baja\Desktop\Korg Pa3x Team Serbian.SET", as_json=True
    )
    assert '"family"' in text, text[:400]


check("gui lifecycle", gui_lifecycle)
check("gui identify task", ui_identify)
check("gui helpers", ui_convert_defaults)
check("identify json", identify_text_json)

print("FAILURES:", failures)
sys.exit(1 if failures else 0)
