import sys

sys.path.insert(0, r"C:\Users\Baja\Desktop\Nova mapa")

from setconvert.sty import StyBank
from setconvert.detect import decode_payload

PATHS = {
    "pa1x Pantic": r"C:\Users\Baja\Desktop\Pantic Pa1X.SET\STYLE\BANK01_LIVE.STY",
    "pa800 GOLE U1": r"C:\Users\Baja\Desktop\GOLE ARX .SET\GOLE ARX .SET\STYLE\USER01.STY",
    "pa800 IZOL": r"C:\Users\Baja\Desktop\STYLE\USER01_IZOLACIJA.STY",
    "pa3x U1": r"C:\Users\Baja\Desktop\Korg Pa3x Team Serbian.SET\STYLE\USER01.STY",
    "pa4x U1": r"C:\Users\Baja\Desktop\Pa4x Pro Dejan Shiki.SET\STYLE\USER01.STY",
    "legacy initpa": r"C:\Users\Baja\Desktop\Nova mapa\Style Works XT Universal\InitKorg\initpa01.STY",
}


def scan(tag4, payload, name):
    pos = 0
    hits = []
    marker = bytes([0x02, 0x00, tag4[0], 0x08])
    while True:
        pos = payload.find(marker, pos)
        if pos < 0:
            break
        if pos + 8 <= len(payload):
            size = int.from_bytes(payload[pos + 4:pos + 8], "big")
            hits.append((pos, size))
        pos += 1
    return hits


for name, path in PATHS.items():
    try:
        bank = StyBank.read(path)
    except Exception as e:
        print(f"{name}: ERR {e}")
        continue
    stats = {}
    first_block = None
    for r in bank.resources:
        if r.kind != 6:
            continue
        dec = decode_payload(r.payload)
        for tag2 in (0, 2):
            for pos, size in scan((tag2,), dec, name):
                if size in (48, 80, 88, 96) and pos + 8 + size <= len(dec):
                    key = (tag2, size)
                    stats[key] = stats.get(key, 0) + 1
                    if first_block is None:
                        first_block = (tag2, pos, dec[pos + 8:pos + 8 + min(size, 48)])
    print(f"{name:14s} blocks={stats}")
    if first_block:
        tag2, pos, body = first_block
        print(f"    first: tag=02 00 {tag2:02x} 08 body[:48]={body.hex(' ')}")
