import os, sys, struct, collections
sys.path.insert(0, r"C:\Users\Baja\Desktop\Nova mapa")
from pa800_native import decode_oc31
sys.stdout.reconfigure(encoding="utf-8", errors="replace")

def res_walk(d):
    """Linear size-chain walk; returns list of (hdr, payload) or None if broken."""
    if d[:4] != b"\x01\x00\x01\x14":
        return None
    total = struct.unpack(">I", d[4:8])[0]
    if total != len(d) - 8:
        return None
    out = []
    pos = 8
    while pos + 8 <= len(d):
        hdr = d[pos:pos+4]
        sz = struct.unpack(">I", d[pos+4:pos+8])[0]
        if sz == 0 or pos + 8 + sz > len(d):
            return None
        out.append((hdr, d[pos+8:pos+8+sz]))
        pos += 8 + sz
    return out

def dec(payload):
    if payload[:4] in (b"OC31", b"OC32"):
        return decode_oc31(b"OC31" + payload[4:])
    return payload

def fingerprint(path):
    d = open(path, "rb").read()
    res = res_walk(d)
    if res is None:
        return {"err": "bad container"}
    fp = {}
    h5 = [h for h, p in res if h[0] == 5]
    h6 = [h for h, p in res if h[0] == 6]
    h9 = [h for h, p in res if h[0] == 9]
    fp["n_styles"] = len(h6)
    fp["hdr05"] = sorted({h.hex(" ") for h in h5})
    fp["hdr06"] = sorted({h.hex(" ") for h in h6})
    fp["hdr09"] = sorted({h.hex(" ") for h in h9})
    fp["mag06"] = sorted({p[:4].decode("latin1") for h, p in res if h[0] == 6 and p[:4] in (b"OC31", b"OC32")})
    fp["raw06"] = sorted({p[:4].hex(" ") for h, p in res if h[0] == 6 and p[:4] not in (b"OC31", b"OC32")})
    # kind05 entry layout
    if h5:
        p5 = [p for h, p in res if h[0] == 5][0]
        if p5[:2] == b"\x00\x52" or p5[0:1] == b"\x00" and p5[1:2] != b"\x00" and len(p5) % 84 == 0:
            fp["tbl05"] = "84B-hdr"
        elif len(p5) % 24 == 0:
            fp["tbl05"] = "24B x%d" % (len(p5) // 24)
        else:
            fp["tbl05"] = "len=%d mod84=%d mod24=%d" % (len(p5), len(p5) % 84, len(p5) % 24)
    # decoded kind06: name child + element/TrackInfo sigs
    n6 = len(h6)
    name_tags = set(); sigs = collections.Counter()
    for h, p in res:
        if h[0] != 6:
            continue
        out = dec(p)
        if len(out) >= 12:
            name_tags.add(tuple(out[8:12]))
        for pos in range(0, len(out) - 8):
            t = out[pos:pos+4]
            if t[0] in (1, 2) and t[1] == 0 and t[3] == 8:
                sz = int.from_bytes(out[pos+4:pos+8], "big")
                if 0 < sz < 400 and pos + 8 + sz <= len(out):
                    sigs[(t[2], sz)] += 1
    fp["name_child"] = sorted({"%02x" % t[2] for t in name_tags})
    fp["sigs"] = sorted({"sub=%02x sz=%d n=%d" % (sub, sz, c) for (sub, sz), c in sigs.items() if c >= max(1, n6)})
    # decoded kind09 mixer
    mix = set()
    for h, p in res:
        if h[0] == 9:
            out = dec(p)
            if len(out) >= 4:
                mix.add(tuple(out[:4]))
    fp["mixer"] = sorted({m[1:].hex(" ") if False else "%02x %02x %02x" % (m[1], m[2], m[3]) for m in mix})
    return fp

def scan_set(setpath, label):
    print("=" * 60)
    print(label, "->", setpath)
    if not os.path.isdir(setpath):
        print("   MISSING"); return
    sub = sorted(os.listdir(setpath))
    print("   folders:", [s for s in sub if os.path.isdir(os.path.join(setpath, s))])
    print("   files  :", [s for s in sub if not os.path.isdir(os.path.join(setpath, s))])
    st = os.path.join(setpath, "STYLE")
    if os.path.isdir(st):
        print("   STYLE:", sorted(os.listdir(st))[:12])
        stys = [f for f in sorted(os.listdir(st)) if f.upper().endswith(".STY")]
        for f in stys[:3]:
            fp = fingerprint(os.path.join(st, f))
            print("   --", f)
            for k in ("n_styles", "hdr05", "tbl05", "hdr06", "mag06", "raw06", "hdr09", "name_child", "mixer", "sigs"):
                if k in fp: print("        %-10s %s" % (k, fp[k]))
    snd = os.path.join(setpath, "SOUND")
    if os.path.isdir(snd):
        print("   SOUND:", sorted(os.listdir(snd))[:10])

sets = [
 (r"C:\Users\Baja\Desktop\Korg Pa3x Team Serbian.SET", "Pa3X-Team-Serbian"),
 (r"C:\Users\Baja\Desktop\Pa4x Pro Dejan Shiki.SET", "Pa4X-Pro-Dejan"),
 (r"C:\Users\Baja\Desktop\KOCE FOLK.SET", "KOCE-FOLK"),
 (r"C:\Users\Baja\Desktop\GOLE ARX .SET\GOLE ARX .SET", "GOLE-ARX(Pa800?)"),
 (r"C:\Users\Baja\Desktop\Pantic Pa1X.SET", "Pantic-Pa1X"),
]
for p, l in sets:
    scan_set(p, l)
