#!/usr/bin/env python3
from pathlib import Path
import struct
from collections import Counter

def scan(root: Path, label: str) -> None:
    print(f"\n==== {label} ====")
    for p in sorted(root.glob("*.[sS][tT][yY]")):
        data = p.read_bytes()
        if data[:4] != b"\x01\x00\x01\x14":
            print(f"  {p.name}: foreign magic {data[:4].hex()}")
            continue
        kend = data.find(b"KEND")
        count = struct.unpack(">I", data[kend+4:kend+8])[0]
        kbeg = kend - 4 - 4*count
        start = kbeg + 4
        offsets = [struct.unpack(">I", data[start+4*i:start+4*i+4])[0] for i in range(count)]
        kinds = Counter()
        t9_markers = Counter()
        t9_lens = Counter()
        t6_b1 = Counter()
        for i, o in enumerate(offsets):
            hdr = data[o:o+4]
            sz = struct.unpack(">I", data[o+4:o+8])[0]
            payload = data[o+8:o+8+sz]
            kinds[hdr[0]] += 1
            if hdr[0] == 9 and payload.startswith(b"OC31"):
                # decode quickly via oc31
                try:
                    import sys
                    sys.path.insert(0, r"C:\Users\Baja\Desktop\BAJA MUSIC\Baja_Music_PA_Manager_V1_WORKING\pa800_native")
                    from oc31_codec import decode_oc31
                    dec = decode_oc31(payload)
                    t9_markers[dec[:4].hex()] += 1
                    t9_lens[len(dec)] += 1
                except Exception as e:
                    t9_markers[f"ERR:{e}"] += 1
            if hdr[0] == 6 and payload.startswith(b"OC31"):
                try:
                    from oc31_codec import decode_oc31
                    dec = decode_oc31(payload)
                    t6_b1[dec[1]] += 1
                except Exception:
                    pass
        trailer = data[offsets[-1]:]
        # find trailer between last resource end and kbeg - approximate
        print(f"  {p.name}: n={count} kinds={dict(kinds)} t9mark={dict(t9_markers)} t9len={dict(t9_lens)} t6b1={dict(t6_b1)}")

roots = {
    "PA800": Path(r"C:\Users\Baja\Desktop\BAJA MUSIC\extracted_files_oc20_lzss\STARTUP\ALL\STYLE"),
    "PA1X": Path(r"C:\Users\Baja\Desktop\Pantic Pa1X.SET\STYLE"),
    "PA3X": Path(r"C:\Users\Baja\AppData\Local\Temp\opencode\pa3x_extract\BRMA NOVI.SET\STYLE"),
}
for label, root in roots.items():
    if root.exists():
        scan(root, label)
    else:
        print("MISSING", root)
