#!/usr/bin/env python3
"""Dump id=1,4,5,15,16 structures + ENG PEG multi-zlib check."""
import struct
import zlib
from pathlib import Path

PKG = Path(r"E:\PA4\Pa4X Operating System v.3.1.0\Pa4X_Operating_System_v310.pkg")
data = PKG.read_bytes()

pos = 16
chunks = []
while pos + 8 <= len(data):
    cid, size = struct.unpack_from("<II", data, pos)
    if cid == 0 or size == 0 or size > len(data):
        break
    chunks.append((pos, cid, size))
    pos += 8 + size
    if pos % 4:
        pos += 4 - (pos % 4)

for want in (1, 5):
    for p, cid, size in chunks:
        if cid == want:
            b = p + 8
            print(f"=== id={cid} size={size} ===")
            print("hex:", data[b:b + min(size, 120)].hex())
            print("ascii:", repr(data[b:b + size]))

for want in (4, 16, 15):
    cnt = 0
    for p, cid, size in chunks:
        if cid != want:
            continue
        cnt += 1
        if cnt > 3:
            continue
        b = p + 8
        print(f"=== id={cid} #{cnt} size={size} ===")
        print("hex:", data[b:b + min(size, 96)].hex())
        print("ascii:", repr(data[b:b + min(size, 200)]))
    print(f"id={want} total={cnt}")

# ENG PEG multi-zlib
print("=== ENG PEG zlib streams ===")
for p, cid, size in chunks:
    if cid != 17:
        continue
    b = p + 8
    dsize, = struct.unpack_from("<I", data, b + 24)
    comp, = struct.unpack_from("<B", data, b + 28)
    i = b + 29
    path = data[i:data.index(b"\0", i)].decode("latin1")
    if not path.endswith("Z110AENG.PEG"):
        continue
    for _ in range(3):
        i = data.index(b"\0", i) + 1
    payload = data[i:i + size - (i - b)]
    off = payload.find(b"\x78\xda")
    d = zlib.decompressobj()
    out = d.decompress(payload[off:])
    total = out
    n = 1
    while d.unused_data:
        off2 = payload[len(payload) - len(d.unused_data):]
        d2 = zlib.decompressobj()
        try:
            chunk = d2.decompress(off2)
        except Exception as e:
            print("  stream", n, "fail", e)
            break
        total += chunk
        d = d2
        n += 1
        if n > 10:
            break
    import hashlib
    print(f"  streams={n} total={len(total)} dsize={dsize} md5={hashlib.md5(total).hex()}")
    # also try single zlib with wbits
    for wb in (47, 15 + 32):
        try:
            o = zlib.decompress(payload[off:], wb)
            print(f"  wbits={wb}: len={len(o)} md5={hashlib.md5(o).hex()}")
        except Exception as e:
            print(f"  wbits={wb}: FAIL {e}")
