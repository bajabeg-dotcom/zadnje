# -*- coding: utf-8 -*-
"""Extract all .SND files into unified JSON + CSV."""
import os, re, json, csv, sys
sys.stdout.reconfigure(encoding='utf-8', errors='replace')

ROOT = r'C:\Users\Baja\Desktop\Nova mapa'
OUT_JSON = r'C:\Users\Baja\AppData\Local\Temp\opencode\snd_all.json'
OUT_CSV = r'C:\Users\Baja\AppData\Local\Temp\opencode\snd_all.csv'

records = []  # list of dicts
errors = []

def rel(p):
    return os.path.relpath(p, ROOT)

# Patterns
RE_TRIPLE = re.compile(r'^(\d{3})-(\d{3})-(\d{3})\s+(.*)$')
RE_DOUBLE = re.compile(r'^(\d{3})-(\d{3})\s+(.*)$')
RE_TRIPLE_T = re.compile(r'^(\d{3})-(\d{4})-(\d{3})\s+(.*)$')  # Technics 4-digit middle
RE_GS_NAME = re.compile(r'^(\d{2})([A-Z])(\d+)\s+(.*)$')        # 00A11 name
RE_GS_DRUM = re.compile(r'^(\d{3})-(\d{3})\s+(.*)$')            # also double
RE_INDEX = re.compile(r'^(\d{3})\s+(.*\S)$')                    # BBB name
RE_VAR = re.compile(r'^\+(\+(\d+)\s+Mains?)')  # placeholder
RE_VAR2 = re.compile(r'^\+\+(\d+)\s+Mains')

for dirpath, dirnames, filenames in os.walk(ROOT):
    for fn in filenames:
        if not fn.upper().endswith('.SND') and not fn.lower().endswith('.snd'):
            # also capture GSdrums.txt style drum maps? keep SND only here
            continue
        path = os.path.join(dirpath, fn)
        relpath = rel(path)
        # guess manufacturer from path
        low = relpath.lower()
        mfg = 'unknown'
        if 'initya' in low or 'init_ya' in low or 'inityamaha' in low:
            mfg = 'Yamaha'
        elif 'initkorg' in low:
            mfg = 'Korg'
        elif 'init_rol' in low or 'initrol' in low:
            mfg = 'Roland'
        elif 'inittech' in low:
            mfg = 'Technics'
        elif 'initsolt' in low:
            mfg = 'Solton'
        elif 'initkaw' in low:
            mfg = 'Kawai'
        elif 'initw' in low or 'init_w' in low:
            mfg = 'Wersi'
        elif 'initg' in low or 'init_g' in low or 'gem' in low:
            mfg = 'GEM'
        elif 'initk' in low:  # InitKurz, Init_Korg already handled
            mfg = 'Kurzweil' if 'kurz' in low else 'Korg'
        elif 'initorla' in low:
            mfg = 'ORLA'
        elif 'initb' in low or 'init_boe' in low or 'bohm' in low:
            mfg = 'Böhm'
        elif 'initbiab' in low:
            mfg = 'BIAB'
        elif 'inits' in low and 'rol' not in low:
            mfg = 'Solton/Ketron?'

        try:
            raw = open(path, 'rb').read()
        except Exception as e:
            errors.append({'file': relpath, 'error': str(e)})
            continue

        # decode: try cp1252/latin-1, strip NULs for mixed
        text = raw.replace(b'\x00', b'\n').decode('latin-1', errors='replace')
        # normalize newlines
        lines = [ln.rstrip('\r') for ln in text.split('\n')]

        category = None
        variants = None
        file_style = None  # detect subtype
        n_before = len(records)

        for ln in lines:
            if not ln.strip():
                continue
            if RE_VAR2.match(ln):
                m = RE_VAR2.match(ln)
                variants = int(m.group(1))
                file_style = file_style or 'yamaha_var'
                continue
            if ln.startswith('***'):
                category = ln.lstrip('*').strip()
                file_style = file_style or 'cat_triple'
                continue
            if ln.startswith('---'):
                continue

            # CSV comma list (Korg i30 style): no dashes, commas
            if ',' in ln and not ln.startswith(('***', '+++')):
                # could be pure name list
                parts = [p.strip() for p in ln.split(',') if p.strip()]
                # only treat as name list if no numeric dash tokens
                if parts and not re.match(r'^\d{3}-', parts[0]):
                    for i, name in enumerate(parts):
                        records.append({
                            'file': relpath, 'mfg': mfg, 'category': category,
                            'msb': None, 'pc': None, 'type': None,
                            'name': name, 'flag': None, 'variants': variants,
                            'form': 'csv_name_list', 'index': i,
                        })
                    file_style = file_style or 'korg_csv'
                    continue

            m = RE_TRIPLE.match(ln)
            if m:
                a, b, c, name = m.group(1), m.group(2), m.group(3), m.group(4)
                # flag prefix
                flag = None
                nm = re.match(r'^([A-Za-z]{1,3})!\s*(.*)$', name)
                if nm and len(nm.group(1)) <= 3:
                    flag = nm.group(1) + '!'
                    name = nm.group(2)
                # trailing spaces for Korg
                name_clean = name.rstrip()
                records.append({
                    'file': relpath, 'mfg': mfg, 'category': category,
                    'msb': int(a), 'pc': int(b), 'type': int(c),
                    'name': name_clean, 'flag': flag, 'variants': variants,
                    'form': 'triple', 'index': None,
                })
                file_style = file_style or 'cat_triple'
                continue

            m = RE_TRIPLE_T.match(ln)  # Technics 4-digit middle
            if m and len(m.group(2)) == 4:
                a, b, c, name = m.group(1), m.group(2), m.group(3), m.group(4)
                records.append({
                    'file': relpath, 'mfg': mfg, 'category': category,
                    'msb': int(a), 'pc': int(b), 'type': int(c),
                    'name': name.rstrip(), 'flag': None, 'variants': variants,
                    'form': 'triple_tech', 'index': None,
                })
                continue

            m = RE_GS_NAME.match(ln)
            if m and re.match(r'^\d{2}[A-Z]\d+$', m.group(1) + m.group(2) + m.group(3)):
                records.append({
                    'file': relpath, 'mfg': mfg, 'category': category or 'GS',
                    'msb': None, 'pc': None, 'type': None,
                    'name': m.group(4).rstrip(), 'flag': None, 'variants': variants,
                    'form': 'gs_name', 'index': None,
                    'gs_bank': m.group(2), 'gs_num': int(m.group(3)),
                    'gs_prefix': int(m.group(1)),
                })
                file_style = file_style or 'gs_name'
                continue

            m = RE_DOUBLE.match(ln)
            if m:
                a, b, name = m.group(1), m.group(2), m.group(3)
                records.append({
                    'file': relpath, 'mfg': mfg, 'category': category,
                    'msb': int(a), 'pc': int(b), 'type': None,
                    'name': name.rstrip(), 'flag': None, 'variants': variants,
                    'form': 'double', 'index': None,
                })
                file_style = file_style or 'double'
                continue

            m = RE_INDEX.match(ln)
            if m and not ln.startswith(('***', '+++', '---')):
                # avoid capturing random text like version headers
                if category is not None or file_style in ('index',):
                    records.append({
                        'file': relpath, 'mfg': mfg, 'category': category,
                        'msb': int(m.group(1)), 'pc': None, 'type': None,
                        'name': m.group(2).rstrip(), 'flag': None, 'variants': variants,
                        'form': 'index_name', 'index': int(m.group(1)),
                    })
                    file_style = file_style or 'index'
                continue

        if file_style is None:
            errors.append({'file': relpath, 'error': 'no_records', 'n_lines': len(lines)})

# Write JSON
with open(OUT_JSON, 'w', encoding='utf-8') as f:
    json.dump({'records': records, 'errors': errors,
               'n': len(records),
               'files': sorted(set(r['file'] for r in records))},
              f, ensure_ascii=False, indent=1)

# Write CSV
fields = ['file', 'mfg', 'category', 'form', 'msb', 'pc', 'type',
          'flag', 'name', 'variants', 'index', 'gs_prefix', 'gs_bank', 'gs_num']
with open(OUT_CSV, 'w', encoding='utf-8-sig', newline='') as f:
    w = csv.DictWriter(f, fieldnames=fields, extrasaction='ignore')
    w.writeheader()
    for r in records:
        w.writerow(r)

print(f'records: {len(records)}')
print(f'files: {len(set(r["file"] for r in records))}')
print(f'errors: {len(errors)}')
for e in errors[:30]:
    print(' ERR', e)

# stats by form
from collections import Counter
print('forms:', Counter(r['form'] for r in records))
print('mfg:', Counter(r['mfg'] for r in records))
# unique files summary
print('\n--- per file ---')
byfile = {}
for r in records:
    byfile.setdefault(r['file'], Counter())[r['form']] += 1
for fn in sorted(byfile):
    print(f'  {fn}: {dict(byfile[fn])}')
