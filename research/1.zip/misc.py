﻿import os, re, struct
d = r"C:\Users\Baja\Desktop\Nova mapa\Style Works XT Universal\InitKorg"
def hd(b, base=0, w=16):
    out=[]
    for i in range(0,len(b),w):
        c=b[i:i+w]
        out.append('%08X  %-47s  |%s|'%(base+i,' '.join('%02X'%x for x in c),
                   ''.join(chr(x) if 32<=x<127 else '.' for x in c)))
    return '\n'.join(out)
print("### KBS / BSQ / ARG / ARK / SNG headers")
for fn in ["INIT_I30.KBS","INIT_I40.KBS","INIT_I30.BSQ","INIT_I40.BSQ","INIT_I30.ARG","INIT_I30.ARK"]:
    data=open(os.path.join(d,fn),'rb').read()
    print("="*80); print(fn,"size",len(data)); print(hd(data[:64]))
print()
print("### .SND text lists in InitKorg (line count, encoding, sample)")
for fn in sorted(os.listdir(d)):
    if not fn.lower().endswith('.snd'): continue
    raw=open(os.path.join(d,fn),'rb').read()
    txt=raw.decode('latin-1')
    lines=txt.splitlines()
    print("-"*70)
    print("%s  bytes=%d  printable=%.3f  lines=%d  CRLF=%s"%(
        fn,len(raw),sum(1 for b in raw if 32<=b<127 or b in (9,10,13))/len(raw),
        len(lines), raw.count(b'\r\n')))
    for L in lines[:6]: print("    |",L)
    if len(lines)>6: print("    ... last: |",lines[-1])
print()
print("### i3 ARR header offsets decode")
data=open(os.path.join(d,"Init_i3.arr"),'rb').read()
o=struct.unpack('<4I',data[0x10:0x20])
print("   LE u32 @0x10 = %s"%(tuple(hex(x) for x in o),))
print("   0x20..0x27F = %d bytes = %d x 10-char names; 0x280..0x29F=%d; 0x2A0..0x20BF=%d; 0x20C0..EOF=%d"%(
    o[1]-o[0], (o[1]-o[0])//10, o[2]-o[1], o[3]-o[2], len(data)-o[3]))
print("   name count @0x20:", (o[1]-o[0])//10, "-> %r ... %r"%(data[0x20:0x2A], data[o[1]-10:o[1]]))
