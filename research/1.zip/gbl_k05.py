﻿from pathlib import Path
import struct
data = Path(r"C:\Users\Baja\Desktop\Nova mapa\NEWNAME.SET\GLOBAL\SETUP.GBL").read_bytes()
pos = 8 + 8 + 12
size = struct.unpack(">I", data[pos + 4:pos + 8])[0]
pay = data[pos + 8:pos + 8 + size]
print("kind05 size", size, "entries", size / 24)
for i in range(0, size, 24):
    e = pay[i:i + 24]
    name = e[:16].split(b"\x00")[0].decode("ascii", "replace")
    meta = e[16:24].hex(" ")
    print(f"{i // 24:3d} name={name!r:22s} meta={meta}")
