import sys, os, glob, re, collections
sys.path.insert(0, r"C:\Users\Baja\Desktop\Nova mapa")
from pa800_native import parse_bank, decode_oc31, parse_type06_trackinfo, parse_type09

D = r"C:\Users\Baja\Desktop\Nova mapa\Style Works XT Universal\InitKorg"

def dec(r):
    p = r.payload
    if p[:4] in (b"OC31", b"OC32"):
        return decode_oc31(b"OC31" + p[4:])
    return p

# --- ROM lists ---
roms = {}
for f in glob.glob(os.path.join(D, "*.SND")) + glob.glob(os.path.join(D, "*.snd")):
    txt = open(f, "rb").read().decode("latin1")
    rows = re.findall(r"^(\d{3})-(\d{3})-(\d{3}) (.+)$", txt, re.M)
    roms[os.path.basename(f)] = rows
for nm, rows in roms.items():
    f1 = collections.Counter(r[0] for r in rows)
    f2 = collections.Counter(r[1] for r in rows)
    f3 = collections.Counter(r[2] for r in rows)
    print(f"{nm}: {len(rows)} rows; field1 top={f1.most_common(5)}; field2 top={f2.most_common(5)}; field3 top={f3.most_common(6)}")
    print("   first:", rows[:3], " last:", rows[-2:])

# --- STY selectors ---
def selectors(path):
    data = open(path, "rb").read()
    if data[:4] != b"\x01\x00\x01\x14":
        return None, None, None
    bank = parse_bank(data)
    styles, sts_names = [], []
    for i, r in enumerate(bank.resources):
        out = dec(r)
        if r.kind == 6:
            try:
                tis = parse_type06_trackinfo(out)
            except Exception as e:
                tis = []
            # style name
            n = out[16] if len(out) > 16 else 0
            nm = out[17:17+n].decode("latin1", "replace") if 1 <= n <= 32 else "?"
            sels = []
            for blk in tis:
                for t in blk["tracks"]:
                    sels.append((t["bank_msb"], t["bank_lsb"], t["program"]))
            styles.append((i, nm, sels, tis))
        elif r.kind == 9:
            try:
                t9 = parse_type09(out)
                sts_names.extend([ns.name for ns in t9.named_slots])
            except Exception as e:
                sts_names.append(f"<err {e}>")
    return styles, sts_names, bank

# selector sets per style file, matched against rom lists
def best_rom(selset):
    scores = {}
    for nm, rows in roms.items():
        for order in ("msb-lsb-prg", "lsb-msb-prg"):
            if order == "msb-lsb-prg":
                s = {(int(r[0]), int(r[1]), int(r[2])) for r in rows}  # wait rows are (f1,f2,f3)
            else:
                s = {(int(r[1]), int(r[0]), int(r[2])) for r in rows}
            inter = len(selset & s)
            scores[(nm, order)] = inter
    return sorted(scores.items(), key=lambda kv: -kv[1])[:4]

for f in sorted(set(glob.glob(os.path.join(D, "*.STY")) + glob.glob(os.path.join(D, "*.sty")))):
    styles, sts, bank = selectors(f)
    if styles is None:
        print(f"\n### {os.path.basename(f)}: i-series, skip")
        continue
    allsel = set()
    for i, nm, sels, tis in styles:
        allsel.update(sels)
    print(f"\n### {os.path.basename(f)}: {len(styles)} styles, {len(allsel)} distinct selectors")
    print("   style names:", [nm for _, nm, _, _ in styles][:20])
    print("   STS names:", sts[:12])
    print("   selector sample:", sorted(allsel)[:10])
    print("   best rom match:", best_rom(allsel))
