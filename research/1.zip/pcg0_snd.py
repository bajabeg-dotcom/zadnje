import sys, io, re, os, collections
sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding='utf-8', errors='replace')
D = r'C:\Users\Baja\Desktop\Nova mapa\Style Works XT Universal\InitKorg'
FILES = {'PA80':'rom_PA80.SND','PA1X':'rom_PA1x.SND','PA2X_PA800':'rom_PA2x.SND',
         'PA3X':'rom_PA3x.SND','PA4X':'rom_PA4x.SND'}
LINE = re.compile(r"^(\d{3})-(\d{3})-(\d{3})\s+(.*)$")

for model, fn in FILES.items():
    p = os.path.join(D, fn)
    rows = []; group = ''
    for line in open(p, encoding='latin1').read().splitlines():
        if line.startswith('***'):
            group = line.strip('* ').strip(); continue
        m = LINE.match(line)
        if m:
            pr, lsb, msb = map(int, m.groups()[:3])
            rows.append((msb, lsb, pr, m.group(4).strip(), group))
    print(f'\n#### {model}  {fn}  entries={len(rows)}')
    print('  sections:', sorted({r[4] for r in rows}))
    lsbhist = collections.Counter((r[0], r[1]) for r in rows)
    print('  (msb,lsb) groups:', dict(sorted(lsbhist.items())))
    print('  -- entries with lsb>=64:')
    for r in rows:
        if r[1] >= 64:
            print(f'     msb={r[0]:3d} lsb={r[1]:3d} prog={r[2]:3d} {r[3]!r} [{r[4]}]')
