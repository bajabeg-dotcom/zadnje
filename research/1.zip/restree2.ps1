﻿$p="C:\Users\Baja\Desktop\Nova mapa\KORG PA Manager\v3\KORGPAManager.exe"
$b=[IO.File]::ReadAllBytes($p)
$BASE=0x0133C800; $RVA=0x04E73000; $RSZ=0x6F800
function Off($r){ return ($r - $RVA + $BASE) }
function InR($r){ return ($r -ge $RVA -and $r -lt ($RVA+$RSZ)) }
function ReadNm($nameField){
  $rel = $nameField -band 0x7FFFFFFF
  $o = $BASE + $rel
  if($o -lt 0 -or $o+2 -ge $b.Length){ return "<bad>" }
  $len=[BitConverter]::ToUInt16($b,$o); $o2=$o+2
  if($len -gt 200 -or $o2+$len*2 -gt $b.Length){ return "<bad2>" }
  $sb=New-Object Text.StringBuilder
  for($i=0;$i -lt $len;$i++){ [void]$sb.Append([char][BitConverter]::ToUInt16($b,$o2+$i*2)) }
  return $sb.ToString()
}
$out = New-Object System.Collections.Generic.List[string]
function Walk($dir,$path,$depth){
  if($depth -gt 4){return}
  if(-not (InR $dir)){ $out.Add("STOP(bad dir $path)"); return }
  $o=Off $dir
  $nn=[BitConverter]::ToUInt16($b,$o+12); $no=[BitConverter]::ToUInt16($b,$o+14)
  if($nn+$no -gt 500){ $out.Add("STOP(bad counts $path nn=$nn no=$no)"); return }
  for($e=0;$e -lt ($nn+$no);$e++){
    $eo=$o+16+$e*8
    $name=[BitConverter]::ToUInt32($b,$eo)
    $off=[BitConverter]::ToUInt32($b,$eo+4)
    $label = if($name -band 0x80000000){ ReadNm $name } else { "$name" }
    if($off -band 0x80000000){ Walk ($dir+($off -band 0x7FFFFFFF)) "$path/$label" ($depth+1) }
    else {
      $fo=Off ($dir+($off -band 0x7FFFFFFF))
      if($fo -lt 0 -or $fo+16 -gt $b.Length){ $out.Add("$path/$label  <bad data entry>"); continue }
      $dRva=[BitConverter]::ToUInt32($b,$fo); $dSz=[BitConverter]::ToUInt32($b,$fo+4)
      $dPage=[BitConverter]::ToUInt32($b,$fo+8); $dCode=[BitConverter]::ToUInt16($b,$fo+12)
      $fo2=Off $dRva
      $out.Add(("{0,-45} dataRVA=0x{1:X8} file=0x{2:X} size=0x{3:X} codepage={4}" -f "$path/$label",$dRva,$fo2,$dSz,$dCode))
    }
  }
}
Walk $RVA "" 0
$out -join "`n"
