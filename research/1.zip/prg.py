﻿import os, re, struct, collections
d = r"C:\Users\Baja\Desktop\Nova mapa\Style Works XT Universal\InitKorg"
def hd(b, base=0, w=16):
    out=[]
    for i in range(0,len(b),w):
        c=b[i:i+w]
        out.append('%08X  %-47s  |%s|'%(base+i,' '.join('%02X'%x for x in c),
                   ''.join(chr(x) if 32<=x<127 else '.' for x in c)))
    return '\n'.join(out)

print("### PRG around 0x5B80 (after 136 stride-172 names)")
data=open(os.path.join(d,"INIT_I30.PRG"),'rb').read()
print(hd(data[0x5B60:0x5C40],0x5B60))
print(" ... section boundary probe: find all offsets where 16 printable bytes occur after 0x5B00")
for m in re.finditer(rb'[A-Za-z0-9][A-Za-z0-9 \.\-\+\']{5,14}  ', data[0x5B00:]):
    print("    0x%X %r"%(0x5B00+m.start(), m.group()))

print()
print("### name offsets in PRG (all), stride histogram")
offs=[m.start() for m in re.finditer(rb'[A-Z][A-Za-z0-9 \.\-\+\']{6,14}  ', data)]
print("   count=%d  first=%s  last=%s"%(len(offs),[hex(o) for o in offs[:3]],[hex(o) for o in offs[-3:]]))
c=collections.Counter(offs[i]-offs[i-1] for i in range(1,len(offs)))
print("   deltas:",c.most_common(6))
# print section sizes hypothesis: header fields
print("   header @0x14: %s"%data[0x14:0x18].hex(' ').upper())

print()
print("### verify KBEG offset table == record offsets [1:-1]")
for fn in sorted(os.listdir(d)):
    if not fn.lower().endswith('.sty'): continue
    p=os.path.join(d,fn); data=open(p,'rb').read()
    if data[:4]!=b'\x01\x00\x01\x14': continue
    i=data.rfind(b'KBEG'); j=data.rfind(b'KEND')
    n=struct.unpack('>I',data[j+4:j+8])[0]
    cnt=(j-i-4)//4
    offs=[struct.unpack('>I',data[i+4+4*k:i+8+4*k])[0] for k in range(cnt)]
    recs=[]; pos=8
    while pos+8<=len(data):
        s=struct.unpack('>I',data[pos+4:pos+8])[0]
        if pos+8+s>len(data): break
        recs.append(pos); pos+=8+s
    print("   %-14s n=%d  offs==recs[1:-1] -> %s   offs[0..2]=%s  recs[0..3]=%s"
          %(fn,n,offs==recs[1:-1],[hex(o) for o in offs[:3]],[hex(o) for o in recs[:4]]))
