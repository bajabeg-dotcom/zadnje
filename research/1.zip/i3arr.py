﻿import os, struct
d = r"C:\Users\Baja\Desktop\Nova mapa\Style Works XT Universal\InitKorg"
data=open(os.path.join(d,"Init_i3.arr"),'rb').read()
def ok16(b): return all(32<=x<127 for x in b)
print("i3 ARR size",len(data))
print("LE u32 @0x10..0x1F:", [hex(x) for x in struct.unpack('<4I',data[0x10:0x20])])
# walk 10-byte name entries from 0x20
off=0x20; n=0
while off+10<=len(data) and ok16(data[off:off+10]):
    n+=1; off+=10
print("consecutive 10-byte printable entries from 0x20: %d, stop at 0x%X"%(n,off))
print("   first5:", [data[0x20+10*k:0x30+10*k] for k in range(5)])
print("   last3 :", [data[off-30:off-20], data[off-20:off-10], data[off-10:off]])
print("   next 32 bytes:", data[off:off+32].hex(' ').upper())
# try 16-byte entries too
off2=0x20; m=0
while off2+16<=len(data) and ok16(data[off2:off2+16]):
    m+=1; off2+=16
print("consecutive 16-byte printable entries from 0x20: %d, stop at 0x%X"%(m,off2))
# section boundaries: what is at 0x280 / 0x2A0 / 0x20C0
for o in (0x280,0x2A0,0x20C0):
    print("  @0x%X: %s  %r"%(o,data[o:o+24].hex(' ').upper(),data[o:o+24]))
print()
print("--- i30 ARR record 0 raw (0x20..0xC4) ---")
a=open(os.path.join(d,"INIT_I30.ARR"),'rb').read()
for i in range(0,0xA4,16):
    c=a[0x20+i:0x30+i]
    print("%08X  %-47s  |%s|"%(0x20+i,' '.join('%02X'%x for x in c),''.join(chr(x) if 32<=x<127 else '.' for x in c)))
print("... record2 @0xC4:", a[0xC4:0xD4])
