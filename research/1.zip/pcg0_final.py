import sys, io, os, re, collections
sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding='utf-8', errors='replace')
sys.path.insert(0, r'C:\Users\Baja\Desktop\Nova mapa')
from pa800_native.sty_container import parse_bank

PRG = r'C:\Users\Baja\Desktop\PA800_AI_PA800_STUDIO_v5_2026-09-20\factory_evidence\native_factory\SOUND\PRGMAPS.TBL'
ROM = r'C:\Users\Baja\Desktop\PA800_AI_PA800_STUDIO_v5_2026-09-20\factory_evidence\native_factory\SOUND\ROM.PCG'
SND = r'C:\Users\Baja\Desktop\Nova mapa\Style Works XT Universal\InitKorg\rom_PA2x.SND'
LINE = re.compile(r"^(\d{3})-(\d{3})-(\d{3})\s+(.*)$")

bank = parse_bank(open(PRG, 'rb').read())
sl = bank.resources[5].payload
pos = 8; entries = []
while pos < len(sl):
    n = int.from_bytes(sl[pos:pos+2], 'big'); pos += 2
    if n == 0: break
    for i in range(n):
        e = sl[pos:pos+6]; pos += 6
        entries.append((int.from_bytes(e[0:2], 'big'), e[2], e[3], e[4], e[5]))
cat = [r for r in parse_bank(open(ROM, 'rb').read()).resources if r.kind == 5][0].payload
names = [cat[i*24:(i+1)*24].split(b'\x00')[0].decode('ascii', 'replace').strip() for i in range(len(cat)//24)]

snd = {}
for line in open(SND, encoding='latin1').read().splitlines():
    m = LINE.match(line)
    if m:
        pr, lsb, msb = map(int, m.groups()[:3])
        snd[(msb, lsb, pr)] = m.group(4).strip()

def norm(s):
    return re.sub(r'[^a-z0-9]+', '', s.lower())

N_MEL = sum(1 for e in entries if e[0] == 121)
print(f'entries={len(entries)} melodic(msb121)={N_MEL} drums(msb120)={sum(1 for e in entries if e[0]==120)}')

ok = bad = miss = 0
badlist = []
for msb, lsb, pc, hi, lo in entries:
    ordi = (N_MEL + lo) if msb == 120 else ((hi << 7) | lo)
    rom = names[ordi] if ordi < len(names) else '<out-of-range>'
    s = snd.get((msb, lsb, pc))
    if s is None:
        miss += 1; badlist.append(('no-snd', (msb, lsb, pc), rom, None)); continue
    if norm(rom) == norm(s): ok += 1
    else:
        bad += 1; badlist.append(('diff', (msb, lsb, pc), rom, s))
print(f'normalized name match: OK={ok}  DIFF={bad}  no-SND-address={miss}  total={len(entries)}')
for b in badlist[:15]:
    print('  ', b)

# SND addresses not present in SoundsLayout (extra)
sl_addr = {(e[0], e[1], e[2]) for e in entries}
extra = [k for k in snd if k not in sl_addr]
print(f'\nSND addresses={len(snd)}  in SoundsLayout={sum(1 for k in snd if k in sl_addr)}  extra SND={len(extra)}')
print('  extra sample:', sorted(extra)[:10])
print('  drums SND pc set vs SL pc set:')
snd_drums = sorted(k[2] for k in snd if k[0] == 120 and k[1] == 0)
sl_drums = sorted(e[2] for e in entries if e[0] == 120)
print('   SND pcs:', snd_drums)
print('   SL  pcs:', sl_drums)
print('   SND-only:', sorted(set(snd_drums) - set(sl_drums)), ' SL-only:', sorted(set(sl_drums) - set(snd_drums)))
