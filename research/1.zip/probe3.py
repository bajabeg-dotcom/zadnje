#!/usr/bin/env python3
"""Probe comp semantics: zlib attempt + id=19 header dump."""
import hashlib
import struct
import zlib
from collections import Counter
from pathlib import Path

PKG = Path(r"E:\PA4\Pa4X Operating System v.3.1.0\Pa4X_Operating_System_v310.pkg")
data = PKG.read_bytes()

pos = 16
chunks = []
while pos + 8 <= len(data):
    cid, size = struct.unpack_from("<II", data, pos)
    if cid == 0 or size == 0 or size > len(data):
        break
    chunks.append((pos, cid, size))
    pos += 8 + size
    if pos % 4:
        pos += 4 - (pos % 4)

records = []
for p, cid, size in chunks:
    if cid != 17:
        continue
    body = p + 8
    md5 = data[body:body + 16]
    dsize, = struct.unpack_from("<I", data, body + 24)
    comp, = struct.unpack_from("<B", data, body + 28)
    i = body + 29
    strs = []
    for _ in range(3):
        z = data.index(b"\0", i)
        strs.append(data[i:z].decode("latin1"))
        i = z + 1
    header_len = i - body
    stored = size - header_len
    records.append(dict(pos=body, md5=md5, dsize=dsize, comp=comp, path=strs[0],
                        date=strs[1], time=strs[2], header_len=header_len,
                        stored=stored, size=size, payload=data[i:i + stored]))

print("=== header dumps (first record per comp) ===")
seen = set()
for r in records:
    if r["comp"] in seen:
        continue
    seen.add(r["comp"])
    print(f"comp={r['comp']} path={r['path']}")
    print("  header hex:", data[r['pos']:r['pos'] + r['header_len']].hex())
    print("  payload[:48]:", r['payload'][:48].hex())
    print(f"  header_len={r['header_len']} stored={r['stored']} dsize={r['dsize']} delta={r['stored'] - r['dsize']}")

print("\n=== comp=1 zlib attempt ===")
ok = fail = noz = 0
for r in records:
    if r["comp"] != 1:
        continue
    off = r["payload"].find(b"\x78\xda")
    if off < 0:
        off = r["payload"].find(b"\x78\x9c")
    if off < 0:
        off = r["payload"].find(b"\x78\x01")
    if off < 0:
        noz += 1
        print("  NO ZLIB:", r["path"], r["payload"][:24].hex())
        continue
    try:
        out = zlib.decompress(r["payload"][off:])
    except Exception as e:
        # try decompressobj to consume trailing junk
        try:
            out = zlib.decompressobj().decompress(r["payload"][off:])
        except Exception as e2:
            print(f"  FAIL {r['path']}: {e2}")
            fail += 1
            continue
    m = hashlib.md5(out).hexdigest()
    match = m == r["md5"].hex()
    ok += match
    fail += (not match)
    if not match or r["path"].endswith("Eng.LNG") or r["path"].endswith("SYSTEM.GBL"):
        print(f"  {'OK ' if match else 'MD5MISMATCH'} off={off} out={len(out)} dsize={r['dsize']} "
              f"payload={r['stored']} path={r['path']} head={out[:40]!r}")
print(f"comp=1: md5ok={ok} md5bad={fail} nozlib={noz}")

print("\n=== comp=16 deltas ===")
deltas = Counter()
for r in records:
    if r["comp"] == 16:
        deltas[r["stored"] - r["dsize"]] += 1
print(sorted(deltas.items()))
# check header 12 vs not
for r in [x for x in records if x["comp"] == 16][:4]:
    print(f"  {r['path'][:50]:<50} hdr={r['header_len']} stored={r['stored']} dsize={r['dsize']}")
    print(f"     payload[:32]={r['payload'][:32].hex()}")

print("\n=== id=19 header (body -> tar) ===")
for p, cid, size in chunks:
    if cid != 19:
        continue
    body = p + 8
    ustar = data.find(b"ustar", body, body + 600)
    print("header bytes:", data[body:ustar - 100].hex())
    print("ascii:", repr(data[body:ustar + 10]))
    # parse: md5(16) + le32 ?
    md5 = data[body:body + 16]
    for off in (16, 20, 24, 28):
        v, = struct.unpack_from("<I", data, body + off)
        print(f"  le32@{off} = {v} ({hex(v)})")
