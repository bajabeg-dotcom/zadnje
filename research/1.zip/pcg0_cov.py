import sys, io, os, re, glob, collections
sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding='utf-8', errors='replace')
sys.path.insert(0, r'C:\Users\Baja\Desktop\Nova mapa')
from setconvert.sty import StyBank
from setconvert import parameters as P
from setconvert import sts as S
from setconvert.sts import StsStats
from setconvert.detect import decode_payload
from setconvert.families import FAMILIES

SND_DIR = r'C:\Users\Baja\Desktop\Nova mapa\Style Works XT Universal\InitKorg'
FILES = {'pa800':'rom_PA2x.SND', 'pa1x':'rom_PA1x.SND', 'pa3x':'rom_PA3x.SND', 'pa4x':'rom_PA4x.SND'}
LINE = re.compile(r"^(\d{3})-(\d{3})-(\d{3})\s+(.*)$")

def load_snd(model):
    d = {}
    group = ''
    for line in open(os.path.join(SND_DIR, FILES[model]), encoding='latin1').read().splitlines():
        if line.startswith('***'):
            group = line.strip('* ').strip(); continue
        m = LINE.match(line)
        if m:
            pr, lsb, msb = map(int, m.groups()[:3])
            d[(msb, lsb, pr)] = (m.group(4).strip(), group)
    return d

SETS = [
    ('pa800', r'C:\Users\Baja\Desktop\KOCE FOLK.SET'),
    ('pa800', r'C:\Users\Baja\Desktop\GOLE ARX .SET'),
    ('pa1x',  r'C:\Users\Baja\Desktop\Pantic Pa1X.SET'),
    ('pa3x',  r'C:\Users\Baja\Desktop\Korg Pa3x Team Serbian.SET'),
    ('pa4x',  r'C:\Users\Baja\Desktop\Pa4x Pro Dejan Shiki.SET'),
]

for family, root in SETS:
    snd = load_snd(family)
    stys = sorted({p for p in glob.glob(os.path.join(root, '**', '*'), recursive=True)
                   if p.lower().endswith('.sty')})[:8]
    dialect = FAMILIES[family].sts_dialect
    sel = collections.Counter()
    for sty in stys:
        try: bank = StyBank.read(sty)
        except Exception: continue
        for res in bank.resources:
            try:
                if res.kind == 6:
                    for blk in P.find_blocks(decode_payload(res.payload)):
                        for rec in blk.records: sel[rec.selector] += 1
                elif res.kind == 9:
                    st = StsStats()
                    for slot in S.read_document_slots(decode_payload(res.payload), dialect, None, st):
                        for row in slot.selectors: sel[row] += 1
            except Exception: pass
    total_hits = sum(sel.values())
    missing = {k: v for k, v in sel.items() if k not in snd}
    miss_hits = sum(missing.values())
    print(f'\n== {family} {os.path.basename(root)}: distinct={len(sel)} covered={len(sel)-len(missing)}/{len(sel)}'
          f'  hits={total_hits-miss_hits}/{total_hits}')
    if missing:
        top = sorted(missing.items(), key=lambda kv: -kv[1])[:8]
        print('   missing top:', [(k, v) for k, v in top])
    # sample resolved names for the most used
    for k, v in sorted(sel.items(), key=lambda kv: -kv[1])[:5]:
        nm, grp = snd.get(k, ('?', '?'))
        print(f'   {k} x{v:5d} -> {nm!r} [{grp}]')
