import sys, io, os, re
sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding='utf-8', errors='replace')
sys.path.insert(0, r'C:\Users\Baja\Desktop\Nova mapa')
from pa800_native.sty_container import parse_bank

FILES = [
 (r'C:\Users\Baja\Desktop\Pa4x Pro Dejan Shiki.SET\SOUND\USER01.PCG', 121),
 (r'C:\Users\Baja\Desktop\Pa4x Pro Dejan Shiki.SET\SOUND\USER02.PCG', 103),
 (r'C:\Users\Baja\Desktop\Pa4x Pro Dejan Shiki.SET\SOUND\USER03.PCG', 117),
 (r'C:\Users\Baja\Desktop\Pa4x Pro Dejan Shiki.SET\SOUND\USER04.PCG', 124),
 (r'C:\Users\Baja\Desktop\Pa4x Pro Dejan Shiki.SET\SOUND\USERDK01.PCG', 97),
]

def walk_v1(payload, end_marker_ok=True):
    """pa4x kind05 v1 catalog: record = u16 A, u16 B, 00 02 00 1c, name(16), pad(15), meta.
    Hypothesis: record length = A + 2."""
    recs = []
    off = 0
    err = None
    while off < len(payload):
        if off + 8 > len(payload):
            err = f'truncated header at {off}'; break
        a = int.from_bytes(payload[off:off+2], 'big')
        b = int.from_bytes(payload[off+2:off+4], 'big')
        sig = payload[off+4:off+8]
        if sig != b'\x00\x02\x00\x1c':
            err = f'bad signature {sig.hex()} at {off} (A={a} B={b})'; break
        ln = a + 2
        if ln < 39 or off + ln > len(payload):
            err = f'bad length {ln} at {off}'; break
        rec = payload[off:off+ln]
        name = rec[8:24].split(b'\x00')[0].decode('ascii', 'replace')
        meta = rec[39:] if ln > 39 else b''
        recs.append({'off': off, 'a': a, 'b': b, 'len': ln, 'name': name, 'meta': meta})
        off += ln
    if off != len(payload) and err is None:
        err = f'walk ended at {off} of {len(payload)}'
    return recs, err

def walk_fixed24(payload):
    return [{'off': i*24, 'name': payload[i*24:i*24+16].split(b'\x00')[0].decode('ascii','replace'),
             'meta': payload[i*24+16:i*24+24]}
            for i in range(len(payload)//24)], (None if len(payload) % 24 == 0 else 'remainder')

for path, expect_progs in FILES:
    bank = parse_bank(open(path, 'rb').read())
    cat = [r for r in bank.resources if r.kind == 5]
    progs = [r for r in bank.resources if r.kind == 16]
    assert len(cat) == 1, (path, len(cat))
    c = cat[0]
    print(f'== {os.path.basename(path)} hdr={c.header.hex(" ")} size={len(c.payload)} progs={len(progs)} expected_progs={expect_progs}')
    recs, err = walk_v1(c.payload)
    print(f'   v1 walk: {len(recs)} records  err={err}')
    if recs:
        lens = [r['len'] for r in recs]
        print(f'   len min/max={min(lens)}/{max(lens)}  A range={min(r["a"] for r in recs)}/{max(r["a"] for r in recs)}')
        names = [r['name'] for r in recs]
        empty = sum(1 for n in names if not n)
        print(f'   empty names={empty}  first5={names[:5]}')
        # meta start byte pattern
        pat = {}
        for r in recs:
            k = r['meta'][:4].hex(' ') if len(r['meta']) >= 4 else '<short>'
            pat[k] = pat.get(k, 0) + 1
        print(f'   meta[:4] histogram: {sorted(pat.items(), key=lambda x: -x[1])[:6]}')
    print(f'   MATCH progs={len(progs)}: {len(recs) == len(progs)}')
    print()
