import sys
sys.path.insert(0, r'C:\Users\Baja\Desktop\Nova mapa')
from pathlib import Path
from setconvert.sty import StyBank
from pa800_native.oc31_codec import decode_oc31

SIZES = {48: ('genA', 6), 80: ('genB', 10), 88: ('genD', 11), 96: ('genE', 12)}


def walk_markers(payload, out, limit=6):
    for sub in range(0, 6):
        marker = bytes([0x02, 0x00, sub, 0x08])
        start = 0
        while True:
            p = payload.find(marker, start)
            if p < 0:
                break
            start = p + 1
            if p + 8 > len(payload):
                continue
            sz = int.from_bytes(payload[p + 4:p + 8], 'big')
            if sz in SIZES and p + 8 + sz <= len(payload):
                name, rec = SIZES[sz]
                block = payload[p + 8:p + 8 + sz]
                if len(block) == sz and sz % rec == 0:
                    key = (sub, sz)
                    out.setdefault(key, [])
                    if len(out[key]) < limit:
                        out[key].append((p, block))


def main(path):
    print('###', Path(path).name)
    data = Path(path).read_bytes()
    bank = StyBank.read(data)
    found = {}
    for i, r in enumerate(bank.resources):
        if r.kind != 6:
            continue
        payload = decode_oc31(r.payload) if r.compressed else r.payload
        walk_markers(payload, found)
    for (sub, sz), items in sorted(found.items()):
        name, rec = SIZES[sz]
        print(' marker 02 00 %02x 08 size=%d (%s, rec=%d)  hits shown=%d' % (sub, sz, name, rec, len(items)))
        for p, block in items[:2]:
            print('  @%d' % p)
            for row in range(0, sz, rec):
                print('    %02d: %s' % (row // rec, block[row:row + rec].hex(' ')))


for path in sys.argv[1:]:
    main(path)
