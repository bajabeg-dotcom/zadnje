import sys, os, struct, collections, glob
sys.path.insert(0, r"C:\Users\Baja\Desktop\Nova mapa")
from pa800_native import parse_bank, decode_oc31

D = r"C:\Users\Baja\Desktop\Nova mapa\Style Works XT Universal\InitKorg"

def walk(data):
    """PA/PX record walk: outer [tag][BE size] then inner records."""
    recs = []
    assert data[0:4] == b"\x01\x00\x01\x14", data[0:4].hex()
    outersize = int.from_bytes(data[4:8], "big")
    pos = 8
    end = 8 + outersize
    while pos < end:
        hdr = data[pos:pos+4]
        size = int.from_bytes(data[pos+4:pos+8], "big")
        recs.append((pos, hdr, size))
        pos += 8 + size
    return outersize, recs, pos

for f in sorted(glob.glob(os.path.join(D, "*.STY")) + glob.glob(os.path.join(D, "*.sty"))):
    data = open(f, "rb").read()
    print("=" * 90)
    print(os.path.basename(f), len(data))
    print("  head:", data[:32].hex(" "))
    try:
        outersize, recs, endpos = walk(data)
        print(f"  outer size={outersize} (len-8={len(data)-8}) walk_end={endpos} len={len(data)} nrec={len(recs)}")
    except AssertionError as e:
        print("  NOT PA/PX container:", e)
        continue
    # KORF record
    for pos, hdr, size in recs:
        if data[pos+8:pos+12] == b"KORF":
            print(f"  KORF rec @0x{pos:X} hdr={hdr.hex(' ')} size={size} payload={data[pos+8:pos+8+size].hex(' ')}")
    # type histogram
    hist = collections.Counter()
    classes = collections.Counter()
    for pos, hdr, size in recs:
        hist[hdr[0]] += 1
        classes[(hdr[0], hdr[1], hdr[2:].hex())] += 1
    print("  type hist:", dict(hist))
    print("  (type,index,class):", dict(classes))
    # compression magics inside payloads
    mag = collections.Counter()
    for pos, hdr, size in recs:
        pl = data[pos+8:pos+8+size]
        if pl[:4] in (b"OC31", b"OC32", b"OC30", b"OC33"):
            mag[pl[:4]] += 1
    print("  payload magics:", dict(mag))
    # pa800_native parse_bank
    try:
        bank = parse_bank(data)
        print(f"  parse_bank OK: prefix={len(bank.prefix)} nres={len(bank.resources)} trailer={len(bank.trailer)}")
        kinds = collections.Counter(r.kind for r in bank.resources)
        print("   kinds:", dict(kinds))
        # try decompress first resource of each kind
        seen = set()
        for i, r in enumerate(bank.resources):
            if r.kind in seen: continue
            seen.add(r.kind)
            if r.compressed:
                try:
                    out = decode_oc31(r.payload)
                    print(f"   res[{i}] kind=0x{r.kind:02X} compressed OC31 -> {len(out)} bytes OK, head={out[:16].hex(' ')}")
                except Exception as e:
                    print(f"   res[{i}] kind=0x{r.kind:02X} compressed FAIL: {e} magic={r.payload[:4]!r} head={r.payload[:16].hex(' ')}")
            else:
                print(f"   res[{i}] kind=0x{r.kind:02X} raw, size={len(r.payload)} head={r.payload[:16].hex(' ')}")
    except Exception as e:
        print("  parse_bank FAIL:", type(e).__name__, e)
