#!/usr/bin/env python3
"""Probe Pa4X .pkg chunk layout."""
import struct
import sys
from collections import Counter
from pathlib import Path

PKG = Path(r"E:\PA4\Pa4X Operating System v.3.1.0\Pa4X_Operating_System_v310.pkg")

data = PKG.read_bytes()
print("file size:", hex(len(data)), len(data))
print("prefix[0:16]:", data[0:16].hex())

# try walking from offset 16
pos = 16
chunks = []
while pos + 8 <= len(data):
    cid, size = struct.unpack_from("<II", data, pos)
    if cid == 0 or size == 0:
        print("stop at", hex(pos), "cid", cid, "size", size)
        break
    if size > len(data):
        print("insane size at", hex(pos), "cid", cid, "size", size)
        break
    chunks.append((pos, cid, size))
    pos += 8 + size
    # pad to 4
    if pos % 4:
        pos += 4 - (pos % 4)

print("chunks walked:", len(chunks), "end pos:", hex(pos), "== filesize:", pos == len(data))
print(Counter(c[1] for c in chunks))
for p, cid, size in chunks[:12]:
    print(f"  @{hex(p):>12} id={cid:<3} size={size:>10} ({hex(size)})")
print("  ...")
for p, cid, size in chunks[-6:]:
    print(f"  @{hex(p):>12} id={cid:<3} size={size:>10} ({hex(size)})")

# id=17 detail
n17 = 0
comp_counter = Counter()
for p, cid, size in chunks:
    if cid != 17:
        continue
    n17 += 1
    body = p + 8
    md5 = data[body:body + 16]
    owner, group, attrs, cond = struct.unpack_from("<HHHH", data, body + 16)
    dsize, = struct.unpack_from("<I", data, body + 24)
    comp, = struct.unpack_from("<B", data, body + 28)
    i = body + 29
    z = data.index(b"\0", i)
    path = data[i:z].decode("latin1")
    i = z + 1
    z = data.index(b"\0", i)
    date = data[i:z].decode("latin1")
    i = z + 1
    z = data.index(b"\0", i)
    timestr = data[i:z].decode("latin1")
    i = z + 1
    used = i - body + dsize
    if n17 <= 4 or used > size:
        print(f"id17#{n17}: size={size} used={used} dsize={dsize} comp={comp} path={path!r} date={date!r} t={timestr!r}"
              f" owner={owner} grp={group} attr={attrs} cond={cond} md5={md5.hex()}")
        if n17 <= 4:
            tail = data[p + 8 + size: p + 8 + size + 8]
            print("   next8 after chunk:", tail.hex())
    comp_counter[comp] += 1
print("id17 count:", n17, "comp values:", dict(comp_counter))

# rootfs (id=19) check tar magic
for p, cid, size in chunks:
    if cid == 19:
        off = p + 8
        print("id19 @", hex(off), "size", size, "magic:", data[off + 257:off + 262], data[off:off + 16].hex())
