import sys

sys.path.insert(0, r"C:\Users\Baja\Desktop\Nova mapa")

from pathlib import Path
from setconvert.sty import StyBank

PATHS = [
    r"C:\Users\Baja\Desktop\Pantic Pa1X.SET\STYLE\BANK01_LIVE.STY",
    r"C:\Users\Baja\Desktop\Pantic Pa1X.SET\STYLE\USER03.STY",
    r"C:\Users\Baja\Desktop\GOLE ARX .SET\GOLE ARX .SET\STYLE\FAVORITE01.STY",
    r"C:\Users\Baja\Desktop\GOLE ARX .SET\GOLE ARX .SET\STYLE\FAVORITE10.STY",
    r"C:\Users\Baja\Desktop\KOCE FOLK.SET\STYLE\FAVORITE05.STY",
    r"C:\Users\Baja\Desktop\Korg Pa3x Team Serbian.SET\STYLE\USER01.STY",
    r"C:\Users\Baja\Desktop\Korg Pa3x Team Serbian.SET\STYLE\FAVORITE12.STY",
    r"C:\Users\Baja\Desktop\Pa4x Pro Dejan Shiki.SET\STYLE\USER01.STY",
    r"C:\Users\Baja\Desktop\Pa4x Pro Dejan Shiki.SET\STYLE\USER03.STY",
    r"C:\Users\Baja\Desktop\STYLE\USER01_IZOLACIJA.STY",
    r"C:\Users\Baja\Desktop\USER01_PA800.STY",
    r"C:\Users\Baja\Desktop\BANK01.STY",
]

fails = 0
for raw in PATHS:
    p = Path(raw)
    data = p.read_bytes()
    try:
        bank = StyBank.read(raw)
        out = bank.build()
        if bank.kbeg_mode == "strict":
            ok = out == data
            tag = "identical" if ok else "DIFFERS"
            if not ok:
                fails += 1
            # rebuild once more from our own output to confirm stability
            again = StyBank.read(out)
            stable = again.build() == out
            print(f"{p.name:24s} {bank.kbeg_mode:9s} {tag:9s} stable={stable} kinds={bank.kinds}")
        else:
            from pa800_native.sty_container import parse_bank
            parse_bank(out)
            again = StyBank.read(out)
            ok = again.kbeg_mode == "strict" and again.build() == out
            same_payloads = [r.payload for r in again.resources] == [r.payload for r in bank.resources]
            print(f"{p.name:24s} {bank.kbeg_mode:9s} repaired_ok={ok} payloads_same={same_payloads} kinds={bank.kinds}")
            if not (ok and same_payloads):
                fails += 1
    except Exception as exc:
        fails += 1
        print(f"{p.name:24s} ERROR: {exc!r}")

print("FAILS:", fails)
