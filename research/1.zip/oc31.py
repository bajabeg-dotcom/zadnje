import struct
import sys


def oc31_backref(state, offset, length):
    out = state["out"]
    backref = len(out) - offset - 1
    if backref < 0:
        raise ValueError(f"backref before start: backref={backref} outlen={len(out)} offset={offset}")
    for _ in range(length):
        if backref >= len(out):
            raise ValueError("backref past end")
        out.append(out[backref])
        backref += 1
    last_byte = state["last_byte"]
    add_byte = last_byte & 3
    comp = state["comp"]
    pos = state["pos"]
    for _ in range(add_byte):
        if pos >= len(comp):
            raise ValueError("extra byte past end")
        out.append(comp[pos])
        pos += 1
    state["pos"] = pos


def oc31_uncompress(comp, compressed_size, uncompressed_size):
    state = {"comp": comp, "pos": 0, "out": bytearray(), "last_byte": 0}
    orig = 0
    while state["pos"] - orig < compressed_size:
        remaining = compressed_size - (state["pos"] - orig)
        if remaining <= 0:
            break
        flag_byte = comp[state["pos"]]
        state["pos"] += 1
        state["last_byte"] = flag_byte
        out_len_before = len(state["out"])

        if flag_byte >= 0x10:
            if flag_byte >= 0x40:
                unknown2 = comp[state["pos"]]
                state["pos"] += 1
                state["last_byte"] = unknown2
                tmp = (flag_byte << 8) | unknown2
                length = (tmp >> 13) + 1
                offset = (tmp >> 2) & 0x7FF
                oc31_backref(state, offset, length)
            elif flag_byte >= 0x20:
                tmp = flag_byte & 0x1F
                if tmp < 2:
                    if tmp == 0:
                        unknown2 = comp[state["pos"]]
                        state["pos"] += 1
                        state["last_byte"] = unknown2
                        length = unknown2 + 0x22
                        unknown3 = comp[state["pos"]]
                        unknown4 = comp[state["pos"] + 1]
                        state["pos"] += 2
                        state["last_byte"] = unknown4
                        offset = ((unknown3 << 8) | unknown4) >> 2
                        oc31_backref(state, offset, length)
                    else:
                        unknown3 = comp[state["pos"]]
                        unknown4 = comp[state["pos"] + 1]
                        length = (unknown3 << 8) | unknown4
                        unknown5 = comp[state["pos"] + 2]
                        unknown6 = comp[state["pos"] + 3]
                        state["pos"] += 4
                        state["last_byte"] = unknown6
                        offset = ((unknown5 << 8) | unknown6) >> 2
                        oc31_backref(state, offset, length)
                else:
                    tmp += 2
                    unknown2 = comp[state["pos"]]
                    unknown3 = comp[state["pos"] + 1]
                    state["pos"] += 2
                    state["last_byte"] = unknown3
                    offset = ((unknown2 << 8) | unknown3) >> 2
                    oc31_backref(state, offset, tmp)
            else:
                tmp = flag_byte & 7
                if tmp < 2:
                    if tmp == 0:
                        length = comp[state["pos"]] + 0xA
                        unknown3 = comp[state["pos"] + 1]
                        unknown4 = comp[state["pos"] + 2]
                        state["pos"] += 3
                        state["last_byte"] = unknown4
                        offset = (((unknown3 << 8) | unknown4) >> 2) + 0x4000
                        if flag_byte & 8:
                            offset += 0x4000
                        oc31_backref(state, offset, length)
                    else:
                        unknown2 = comp[state["pos"]]
                        unknown3 = comp[state["pos"] + 1]
                        length = (unknown2 << 8) | unknown3
                        unknown4 = comp[state["pos"] + 2]
                        unknown5 = comp[state["pos"] + 3]
                        state["pos"] += 4
                        state["last_byte"] = unknown5
                        offset = (((unknown4 << 8) | unknown5) >> 2) + 0x4000
                        if flag_byte & 8:
                            offset += 0x4000
                        oc31_backref(state, offset, length)
                else:
                    tmp += 2
                    unknown3 = comp[state["pos"]]
                    unknown4 = comp[state["pos"] + 1]
                    state["pos"] += 2
                    state["last_byte"] = unknown4
                    offset = (((unknown3 << 8) | unknown4) >> 2) + 0x4000
                    if flag_byte & 8:
                        offset += 0x4000
                    oc31_backref(state, offset, tmp)
        elif flag_byte >= 2:
            length = flag_byte + 2
            if state["pos"] + length > len(comp):
                raise ValueError("literal past end")
            state["out"].extend(comp[state["pos"]:state["pos"] + length])
            state["pos"] += length
        else:
            if flag_byte == 0:
                unknown2 = comp[state["pos"]]
                state["pos"] += 1
                state["last_byte"] = unknown2
                length = unknown2 + 0x12
                if state["pos"] + length > len(comp):
                    raise ValueError("literal1 past end")
                state["out"].extend(comp[state["pos"]:state["pos"] + length])
                state["pos"] += length
            else:
                unknown2 = comp[state["pos"]]
                unknown3 = comp[state["pos"] + 1]
                length = (unknown2 << 8) | unknown3
                state["pos"] += 2
                state["last_byte"] = unknown3
                if length == 0:
                    if len(state["out"]) == uncompressed_size:
                        break
                if state["pos"] + length > len(comp):
                    raise ValueError("literal2 past end")
                state["out"].extend(comp[state["pos"]:state["pos"] + length])
                state["pos"] += length

        if uncompressed_size and len(state["out"]) > uncompressed_size + 16:
            raise ValueError(f"output overflow: {len(state['out'])} > {uncompressed_size}")

    leftover = compressed_size - state["pos"]
    return bytes(state["out"]), leftover


def oc31_errorcorrectioncode(data):
    n_ints = len(data) >> 4
    n_bytes = len(data) - (n_ints << 4)
    accu = 0
    off = 0
    for _ in range(n_ints):
        for _ in range(4):
            word = struct.unpack_from("<I", data, off)[0]
            accu ^= word
            off += 4
    result = accu & 0xFF
    accu >>= 8
    result ^= accu & 0xFF
    accu >>= 8
    result ^= accu & 0xFF
    accu >>= 8
    result ^= accu
    for _ in range(n_bytes):
        result ^= data[off]
        off += 1
    return result & 0xFF


def decompress_block(payload, expected_uncompressed=None):
    if len(payload) < 2:
        raise ValueError("payload too short")
    ecc = payload[-1]
    data = payload[:-1]
    out, leftover = oc31_uncompress(data, len(data), expected_uncompressed or 0)
    computed = oc31_errorcorrectioncode(out)
    return out, {"ecc_ok": ecc == computed, "ecc_stored": ecc, "ecc_computed": computed, "leftover": leftover}
