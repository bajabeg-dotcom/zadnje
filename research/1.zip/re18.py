import sys, os, re, collections
sys.path.insert(0, r"C:\Users\Baja\Desktop\Nova mapa")
from pa800_native import parse_bank, decode_oc31
from pa800_native.type06_trackinfo import parse_type06_trackinfo
sys.stdout.reconfigure(encoding="utf-8", errors="replace")

ROMDIR = r"C:\Users\Baja\Desktop\Nova mapa\Style Works XT Universal\InitKorg"

def load_rom(path):
    """parse 'PPP-LLL-MSB Name' lines -> set of (msb, lsb, prg)"""
    out = set()
    txt = open(path, "r", encoding="latin1", errors="replace").read()
    for line in txt.splitlines():
        m = re.match(r"\s*(\d+)-(\d+)-(\d+)\s+(.*)$", line)
        if m:
            a, b, c = int(m.group(1)), int(m.group(2)), int(m.group(3))
            # possible perms of (msb,lsb,prg)
            out.add((a, b, c))
    return out

roms = {}
for f in ["rom_PA1x.SND", "rom_PA2x.SND", "rom_PA3x.SND", "rom_PA4x.SND", "rom_PA80.SND"]:
    roms[f] = load_rom(os.path.join(ROMDIR, f))
    print(f, "entries:", len(roms[f]))
print("sample:", sorted(roms["rom_PA80.SND"])[:5])

def dec(r):
    p = r.payload
    if p[:4] in (b"OC31", b"OC32"):
        return decode_oc31(b"OC31" + p[4:])
    return p

TARGETS = [
    (r"C:\Users\Baja\Desktop\Pantic Pa1X.SET\STYLE\BANK01_LIVE.STY", "Pantic-LIVE"),
    (r"C:\Users\Baja\Desktop\GOLE ARX .SET\GOLE ARX .SET\STYLE\FAVORITE01.STY", "GOLEARX-FAV01"),
    (r"C:\Users\Baja\Desktop\Moduli na PYTHONU\Pa800_System\output\Pa800_os_res_v202\STARTUP\ALL\STYLE\BANK01.STY", "PA800-OS"),
    (r"C:\Users\Baja\Desktop\Nova mapa\Style Works XT Universal\InitKorg\Initpa01.STY", "Init-pa01"),
]
for path, label in TARGETS:
    if not os.path.exists(path):
        continue
    d = open(path, "rb").read()
    bank = parse_bank(d)
    sels = set()
    for r in bank.resources:
        if r.kind != 6:
            continue
        for blk in parse_type06_trackinfo(dec(r)):
            for t in blk["tracks"]:
                sels.add(t["selector"])
    print("=" * 60, label, "selectors:", len(sels))
    for perm_name, perm in (("msb,lsb,prg", lambda s: s),):
        for rn, rom in roms.items():
            hit = sum(1 for s in sels if s in rom)
            print(f"    {rn:14s} direct-hit {hit}/{len(sels)}")
            # try other perms: (msb,prg,lsb),(lsb,msb,prg),(prg,msb,lsb),(lsb,prg,msb),(prg,lsb,msb)
            best = None
            for pname, fn in (
                ("msb,lsb,prg", lambda s: (s[0], s[1], s[2])),
                ("msb,prg,lsb", lambda s: (s[0], s[2], s[1])),
                ("lsb,msb,prg", lambda s: (s[1], s[0], s[2])),
                ("prg,msb,lsb", lambda s: (s[2], s[0], s[1])),
                ("lsb,prg,msb", lambda s: (s[1], s[2], s[0])),
                ("prg,lsb,msb", lambda s: (s[2], s[1], s[0])),
            ):
                h = sum(1 for s in sels if fn(s) in rom)
                if best is None or h > best[1]:
                    best = (pname, h)
            print(f"      best perm {best[0]} -> {best[1]}/{len(sels)}")
