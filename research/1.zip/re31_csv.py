﻿import os, sys
sys.stdout.reconfigure(encoding="utf-8", errors="replace")
p = r"C:\Users\Baja\Desktop\BAJA MUSIC\PA800_PREOSTALO_I_DOKAZI_2026-09-22\05_CROSS_MODEL\KORG_CROSS_MODEL_ADAPTER_MATRIX.csv"
print("size", os.path.getsize(p))
with open(p, encoding="utf-8", errors="replace") as f:
    for i, line in enumerate(f):
        if i < 8: print(line.rstrip())
        else: break
# count lines
with open(p, encoding="utf-8", errors="replace") as f:
    print("lines", sum(1 for _ in f))
