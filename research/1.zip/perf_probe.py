import sys, time

sys.path.insert(0, r"C:\Users\Baja\Desktop\Nova mapa")

from pathlib import Path
from setconvert.sty import StyBank
from setconvert.detect import decode_payload
from pa800_native.oc31_codec import decode_oc31
from pa800_native.oc31_optimal_encoder import encode_oc31

PA1X = r"C:\Users\Baja\Desktop\Pantic Pa1X.SET\STYLE\BANK01_LIVE.STY"

bank = StyBank.read(PA1X)
r6 = [r for r in bank.resources if r.kind == 6][0]
dec = decode_payload(r6.payload)
print(f"kind06 decoded len={len(dec)} magic={r6.payload[:4]}", flush=True)

t = time.time()
out = encode_oc31(dec)
print(f"encode_oc31: {time.time()-t:.2f}s len={len(out)}", flush=True)

t = time.time()
dec2 = decode_oc31(out)
print(f"decode: {time.time()-t:.2f}s equal={dec2==dec}", flush=True)

t = time.time()
from setconvert.detect import fingerprint_sty
p = fingerprint_sty(PA1X)
print(f"fingerprint: {time.time()-t:.2f}s family={p.family}", flush=True)

t = time.time()
from setconvert.conv import convert_sty
data = Path(PA1X).read_bytes()
out, rep = convert_sty(data, "pa800")
print(f"convert pa1x->pa800: {time.time()-t:.2f}s len={len(out)}", flush=True)
