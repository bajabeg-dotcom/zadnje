import sys, io, os, glob, collections
sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding='utf-8', errors='replace', line_buffering=True)
sys.path.insert(0, r'C:\Users\Baja\Desktop\Nova mapa')
from pa800_native.sty_container import parse_bank

files = [p for p in glob.glob(r'C:\Users\Baja\Desktop\**\*.pcg', recursive=True)]
print(f'PCG corpus on Desktop: {len(files)}')
ok = bad = fail = 0
fails = []
kinds_all = collections.Counter()
for p in files:
    try:
        data = open(p, 'rb').read()
    except Exception as e:
        fail += 1; fails.append((p, f'read:{e}')); continue
    try:
        bank = parse_bank(data)
        if bank.build() == data: ok += 1
        else:
            bad += 1; fails.append((p, 'RT-DIFF'))
        for r in bank.resources:
            kinds_all[(r.kind, r.header[1])] += 1
    except ValueError as e:
        fail += 1; fails.append((p, f'parse:{e}'))
print(f'RT-OK={ok} RT-DIFF={bad} PARSE-FAIL={fail}')
for p, why in fails[:15]:
    print('   ', why, '|', p)
print('kinds (kind, sub):', dict(sorted(kinds_all.items())))

# pa4x var-record field stats
stats = collections.defaultdict(collections.Counter)
meta_ok = 0; meta_bad = 0; bankmatch = 0; bankmis = 0
for p in files:
    try:
        bank = parse_bank(open(p, 'rb').read())
    except Exception:
        continue
    k5 = [r for r in bank.resources if r.kind == 5]
    if not k5 or k5[0].header[1] != 1:
        continue
    pay = k5[0].payload
    base = os.path.basename(p).upper()
    want = {'USER01.PCG': 9, 'USER02.PCG': 10, 'USER03.PCG': 12, 'USER04.PCG': 13,
            'USERDK.PCG': 11, 'USERDK01.PCG': 11}.get(base)
    pos = 0
    while pos < len(pay):
        rl = int.from_bytes(pay[pos:pos+2], 'big') + 2
        r = pay[pos:pos+rl]
        stats['f2_4'][r[2:4].hex()] += 1
        stats['f4_6'][r[4:6].hex()] += 1
        stats['f6_8'][r[6:8].hex()] += 1
        stats['m39_41'][r[39:41].hex()] += 1
        bankv, progv = r[41], r[42]
        stats['bank'][bankv] += 1
        stats['prog_range'][(progv <= 127)] += 1
        if want is not None:
            if bankv == want: bankmatch += 1
            else: bankmis += 1
        pos += rl
print('pa4x [2:4]:', dict(stats['f2_4']))
print('pa4x [4:6]:', dict(stats['f4_6']))
print('pa4x [6:8]:', dict(stats['f6_8']))
print('pa4x meta[39:41]:', dict(stats['m39_41']))
print('pa4x bank values:', dict(stats['bank']), 'filename-match:', bankmatch, 'mismatch:', bankmis)
print('pa4x prog<=127:', dict(stats['prog_range']))
