import sys, io, os, glob, collections
sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding='utf-8', errors='replace')
sys.path.insert(0, r'C:\Users\Baja\Desktop\Nova mapa')
from setconvert.sty import StyBank
from setconvert import parameters as P
from setconvert import sts as S
from setconvert.sts import StsStats
from setconvert.detect import decode_payload
from setconvert.families import FAMILIES
from pa800_native.sty_container import parse_bank

NUL = b"\x00"

def pcg_catalog(path):
    bank = parse_bank(open(path, 'rb').read())
    cat = [r for r in bank.resources if r.kind == 5]
    if not cat:
        return None, []
    c = cat[0]
    recs = []
    if c.header[1] == 0:
        for i in range(len(c.payload) // 24):
            rec = c.payload[i*24:(i+1)*24]
            meta = rec[16:]
            recs.append({'name': rec[:16].split(NUL)[0].decode('ascii', 'replace'),
                         'bank': meta[3], 'prog': meta[4]})
    else:
        pos = 0
        while pos < len(c.payload):
            a = int.from_bytes(c.payload[pos:pos+2], 'big'); ln = a + 2
            if c.payload[pos+4:pos+8] != b'\x00\x02\x00\x1c' or ln < 39 or pos + ln > len(c.payload):
                break
            rec = c.payload[pos:pos+ln]; meta = rec[39:47]
            recs.append({'name': rec[8:24].split(NUL)[0].decode('ascii', 'replace'),
                         'bank': meta[2] if len(meta) > 2 else None,
                         'prog': meta[3] if len(meta) > 3 else None})
            pos += ln
    return (c.header, recs)

SETS = [
    ('pa800', r'C:\Users\Baja\Desktop\KOCE FOLK.SET'),
    ('pa800', r'C:\Users\Baja\Desktop\GOLE ARX .SET'),
    ('pa1x',  r'C:\Users\Baja\Desktop\Pantic Pa1X.SET'),
    ('pa3x',  r'C:\Users\Baja\Desktop\Korg Pa3x Team Serbian.SET'),
    ('pa4x',  r'C:\Users\Baja\Desktop\Pa4x Pro Dejan Shiki.SET'),
]

for family, root in SETS:
    print(f'\n######## {family}  {os.path.basename(root)}')
    # user banks: label by file name, keyed also by catalog bank index
    banks = {}   # bankidx -> {'file':..., 'progs': set, 'by_prog': {prog: name}}
    for p in sorted(glob.glob(os.path.join(root, '**', '*.PCG'), recursive=True) +
                    glob.glob(os.path.join(root, '**', '*.pcg'), recursive=True)):
        hdr, recs = pcg_catalog(p)
        if not recs:
            continue
        by_prog = {r['prog']: r['name'] for r in recs if r['prog'] is not None}
        bi = recs[0]['bank']
        label = os.path.basename(p)
        banks[bi] = {'file': label, 'progs': set(by_prog), 'by_prog': by_prog, 'n': len(recs)}
    for bi in sorted(banks):
        b = banks[bi]
        print(f'  bank {bi:3d} {b["file"]:12s} n={b["n"]:3d} progs={sorted(b["progs"])[:6]}...{sorted(b["progs"])[-3:]}')
    # selectors
    stys = sorted({p for p in glob.glob(os.path.join(root, '**', '*'), recursive=True)
                   if p.lower().endswith('.sty')})[:8]
    dialect = FAMILIES[family].sts_dialect
    sel = collections.Counter()
    for sty in stys:
        try:
            bank = StyBank.read(sty)
        except Exception:
            continue
        for res in bank.resources:
            try:
                if res.kind == 6:
                    for blk in P.find_blocks(decode_payload(res.payload)):
                        for rec in blk.records:
                            sel[rec.selector] += 1
                elif res.kind == 9:
                    stats = StsStats()
                    for slot in S.read_document_slots(decode_payload(res.payload), dialect, None, stats):
                        for row in slot.selectors:
                            sel[row] += 1
            except Exception:
                pass
    grp = collections.defaultdict(collections.Counter)
    for (msb, lsb, pc), n in sel.items():
        if lsb >= 64:
            grp[(msb, lsb)][pc] += n
    for key in sorted(grp, key=lambda k: -sum(grp[k].values())):
        pcset = grp[key]
        hits = {}
        for bi, b in banks.items():
            h = sum(n for pc, n in pcset.items() if pc in b['progs'])
            hits[b['file']] = (h, sum(pcset.values()))
        best = max(hits.items(), key=lambda kv: kv[1][0])
        print(f'  (msb={key[0]}, lsb={key[1]}) distinct_pc={len(pcset)} hits={sum(pcset.values())}'
              f'  best={best[0]} {best[1][0]}/{best[1][1]} ({100*best[1][0]/max(1,best[1][1]):.0f}%)')
        print(f'      per-bank: ' + ', '.join(f'{k}:{v[0]}/{v[1]}' for k, v in hits.items()))
        # sample unresolved
        for bankfile in [best[0]]:
            progs = banks[[bi for bi, b in banks.items() if b['file'] == bankfile][0]]['progs']
            miss = [pc for pc in sorted(pcset) if pc not in progs][:8]
            if miss:
                print(f'      missing in {bankfile} (pc): {miss}')
