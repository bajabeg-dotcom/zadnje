﻿import sys, struct
sys.path.insert(0, r"C:\Users\Baja\Desktop\Nova mapa")
from pa800_native import parse_bank, decode_oc31
sys.stdout.reconfigure(encoding="utf-8", errors="replace")

def dump(path, label, n=260):
    d = open(path, "rb").read()
    bank = parse_bank(d)
    r5 = [r for r in bank.resources if r.kind == 5][0]
    p = r5.payload
    print("=" * 70)
    print(label, "hdr", r5.header.hex(" "), "payload len", len(p), "mod84", len(p) % 84, "mod24", len(p) % 24)
    # hexdump first n bytes
    for off in range(0, min(n, len(p)), 16):
        chunk = p[off:off+16]
        hx = " ".join("%02x" % b for b in chunk)
        asc = "".join(chr(b) if 32 <= b < 127 else "." for b in chunk)
        print("  %04x  %-48s  %s" % (off, hx, asc))
    print("  ...")
    # ascii runs
    import re
    runs = [(m.start(), m.group().decode()) for m in re.finditer(rb"[\x20-\x7e]{4,}", p)]
    print("  ascii runs:", runs[:18])

dump(r"C:\Users\Baja\Desktop\Pa4x Pro Dejan Shiki.SET\STYLE\USER01.STY", "Pa4X USER01")
dump(r"C:\Users\Baja\Desktop\Nova mapa\Style Works XT Universal\InitKorg\initPx04.STY", "Px04", 200)
dump(r"C:\Users\Baja\Desktop\Korg Pa3x Team Serbian.SET\STYLE\USER01.STY", "Pa3X USER01", 140)
dump(r"C:\Users\Baja\Desktop\Nova mapa\Style Works XT Universal\InitKorg\InitPx03.STY", "Px03", 140)
