import sys, io, os, re, collections
sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding='utf-8', errors='replace')
sys.path.insert(0, r'C:\Users\Baja\Desktop\Nova mapa')
from pa800_native.sty_container import parse_bank

PRG = r'C:\Users\Baja\Desktop\PA800_AI_PA800_STUDIO_v5_2026-09-20\factory_evidence\native_factory\SOUND\PRGMAPS.TBL'
ROM = r'C:\Users\Baja\Desktop\PA800_AI_PA800_STUDIO_v5_2026-09-20\factory_evidence\native_factory\SOUND\ROM.PCG'
SND = r'C:\Users\Baja\Desktop\Nova mapa\Style Works XT Universal\InitKorg\rom_PA2x.SND'
LINE = re.compile(r"^(\d{3})-(\d{3})-(\d{3})\s+(.*)$")

bank = parse_bank(open(PRG, 'rb').read())
sl = bank.resources[5].payload
pos = 8; entries = []
while pos < len(sl):
    n = int.from_bytes(sl[pos:pos+2], 'big'); pos += 2
    if n == 0: break
    for i in range(n):
        e = sl[pos:pos+6]; pos += 6
        entries.append((int.from_bytes(e[0:2], 'big'), e[2], e[3], (e[4] << 7) | e[5], e[4], e[5]))
cat = [r for r in parse_bank(open(ROM, 'rb').read()).resources if r.kind == 5][0].payload
names = [cat[i*24:(i+1)*24].split(b'\x00')[0].decode('ascii', 'replace').strip() for i in range(len(cat)//24)]

snd = {}
for line in open(SND, encoding='latin1').read().splitlines():
    m = LINE.match(line)
    if m:
        pr, lsb, msb = map(int, m.groups()[:3])
        snd[(msb, lsb, pr)] = m.group(4).strip()

print(f'ROM catalog: {len(names)} names')
print('ROM names[1000..1070]:')
print('  ' + ', '.join(f'{i}:{names[i]!r}' for i in range(1000, min(1071, len(names)))))

drums = [e for e in entries if e[0] == 120]
print(f'\nDrum SoundsLayout entries: {len(drums)}')
name2ord = collections.defaultdict(list)
for i, nm in enumerate(names):
    name2ord[nm].append(i)

print('\npc -> SND name -> ROM ordinal(s) where that name occurs:')
pairs = []
for msb, lsb, pc, ordi, hi, lo in drums:
    s = snd.get((120, lsb, pc), '<no-snd>')
    found = name2ord.get(s, [])
    pairs.append((pc, lo, ordi, s, found))
    print(f'  pc={pc:3d} lo={lo:3d} cur_ord={ordi:4d} SND={s!r:24s} ROM_ord={found}')

print('\nTry formulas:')
def norm(x): return re.sub(r'\s+', ' ', x).strip().lower()
for meth in ('ord', '1007+pc', '1007+lo', 'otc_pc'):
    hits = 0
    for pc, lo, ordi, s, found in pairs:
        if not found: continue
        cand = {'ord': ordi, '1007+pc': 1007+pc, '1007+lo': 1007+lo}.get(meth)
        if meth == 'otc_pc':
            continue
        if cand is not None and cand in found:
            hits += 1
    print(f'  {meth}: {hits}/{len(pairs)} (among names found in ROM)')

# exhaustive: which ordinal index range do SND drum names occupy?
print('\nAll ROM ordinals whose name matches any SND (120,0) drum name:')
s2 = {v: k for k, v in snd.items() if k[0] == 120 and k[1] == 0}
matched = [(i, nm) for i, nm in enumerate(names) if nm in s2]
print(f'  count={len(matched)} range={matched[0][0] if matched else None}..{matched[-1][0] if matched else None}')
print('  first 12:', matched[:12])
print('  last 12:', matched[-12:])
