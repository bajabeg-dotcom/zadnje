import sys, glob, os
sys.path.insert(0, r"C:\Users\Baja\Desktop\Nova mapa")
from pa800_native import parse_bank, decode_oc31
sys.stdout.reconfigure(encoding="utf-8", errors="replace")
D = r"C:\Users\Baja\Desktop\Nova mapa\Style Works XT Universal\InitKorg"

def dec(r):
    p = r.payload
    return decode_oc31(b"OC31" + p[4:]) if p[:4] in (b"OC31", b"OC32") else p

files = ["Initpa01.STY", "INITPA02.STY", "INITPA03.STY", "InitPx01.STY", "InitPx02.STY", "InitPx03.STY", "initPx04.STY"]
for name in files:
    d = open(os.path.join(D, name), "rb").read()
    bank = parse_bank(d)
    print("=" * 78, name, f"size={len(d)} resources={len(bank.resources)}")
    kinds = {}
    for r in bank.resources:
        kinds[r.kind] = kinds.get(r.kind, 0) + 1
    print("  kinds:", {f"0x{k:02x}": v for k, v in sorted(kinds.items())})
    for i, r in enumerate(bank.resources):
        if r.kind != 5:
            continue
        out = dec(r)
        print(f"  -- kind05 #{i} payload len={len(out)}")
        # detect stride: look for repeated structure
        if len(out) % 24 == 0 and out[:1] != b"\x00":
            for e in range(0, len(out), 24):
                ent = out[e:e + 24]
                print(f"     [{e:3d}] {ent.hex(' ')}  | {''.join(chr(c) if 32 <= c < 127 else '.' for c in ent)}")
        else:
            # gen C style: entries of 84 bytes?
            for e in range(0, len(out), 84):
                ent = out[e:e + 84]
                if len(ent) < 84:
                    print(f"     tail: {ent.hex(' ')}")
                    break
                print(f"     [{e:3d}] hdr={ent[:8].hex(' ')} name='{ent[8:36].decode('latin1').rstrip(chr(0))}' mid={ent[36:66].hex(' ')}")
                print(f"           tail={ent[66:84].hex(' ')} | {''.join(chr(c) if 32 <= c < 127 else '.' for c in ent[66:84])}")
