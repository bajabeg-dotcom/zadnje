import sys, os, glob, collections
sys.path.insert(0, r"C:\Users\Baja\Desktop\Nova mapa")
from pa800_native import parse_bank, decompress_bank, decode_oc31
from pa800_native.type06_trackinfo import parse_type06_trackinfo, TRACKINFO_MARKER
from pa800_native.type09_codec import parse_type09
sys.stdout.reconfigure(encoding="utf-8", errors="replace")

TARGETS = [
    (r"C:\Users\Baja\Desktop\Moduli na PYTHONU\Pa800_System\output\Pa800_os_res_v202\STARTUP\ALL\STYLE\BANK01.STY", "PA800-OS"),
    (r"C:\Users\Baja\Desktop\Pantic Pa1X.SET\STYLE\BANK01_LIVE.STY", "Pantic-LIVE"),
    (r"C:\Users\Baja\Desktop\Pantic Pa1X.SET\STYLE\USER02.STY", "Pantic-USER02"),
    (r"C:\Users\Baja\Desktop\GOLE ARX .SET\GOLE ARX .SET\STYLE\FAVORITE01.STY", "GOLEARX-FAV01"),
    (r"C:\Users\Baja\Desktop\GOLE ARX .SET\GOLE ARX .SET\STYLE\USER01.STY", "GOLEARX-USER01"),
    (r"C:\Users\Baja\Desktop\STYLE\USER01_IZOLACIJA.STY", "IZOLACIJA"),
    (r"C:\Users\Baja\Desktop\Nova mapa\Style Works XT Universal\InitKorg\Initpa01.STY", "Init-pa01"),
    (r"C:\Users\Baja\Desktop\Nova mapa\Style Works XT Universal\InitKorg\InitPx01.STY", "Init-Px01"),
    (r"C:\Users\Baja\Desktop\Nova mapa\Style Works XT Universal\InitKorg\InitPx03.STY", "Init-Px03"),
    (r"C:\Users\Baja\Desktop\Nova mapa\Style Works XT Universal\InitKorg\initPx04.STY", "Init-Px04"),
]

def dec(r):
    p = r.payload
    if p[:4] in (b"OC31", b"OC32"):
        return decode_oc31(b"OC31" + p[4:])
    return p

for path, label in TARGETS:
    if not os.path.exists(path):
        continue
    d = open(path, "rb").read()
    print("=" * 70, label)
    bank = parse_bank(d)
    n06 = n09 = 0
    ti_blocks = 0
    ti_tags = collections.Counter()
    k9_first = collections.Counter()
    k9_childtags = collections.Counter()
    for r in bank.resources:
        out = dec(r)
        if r.kind == 6:
            n06 += 1
            ti_blocks += len(parse_type06_trackinfo(out))
            for marker in (b"\x02\x00\x00\x08", b"\x02\x00\x01\x08", b"\x02\x00\x02\x08",
                           b"\x02\x00\x03\x08", b"\x02\x00\x04\x08", b"\x02\x01\x00\x08",
                           b"\x02\x00\x00\x0c"):
                for sz in (0x30, 0x18, 0x40, 0x08, 0x20):
                    m = marker + sz.to_bytes(4, "big")
                    c = out.count(m)
                    if c:
                        ti_tags[f"{marker.hex(' ')}|sz={sz:#x}"] += c
        elif r.kind == 9:
            n09 += 1
            k9_first[out[:4].hex(" ")] += 1
            # walk children
            pos = 0
            while pos + 8 <= len(out):
                tag = out[pos:pos + 4]
                if tag[3] != 8:
                    break
                sz = int.from_bytes(out[pos + 4:pos + 8], "big")
                if sz == 0 or pos + 8 + sz > len(out):
                    break
                k9_childtags[tag.hex(" ")] += 1
                pos += 8 + sz
    print(f"  kind06={n06} kind09={n09} trackinfo_valid_blocks={ti_blocks}")
    print(f"  ti marker variants: {dict(ti_tags)}")
    print(f"  kind09 first4: {dict(k9_first)}")
    print(f"  kind09 child tags: {dict(k9_childtags)}")
    # try parse_type09 on first kind09
    for r in bank.resources:
        if r.kind == 9:
            try:
                res = parse_type09(dec(r))
                print("  parse_type09 OK:", str(res)[:160])
            except Exception as e:
                print("  parse_type09 FAIL:", e)
            break
