﻿import os, re, struct
d = r"C:\Users\Baja\Desktop\Nova mapa\Style Works XT Universal\InitKorg"
print("### fixed-width printable name runs (>=10 chars incl. trailing spaces) in i-series files")
for fn in ["INIT_I30.STY","INIT_I40.STY","Init_i3.sty","INIT_I30.PRG","Init_i3.pcg","INIT_I30.GBL","Init_i3.arr"]:
    data=open(os.path.join(d,fn),'rb').read()
    hits=[(m.start(), m.group()) for m in re.finditer(rb'[A-Za-z0-9][A-Za-z0-9 \.\-\+\&\']{6,}[ ]{2,}', data)]
    print("--",fn,"n=",len(hits))
    for off,s in hits[:8]:
        print("     0x%04X %r"%(off,s))
    if len(hits)>8: print("     ... last:", "0x%04X %r"%hits[-1])
print()
print("### PRG record layout probe")
for fn in ["INIT_I30.PRG","INIT_I40.PRG"]:
    data=open(os.path.join(d,fn),'rb').read()
    offs=[m.start() for m in re.finditer(rb'[A-Z][A-Za-z0-9 \.\-\+\']{5,14}  ', data)]
    print("   %s size=%d first=%s last=%s"%(fn,len(data),[hex(o) for o in offs[:3]],[hex(o) for o in offs[-3:]]))
    if offs:
        last=offs[-1]
        print("      (last-0x30)=%d  /172=%.2f   remaining after last record=%d"%(last-0x30,(last-0x30)/172, len(data)-(last-0x30+172)))
print()
print("### i-series STY: locate 16-byte padded names")
for fn in ["INIT_I30.STY","INIT_I40.STY"]:
    data=open(os.path.join(d,fn),'rb').read()
    hits=[m.start() for m in re.finditer(rb'[A-Za-z0-9][A-Za-z0-9 ]{13}  ', data)]
    print("   %s -> %s"%(fn,[hex(o) for o in hits[:12]]))
