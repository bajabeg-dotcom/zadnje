import io, sys, collections
sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding="utf-8", errors="replace")
from pathlib import Path
import sys as _s
_s.path.insert(0, r"C:\Users\Baja\Desktop\Nova mapa")
from setconvert.sty import StyBank

FILES = {
    "pa4x USER01": r"C:\Users\Baja\Desktop\Pa4x Pro Dejan Shiki.SET\SOUND\USER01.PCG",
    "pa4x USERDK": r"C:\Users\Baja\Desktop\Pa4x Pro Dejan Shiki.SET\SOUND\USERDK01.PCG",
    "pa3x USER01": r"C:\Users\Baja\Desktop\Korg Pa3x Team Serbian.SET\SOUND\USER01.PCG",
    "pa3x USERDK": r"C:\Users\Baja\Desktop\Korg Pa3x Team Serbian.SET\SOUND\USERDK.PCG",
    "pa1x USER01": r"C:\Users\Baja\Desktop\Pantic Pa1X.SET\SOUND\USER01.PCG",
    "pa800 USER01": r"C:\Users\Baja\Desktop\KOCE FOLK.SET\SOUND\USER01.PCG",
}

for label, path in FILES.items():
    p = Path(path)
    if not p.is_file():
        print(f"{label}: MISSING {p}")
        continue
    bank = StyBank.read(p.read_bytes())
    print(f"== {label} ({p.stat().st_size} B) resources={len(bank.resources)} kbeg={bank.kbeg_mode}")
    for i, res in enumerate(bank.resources):
        print(f"   [{i}] kind={res.kind} hdr={res.header.hex(' ')} payload={len(res.payload)} "
              f"head={res.payload[:16].hex(' ')}")

# dump pa4x variable kind05 records fully
print()
print("== pa4x USER01 kind05 records ==")
p = Path(FILES["pa4x USER01"])
bank = StyBank.read(p.read_bytes())
kind5 = [r for r in bank.resources if r.kind == 5][0]
pl = kind5.payload
print("payload len", len(pl), "head", pl[:16].hex(" "))
off = 0
n = 0
while off + 2 <= len(pl) and n < 4:
    size = int.from_bytes(pl[off:off+2], "big")
    rec = pl[off:off+size+2]
    print(f" u16={size} total={len(rec)} full={rec.hex(' ')}")
    off += size + 2
    n += 1
print(" remaining after first pass would need full walk; count below")

# full walk: collect lengths
off = 0
lens = collections.Counter()
while off + 2 <= len(pl):
    size = int.from_bytes(pl[off:off+2], "big")
    lens[size] += 1
    off += size + 2
print("record u16 lengths:", dict(lens), "consumed", off, "of", len(pl))

# pa3x fixed records
print()
print("== pa3x USER01 kind05 fixed records (first 3) ==")
bank3 = StyBank.read(Path(FILES["pa3x USER01"]).read_bytes())
k5 = [r for r in bank3.resources if r.kind == 5][0]
for i in range(3):
    rec = k5.payload[i*24:(i+1)*24]
    print(f"  {rec.hex(' ')}  name={rec[:17]!r} meta={rec[17:].hex(' ')}")

print()
print("== pa4x kind16 vs pa3x kind16 compare ==")
for label in ("pa4x USER01", "pa3x USER01"):
    bank = StyBank.read(Path(FILES[label]).read_bytes())
    k16 = [r for r in bank.resources if r.kind == 16]
    print(f"  {label}: kind16 count={len(k16)} lens={collections.Counter(len(r.payload) for r in k16)}")
