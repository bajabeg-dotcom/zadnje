import sys, io, os, glob, collections
sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding='utf-8', errors='replace')
sys.path.insert(0, r'C:\Users\Baja\Desktop\Nova mapa')
from setconvert.sty import StyBank
from setconvert.detect import decode_payload
from setconvert.sts import child_spans

FILES = [
    r'C:\Users\Baja\Desktop\PA800_ENGINE_SESSION_05\bkp_extracted\NewName_final\records\STYLE\USER01.STY',
    r'C:\Users\Baja\Desktop\KOCE FOLK.SET\STYLE\FAVORITE01.STY',
    r'C:\Users\Baja\Desktop\Pantic Pa1X.SET\STYLE',
    r'C:\Users\Baja\Desktop\Korg Pa3x Team Serbian.SET\STYLE',
    r'C:\Users\Baja\Desktop\Pa4x Pro Dejan Shiki.SET\STYLE',
]
files = []
for f in FILES:
    if os.path.isdir(f):
        files += sorted(glob.glob(os.path.join(f, '*')))[:2]
    elif os.path.exists(f):
        files.append(f)

for f in files:
    if not f.lower().endswith('.sty'):
        continue
    print(f'\n#### {f}')
    try:
        bank = StyBank.read(f)
    except Exception as e:
        print('  read err', e); continue
    stats = collections.Counter()
    rows = []
    for res in bank.resources:
        if res.kind != 9:
            continue
        dec = decode_payload(res.payload)
        spans = child_spans(dec)
        if not spans:
            continue
        body = dec[spans[0].body_start:spans[0].end]
        records = int.from_bytes(body[8:12], 'big'); count = body[12]
        if records not in (408, 504):
            continue
        SLOT, DET = (261, 113) if records == 408 else (357, 209)
        for si in range(count):
            slot = body[records + si*SLOT: records + (si+1)*SLOT]
            for t in range(4):
                ten = slot[17 + t*10: 27 + t*10]
                base = DET + t*37 + 8
                sel = tuple(slot[base:base+4])
                stats['ten:' + ten[:3].hex(' ')] += 1
                if ten[7:10] != b'\x00\x00\x00':
                    rows.append((ten, sel))
    print('  ten prefix hist:', dict(stats))
    print(f'  user-like records (ten[7:10]!=0): {len(rows)}')
    for ten, sel in rows[:12]:
        print(f'    ten={ten.hex(" ")}  detail(msb,lsb,res,pc)={sel}')
    # cross-check: detail selectors with lsb>=64
    lsb64 = collections.Counter()
    for res in bank.resources:
        if res.kind != 9:
            continue
        try:
            dec = decode_payload(res.payload)
            spans = child_spans(dec)
            if not spans: continue
            body = dec[spans[0].body_start:spans[0].end]
            records = int.from_bytes(body[8:12], 'big'); count = body[12]
            if records not in (408, 504): continue
            SLOT, DET = (261, 113) if records == 408 else (357, 209)
            for si in range(count):
                slot = body[records + si*SLOT: records + (si+1)*SLOT]
                for t in range(4):
                    base = DET + t*37 + 8
                    sel = tuple(slot[base:base+4])
                    if sel[1] >= 64:
                        lsb64[sel] += 1
        except Exception:
            pass
    print('  detail selectors with lsb>=64:', dict(list(lsb64.items())[:10]), 'total', sum(lsb64.values()))
