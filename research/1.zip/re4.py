import sys, os, glob
sys.path.insert(0, r"C:\Users\Baja\Desktop\Nova mapa")
from pa800_native import parse_bank, decode_oc31

D = r"C:\Users\Baja\Desktop\Nova mapa\Style Works XT Universal\InitKorg"

ok = fail = 0
fails = []
for f in sorted(set(glob.glob(os.path.join(D, "*.STY")) + glob.glob(os.path.join(D, "*.sty")))):
    data = open(f, "rb").read()
    if data[:4] != b"\x01\x00\x01\x14":
        continue
    bank = parse_bank(data)
    for i, r in enumerate(bank.resources):
        if r.payload[:4] != b"OC32":
            continue
        fake = b"OC31" + r.payload[4:]
        try:
            out = decode_oc31(fake)
            ok += 1
            if ok <= 5:
                print(f"OK {os.path.basename(f)} res[{i}] kind={r.kind:02X} comp={len(r.payload)} -> {len(out)} head={out[:24].hex(' ')}")
        except Exception as e:
            fail += 1
            fails.append((os.path.basename(f), i, r.kind, str(e)))
print(f"\nmagic-swap decode: ok={ok} fail={fail}")
seen = set()
for nm, i, k, e in fails:
    key = e.split(" at ")[0]
    if key not in seen:
        seen.add(key)
        print("  FAIL e.g.:", nm, i, hex(k), e)
