#!/usr/bin/env python3
"""Diagnose the one comp=1 file that fails md5 (Z110AENG.PEG)."""
import hashlib
import struct
import zlib
from pathlib import Path

PKG = Path(r"E:\PA4\Pa4X Operating System v.3.1.0\Pa4X_Operating_System_v310.pkg")
data = PKG.read_bytes()

pos = 16
target = None
while pos + 8 <= len(data):
    cid, size = struct.unpack_from("<II", data, pos)
    if cid == 0 or size == 0 or size > len(data):
        break
    if cid == 17:
        b = pos + 8
        i = b + 29
        path = data[i:data.index(b"\0", i)].decode("latin1")
        if path.endswith("Z110AENG.PEG"):
            for _ in range(3):
                i = data.index(b"\0", i) + 1
            target = (b, size, i)
            break
    pos += 8 + size
    if pos % 4:
        pos += 4 - (pos % 4)

b, size, i = target
dsize, = struct.unpack_from("<I", data, b + 24)
md5 = data[b:b + 16].hex()
payload = data[i:i + size - (i - b)]
print("payload", len(payload), "dsize", dsize, "md5", md5)
print("first48:", payload[:48].hex())

# all zlib-like positions
cands = [j for j in range(len(payload) - 1) if payload[j] == 0x78 and payload[j + 1] in (0x01, 0x9C, 0xDA)]
print("zlib-like offsets:", cands[:20], "count", len(cands))

# sequential decompress loop
rest = payload[12:]
total = b""
streams = 0
while rest:
    if rest[0] != 0x78 or rest[1] not in (0x01, 0x9C, 0xDA):
        print("remaining not zlib, head:", rest[:32].hex(), "len", len(rest))
        break
    d = zlib.decompressobj()
    try:
        out = d.decompress(rest)
    except Exception as e:
        print("fail:", e, "head", rest[:16].hex())
        break
    total += out
    streams += 1
    print(f"  stream {streams}: out={len(out)} unused={len(d.unused_data)} eof={d.eof}")
    rest = d.unused_data

print("total", len(total), "md5match", hashlib.md5(total).hexdigest() == md5)
# tail of expected output: what do first 16/last 16 look like
print("head:", total[:32])
