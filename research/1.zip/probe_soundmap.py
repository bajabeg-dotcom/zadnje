﻿import io, sys, collections
sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding="utf-8", errors="replace")
from pathlib import Path

sys.path.insert(0, r"C:\Users\Baja\Desktop\Nova mapa")
from setconvert.soundmap import SoundMap, match_by_name
from setconvert.pcg import PcgBank
from setconvert.sty import StyBank
from setconvert import detect, parameters as P, sts as S, families as F

DESK = Path(r"C:\Users\Baja\Desktop")
SETS = [
    ("KOCE FOLK.SET", "pa800"),
    ("GOLE ARX .SET", "pa800"),
    ("Pantic Pa1X.SET", "pa1x"),
    ("Korg Pa3x Team Serbian.SET", "pa3x"),
    ("Pa4x Pro Dejan Shiki.SET", "pa4x"),
]


def stys(root):
    return sorted(set(root.rglob("*.STY")) | set(root.rglob("*.sty")))


def extract(sty_data, family):
    params, sts, errs = set(), set(), []
    fam = F.FAMILIES[family]
    try:
        bank = StyBank.read(sty_data)
    except Exception as exc:
        return params, sts, [f"sty read: {exc}"]
    for res in bank.resources:
        try:
            decoded = detect.decode_payload(res.payload)
            if res.kind == 6:
                for block in P.find_blocks(decoded):
                    for rec in block.records:
                        if rec.bank_msb != 0xFF and rec.bank_lsb != 0xFF:
                            params.add(rec.selector)
            elif res.kind == 9:
                slots = S.read_document_slots(decoded, fam.sts_dialect, None, S.StsStats())
                for slot in slots:
                    for sel in slot.selectors:
                        if sel[0] != 0xFF and sel[1] != 0xFF:
                            sts.add(tuple(sel))
        except Exception as exc:
            errs.append(f"kind{res.kind}: {type(exc).__name__}: {exc}")
    return params, sts, errs


sels_by_family = {}
for name, family in SETS:
    root = DESK / name
    print(f"=== {name} [{family}]")
    sm = SoundMap.for_family(family)
    for pcg_path in sorted((root / "SOUND").glob("USER*.PCG")):
        try:
            pcg = PcgBank.read(pcg_path)
            banks = sorted(pcg.catalog_by_bank())
            gaps = sm.pcg_gaps(pcg)
            overlaid = sm.with_pcg(pcg)
            ok = None
            for bank_no in banks:
                addr = sm.user_address(bank_no)
                if addr is None:
                    continue
                first = pcg.catalog_by_bank()[bank_no][0]
                ok = overlaid.name((addr[0], addr[1], first.program)) == first.name
            print(f"  {pcg_path.name}: banks={banks} gaps={gaps} overlay_ok={ok}")
            sm = overlaid
        except Exception as exc:
            print(f"  {pcg_path.name}: ERROR {type(exc).__name__}: {exc}")

    pset, sset, serr = set(), set(), []
    files = stys(root)
    for sty in files:
        p, q, e = extract(sty.read_bytes(), family)
        pset |= p; sset |= q; serr += e
    sel = pset | sset
    sels_by_family.setdefault(family, set()).update(sel)
    named = [s for s in sel if sm.name(s) is not None]
    unnamed = sorted(s for s in sel if sm.name(s) is None)
    print(f"  styles={len(files)} params={len(pset)} sts={len(sset)} unique={len(sel)} "
          f"named={len(named)} unnamed={len(unnamed)} errors={len(serr)}")
    if unnamed:
        print(f"    unnamed: {unnamed[:16]}")
    if serr:
        cnt = collections.Counter(serr)
        print(f"    errs: {cnt.most_common(3)}")

print()
print("=== cross-family match_by_name matrix")
fams = ["pa1x", "pa800", "pa3x", "pa4x"]
maps = {f: SoundMap.for_family(f) for f in fams}
for src in fams:
    if src not in sels_by_family:
        continue
    sels = sorted(sels_by_family[src])
    for dst in fams:
        if dst == src:
            continue
        counts = collections.Counter(match_by_name(maps[src], maps[dst], s) for s in sels)
        print(f"  {src}->{dst}: n={len(sels)} " +
              " ".join(f"{k}={v}" for k, v in sorted(counts.items())))

