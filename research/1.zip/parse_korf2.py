# -*- coding: utf-8 -*-
"""Deep parse Korg KORF per-style blocks + name tables."""
import struct, os, sys, re
sys.stdout.reconfigure(encoding='utf-8', errors='replace')

ROOT = r'C:\Users\Baja\Desktop\Nova mapa\Style Works XT Universal\InitKorg'

def cstr(b, o, n):
    s = b[o:o+n]
    z = s.find(b'\x00')
    if z >= 0:
        s = s[:z]
    return s.decode('latin-1', 'replace').rstrip()

def parse_korf(fn):
    path = os.path.join(ROOT, fn)
    b = open(path, 'rb').read()
    print('=' * 70)
    print(fn, 'size', len(b))
    print('head32:', b[:32].hex())
    assert b[23:27] == b'KORF', b[23:27]
    print('post-KORF:', b[27:48].hex())

    names = []
    p = 0x24
    while p + 24 <= len(b):
        nm = cstr(b, p, 16)
        if not re.match(r'^[\x20-\x7e]{2,}', nm or ''):
            break
        bank = b[p + 18]
        code = b[p + 19]
        idx = struct.unpack_from('<I', b, p + 20)[0]
        names.append({'name': nm, 'bank': bank, 'code': code, 'idx': idx, 'off': p})
        p += 24
    end_names = p
    print('name table: {} entries, ends @ {:#x}'.format(len(names), end_names))
    print(' first5:', names[:5])
    print(' last3:', names[-3:])
    banks = {}
    for n in names:
        banks.setdefault((n['bank'], n['code']), []).append(n['idx'])
    print(' bank/code groups:', {k: (len(v), min(v), max(v)) for k, v in banks.items()})

    # Find embedded style names in data section
    found = []
    seen_names = set()
    for n in names:
        if n['name'] in seen_names:
            continue
        seen_names.add(n['name'])
        nb = n['name'].encode('latin-1', 'replace')
        pos = b.find(nb, end_names)
        if pos < 0:
            pos = b.find(nb, 0)
            if pos < 0 or pos < 0x24:
                continue
        found.append({'name': n['name'], 'first_at': pos, 'idx': n['idx']})
    found.sort(key=lambda x: x['first_at'])
    print('embedded name locations:', len(found))

    # Determine block stride from successive embedded names
    if len(found) >= 3:
        deltas = [found[i + 1]['first_at'] - found[i]['first_at'] for i in range(min(8, len(found) - 1))]
        print('name deltas between consecutive styles:', deltas)

    for f in found[:10]:
        pos = f['first_at']
        pre = b[max(0, pos - 32):pos]
        name_field = b[pos:pos + 24]
        post = b[pos + 24:pos + 96]
        print('  @{:#08x} {!r}'.format(pos, f['name']))
        print('    pre:  ' + pre.hex())
        print('    name: ' + name_field.hex())
        print('    post: ' + post.hex())
        if len(post) >= 32:
            u32s = struct.unpack_from('<8I', post, 0)
            print('    post u32:', u32s)
            # try u16s
            u16s = struct.unpack_from('<16H', post, 0)
            print('    post u16:', u16s[:16])
    return names, end_names, b, found

for fn in ['Initpa01.STY', 'InitPx03.STY', 'InitPx01.STY', 'InitPx04.STY']:
    try:
        parse_korf(fn)
    except Exception as e:
        print(fn, 'ERR', e)
    print()
