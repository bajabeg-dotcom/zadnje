﻿import os, glob
d = r"C:\Users\Baja\Desktop\Nova mapa\Style Works XT Universal"
snds=[]
for root,dirs,fs in os.walk(d):
    for f in fs:
        if f.lower().endswith('.snd'):
            snds.append(os.path.join(root,f))
def hd(b, base=0, w=16):
    out=[]
    for i in range(0,len(b),w):
        c=b[i:i+w]
        out.append('%08X  %-47s  |%s|'%(base+i,' '.join('%02X'%x for x in c),
                   ''.join(chr(x) if 32<=x<127 else '.' for x in c)))
    return '\n'.join(out)
for p in sorted(snds):
    data=open(p,'rb').read()
    print("="*90)
    print(os.path.relpath(p,d), "size",len(data))
    print("first 64 bytes:")
    print(hd(data[:64]))
    # text detection
    printable=sum(1 for b in data if 32<=b<127 or b in (9,10,13))
    print("printable ratio: %.3f"%(printable/len(data)))
    print("first 12 lines (decoded latin-1):")
    txt=data.decode('latin-1')
    lines=txt.splitlines()
    for L in lines[:12]:
        print("   |"+L)
