﻿import os, struct, re, collections
d = r"C:\Users\Baja\Desktop\Nova mapa\Style Works XT Universal\InitKorg"
exts=('.sty','.arr','.gbl','.kbs','.prg','.pcg','.bsq','.arg','.ark','.sng')
files=[f for f in sorted(os.listdir(d)) if os.path.splitext(f)[1].lower() in exts]
want=[b'KORG',b'KORF',b'OC31',b'OC32',b'KBEG',b'KEND',b'BSeq',b'Z110',b'MUS ']
print("### structural ASCII tags: counts and offsets")
for t in want:
    print("--", t.decode())
    for fn in files:
        data=open(os.path.join(d,fn),'rb').read()
        offs=[m.start() for m in re.finditer(re.escape(t), data)]
        if offs:
            print("     %-16s n=%-3d offs=%s"%(fn,len(offs),[hex(o) for o in offs[:8]]))
print()
print("### i-series header bytes (first 8) for every file")
for fn in files:
    data=open(os.path.join(d,fn),'rb').read()
    print("   %-16s %s   ascii=%s"%(fn,' '.join('%02X'%b for b in data[:8]),
          ''.join(chr(b) if 32<=b<127 else '.' for b in data[:8])))
