import io
import sys
import traceback
from pathlib import Path

sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding="utf-8", errors="replace")
sys.path.insert(0, r"C:\Users\Baja\Desktop\Nova mapa")

from setconvert.pcg import PcgBank  # noqa: E402
from setconvert.pcgconvert import PcgError, convert_pcg  # noqa: E402


def show(label, data, dst, src):
    try:
        out, rep = convert_pcg(data, dst, src_family=src)
    except PcgError as e:
        print(f"{label}: REFUSED: {e}")
        return
    except Exception as e:
        print(f"{label}: ERROR {type(e).__name__}: {e}")
        traceback.print_exc()
        return
    d = rep.as_dict()
    c = d["catalog"]
    print(
        f"{label}: bytes {len(data)}->{len(out)} {d['src_layout']}->{d['dst_layout']}"
        f" entries={c['entries']} edit={c['edited']} pass={c['passthrough']}"
        f" trunc={c['names_truncated']} zero={c['fields_zero_filled']}"
        f" ext_drop={c['extension_bytes_dropped']} unproven={c['addresses_unproven']}"
        f" data={d['data']['resources']}r/{d['data']['bytes']}b"
    )
    for o in rep.open_items:
        print("   OPEN:", o)
    for n in rep.notes:
        print("   NOTE:", n)
    ent = PcgBank.read(out).catalog()
    print("   reparse:", len(ent), "first=", repr(ent[0].name), ent[0].bank, ent[0].program)


base = Path(r"C:\Users\Baja\Desktop")
cases = [
    ("pa4x->pa3x  ", base / "Pa4x Pro Dejan Shiki.SET" / "SOUND" / "USER01.PCG", "pa3x", "pa4x"),
    ("pa4x->pa800 ", base / "Pa4x Pro Dejan Shiki.SET" / "SOUND" / "USERDK01.PCG", "pa800", "pa4x"),
    ("pa4x03->pa80", base / "Pa4x Pro Dejan Shiki.SET" / "SOUND" / "USER03.PCG", "pa800", "pa4x"),
    ("pa3x03->pa80", base / "Korg Pa3x Team Serbian.SET" / "SOUND" / "USER03.PCG", "pa800", "pa3x"),
    ("pa3x->pa800 ", base / "Korg Pa3x Team Serbian.SET" / "SOUND" / "USER01.PCG", "pa800", "pa3x"),
    ("pa800->pa1x ", base / "KOCE FOLK.SET" / "SOUND" / "USER01.PCG", "pa1x", "pa800"),
    ("pa3x->pa4x  ", base / "Korg Pa3x Team Serbian.SET" / "SOUND" / "USER01.PCG", "pa4x", "pa3x"),
    ("pa800->pa4x ", base / "KOCE FOLK.SET" / "SOUND" / "USER01.PCG", "pa4x", "pa800"),
    ("pa1x->pa4x  ", base / "Pantic Pa1X.SET" / "SOUND" / "USER01.PCG", "pa4x", "pa1x"),
    ("pa3x->legacy", base / "Korg Pa3x Team Serbian.SET" / "SOUND" / "USER01.PCG", "legacy", "pa3x"),
    ("pa3x->pa3x  ", base / "Korg Pa3x Team Serbian.SET" / "SOUND" / "USER01.PCG", "pa3x", "pa3x"),
    ("pa4x->pa4x  ", base / "Pa4x Pro Dejan Shiki.SET" / "SOUND" / "USER01.PCG", "pa4x", "pa4x"),
]
for label, path, dst, src in cases:
    if not path.exists():
        print(f"{label}: MISSING {path}")
        continue
    show(label, path.read_bytes(), dst, src)
