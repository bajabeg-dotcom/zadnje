import sys, re
sys.stdout.reconfigure(encoding="utf-8", errors="replace")
paths = [
    r"C:\Users\Baja\Desktop\Nova mapa\Style Works XT Universal\StwTypes2.dll",
    r"C:\Users\Baja\Desktop\Nova mapa\Style Works XT Universal\System\Sts_auto.exe",
    r"C:\Users\Baja\Desktop\Nova mapa\Style Works XT Universal\System\wizard.exe",
]
pat = re.compile(rb"[\x20-\x7e]{5,}")
for p in paths:
    data = open(p, "rb").read()
    print("=" * 70, p.split("\\")[-1])
    hits = []
    for m in pat.finditer(data):
        s = m.group().decode("ascii")
        low = s.lower()
        if any(k in low for k in ("init", "korg", "pa80", "pa1x", "pa2x", "pa3x", "pa4x", "pa500", "pa800", "sty", "select_", "rom_", "set")):
            hits.append((m.start(), s))
    for off, s in hits[:120]:
        print(f"  0x{off:06x}  {s}")
    print(f"  total hits: {len(hits)}")
