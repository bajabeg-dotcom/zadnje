import sys, os, collections
sys.path.insert(0, r"C:\Users\Baja\Desktop\Nova mapa")
from pa800_native import parse_bank, decode_oc31
sys.stdout.reconfigure(encoding="utf-8", errors="replace")

def dec(r):
    p = r.payload
    if p[:4] in (b"OC31", b"OC32"):
        return decode_oc31(b"OC31" + p[4:])
    return p

def walk(buf, start=0):
    pos, out = start, []
    while pos + 8 <= len(buf):
        tag = buf[pos:pos + 4]
        if tag[3] != 8:
            break
        size = int.from_bytes(buf[pos + 4:pos + 8], "big")
        if size == 0 or pos + 8 + size > len(buf) or size > 5_000_000:
            break
        out.append((pos, tag, size))
        pos += 8 + size
    return out, pos

TARGETS = [
    (r"C:\Users\Baja\Desktop\GOLE ARX .SET\GOLE ARX .SET\STYLE\USER01.STY", "GOLEARX-USER01"),
    (r"C:\Users\Baja\Desktop\GOLE ARX .SET\GOLE ARX .SET\STYLE\FAVORITE01.STY", "GOLEARX-FAV01"),
    (r"C:\Users\Baja\Desktop\STYLE\USER01_IZOLACIJA.STY", "IZOLACIJA"),
    (r"C:\Users\Baja\Desktop\Moduli na PYTHONU\Pa800_System\output\Pa800_os_res_v202\STARTUP\ALL\STYLE\BANK01.STY", "PA800-OS"),
    (r"C:\Users\Baja\Desktop\Pantic Pa1X.SET\STYLE\BANK01_LIVE.STY", "Pantic-LIVE"),
    (r"C:\Users\Baja\Desktop\Nova mapa\Style Works XT Universal\InitKorg\Initpa01.STY", "Init-pa01"),
    (r"C:\Users\Baja\Desktop\Nova mapa\Style Works XT Universal\InitKorg\InitPx03.STY", "Init-Px03"),
]
for path, label in TARGETS:
    if not os.path.exists(path):
        continue
    d = open(path, "rb").read()
    bank = parse_bank(d)
    print("=" * 72, label)
    shown = 0
    for ri, r in enumerate(bank.resources):
        if r.kind != 6:
            continue
        out = dec(r)
        children, endp = walk(out, 0)
        # find name child at 0? payload starts with name child? actually payload[0:4] is tag?
        print(f"  kind06 #{ri} len={len(out)} head={out[:16].hex(' ')}")
        # walk starting from offset 0 (payload begins with child tag)
        for pos, tag, size in children:
            pl = out[pos + 8:pos + 8 + size]
            print(f"     @0x{pos:05X} {tag.hex(' ')} size={size:6d} head={pl[:20].hex(' ')}")
        print(f"     walk ended at {endp}/{len(out)}")
        # scan all plausible child tags in whole payload
        tags = collections.Counter()
        for pos in range(0, len(out) - 8):
            if out[pos + 3] == 8:
                sz = int.from_bytes(out[pos + 4:pos + 8], "big")
                if 8 <= sz <= 64 and pos + 8 + sz <= len(out):
                    tags[out[pos:pos + 4].hex(" ")] += 1
        print(f"     small-tag histogram: {dict(sorted(tags.items(), key=lambda kv: -kv[1])[:8])}")
        shown += 1
        if shown >= 2:
            break
