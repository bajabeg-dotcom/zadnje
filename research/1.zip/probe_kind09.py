import sys

sys.path.insert(0, r"C:\Users\Baja\Desktop\Nova mapa")

from pathlib import Path
from setconvert.sty import StyBank
from setconvert.detect import decode_payload


def children(payload):
    out = []
    pos = 0
    while pos + 8 <= len(payload):
        marker = payload[pos:pos + 4]
        size = int.from_bytes(payload[pos + 4:pos + 8], "big")
        end = pos + 8 + size
        if end > len(payload):
            out.append((marker, size, "OVERRUN", len(payload) - pos))
            break
        out.append((marker, size, payload[pos + 8:end], None))
        pos = end
    return out, pos


PATHS = {
    "Pantic/BANK01_LIVE": r"C:\Users\Baja\Desktop\Pantic Pa1X.SET\STYLE\BANK01_LIVE.STY",
    "GOLE/FAVORITE01": r"C:\Users\Baja\Desktop\GOLE ARX .SET\GOLE ARX .SET\STYLE\FAVORITE01.STY",
    "GOLE/USER01": r"C:\Users\Baja\Desktop\GOLE ARX .SET\GOLE ARX .SET\STYLE\USER01.STY",
    "KOCE/USER01": r"C:\Users\Baja\Desktop\KOCE FOLK.SET\STYLE\USER01.STY",
    "Pa3X/USER01": r"C:\Users\Baja\Desktop\Korg Pa3x Team Serbian.SET\STYLE\USER01.STY",
    "Pa4X/USER01": r"C:\Users\Baja\Desktop\Pa4x Pro Dejan Shiki.SET\STYLE\USER01.STY",
    "Pa4X/USER03": r"C:\Users\Baja\Desktop\Pa4x Pro Dejan Shiki.SET\STYLE\USER03.STY",
    "IZOL": r"C:\Users\Baja\Desktop\STYLE\USER01_IZOLACIJA.STY",
}

for name, raw in PATHS.items():
    bank = StyBank.read(raw)
    kind09 = [r for r in bank.resources if r.kind == 9]
    print(f"=== {name} ({len(kind09)} kind09) ===")
    seen = set()
    for r in kind09:
        dec = decode_payload(r.payload)
        top, endpos = children(dec)
        sig = tuple((m.hex(' '), s) for m, s, b, x in top if b == "OVERRUN" or True)
        sig_short = tuple((m.hex(' '), s, (b.hex(' ') if isinstance(b, bytes) and len(b) > 0 else '')) for m, s, b, x in top)
        if sig_short in seen:
            continue
        seen.add(sig_short)
        print(f"  res {r.header.hex(' ')} dec={len(dec)} top_children_end={endpos}")
        for m, s, body, over in top:
            if isinstance(body, bytes):
                inner_desc = ""
                if s > 2000 and body[:4] != b"\xab\xcd\xef":
                    inner, iend = children(body)
                    inner_desc = " inner=" + ",".join(
                        f"{im.hex(' ')}/{isize}" + (f"[{ib[:4].hex(' ') if isinstance(ib, bytes) else ib}..]" if isinstance(ib, bytes) else "") for im, isize, ib, _ in inner)
                print(f"    {m.hex(' ')} size={s} head={body[:16].hex(' ')}{inner_desc}")
                if body[:2] == b"\xab\xcd":
                    named = body[16] if len(body) > 16 else -1
                    print(f"    metadata AB CD EF: named_count={named} len={s} expect={249 + named * 167 + 4}")
            else:
                print(f"    {m.hex(' ')} size={s} {body}")
