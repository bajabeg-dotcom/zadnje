import sys
import time
from pathlib import Path

ROOT = Path(r"C:\Users\Baja\Desktop\Nova mapa")
sys.path.insert(0, str(ROOT))

import setconvert.genab as genab
import setconvert.conv as conv
from pa800_native import oc31_optimal_encoder as opt

calls = {"n": 0, "time": 0.0}
orig = opt.encode_oc31


def counting_encode(data):
    calls["n"] += 1
    t = time.perf_counter()
    try:
        return orig(data)
    finally:
        calls["time"] += time.perf_counter() - t


opt.encode_oc31 = counting_encode
genab.encode_oc31 = counting_encode
conv.encode_oc31 = counting_encode

folder = ROOT / "Style Works XT Universal" / "InitKorg"
files = sorted(folder.glob("*.[Ss][Tt][Yy]"))
ok = 0
fail = 0
t0 = time.perf_counter()
for f in files:
    try:
        conv.convert_sty(f.read_bytes(), "pa800", strict=True, progress=lambda a, b, c: None)
        ok += 1
    except Exception as exc:
        fail += 1
        print(f"  {f.name}: {type(exc).__name__}: {exc}")
dt = time.perf_counter() - t0
print(f"converted={ok} failed={fail} total_time={dt:.2f}s")
print(f"optimal encoder calls={calls['n']} time={calls['time']:.3f}s")
print("OK" if calls["n"] == 0 else "FALLBACK TRIGGERED")
