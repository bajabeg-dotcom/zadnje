import sys
import time
import traceback
from pathlib import Path

sys.path.insert(0, r"C:\Users\Baja\Desktop\Nova mapa")

from setconvert.gui import convert_text

src = r"C:\Users\Baja\Desktop\Korg Pa3x Team Serbian.SET\STYLE\FAVORITE12.STY"
out = r"C:\Users\Baja\AppData\Local\Temp\opencode\FAVORITE12_pa800.STY"

t0 = time.time()
try:
    text = convert_text(src, out, "pa800", None, True, False)
except Exception:
    traceback.print_exc()
    sys.exit(1)
print(f"elapsed {time.time() - t0:.1f}s")
print(text[:3000])
ok = Path(out).exists() and Path(out).stat().st_size > 0
print("output exists:", ok, Path(out).stat().st_size if ok else 0)
print("FAILED marker:", "FAILED" in text)
sys.exit(0 if ok and "FAILED" not in text else 1)
