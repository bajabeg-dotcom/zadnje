#!/usr/bin/env python3
"""Probe id=17 comp semantics + id=19 header."""
import math
import struct
import zlib
from collections import Counter
from pathlib import Path

PKG = Path(r"E:\PA4\Pa4X Operating System v.3.1.0\Pa4X_Operating_System_v310.pkg")
data = PKG.read_bytes()


def entropy(b: bytes) -> float:
    if not b:
        return 0.0
    c = Counter(b)
    n = len(b)
    return -sum((v / n) * math.log2(v / n) for v in c.values())


pos = 16
chunks = []
while pos + 8 <= len(data):
    cid, size = struct.unpack_from("<II", data, pos)
    if cid == 0 or size == 0 or size > len(data):
        break
    chunks.append((pos, cid, size))
    pos += 8 + size
    if pos % 4:
        pos += 4 - (pos % 4)

by_comp = {}
for p, cid, size in chunks:
    if cid != 17:
        continue
    body = p + 8
    md5 = data[body:body + 16]
    owner, group, attrs, cond = struct.unpack_from("<HHHH", data, body + 16)
    dsize, = struct.unpack_from("<I", data, body + 24)
    comp, = struct.unpack_from("<B", data, body + 28)
    i = body + 29
    fields = []
    for _ in range(3):
        z = data.index(b"\0", i)
        fields.append(data[i:z].decode("latin1"))
        i = z + 1
    path, date, timestr = fields
    header_len = i - body
    stored = size - header_len
    blob = data[i:i + stored]
    rec = dict(path=path, size=size, dsize=dsize, stored=stored, header_len=header_len,
               md5=md5, ent=entropy(blob), first16=blob[:16].hex())
    by_comp.setdefault(comp, []).append(rec)

for comp in sorted(by_comp):
    recs = by_comp[comp]
    print(f"=== comp={comp}  n={len(recs)} ===")
    for r in recs[:5]:
        ratio = r["stored"] / r["dsize"] if r["dsize"] else 0
        print(f"  {r['path'][:60]:<60} size={r['size']} stored={r['stored']} dsize={r['dsize']} "
              f"ratio={ratio:.3f} ent={r['ent']:.2f}")
        print(f"     first16={r['first16']}")
    ratios = [r["stored"] / r["dsize"] for r in recs if r["dsize"]]
    print(f"  ratio min={min(ratios):.3f} max={max(ratios):.3f}  ent min={min(r['ent'] for r in recs):.2f} max={max(r['ent'] for r in recs):.2f}")

# --- md5 verification for comp=0 and comp=16 (stored raw?) ---
print("\n=== MD5 check (md5hdr vs md5(stored)) ===")
for p, cid, size in chunks:
    if cid != 17:
        continue
    body = p + 8
    md5 = data[body:body + 16]
    dsize, = struct.unpack_from("<I", data, body + 24)
    comp, = struct.unpack_from("<B", data, body + 28)
    if comp not in (0, 16):
        continue
    i = body + 29
    for _ in range(3):
        i = data.index(b"\0", i) + 1
    stored = size - (i - body)
    blob = data[i:i + stored]
    import hashlib
    h = hashlib.md5(blob).hexdigest()
    print(f"  comp={comp} match={h == md5.hex()} stored={stored} dsize={dsize} head={data[i:i+20].hex()}")
    if comp == 16:
        # try: maybe stored = dsize exactly
        print(f"     stored==dsize? {stored == dsize}  md5hdr={md5.hex()} md5(blob)={h}")
    if comp == 0:
        print(f"     stored={stored} dsize={dsize} md5hdr={md5.hex()} md5(blob)={h}")

# --- id=19 header ---
print("\n=== id=19 header ===")
for p, cid, size in chunks:
    if cid != 19:
        continue
    body = p + 8
    print("body@hex:", hex(body))
    print("bytes[0:64]:", data[body:body + 64].hex())
    # find ustar
    ustar = data.find(b"ustar", body, body + 512)
    print("ustar at", hex(ustar) if ustar != -1 else None, "delta", ustar - body if ustar != -1 else None)
    print("text around:", repr(data[body:body + 48]))
