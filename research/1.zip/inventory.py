# -*- coding: utf-8 -*-
"""Inventory style files + KORG9 section layout + KORF block headers."""
import os, sys, struct, re, json
from collections import defaultdict
sys.stdout.reconfigure(encoding='utf-8', errors='replace')

ROOT = r'C:\Users\Baja\Desktop\Nova mapa\Style Works XT Universal'

def read(p, n=None):
    with open(p, 'rb') as f:
        return f.read() if n is None else f.read(n)

def detect(path):
    b = read(path, 512)
    name = os.path.basename(path)
    ext = os.path.splitext(name)[1].lower()
    # SMF / Yamaha SFF
    if b[:4] == b'MThd':
        fmt, ntrk, div = struct.unpack('>HHH', b[8:14])
        return 'Yamaha_SFF', {'smf_fmt': fmt, 'ntrk': ntrk, 'div': div}
    if b[:5] in (b'KORG9', b'KORGI', b'KORGM'):
        return 'Korg_' + b[:5].decode(), {
            'b5': b[5], 'type': b[6], 'flag': b[7],
            'type_name': {0: 'PRG', 1: 'SNG/BSQ', 3: 'ARR', 4: 'STY',
                          5: 'BSQ', 6: 'GBL', 7: 'ARG', 8: 'ARK/KBS'}.get(b[6], '?'),
        }
    if b[23:27] == b'KORF' or b[:4] == b'\x01\x00\x01\x14':
        # Pa series style or other
        return 'Korg_Pa_KORF', {'kor_f_at': b.find(b'KORF'), 'head': b[:16].hex()}
    if b[:4] == b'YCKW':
        return 'Kurzweil_KST', {}
    if b[:8] == b'MT_STYL':
        return 'ORLA_STL', {}
    if b[:4] == b'KPAT':
        return 'Solton_Ketron_PAT', {}
    if b[:4] == b'NCP1':
        return 'Kawai_E51', {}
    if b[:6] == b'DISK   ' or b[:8] == b'SONG    ':
        return 'Yamaha_MNG', {}
    if b'ZZZ' in b[:64] or b[:2] == b'ZZ' or b[:4] == b'ZZZZ':
        return 'Technics_ZZZ', {'sub': b[:16].hex()}
    if b[:4] == b'45\x00KP' or b[:4] == b'\x45\x00\x4b\x50':
        return 'Technics_CMP', {}
    if b[:3] == b'HK ':
        return 'Technics_PMT', {}
    if b[:3] in (b'IK ', b'JK ') or b[:2] == b'J ' or b[:2] == b'JK':
        return 'Technics_JK', {}
    if b[:4] == b'EV\x00\x01' or (b[:2] == b'EV' and ext in ('.stl', '.sth')):
        return 'Roland_E', {}
    if b[:4] == b'MThd':
        return 'SMF', {}
    # Roland STL with free name
    if ext in ('.stl', '.sth') and (b[0:1] == b'\x00' or all(32 <= x < 127 for x in b[:16])):
        return 'Roland_STL?', {'head': b[:16].hex()}
    if ext == '.rmp':
        if b.startswith(b'VersionId'):
            line1 = b.split(b'\r\n')[0].decode('latin-1', 'replace')
            return 'ReferenceMap_RMP', {'version': line1}
        return 'RMP?', {}
    if ext == '.snd':
        if b'\x00' in b[:20] and not re.search(rb'\d{3}-', b[:100]):
            return 'SND_binary', {}
        return 'SND_text', {}
    if ext in ('.u01', '.u02'):
        return 'GEM_U0x', {}
    if ext == '.al2':
        return 'Kawai_AL2', {}
    return 'unknown_' + (ext or name), {'head': b[:16].hex()}

# Walk all style-ish extensions
STYLE_EXT = {'.sty', '.stl', '.sth', '.kst', '.pat', '.tm', '.lsw', '.cmp',
             '.seq', '.sqf', '.sqt', '.msp', '.pmt', '.efc', '.arr', '.bsq',
             '.gbl', '.kbs', '.arg', '.ark', '.pcg', '.sng', '.prg', '.set',
             '.u01', '.u02', '.al2', '.e51', '.rmp', '.snd'}

inventory = defaultdict(list)
for dirpath, dns, fns in os.walk(ROOT):
    for fn in fns:
        ext = os.path.splitext(fn)[1].lower()
        if ext not in STYLE_EXT and not fn.lower().endswith('.sty'):
            continue
        path = os.path.join(dirpath, fn)
        rel = os.path.relpath(path, ROOT)
        try:
            kind, meta = detect(path)
        except Exception as e:
            kind, meta = 'ERR', {'err': str(e)}
        inventory[kind].append({'file': rel, 'size': os.path.getsize(path), **meta})

print('=== FORMAT INVENTORY ===')
for kind in sorted(inventory):
    items = inventory[kind]
    print('\n[{}]  n={}'.format(kind, len(items)))
    for it in items[:8]:
        extra = {k: v for k, v in it.items() if k not in ('file', 'size')}
        print('  {:6d}  {}  {}'.format(it['size'], it['file'], extra if extra else ''))
    if len(items) > 8:
        print('  ... +{} more'.format(len(items) - 8))

# Save inventory JSON
out = r'C:\Users\Baja\AppData\Local\Temp\opencode\format_inventory.json'
with open(out, 'w', encoding='utf-8') as f:
    json.dump({k: v for k, v in inventory.items()}, f, ensure_ascii=False, indent=1)
print('\nwrote', out)

# KORG9: section name positions + data between them
print('\n=== KORG9 STY sections ===')
p = os.path.join(ROOT, 'InitKorg', 'Init_i3.sty')
b = open(p, 'rb').read()
# known name slots
names_pos = []
for o in range(0, len(b) - 10):
    chunk = b[o:o + 10]
    if all(32 <= x < 127 for x in chunk) and re.match(rb'[A-Za-z]', chunk) and chunk.endswith(b'  '):
        if o == 0 or not (32 <= b[o - 1] < 127):
            names_pos.append((o, chunk.decode('ascii').rstrip()))
print('sections:', names_pos)
for i, (o, nm) in enumerate(names_pos):
    end = names_pos[i + 1][0] if i + 1 < len(names_pos) else len(b)
    print('  [{}] {!r} @ {:#x}..{:#x}  span={}'.format(i, nm, o, end, end - o))

# KORF per-style block: find 'OC32'/'OC33' markers and style name blocks
print('\n=== KORF style data blocks (Initpa01) ===')
p = os.path.join(ROOT, 'InitKorg', 'Initpa01.STY')
b = open(p, 'rb').read()
# name index ends 0x324
# search for OC32 pattern (4f 43 33 32)
pos = 0
ocs = []
while True:
    i = b.find(b'OC3', pos)
    if i < 0:
        break
    tag = b[i:i + 4]
    ocs.append((i, tag.decode('latin-1', 'replace')))
    pos = i + 1
print('OC3x markers:', ocs[:20], 'count', len(ocs))

# Each style block seems preceded by: 30 00 00 XX XX 4f433332 ...
# Find all '4f433332' (OC32) and show context
for i, tag in ocs[:6]:
    pre = b[max(0, i - 16):i]
    post = b[i:i + 32]
    print('  @{:#x} {}  pre={}  post={}'.format(i, tag, pre.hex(), post.hex()))
    # decode post as possible size fields
    if len(post) >= 16:
        u16s = struct.unpack_from('<8H', post, 0)
        print('    u16:', u16s)

# Style name embedded with 0xaa 0xa0 marker before params?
# From earlier: name + aa a0 f8 03 ff 02 80 ...
# pattern: <name up to 15 chars> aa a0 <params>
print('\nembedded style headers (name + aa a0 marker):')
pos = 0x324
count = 0
while count < 32:
    i = b.find(b'\xaa\xa0', pos)
    if i < 0:
        break
    # name is before, null-padded to... find start
    # look back for previous marker or non-name
    start = i
    while start > 0 and (32 <= b[start - 1] < 127 or b[start - 1] == 0):
        # stop if too far
        if i - start > 40:
            break
        start -= 1
        if b[start] == 0 and start > 0 and 32 <= b[start - 1] < 127:
            continue
    # simpler: take 16 bytes before aa a0 as name field (null padded)
    name_field = b[i - 16:i] if i >= 16 else b''

    def cs(x):
        z = x.find(b'\x00')
        if z >= 0:
            x = x[:z]
        return x.decode('latin-1', 'replace').strip()

    nm = cs(name_field)
    params = b[i:i + 12]
    print('  @{:#06x} name={!r} marker=aaa0 params={}'.format(i, nm, params[2:].hex()))
    pos = i + 2
    count += 1
print('shown', count)
