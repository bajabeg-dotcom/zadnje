import re, os, glob, sys
sys.stdout.reconfigure(encoding="utf-8", errors="replace")
D = r"C:\Users\Baja\Desktop\Nova mapa\Style Works XT Universal\InitKorg"
for f in sorted(glob.glob(os.path.join(D, "*"))):
    if not os.path.isfile(f): continue
    ext = os.path.splitext(f)[1].lower()
    if ext in (".bmp", ".gif", ".jpg", ".snd", ".txt"): continue
    b = open(f, "rb").read()
    a = set(m.group().decode() for m in re.finditer(rb"[\x20-\x7e]{6,}", b))
    u = set(m.group().decode("utf-16le", "replace") for m in re.finditer(rb"(?:[\x20-\x7e]\x00){6,}", b))
    hits = sorted(x for x in (a | u) if re.search(r"[A-Za-z]{3}", x) and not re.fullmatch(r"[\x20-\x7e]{6}", x) or re.search(r"MUS|KORG|PA\d|v\d\.\d|Z\d{3}", x))
    interesting = [x for x in hits if re.search(r"MUS|KORG|Korf|v\d+\.\d+|PA\d|i\d\d|Z\d{3}|Style|bank|Bank|OS\b|version|Version", x)]
    print(f"### {os.path.basename(f)} ({len(b)} bytes): {sorted(a|u)[:0]}")
    for x in sorted(set(interesting))[:25]:
        print("   ", repr(x))
