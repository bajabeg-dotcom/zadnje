import sys, os, glob, re, collections, itertools
sys.path.insert(0, r"C:\Users\Baja\Desktop\Nova mapa")
from pa800_native import parse_bank, decode_oc31, parse_type06_trackinfo

D = r"C:\Users\Baja\Desktop\Nova mapa\Style Works XT Universal\InitKorg"

def dec(r):
    p = r.payload
    if p[:4] in (b"OC31", b"OC32"):
        return decode_oc31(b"OC31" + p[4:])
    return p

def walk_children(buf, start=8):
    pos, out = start, []
    while pos + 8 <= len(buf):
        tag = buf[pos:pos+4]
        size = int.from_bytes(buf[pos+4:pos+8], "big")
        if tag[3] != 8 or pos + 8 + size > len(buf):
            break
        out.append((pos, tag, size, buf[pos+8:pos+8+size]))
        pos += 8 + size
    return out, pos

# rom lists
roms = {}
for f in glob.glob(os.path.join(D, "*.SND")):
    txt = open(f, "rb").read().decode("latin1")
    roms[os.path.basename(f)] = [(int(a), int(b), int(c), n.strip()) for a, b, c, n in
                                 re.findall(r"^(\d{3})-(\d{3})-(\d{3}) (.+)$", txt, re.M)]

files = sorted(set(glob.glob(os.path.join(D, "*.STY")) + glob.glob(os.path.join(D, "*.sty"))))
sty_sels, sty_names05 = {}, {}

for f in files:
    data = open(f, "rb").read()
    if data[:4] != b"\x01\x00\x01\x14":
        continue
    base = os.path.basename(f)
    bank = parse_bank(data)
    sels, names05, kids06 = [], [], []
    for i, r in enumerate(bank.resources):
        out = dec(r)
        if r.kind == 5:
            # 24-byte name entries (may have small per-entry header)
            names05.append((i, out))
        elif r.kind == 6:
            try:
                for blk in parse_type06_trackinfo(out):
                    for t in blk["tracks"]:
                        sels.append((t["bank_msb"], t["bank_lsb"], t["program"]))
            except Exception:
                pass
            if not kids06:
                ch, endp = walk_children(out)
                kids06 = [(pos, tag, size, pl[:40]) for pos, tag, size, pl in ch]
    sty_sels[base] = sels
    sty_names05[base] = names05
    if kids06:
        print(f"--- {base}: kind06 children ---")
        for pos, tag, size, pl in kids06[:8]:
            print(f"    @0x{pos:X} tag={tag.hex(' ')} size={size} payload[:40]={pl.hex(' ')} | {pl[:32]!r}")

print("\n--- 05 record names ---")
for base, tables in sty_names05.items():
    for i, out in tables:
        # try 24-byte stride entries, printable
        ents = [out[k:k+24] for k in range(0, len(out) - 23, 24)]
        names = [e.split(b"\x00")[0].split(b" ")[0].decode("latin1", "replace") if False else e.rstrip(b"\x00 ").decode("latin1", "replace") for e in ents]
        print(f"{base} res[{i}] len={len(out)} n={len(ents)}: {names[:16]}")

# selector vs rom matching, all field permutations
print("\n--- selector/rom match (permutations of rom fields -> (msb,lsb,prg)) ---")
allsel = {k: set(v) for k, v in sty_sels.items()}
for base, ss in allsel.items():
    if not ss:
        print(f"{base}: no selectors")
        continue
    res = []
    for perm in itertools.permutations(range(3)):
        for rn, rows in roms.items():
            rs = {(r[perm[0]], r[perm[1]], r[perm[2]]) for r in rows}
            res.append((len(ss & rs), perm, rn))
    res.sort(reverse=True)
    print(f"{base}: nsel={len(ss)} top={res[:3]}")
