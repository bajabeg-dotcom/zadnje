﻿$p="C:\Users\Baja\Desktop\Nova mapa\KORG PA Manager\v3\KORGPAManager.exe"
$b=[IO.File]::ReadAllBytes($p)
$base=0x0133C800; $va=0x04E73000
function Rva2Off($r){ return ($r - $va + $base) }
function ReadName($rva){
  $o=Rva2Off $rva
  $len=[BitConverter]::ToUInt16($b,$o); $o2=$o+2
  $chars=@(); for($i=0;$i -lt $len;$i++){ $chars+=[char][BitConverter]::ToUInt16($b,$o2+$i*2) }
  return (-join $chars)
}
function Walk($dirRva,$depth,$path){
  $o=Rva2Off $dirRva
  $nn=[BitConverter]::ToUInt16($b,$o+12); $no=[BitConverter]::ToUInt16($b,$o+14)
  for($e=0;$e -lt ($nn+$no);$e++){
    $eo=$o+16+$e*8
    $name=[BitConverter]::ToUInt32($b,$eo)
    $off=[BitConverter]::ToUInt32($b,$eo+4)
    $label=""
    if($name -band 0x80000000){ $label=ReadName ($dirRva - ($name -band 0x7FFFFFFF)*0 -band 0) }
    # name RVA is relative to resource dir start
    if($name -band 0x80000000){ $label=ReadName ($dirRva + ($name -band 0x7FFFFFFF)) } else { $label="$name" }
    $isDir = ($off -band 0x80000000) -ne 0
    $child = $dirRva + ($off -band 0x7FFFFFFF)
    if($isDir){ Walk $child ($depth+1) "$path/$label" }
    else {
      $fo=Rva2Off $child
      $dRva=[BitConverter]::ToUInt32($b,$fo); $dSz=[BitConverter]::ToUInt32($b,$fo+4)
      "{0,-40} off=0x{1:X} size=0x{2:X}" -f "$path/$label",$dRva,$dSz
    }
  }
}
Walk 0x04E73000 0 ""
