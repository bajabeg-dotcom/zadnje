﻿import os, re, collections, struct
d = r"C:\Users\Baja\Desktop\Nova mapa\Style Works XT Universal\InitKorg"
def names16(data, minlen=4):
    # find fixed-width (16) space/NUL-padded uppercase-ish names
    out=[]
    for m in re.finditer(rb'[A-Za-z0-9][A-Za-z0-9 _\.\-\+\&\(\)\']{%d,15}[ ]{2,}'%minlen, data):
        pass
    return out
def scan(fn, hdr_guess):
    p=os.path.join(d,fn); data=open(p,'rb').read()
    # find runs of >=8 printable chars followed by >=2 spaces, aligned
    hits=[m.start() for m in re.finditer(rb'[A-Z][A-Za-z0-9 \.\-\+\&\']{5,14}  ', data)]
    c=collections.Counter()
    for i in range(1,len(hits)):
        c[hits[i]-hits[i-1]]+=1
    print("%-16s size=%-7d name-like starts=%d  common deltas=%s"%(fn,len(data),len(hits),c.most_common(5)))
    return hits
for fn in ["INIT_I30.ARR","INIT_I40.ARR","Init_i3.arr","INIT_I30.PRG","INIT_I40.PRG",
           "Init_i3.pcg","INIT_I30.STY","INIT_I40.STY","Init_i3.sty","INIT_I30.GBL","Init_i3.bsq"]:
    scan(fn,0)
print()
print("### exact stride check")
def check(fn, base, stride, count, label):
    p=os.path.join(d,fn); data=open(p,'rb').read()
    ok=0
    for i in range(count):
        off=base+i*stride
        if off>=len(data): break
        nm=data[off:off+16]
        if all(32<=b<127 or b==0 for b in nm): ok+=1
    print("   %-14s %s base=0x%X stride=%d n=%d -> %d/%d readable  end=0x%X (file=0x%X)"%(
        fn,label,base,stride,count,ok,count,base+count*stride,len(data)))
check("INIT_I30.ARR",0x20,164,128,"ARR")
check("INIT_I40.ARR",0x20,164,64,"ARR")
check("Init_i3.arr",0x20,164,55,"ARR")
# PRG stride probe
for fn in ["INIT_I30.PRG","INIT_I40.PRG"]:
    data=open(os.path.join(d,fn),'rb').read()
    offs=[m.start() for m in re.finditer(rb'[A-Z][a-z]{2,}[a-zA-Z ]{0,12}  ', data[:600])]
    print("   %s first name offsets: %s"%(fn,[hex(o) for o in offs[:6]]))
