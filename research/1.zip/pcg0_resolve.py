import sys, io, os, glob, collections
sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding='utf-8', errors='replace')
sys.path.insert(0, r'C:\Users\Baja\Desktop\Nova mapa')
from setconvert.sty import StyBank
from setconvert import parameters as P
from setconvert import sts as S
from setconvert.sts import StsStats
from setconvert.detect import decode_payload
from setconvert.families import FAMILIES
from pa800_native.sty_container import parse_bank

PRG = r'C:\Users\Baja\Desktop\PA800_AI_PA800_STUDIO_v5_2026-09-20\factory_evidence\native_factory\SOUND\PRGMAPS.TBL'
ROM = r'C:\Users\Baja\Desktop\PA800_AI_PA800_STUDIO_v5_2026-09-20\factory_evidence\native_factory\SOUND\ROM.PCG'

def build_pa800_map():
    bank = parse_bank(open(PRG, 'rb').read())
    otc_raw, nvar_raw, sl = bank.resources[1].payload, bank.resources[2].payload, bank.resources[5].payload
    otc = [int.from_bytes(otc_raw[8+i*2:10+i*2], 'big') for i in range((len(otc_raw)-8)//2)]
    nvar = list(nvar_raw[8:])
    pos = 8
    entries = []
    while pos < len(sl):
        n = int.from_bytes(sl[pos:pos+2], 'big'); pos += 2
        if n == 0: break
        for i in range(n):
            e = sl[pos:pos+6]; pos += 6
            entries.append((int.from_bytes(e[0:2], 'big'), e[2], e[3], (e[4] << 7) | e[5]))
    cat = [r for r in parse_bank(open(ROM, 'rb').read()).resources if r.kind == 5][0].payload
    names = [cat[i*24:(i+1)*24].split(b'\x00')[0].decode('ascii', 'replace') for i in range(len(cat)//24)]
    out = {}
    for msb, lsb, pc, ordinal in entries:
        nm = names[ordinal] if ordinal < len(names) else None
        out[(msb, lsb, pc)] = (ordinal, nm, otc, nvar)
    return out, entries, names

MAP, ENTRIES, NAMES = build_pa800_map()
print(f'pa800 SoundsLayout entries: {len(ENTRIES)} distinct selectors: {len(MAP)} catalog: {len(NAMES)}')
print(f'  with name: {sum(1 for v in MAP.values() if v[1])}')

SETS = [
    ('pa800', r'C:\Users\Baja\Desktop\KOCE FOLK.SET'),
    ('pa800', r'C:\Users\Baja\Desktop\GOLE ARX .SET'),
    ('pa1x',  r'C:\Users\Baja\Desktop\Pantic Pa1X.SET'),
    ('pa3x',  r'C:\Users\Baja\Desktop\Korg Pa3x Team Serbian.SET'),
    ('pa4x',  r'C:\Users\Baja\Desktop\Pa4x Pro Dejan Shiki.SET'),
]

for family, root in SETS:
    stys = sorted({p for p in glob.glob(os.path.join(root, '**', '*'), recursive=True)
                   if p.lower().endswith('.sty')})[:8]
    dialect = FAMILIES[family].sts_dialect
    param, sts = collections.Counter(), collections.Counter()
    errs = collections.Counter()
    for sty in stys:
        try:
            bank = StyBank.read(sty)
        except Exception as e:
            errs[f'read:{e}'] += 1; continue
        for res in bank.resources:
            if res.kind == 6:
                try:
                    for blk in P.find_blocks(decode_payload(res.payload)):
                        for rec in blk.records:
                            param[rec.selector] += 1
                except Exception as e:
                    errs[f'k6:{e}'] += 1
            elif res.kind == 9:
                try:
                    stats = StsStats()
                    for slot in S.read_document_slots(decode_payload(res.payload), dialect, None, stats):
                        for row in slot.selectors:
                            sts[row] += 1
                except Exception as e:
                    errs[f'k9:{type(e).__name__}:{e}'] += 1
    allsel = param + sts
    resolved = [k for k in allsel if k in MAP]
    unresolved = [k for k in allsel if k not in MAP]
    print(f'\n== {family} {os.path.basename(root)} files={len(stys)}')
    print(f'   param={sum(param.values())} sts={sum(sts.values())} distinct={len(allsel)}')
    print(f'   resolved by pa800 SoundsLayout: {len(resolved)} distinct / {len(allsel)}')
    print(f'   msb hist (all): {dict(collections.Counter(k[0] for k in allsel))}')
    print(f'   unresolved top: {[(k, allsel[k]) for k in sorted(unresolved, key=lambda x: -allsel[x])[:10]]}')
    if errs:
        print('   errors:', dict(errs))
    # sample names for resolved
    sample = sorted(resolved, key=lambda k: -allsel[k])[:6]
    for k in sample:
        ordinal, nm, _, _ = MAP[k]
        print(f'     {k} x{allsel[k]:5d} -> [{ordinal}] {nm!r}')
