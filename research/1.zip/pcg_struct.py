import sys, io, os, glob, collections
sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding='utf-8', errors='replace', line_buffering=True)
sys.path.insert(0, r'C:\Users\Baja\Desktop\Nova mapa')
from pa800_native.sty_container import parse_bank

SET = [
    ('pa800 KOCE', r'C:\Users\Baja\Desktop\KOCE FOLK.SET'),
    ('pa800 GOLE', r'C:\Users\Baja\Desktop\GOLE ARX .SET'),
    ('pa1x Pantic', r'C:\Users\Baja\Desktop\Pantic Pa1X.SET'),
    ('pa3x Serbian', r'C:\Users\Baja\Desktop\Korg Pa3x Team Serbian.SET'),
    ('pa4x Dejan', r'C:\Users\Baja\Desktop\Pa4x Pro Dejan Shiki.SET'),
]
for label, root in SET:
    files = sorted(glob.glob(os.path.join(root, '**', '*.pcg'), recursive=True))
    print(f'\n#### {label}: {len(files)} PCG')
    for p in files[:6]:
        data = open(p, 'rb').read()
        head = data[:8]
        try:
            bank = parse_bank(data)
            kinds = collections.Counter((r.kind, r.header[1:].hex(' ')) for r in bank.resources)
            rt = 'RT-OK' if bank.build() == data else 'RT-DIFF'
            info = []
            for r in bank.resources:
                if r.kind == 5:
                    info.append(f'k5 len={len(r.payload)} first24={r.payload[:24].hex(" ")}')
            print(f'  {os.path.basename(p):18s} magic={head.hex(" ")} kinds={dict(kinds)} {rt}')
            for i in info[:2]:
                print(f'      {i}')
        except ValueError as e:
            print(f'  {os.path.basename(p):18s} magic={head.hex(" ")} PARSE-FAIL: {e}')
