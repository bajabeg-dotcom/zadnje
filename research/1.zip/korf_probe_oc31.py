import os
import struct
import sys
import traceback

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from oc31 import decompress_block

STY = r"C:\Users\Baja\Desktop\Nova mapa\Style Works XT Universal\InitKorg\Initpa01.STY"
STY31 = r"C:\Users\Baja\Desktop\Nova mapa\Style Works XT Universal\InitKorg\InitPx03.STY"


def find_magics(data):
    hits = []
    i = 0
    while True:
        i = data.find(b"OC3", i)
        if i < 0:
            break
        if i + 4 <= len(data) and data[i:i + 4] in (b"OC31", b"OC32", b"OC33"):
            hits.append((i, data[i:i + 4].decode()))
        i += 1
    return hits


def try_decompress(data, magic_off, magic, label):
    pre = data[max(0, magic_off - 16):magic_off]
    hdr_after = data[magic_off + 4:magic_off + 16]
    print(f"\n== {label} @{magic_off:#x} {magic} ==")
    print(f"  pre-16 : {pre.hex(' ')}")
    print(f"  +4..+16: {hdr_after.hex(' ')}")

    # Layout A (oc31.c): [u32be totalSize][magic][u32le uncompr][payload of totalSize-8]
    cands = []
    if magic_off >= 4:
        size_be = struct.unpack_from(">I", data, magic_off - 4)[0]
        cands.append(("u32be@-4", size_be, magic_off + 8, magic_off + 4 + size_be))
    if magic_off >= 2:
        size_be16 = struct.unpack_from(">H", data, magic_off - 2)[0]
        cands.append(("u16be@-2", size_be16, magic_off + 8, magic_off + 4 + 2 + size_be16 - 8))
        cands.append(("u16be@-2_full", size_be16, magic_off + 8, magic_off + 8 + size_be16))
    if magic_off >= 6:
        size_be16 = struct.unpack_from(">H", data, magic_off - 2)[0]
        cands.append(("u16be@-2_v2", size_be16, magic_off + 8, magic_off + 8 + size_be16 - 8))

    uncompr = struct.unpack_from("<I", data, magic_off + 4)[0]
    if uncompr > 5_000_000:
        uncompr = struct.unpack_from(">I", data, magic_off + 4)[0]
        print(f"  uncompr(be) = {uncompr}")
    else:
        print(f"  uncompr(le) = {uncompr}")

    # next magic for dist
    return pre, hdr_after, uncompr, cands


def run(path):
    data = open(path, "rb").read()
    print(f"\n##### {os.path.basename(path)} size={len(data)} #####")
    magics = find_magics(data)
    print(f"magics: {[(hex(o), m) for o, m in magics]}")

    for idx, (off, magic) in enumerate(magics[:4]):
        pre, hdr, uncompr, cands = try_decompress(data, off, magic, f"block{idx}")

        # dist to next magic
        if idx + 1 < len(magics):
            dist = magics[idx + 1][0] - off
            print(f"  dist to next magic = {dist} (size candidates should be dist or dist-8: {dist}, {dist - 8})")

        tried = set()
        for name, size, start, end in cands:
            key = (start, end)
            if key in tried:
                continue
            tried.add(key)
            if size > 10_000_000 or size < 8:
                continue
            if start < 0 or end > len(data) or end <= start:
                print(f"  [{name}] size={size} range OOB start={start} end={end}")
                continue
            payload = data[start:end]
            print(f"  [{name}] size={size} payload[{start}:{end}] len={len(payload)} first8={payload[:8].hex(' ')}")
            try:
                out, meta = decompress_block(payload, uncompr)
                print(f"    OK out={len(out)} leftover={meta['leftover']} ecc_ok={meta['ecc_ok']} ({meta['ecc_stored']:02x} vs {meta['ecc_computed']:02x})")
                printable = bytes(b if 32 <= b < 127 else 46 for b in out[:120])
                print(f"    head: {printable}")
                # show strings
                s = out[:200]
                print(f"    hex  : {out[:64].hex(' ')}")
            except Exception as e:
                print(f"    FAIL: {e}")
                # traceback.print_exc()


if __name__ == "__main__":
    run(STY)
    run(STY31)
