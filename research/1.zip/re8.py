import sys, os, glob, re, itertools
sys.path.insert(0, r"C:\Users\Baja\Desktop\Nova mapa")
from pa800_native import parse_bank, decode_oc31, parse_type06_trackinfo
D = r"C:\Users\Baja\Desktop\Nova mapa\Style Works XT Universal\InitKorg"
sys.stdout.reconfigure(encoding="utf-8", errors="replace")

def dec(r):
    p = r.payload
    return decode_oc31(b"OC31" + p[4:]) if p[:4] in (b"OC31", b"OC32") else p

roms = {}
for f in glob.glob(os.path.join(D, "*.SND")):
    txt = open(f, "rb").read().decode("latin1")
    roms[os.path.basename(f)] = [(int(a), int(b), int(c), n.strip()) for a, b, c, n in
                                 re.findall(r"^(\d{3})-(\d{3})-(\d{3}) (.+)$", txt, re.M)]

files = sorted(set(glob.glob(os.path.join(D, "*.STY")) + glob.glob(os.path.join(D, "*.sty"))))
for f in files:
    data = open(f, "rb").read()
    if data[:4] != b"\x01\x00\x01\x14":
        continue
    base = os.path.basename(f)
    bank = parse_bank(data)
    sels, t05 = [], None
    for i, r in enumerate(bank.resources):
        out = dec(r)
        if r.kind == 5 and t05 is None:
            t05 = out
        elif r.kind == 6:
            try:
                for blk in parse_type06_trackinfo(out):
                    for t in blk["tracks"]:
                        sels.append((t["bank_msb"], t["bank_lsb"], t["program"]))
            except Exception:
                pass
    print(f"\n=== {base} ({len(sels)} trackinfo records)")
    ss = set(sels)
    print("  distinct selectors:", sorted(ss))
    res = []
    for perm in itertools.permutations(range(3)):
        for rn, rows in roms.items():
            rs = {(r[perm[0]], r[perm[1]], r[perm[2]]) for r in rows}
            res.append((len(ss & rs), len(ss), perm, rn))
    res.sort(reverse=True)
    print("  top matches:", [(c, n, perm, rn) for c, n, perm, rn in res[:4]])
    if t05 is not None:
        print("  05 entries hex:")
        for k in range(0, min(len(t05), 24*4), 24):
            print("   ", t05[k:k+24].hex(" "))
