import struct, sys
from pathlib import Path

sys.path.insert(0, r"C:\Users\Baja\Desktop\Nova mapa")
from pa800_native.oc31_codec import decode_oc31

PA800_FILES = [
    r"C:\Users\Baja\Desktop\GOLE ARX .SET\GOLE ARX .SET\STYLE\USER01.STY",
    r"C:\Users\Baja\Desktop\GOLE ARX .SET\GOLE ARX .SET\STYLE\FAVORITE01.STY",
    r"C:\Users\Baja\Desktop\KOCE FOLK.SET\STYLE\USER01.STY",
    r"C:\Users\Baja\Desktop\KOCE FOLK.SET\STYLE\FAVORITE01.STY",
    r"C:\Users\Baja\Desktop\USER01_PA800.STY",
]
PA3X_FILES = [
    r"C:\Users\Baja\Desktop\Korg Pa3x Team Serbian.SET\STYLE\FAVORITE12.STY",
    r"C:\Users\Baja\Desktop\Korg Pa3x Team Serbian.SET\STYLE\USER01.STY",
    r"C:\Users\Baja\Desktop\Korg Pa3x Team Serbian.SET\STYLE\USER02.STY",
    r"C:\Users\Baja\Desktop\Korg Pa3x Team Serbian.SET\STYLE\USER03.STY",
]
PA4X_FILES = [
    r"C:\Users\Baja\Desktop\Pa4x Pro Dejan Shiki.SET\STYLE\USER01.STY",
    r"C:\Users\Baja\Desktop\Pa4x Pro Dejan Shiki.SET\STYLE\USER02.STY",
    r"C:\Users\Baja\Desktop\Pa4x Pro Dejan Shiki.SET\STYLE\USER03.STY",
]


def container(data):
    pos = 8
    out = []
    while pos + 8 <= len(data):
        hdr = data[pos:pos + 4]
        size = struct.unpack(">I", data[pos + 4:pos + 8])[0]
        out.append((hdr, data[pos + 8:pos + 8 + size]))
        pos += 8 + size
    return out


def dec(p):
    if p[:4] in (b"OC31", b"OC32"):
        return decode_oc31(p)
    return p


def kind09(path):
    data = Path(path).read_bytes()
    for hdr, payload in container(data):
        if hdr[0] == 9:
            return dec(payload)
    raise SystemExit("no kind09 " + path)


def children(buf):
    pos = 0
    out = []
    while pos + 8 <= len(buf):
        tag = buf[pos:pos + 4]
        size = struct.unpack(">I", buf[pos + 4:pos + 8])[0]
        if pos + 8 + size > len(buf):
            out.append((tag, size, None, pos))
            break
        out.append((tag, size, buf[pos + 8:pos + 8 + size], pos))
        pos += 8 + size
    return out, pos


def hx(b, n=None):
    if n is not None:
        b = b[:n]
    s = b.hex(" ")
    if len(b) > (n or len(b)):
        s += " ..."
    return s


def walk_named(buf, path=""):
    """yield (path, tag, body) recursively for children that parse cleanly."""
    kids, end = children(buf)
    if not kids or end != len(buf) or any(k[2] is None for k in kids):
        return None
    res = []
    for tag, size, body, _ in kids:
        p = f"{path}/{tag.hex()}"
        res.append((p, tag, body))
        sub = walk_named(body, p)
        if sub:
            res.extend(sub)
    return res


# ---------------- pa800 parts ----------------
def pa800_parts(decoded):
    kids, end = children(decoded)
    mixer = kids[0][2]
    meta = kids[1][2]
    parts = {}
    parts["mixer_hdr"] = mixer[0:208]
    parts["trks"] = [mixer[208 + i * 37:208 + (i + 1) * 37] for i in range(8)]
    parts["slots"] = [mixer[504 + i * 357:504 + (i + 1) * 357] for i in range(4)]
    parts["meta_hdr"] = meta[0:249]
    parts["named"] = [meta[249 + i * 167:249 + (i + 1) * 167] for i in range(4)]
    return parts


# ---------------- pa3x parts ----------------
def unwrap(decoded):
    """pa3x/pa4x kind09 = single wrapper child chain: 00000000 -> 01000000 -> real."""
    buf = decoded
    depth = 0
    while depth < 4:
        kids, end = children(buf)
        if (len(kids) == 1 and kids[0][2] is not None and end == len(buf)
                and kids[0][0] in (b"\x00\x00\x00\x00", b"\x01\x00\x00\x00")):
            buf = kids[0][2]
            depth += 1
        else:
            break
    return buf


def pa3x_parts(decoded):
    kids, end = children(unwrap(decoded))
    parts = {"top": [(k[0], k[1]) for k in kids], "trail": len(decoded) - end}
    # find mixer: top child 02 -> child 05
    mixer = None
    sts = []
    top04 = None
    for tag, size, body, _ in kids:
        if tag == b"\x04\x00\x01\x08":
            top04 = body
        elif tag == b"\x02\x00\x00\x00":
            sub, _e = children(body)
            if sub and sub[0][0] == b"\x05\x00\x00\x00":
                mixer = sub[0][2]
        elif tag == b"\x03\x00\x00\x00":
            sts.append(body)
    parts["top04"] = top04
    parts["mixer"] = mixer
    parts["sts"] = sts
    if mixer:
        mk, _ = children(mixer)
        parts["mixer_children"] = [(t, s) for t, s, b, _ in mk]
        parts["m06"] = [b for t, s, b, _ in mk if t == b"\x06\x00\x00\x08"]
        parts["m07"] = [b for t, s, b, _ in mk if t == b"\x07\x00\x00\x08"]
        parts["m08"] = [b for t, s, b, _ in mk if t == b"\x08\x00\x00\x08"]
        parts["m09"] = [b for t, s, b, _ in mk if t == b"\x09\x00\x00\x08"]
    sts_pieces = {}
    for i, body in enumerate(sts):
        sk, se = children(body)
        for t, s, b, _ in sk:
            if b is None:
                continue
            sts_pieces.setdefault(t, []).append(b)
        sts_pieces.setdefault("_trail", []).append(len(body) - se)
    parts["sts_pieces"] = sts_pieces
    return parts


# ---------------- const/var analysis ----------------
def constvar(name, blobs, out):
    if not blobs:
        return
    n = len(blobs[0])
    if any(len(b) != n for b in blobs):
        out.append(f"{name}: LENGTH MISMATCH {[len(b) for b in blobs]}")
        return
    const = []
    var = []
    for i in range(n):
        vals = {b[i] for b in blobs}
        if len(vals) == 1:
            const.append((i, next(iter(vals))))
        else:
            var.append(i)
    # group const runs
    runs = []
    for i, v in const:
        if runs and runs[-1][1] + 1 == i:
            runs[-1][1] = i
            runs[-1][2].append(v)
        else:
            runs.append([i, i, [v]])
    parts = []
    for a, b_, vs in runs:
        if a == b_:
            parts.append(f"[{a}]=0x{vs[0]:02x}")
        else:
            parts.append(f"[{a}:{b_+1}]=" + "".join(f"{v:02x}" for v in vs))
    out.append(f"{name}: CONST " + " ".join(parts) + (f" | VAR {var}" if var else ""))


# ---------------- cross match ----------------
def longest_matches(hay, needles, minlen=12):
    """for each needle region (bytes), find all maximal exact substrings of hay >= minlen"""
    out = []
    for label, nd in needles:
        i = 0
        found = []
        while i + minlen <= len(nd):
            # binary-ish scan: extend from i
            best = 0
            for L in range(len(nd) - i, minlen - 1, -1):
                sub = nd[i:i + L]
                pos = hay.find(sub)
                if pos >= 0:
                    best = L
                    break
            if best:
                found.append((i, i + best, best, hay.find(nd[i:i + best])))
                i += best
            else:
                i += 1
        out.append((label, found))
    return out


def main():
    out = []
    # ---------- pa800 multi-file ----------
    p800 = [pa800_parts(kind09(p)) for p in PA800_FILES]
    out.append("==== PA800 multi-file const/var ====")
    constvar("mixer_hdr", [p["mixer_hdr"] for p in p800], out)
    for i in range(8):
        constvar(f"trk{i}", [p["trks"][i] for p in p800], out)
    constvar("trk_ALL(i=0..8)", [b"".join(p["trks"]) for p in p800], out)
    constvar("slot0_head", [p["slots"][0][:17] for p in p800], out)
    constvar("slot_ALL_head", [b"".join(s[:17] for s in p["slots"]) for p in p800], out)
    constvar("meta_hdr", [p["meta_hdr"] for p in p800], out)
    constvar("named_ALL", [b"".join(p["named"]) for p in p800], out)
    constvar("slot0", [p["slots"][0] for p in p800], out)
    constvar("slot0_mid", [p["slots"][0][57:113] for p in p800], out)
    constvar("slot0_detail0", [p["slots"][0][113:174] for p in p800], out)
    constvar("slot0_sound", [p["slots"][0][17:57] for p in p800], out)

    # ---------- pa3x multi-file ----------
    p3 = [pa3x_parts(kind09(p)) for p in PA3X_FILES]
    out.append("")
    out.append("==== PA3X structure ====")
    out.append(f"top: {p3[0]['top']} trail={p3[0]['trail']}")
    out.append(f"mixer_children: {p3[0].get('mixer_children')}")
    for k, v in p3[0]["sts_pieces"].items():
        if k == "_trail":
            out.append(f"sts trailing: {v}")
        else:
            out.append(f"sts piece {k.hex()}: n={len(v)} sizes={[len(x) for x in v]}")
    out.append("")
    out.append("==== PA3X multi-file const/var ====")
    if p3[0].get("top04"):
        constvar("top04(77)", [p["top04"] for p in p3], out)
    for i, tag in enumerate([b"\x06\x00\x00\x08", b"\x07\x00\x00\x08", b"\x08\x00\x00\x08", b"\x09\x00\x00\x08"]):
        key = {6: "m06", 7: "m07", 8: "m08", 9: "m09"}[tag[0]]
        blobs = [p[key][0] for p in p3 if p.get(key)]
        if blobs:
            constvar(f"{key}[0]", blobs, out)
    # m09 content alignment: id4 + content36
    m09 = []
    for p in p3:
        for b in p.get("m09", []):
            m09.append(b[4:40])
    constvar("m09 content[0:36] ALL", m09, out)
    for tag in sorted(t for t in p3[0]["sts_pieces"] if t != "_trail"):
        blobs = p3[0]["sts_pieces"][tag]
        blobs2 = []
        ok = True
        for p in p3:
            v = p["sts_pieces"].get(tag)
            if not v or len(v) != len(blobs):
                ok = False
                break
            blobs2.extend(v)
        if ok:
            constvar(f"sts {tag.hex()} ALL", blobs2, out)

    # ---------- pa800 vs pa3x cross-match ----------
    out.append("")
    out.append("==== CROSS: pa800 regions found inside pa3x FAVORITE12 kind09 ====")
    hay3 = unwrap(kind09(PA3X_FILES[0]))
    parts8 = pa800_parts(kind09(PA800_FILES[0]))
    needles = [
        ("mixer_hdr208", parts8["mixer_hdr"]),
        ("trk0(37)", parts8["trks"][0]),
        ("trk0[0:36]", parts8["trks"][0][:36]),
        ("slot0_head17", parts8["slots"][0][:17]),
        ("slot0_mid56", parts8["slots"][0][57:113]),
        ("slot0_detail0", parts8["slots"][0][113:174]),
        ("slot0_detail1", parts8["slots"][0][174:235]),
        ("meta_hdr249", parts8["meta_hdr"]),
        ("named0_167", parts8["named"][0]),
        ("named0_rest150", parts8["named"][0][17:]),
    ]
    for label, found in longest_matches(hay3, needles, minlen=12):
        out.append(f"{label}: " + (", ".join(f"src[{a}:{b_}] len{L} @pa3x{pos}" for a, b_, L, pos in found) or "NO MATCH >=12"))

    out.append("")
    out.append("==== CROSS: pa3x pieces found inside pa800 USER01 kind09 ====")
    hay8 = kind09(PA800_FILES[0])
    n3 = []
    if p3[0]["top04"]:
        n3.append(("top04(77)", p3[0]["top04"]))
    for i, b in enumerate(p3[0].get("m07", [])):
        n3.append((f"m07_{i}(78)", b))
    for i, b in enumerate(p3[0].get("m08", [])):
        n3.append((f"m08_{i}(19)", b))
    for i, b in enumerate(p3[0].get("m09", [])):
        n3.append((f"m09_{i}[0:40]", b[:40]))
    for tag in sorted(t for t in p3[0]["sts_pieces"] if t != "_trail"):
        for i, b in enumerate(p3[0]["sts_pieces"][tag][:2]):
            n3.append((f"sts{tag.hex()}_{i}({len(b)})", b))
    for label, found in longest_matches(hay8, n3, minlen=12):
        out.append(f"{label}: " + (", ".join(f"src[{a}:{b_}] len{L} @pa800{pos}" for a, b_, L, pos in found) or "NO MATCH >=12"))

    # ---------- detailed dumps ----------
    out.append("")
    out.append("==== PA3X FAVORITE12 full dumps ====")
    out.append(f"top04(77): {hx(p3[0]['top04'])}")
    out.append(f"m06: {hx(p3[0]['m06'][0])}")
    for i, b in enumerate(p3[0]["m07"]):
        out.append(f"m07_{i}(78): {hx(b)}")
    for i, b in enumerate(p3[0]["m08"]):
        out.append(f"m08_{i}(19): {hx(b)}")
    for i, b in enumerate(p3[0]["m09"]):
        out.append(f"m09_{i}(242): {hx(b)}")
    sts0 = children(p3[0]["sts"][0])[0]
    # dump sts child 0 fully
    sk, se = children(p3[0]["sts"][0])
    out.append(f"sts0 trail={len(p3[0]['sts'][0]) - se}")
    for t, s, b, _ in sk:
        out.append(f"  sts0 {t.hex()} size={s}: {hx(b)}")

    out.append("")
    out.append("==== PA800 USER01 full dumps ====")
    out.append(f"mixer_hdr(208): {hx(parts8['mixer_hdr'])}")
    for i, t in enumerate(parts8["trks"]):
        out.append(f"trk{i}(37): {hx(t)}")
    for i, s in enumerate(parts8["slots"]):
        out.append(f"slot{i} head(17): {hx(s[:17])}")
        out.append(f"slot{i} sound(40): {hx(s[17:57])}")
        out.append(f"slot{i} mid(56): {hx(s[57:113])}")
        for d in range(4):
            out.append(f"slot{i} detail{d}(61): {hx(s[113 + d * 61:113 + (d + 1) * 61])}")
    out.append(f"meta_hdr(249): {hx(parts8['meta_hdr'])}")
    for i, nm in enumerate(parts8["named"]):
        out.append(f"named{i}(167): {hx(nm)}")

    out.append("")
    out.append("==== PA4X kind09 structure ====")
    for p in PA4X_FILES:
        d = kind09(p)
        out.append(f"{Path(p).name}: raw_total={len(d)} raw_top={[(t.hex(), s) for t, s, b, _ in children(d)[0]]}")
        u = unwrap(d)
        kids, end = children(u)
        out.append(f"  unwrapped={len(u)} top={[(t.hex(), s) for t, s, b, _ in kids]} trail={len(u) - end}")
        for t, s, b, _ in kids:
            if b is not None and t in (b"\x02\x00\x00\x00", b"\x05\x00\x00\x00", b"\x03\x00\x00\x00", b"\x04\x00\x01\x08"):
                sub, _e = children(b) if s > 8 and len(b) > 8 else ([], 0)
                if sub and all(x[2] is not None for x in sub):
                    out.append(f"    {t.hex()} -> {[(y[0].hex(), y[1]) for y in sub[:20]]}")

    text = "\n".join(out)
    Path(r"C:\Users\Baja\AppData\Local\Temp\opencode\re09a.txt").write_text(text, encoding="utf-8")
    print("WROTE", len(text), "chars")


main()
