import sys, io, os, glob, collections
sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding='utf-8', errors='replace')
sys.path.insert(0, r'C:\Users\Baja\Desktop\Nova mapa')
from setconvert.sty import StyBank
from setconvert import parameters as P
from setconvert import sts as S
from setconvert.detect import decode_payload
from setconvert.families import FAMILIES

SETS = [
    ('pa800', r'C:\Users\Baja\Desktop\KOCE FOLK.SET'),
    ('pa1x',  r'C:\Users\Baja\Desktop\Pantic Pa1X.SET'),
    ('pa3x',  r'C:\Users\Baja\Desktop\Korg Pa3x Team Serbian.SET'),
    ('pa4x',  r'C:\Users\Baja\Desktop\Pa4x Pro Dejan Shiki.SET'),
    ('pa800', r'C:\Users\Baja\Desktop\GOLE ARX .SET'),
]

for family, root in SETS:
    stys = sorted(glob.glob(os.path.join(root, '**', '*.sty'), recursive=True))[:6]
    stys += sorted(glob.glob(os.path.join(root, '**', '*.STY'), recursive=True))[:6]
    if not stys:
        print(f'== {family} {root}: no STY'); continue
    dialect = FAMILIES[family].sts_dialect
    param_sel = collections.Counter()
    sts_sel = collections.Counter()
    errs = collections.Counter()
    for sty in stys:
        try:
            bank = StyBank.read(sty)
        except Exception as e:
            errs[f'read:{type(e).__name__}'] += 1; continue
        for res in bank.resources:
            if res.kind == 6:
                try:
                    dec = decode_payload(res.payload)
                    for blk in P.find_blocks(dec):
                        for rec in blk.records:
                            param_sel[rec.selector] += 1
                except Exception as e:
                    errs[f'k6:{type(e).__name__}:{e}'] += 1
            elif res.kind == 9:
                try:
                    dec = decode_payload(res.payload)
                    for slot in S.read_document_slots(dec, dialect, None):
                        for row in slot.selectors:
                            sts_sel[row] += 1
                except Exception as e:
                    errs[f'k9:{type(e).__name__}:{e}'] += 1
    print(f'== {family}  {os.path.basename(root)}  files={len(stys)}  dialect={dialect}')
    print(f'   param selectors: {len(param_sel)} distinct, {sum(param_sel.values())} total')
    print(f'     msb hist: {dict(collections.Counter(k[0] for k in param_sel))}')
    print(f'   sts selectors:   {len(sts_sel)} distinct, {sum(sts_sel.values())} total')
    print(f'     msb hist: {dict(collections.Counter(k[0] for k in sts_sel))}')
    if errs:
        print('   errors:', dict(errs))
    print('   top param:', param_sel.most_common(8))
    print('   top sts:  ', sts_sel.most_common(8))
    print()
