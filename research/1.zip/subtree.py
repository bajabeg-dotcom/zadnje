import sys
sys.path.insert(0, r'C:\Users\Baja\Desktop\Nova mapa')
from pathlib import Path
from setconvert.sty import StyBank
from pa800_native.oc31_codec import decode_oc31

path = sys.argv[1]
res_index = int(sys.argv[2])
offsets = [int(x) for x in sys.argv[3].split(',')]
data = Path(path).read_bytes()
bank = StyBank.read(data)
r = bank.resources[res_index]
payload = decode_oc31(r.payload) if r.compressed else r.payload


def children(buf):
    out = []
    c = 0
    while c + 8 <= len(buf):
        tag = buf[c:c + 4]
        sz = int.from_bytes(buf[c + 4:c + 8], 'big')
        if sz > len(buf) - c - 8:
            return out, buf[c:]
        out.append((c, tag, buf[c + 8:c + 8 + sz]))
        c += 8 + sz
    return out, b''


for off in offsets:
    buf = payload[off:]
    print('=== dump @%d (len %d) ===' % (off, len(buf)))
    print(buf[:64].hex(' '))
    kids, trail = children(buf)
    for pos, tag, body in kids:
        print('  child +%d tag=%s size=%d head=%s' % (pos, tag.hex(' '), len(body), body[:32].hex(' ')))
        kk, tt = children(body)
        for pos2, tag2, body2 in kk[:12]:
            print('    child +%d tag=%s size=%d head=%s' % (pos2, tag2.hex(' '), len(body2), body2[:32].hex(' ')))
            if pos2 > 4000:
                break
        if tt:
            print('    trailing %d: %s' % (len(tt), tt[:24].hex(' ')))
    if trail:
        print('  trailing %d: %s' % (len(trail), trail[:24].hex(' ')))
