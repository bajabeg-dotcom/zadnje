﻿import os, sys
sys.stdout.reconfigure(encoding="utf-8", errors="replace")
roots = [
    r"C:\Users\Baja\Desktop\Nova mapa (6)",
    r"C:\Users\Baja\Desktop\BAJA MUSIC\Baja_Music_PA_Manager_V1_WORKING",
]
for root in roots:
    print("=" * 70)
    print(root)
    if not os.path.isdir(root):
        print("  MISSING"); continue
    for dirpath, dirnames, filenames in os.walk(root):
        rel = os.path.relpath(dirpath, root)
        depth = 0 if rel == "." else rel.count(os.sep) + 1
        if depth > 3:
            dirnames[:] = []
            continue
        py = [f for f in filenames if f.endswith((".py", ".md", ".txt"))]
        if py:
            print("  " * (depth + 1), rel, "->", py[:20])
