﻿$p="C:\Users\Baja\Desktop\Nova mapa\KORG PA Manager\v3\KORGPAManager.exe"
$b=[IO.File]::ReadAllBytes($p)
$latin=[Text.Encoding]::GetEncoding(28591).GetString($b)
$uni0=[Text.Encoding]::Unicode.GetString($b)
$uni1=[Text.Encoding]::Unicode.GetString($b,1,$b.Length-1)
$keys=@('TPF0','ComboBox','SysListView32','SysTreeView32','BUTTON','KERNEL32','kernel32','USER32','user32','GDI32','gdi32','COMDLG32','comdlg32','COMCTL32','comctl32','SHELL32','shell32','ole32','OLEAUT32','msvbvm','MSVBVM','MSVCRT','VCL','VBRUN','Riched','MSCOMCTL','SysAnimate32','SysTabControl32','Thunder','Form','Caption','StyleVersion','KORGPA','korgpa','.set','SetFolder','PA5X','PA80','PA900','i900','Pa4X')
foreach($k in $keys){
  $r=@()
  $i=$latin.IndexOf($k,[StringComparison]::Ordinal); if($i -ge 0){$r+="A@0x{0:X}" -f $i}
  $i=$uni0.IndexOf($k,[StringComparison]::Ordinal); if($i -ge 0){$r+="U0@0x{0:X}" -f ($i*2)}
  $i=$uni1.IndexOf($k,[StringComparison]::Ordinal); if($i -ge 0){$r+="U1@0x{0:X}" -f ($i*2+1)}
  if($r){ "{0,-16} {1}" -f $k,($r -join ' ') }
}
