import sys, io, os, struct, collections
sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding='utf-8', errors='replace')
sys.path.insert(0, r'C:\Users\Baja\Desktop\Nova mapa')
from pa800_native.sty_container import parse_bank

PRG = r'C:\Users\Baja\Desktop\PA800_AI_PA800_STUDIO_v5_2026-09-20\factory_evidence\native_factory\SOUND\PRGMAPS.TBL'
ROM = r'C:\Users\Baja\Desktop\PA800_AI_PA800_STUDIO_v5_2026-09-20\factory_evidence\native_factory\SOUND\ROM.PCG'

bank = parse_bank(open(PRG, 'rb').read())
cat = bank.resources[0].payload
print('catalog names:', [cat[i*24:(i+1)*24].split(b'\x00')[0].decode('ascii','replace') for i in range(len(cat)//24)])

otc = bank.resources[1].payload
nvar = bank.resources[2].payload
dkgm = bank.resources[3].payload
sl = bank.resources[5].payload

print()
print('OffsetToCap head', otc[:16].hex(' '), 'len', len(otc))
vals = [int.from_bytes(otc[8+i*2:10+i*2], 'big') for i in range((len(otc)-8)//2)]
print('  count', len(vals), 'first', vals[:8], 'last', vals[-4:], 'monotonic', all(vals[i+1] >= vals[i] for i in range(len(vals)-1)))
print('NumOfVar head', nvar[:16].hex(' '), 'len', len(nvar))
nv = nvar[8:]
print('  count', len(nv), 'first', list(nv[:8]), 'sum', sum(nv))
print('  OffsetToCap[p+1] == OffsetToCap[p]+NumOfVar[p]+1 :',
      all(vals[i+1] == vals[i] + nv[i] + 1 for i in range(len(vals)-1)))

print()
print('SoundsLayout len', len(sl), 'head', sl[:24].hex(' '))
for stride in (6, 8):
    body = sl[4:] if stride == 6 else sl[4:]
    n = len(body) // stride
    print(f'  stride {stride}: {n} entries, rem {len(body)%stride}')

# dump first 12 entries at stride 6 starting after 4-byte header
print('  raw rows (first 72 bytes):')
for off in range(0, 72, 12):
    print('   ', sl[off:off+12].hex(' '))

# hypothesis: 6-byte entry: ?? ?? ?? MSB LSB PC
print()
print('  stride6 guess (skip4):')
for i in range(6):
    e = sl[4+i*6:10+i*6]
    print('   ', e.hex(' '), e)
