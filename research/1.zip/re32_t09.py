﻿import sys, struct
sys.path.insert(0, r"C:\Users\Baja\Desktop\Nova mapa")
from pa800_native import parse_bank, decode_oc31
sys.stdout.reconfigure(encoding="utf-8", errors="replace")

def dec(p):
    if p[:4] in (b"OC31", b"OC32"):
        return decode_oc31(b"OC31" + p[4:])
    return p

def walk(payload):
    out = []
    pos = 0
    while pos + 8 <= len(payload):
        marker = payload[pos:pos+4]
        size = int.from_bytes(payload[pos+4:pos+8], "big")
        end = pos + 8 + size
        if end > len(payload):
            out.append((marker.hex(" "), size, "OVERRUN", b""))
            break
        out.append((marker.hex(" "), size, "ok", payload[pos+8:end]))
        pos = end
    return out, pos, len(payload)

T = [
 (r"C:\Users\Baja\Desktop\Pantic Pa1X.SET\STYLE\BANK01_LIVE.STY", "Pa1X", 1),
 (r"C:\Users\Baja\Desktop\GOLE ARX .SET\GOLE ARX .SET\STYLE\FAVORITE01.STY", "Pa800-GOLE", 1),
 (r"C:\Users\Baja\Desktop\Korg Pa3x Team Serbian.SET\STYLE\USER01.STY", "Pa3X", 1),
 (r"C:\Users\Baja\Desktop\Pa4x Pro Dejan Shiki.SET\STYLE\USER01.STY", "Pa4X", 1),
 (r"C:\Users\Baja\Desktop\Nova mapa\Style Works XT Universal\InitKorg\InitPx03.STY", "Px03", 1),
 (r"C:\Users\Baja\Desktop\Nova mapa\Style Works XT Universal\InitKorg\initPx04.STY", "Px04", 1),
]
for path, label, n in T:
    d = open(path, "rb").read()
    try:
        bank = parse_bank(d)
    except Exception as e:
        print(label, "parse_bank FAIL", e); continue
    kinds9 = [r for r in bank.resources if r.kind == 9]
    print("=" * 70)
    print(label, "kind09 count", len(kinds9))
    for r in kinds9[:n]:
        out = dec(r.payload)
        print("  decompressed len", len(out), "hdr", r.header.hex(" "))
        ch, end, total = walk(out)
        for i, (m, sz, st, body) in enumerate(ch):
            extra = ""
            if st == "ok" and len(body) >= 13:
                a = int.from_bytes(body[8:12], "big") if len(body) >= 12 else -1
                b = body[12] if len(body) > 12 else -1
                extra = " body[:13]=%s  hdr8=%d cnt=%d  tail4=%s" % (
                    body[:13].hex(" "), a, b, body[-4:].hex(" ") if len(body) >= 4 else "?")
            print("   child%d marker=%s size=%-6d %s%s" % (i, m, sz, st, extra))
        if end != total:
            print("   WALK END", end, "!= total", total)
