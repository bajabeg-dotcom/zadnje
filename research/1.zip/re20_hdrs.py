﻿import sys, struct, collections
sys.path.insert(0, r"C:\Users\Baja\Desktop\Nova mapa")
sys.stdout.reconfigure(encoding="utf-8", errors="replace")
def hdrs(path, label):
    d = open(path, "rb").read()
    if d[:4] != b"\x01\x00\x01\x14":
        print(label, "NOT CONTAINER", d[:8].hex(" ")); return
    total = struct.unpack(">I", d[4:8])[0]
    pos = 8
    h6 = collections.Counter(); h9 = collections.Counter(); h5 = []
    ok = True
    while pos + 8 <= len(d):
        hdr = d[pos:pos+4]
        sz = struct.unpack(">I", d[pos+4:pos+8])[0]
        if sz == 0 or pos + 8 + sz > len(d):
            ok = False
            print(label, "BAD at", hex(pos), hdr.hex(" "), sz); break
        k = hdr[0]
        if k == 6: h6[hdr.hex(" ")] += 1
        elif k == 9: h9[hdr.hex(" ")] += 1
        elif k == 5: h5.append(hdr.hex(" "))
        pos += 8 + sz
    print(label, "ok=%s end=%s/%s" % (ok, hex(pos), hex(len(d))))
    print("   kind06:", dict(h6))
    print("   kind09:", dict(h9))
    print("   kind05:", h5[:3])
T = [
 (r"C:\Users\Baja\Desktop\Pantic Pa1X.SET\STYLE\BANK01_LIVE.STY", "Pantic-LIVE"),
 (r"C:\Users\Baja\Desktop\Pantic Pa1X.SET\STYLE\USER02.STY", "Pantic-USER02"),
 (r"C:\Users\Baja\Desktop\GOLE ARX .SET\GOLE ARX .SET\STYLE\FAVORITE01.STY", "GOLE-FAV01"),
 (r"C:\Users\Baja\Desktop\GOLE ARX .SET\GOLE ARX .SET\STYLE\USER01.STY", "GOLE-USER01"),
 (r"C:\Users\Baja\Desktop\STYLE\USER01_IZOLACIJA.STY", "IZOLACIJA"),
 (r"C:\Users\Baja\Desktop\Moduli na PYTHONU\Pa800_System\output\Pa800_os_res_v202\STARTUP\ALL\STYLE\BANK01.STY", "PA800-OS-B01"),
 (r"C:\Users\Baja\Desktop\Moduli na PYTHONU\Pa800_System\output\Pa800_os_res_v202\STARTUP\ALL\STYLE\USER01.sty", "PA800-OS-USER01"),
 (r"C:\Users\Baja\Desktop\BANK01.STY", "Desktop-BANK01"),
 (r"C:\Users\Baja\Desktop\USER01.STY", "Desktop-USER01"),
 (r"C:\Users\Baja\Desktop\USER01_PA800.STY", "USER01_PA800"),
 (r"C:\Users\Baja\Desktop\Nova mapa\Style Works XT Universal\InitKorg\Initpa01.STY", "Init-pa01"),
 (r"C:\Users\Baja\Desktop\Nova mapa\Style Works XT Universal\InitKorg\InitPx01.STY", "Init-Px01"),
 (r"C:\Users\Baja\Desktop\Nova mapa\Style Works XT Universal\InitKorg\InitPx03.STY", "Init-Px03"),
 (r"C:\Users\Baja\Desktop\Nova mapa\Style Works XT Universal\InitKorg\initPx04.STY", "Init-Px04"),
]
for p, l in T:
    try: hdrs(p, l)
    except Exception as e: print(l, "ERR", e)
