import sys
sys.path.insert(0, r'C:\Users\Baja\Desktop\Nova mapa')
from pathlib import Path
from setconvert.sty import StyBank
from pa800_native.oc31_codec import decode_oc31

def kids(p, start=0, end=None):
    out = []
    pos = start
    if end is None: end = len(p)
    while pos + 8 <= end:
        tag = p[pos:pos+4]
        sz = int.from_bytes(p[pos+4:pos+8], 'big')
        if sz > end - pos - 8: break
        out.append((tag, pos, sz, p[pos+8:pos+8+sz]))
        pos += 8 + sz
    return out, pos

def hx(b):
    return b.hex(' ')

data = Path(r'C:\Users\Baja\Desktop\Korg Pa3x Team Serbian.SET\STYLE\USER01.STY').read_bytes()
bank = StyBank.read(data)
# find kind09
for i, r in enumerate(bank.resources):
    if r.kind != 9: continue
    p = decode_oc31(r.payload) if r.compressed else r.payload
    k1, _ = kids(p)
    print('top children:', [(t.hex(' '), s) for t, _, s, _ in k1])
    wrap = k1[0][3]
    k2, _ = kids(wrap)
    print('wrap children:', [(t.hex(' '), s) for t, _, s, _ in k2])
    inner = k2[0][3]
    k3, _ = kids(inner)
    print('inner children:', [(t.hex(' '), s) for t, _, s, _ in k3])
    for t, pos, sz, body in k3:
        if t == b'\x02\x00\x00\x00':
            k4, _ = kids(body)
            print(' mixer wrapper children:', [(t4.hex(' '), s4) for t4, _, s4, _ in k4])
            mixer = k4[0][3]
            k5, _ = kids(mixer)
            print(' mixer children:')
            for t5, p5, s5, b5 in k5:
                print(f'   {t5.hex(" ")} @{p5} sz={s5} head={hx(b5[:40])}')
            # full dump of one 09 record and one 07
            for t5, p5, s5, b5 in k5:
                if t5 == b'\x09\x00\x00\x08':
                    print(f' 09 record ({s5}):')
                    for off in range(0, s5, 16):
                        print(f'   {off:3d}: {hx(b5[off:off+16])}')
                    break
            for t5, p5, s5, b5 in k5:
                if t5 == b'\x07\x00\x00\x08':
                    print(f' 07 record ({s5}): {hx(b5)}')
                if t5 == b'\x08\x00\x00\x08':
                    print(f' 08 record ({s5}): {hx(b5)}')
            break
    # STS structure
    for t, pos, sz, body in k3:
        if t == b'\x03\x00\x00\x00':
            k4, _ = kids(body)
            print(' STS children:', [(t4.hex(' '), s4) for t4, _, s4, _ in k4])
            for t4, p4, s4, b4 in k4:
                if t4 == b'\x0a\x00\x00\x00':
                    k5, _ = kids(b4)
                    print('  sts-0a children:')
                    for t5, p5, s5, b5 in k5:
                        print(f'    {t5.hex(" ")} @{p5} sz={s5} head={hx(b5[:48])}')
            break
    break
