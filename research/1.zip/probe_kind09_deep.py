import sys

sys.path.insert(0, r"C:\Users\Baja\Desktop\Nova mapa")

from setconvert.sty import StyBank
from setconvert.detect import decode_payload


def walk(payload, depth=0, max_depth=3, label="root"):
    pos = 0
    idx = 0
    while pos + 8 <= len(payload):
        marker = payload[pos:pos + 4]
        size = int.from_bytes(payload[pos + 4:pos + 8], "big")
        end = pos + 8 + size
        if size == 0 or end > len(payload) or size > len(payload):
            print("  " * depth + f"[{label}#{idx}] marker={marker.hex(' ')} size={size} INVALID at {pos} (len={len(payload)})")
            return pos
        body = payload[pos + 8:end]
        print("  " * depth + f"[{label}#{idx}] marker={marker.hex(' ')} size={size} head={body[:32].hex(' ')}")
        if depth < max_depth and size > 16:
            walk(body, depth + 1, max_depth, f"{label}#{idx}")
        pos = end
        idx += 1
    if pos != len(payload):
        print("  " * depth + f"[{label}] trailing {len(payload) - pos} bytes: {payload[pos:pos + 16].hex(' ')}")
    return pos


def probe(path, nth=0, header=None):
    bank = StyBank.read(path)
    kind09 = [r for r in bank.resources if r.kind == 9]
    if header is not None:
        kind09 = [r for r in kind09 if r.header.hex(" ") == header]
        if not kind09:
            print(f"=== {path}: header {header} not found ===")
            return
    r = kind09[nth]
    dec = decode_payload(r.payload)
    print(f"=== {path.split(chr(92))[-1]} res={r.header.hex(' ')} dec={len(dec)} ===")
    walk(dec, max_depth=4)


probe(r"C:\Users\Baja\Desktop\Korg Pa3x Team Serbian.SET\STYLE\USER01.STY")
probe(r"C:\Users\Baja\Desktop\Pa4x Pro Dejan Shiki.SET\STYLE\USER01.STY", 0)
probe(r"C:\Users\Baja\Desktop\Pa4x Pro Dejan Shiki.SET\STYLE\USER01.STY", 3, "09 01 00 30")
probe(r"C:\Users\Baja\Desktop\Pa4x Pro Dejan Shiki.SET\STYLE\USER01.STY", 0, "09 02 01 30")
probe(r"C:\Users\Baja\Desktop\KOCE FOLK.SET\STYLE\USER01.STY", 0, "09 00 02 30")
