# -*- coding: utf-8 -*-
"""KORG Pa: dekodiraj parametre posle f803, note sekvence, OC31/32, kompresiju."""
import struct, os, sys, re, zlib
from collections import Counter, defaultdict
sys.stdout.reconfigure(encoding='utf-8', errors='replace')

ROOT = r'C:\Users\Baja\Desktop\Nova mapa\Style Works XT Universal\InitKorg'

def u16(b, o): return struct.unpack_from('<H', b, o)[0]
def u16be(b, o): return struct.unpack_from('>H', b, o)[0]
def u32(b, o): return struct.unpack_from('<I', b, o)[0]
def s16(b, o): return struct.unpack_from('<h', b, o)[0]

def cstr(b, o, n):
    s = b[o:o+n]
    z = s.find(b'\x00')
    if z >= 0: s = s[:z]
    return s.decode('latin-1', 'replace').rstrip()

def hexdump(b, o, n, label=''):
    if label: print('  ' + label + ' @ {:#x}'.format(o))
    for i in range(0, n, 16):
        chunk = b[o+i:o+i+16]
        hx = ' '.join('{:02x}'.format(x) for x in chunk)
        pr = ''.join(chr(x) if 32 <= x < 127 else '.' for x in chunk)
        print('  {:06x}  {:<48}  {}'.format(o+i, hx, pr))

def parse_names(b, start=0x24):
    names, p = [], start
    while p + 24 <= len(b):
        nm = cstr(b, p, 16)
        if not re.match(r'^[\x20-\x7e]{2,}', nm or ''):
            if nm == '' and b[p:p+16] == b'\x00'*16:
                nm2 = cstr(b, p+24, 16)
                if not (nm2 and re.match(r'^[\x20-\x7e]{2,}', nm2)):
                    break
            else:
                break
        names.append({'name': nm, 'bank': b[p+18], 'code': b[p+19],
                      'idx': u32(b, p+20), 'off': p})
        p += 24
    return names, p

def find_all(b, sig, start=0):
    hits, pos = [], start
    while True:
        i = b.find(sig, pos, )
        if i < 0: break
        hits.append(i)
        pos = i + 1
    return hits

# ============================================================
# 1) Block framing: 06 00 00 30 00 00 size | OC31/OC32 | ...
# ============================================================
def analyze_framing(fn):
    path = os.path.join(ROOT, fn)
    b = open(path, 'rb').read()
    print('=' * 78)
    print('FRAMING', fn)
    names, end_n = parse_names(b)
    # Find all '06 00 00 30' or more generally pattern before OC3
    ocs = find_all(b, b'OC3')
    print('OC tags:', [b[o:o+4].decode() for o in ocs[:20]])
    print('OC count', len(ocs), 'kinds', Counter(b[o:o+4] for o in ocs))

    print('\n8 bytes before each OC3 (first 12):')
    for o in ocs[:12]:
        pre8 = b[o-8:o]
        sz = u16be(b, o-2) if o >= 2 else -1
        # also try u16le
        sz_le = u16(b, o-6) if o >= 6 else -1
        nxt = None
        # find next OC
        for o2 in ocs:
            if o2 > o:
                nxt = o2; break
        dist = (nxt - o) if nxt else (len(b) - o)
        print('  @{:#06x} pre={} size_be@-2={} size_le@-6={} dist={} match_be={}'.format(
            o, pre8.hex(), sz, sz_le, dist, sz == dist - 8 or sz == dist))

    # first block: right after name table
    print('\nend_names region:')
    hexdump(b, end_n, 32, 'at end_names')
    # Is there 06 00 00 30 before first OC?
    if ocs:
        print('first OC pre16:', b[ocs[0]-16:ocs[0]].hex())

    # ============================================================
    # 2) After OC3: header fields then name+params or compressed
    # ============================================================
    print('\nAfter-OC3 header decode (first 6 styles):')
    for bi, o in enumerate(ocs[:6]):
        tag = b[o:o+4]
        # common header:
        # OC3X | u16le ? | u16le ? | u16le ? | u16le ? | ...
        f = {
            'tag': tag.decode(),
            'w0': u16(b, o+4),   # often large - uncompressed size? CRC?
            'w1': u16(b, o+6),
            'w2': u16(b, o+8),
            'w3': u16(b, o+10),
            'w4': u16(b, o+12),
            'w5': u16(b, o+14),
            'b16': list(b[o+16:o+24]),
        }
        # Try w0 as uncompressed size; compare to next dist
        nxt = next((x for x in ocs if x > o), len(b))
        dist = nxt - o
        # Look for name: bytes after fixed header until aa a0 or f803
        # Scan o+16 .. o+64 for printable run or f803
        name_at = None
        f803_at = None
        aaa0_at = None
        for j in range(o+16, min(o+80, len(b)-2)):
            if b[j:j+2] == b'\xf8\x03' and f803_at is None:
                f803_at = j
            if b[j:j+2] == b'\xaa\xa0' and aaa0_at is None:
                aaa0_at = j
            # name: 3+ printable then either 00, aa, or f803
            if name_at is None and 32 <= b[j] < 127:
                # check run
                k = j
                while k < len(b) and 32 <= b[k] < 127:
                    k += 1
                if k - j >= 4:
                    # terminated by 00 or aa or f8?
                    if k < len(b) and (b[k] == 0 or b[k:k+1] == b'\xaa' or b[k:k+2] == b'\xf8\x03' or b[k] == 0xaa):
                        # reject if looks like params (mostly high bytes after short)
                        cand = b[j:k].decode('latin-1')
                        if re.match(r'^[A-Za-z0-9].{2,}', cand) and not cand.startswith(('OC',)):
                            # skip if too early header area with binary
                            if j >= o + 20:
                                name_at = (j, cand, k)
                                break
        f['dist'] = dist
        f['name_at'] = name_at
        f['f803_at'] = f803_at
        f['aaa0_at'] = aaa0_at
        print('  [{}] {} w0={} w1={} w2={} w3={} w4={} w5={} b16={}'.format(
            bi, f['tag'], f['w0'], f['w1'], f['w2'], f['w3'], f['w4'], f['w5'], f['b16']))
        print('       dist={} name={} f803={} aaa0={}'.format(
            dist, name_at, f803_at, aaa0_at))
        if f803_at:
            hexdump(b, max(o, f803_at - 24), 64, 'around f803')

    # ============================================================
    # 3) Params after f803 ff 02 80
    # ============================================================
    print('\n=== PARAM BLOCKS (f8 03 ff 02 80 ...) ===')
    sig = b'\xf8\x03\xff\x02\x80'
    hits = find_all(b, sig)
    print('f803-ff02-80 count:', len(hits), 'first:', [hex(x) for x in hits[:10]])
    for h in hits[:4]:
        hexdump(b, h, 96, 'params')
        # decode u16 stream
        ws = [u16(b, h+5+i*2) for i in range(24)]
        print('  u16le from +5:', ws)
        bs = list(b[h+5:h+5+40])
        print('  bytes from +5:', bs)

    # Also try signature without requiring 80
    sig2 = b'\xf8\x03\xff\x02'
    hits2 = find_all(b, sig2)
    print('f803-ff02 count:', len(hits2))

    # ============================================================
    # 4) Compression test: is payload zlib/lzma/deflate?
    # ============================================================
    print('\n=== COMPRESSION PROBE ===')
    if ocs:
        o = ocs[0]
        # try various offsets as start of compressed stream
        for start in [o+4, o+8, o+16, o+20, o+24, o+32]:
            for end_off in [8, 16]:  # try ending before next block trailer
                # try zlib
                for wbits in (15, -15, 31):
                    try:
                        dec = zlib.decompress(b[start:start+dist-start] if False else b[start:ocs[1]-16], wbits)
                        print('  ZLIB OK wbits={} start={:#x} -> {} bytes'.format(wbits, start, len(dec)))
                        print('   head:', dec[:40].hex())
                    except Exception:
                        pass
                # try decompressobj ignore
                try:
                    d = zlib.decompressobj(wbits)
                    dec = d.decompress(b[start:start+4096])
                    if dec:
                        print('  partial zlib wbits={} start={:#x} len={}'.format(wbits, start, len(dec)))
                except Exception:
                    pass

    # Entropy of block bodies
    import math
    print('\n=== ENTROPY per block (compressed?) ===')
    for i, o in enumerate(ocs[:8]):
        nxt = ocs[i+1] if i+1 < len(ocs) else len(b)
        # skip header/trailer ~16 bytes each end
        body = b[o+16:nxt-8]
        if len(body) < 32: continue
        cnt = Counter(body)
        ent = -sum((c/len(body)) * math.log2(c/len(body)) for c in cnt.values())
        # also look for uncompressed note patterns (many small deltas)
        print('  block{} len={} entropy={:.2f} top_bytes={}'.format(
            i, len(body), ent, cnt.most_common(5)))

    return b, names, end_n, ocs

for fn in ['Initpa01.STY', 'InitPx03.STY']:
    analyze_framing(fn)
    print()

# ============================================================
# 5) Compare OC31 vs OC32 headers side by side
# ============================================================
print('=' * 78)
print('OC31 vs OC32 side-by-side (first block each)')
print('=' * 78)
for fn, tag in [('Initpa01.STY', b'OC32'), ('InitPx03.STY', b'OC31')]:
    b = open(os.path.join(ROOT, fn), 'rb').read()
    o = b.find(tag)
    print('\n{} first {} @ {:#x}'.format(fn, tag.decode(), o))
    hexdump(b, o, 80, 'raw')
    # Interpret as structured fields with plausible meanings
    # Common PA style header community-known (partial):
    # After OC3X:
    # u16 unknown/size
    # u16 unknown
    # u16 flags/version
    fields_le = [u16(b, o+4+i*2) for i in range(16)]
    print('  u16le[16]:', fields_le)
    fields_be = [u16be(b, o+4+i*2) for i in range(8)]
    print('  u16be[8]:', fields_be)

# ============================================================
# 6) Look for MIDI-like note data: 9n / note / vel patterns
# ============================================================
print('\n' + '=' * 78)
print('NOTE-LIKE SCAN in block bodies')
print('=' * 78)
b = open(os.path.join(ROOT, 'InitPx03.STY'), 'rb').read()
# Discofox block: OC31@0x8c .. 0x391e
body = b[0x100:0x3900]
# Look for runs where we see sequences of (note 36-108, vel 1-127)
# Also delta-time VLQ-like (bytes with high bit clear mostly)
# Count byte value histogram
cnt = Counter(body)
print('byte histogram top20:', cnt.most_common(20))
# Find positions of classic drum notes as isolated bytes with context
for note in (36, 38, 42, 46):  # kick snare hh
    positions = [i for i, x in enumerate(body) if x == note][:5]
    print('note {} sample positions: {}'.format(note, positions[:5]))
    for p in positions[:2]:
        ctx = body[max(0,p-4):p+5]
        print('   ctx:', ' '.join('{:02x}'.format(x) for x in ctx),
              ' ascii=', ''.join(chr(x) if 32<=x<127 else '.' for x in ctx))

# ============================================================
# 7) Try known Korg style decompression (byte-wise XOR / RLE / LZSS)
# ============================================================
print('\n=== RLE / simple LZ probe on first block ===')
b = open(os.path.join(ROOT, 'Initpa01.STY'), 'rb').read()
ocs = find_all(b, b'OC3')
start, end = ocs[0]+16, ocs[1]-8
data = b[start:end]
print('raw len', len(data), 'head', data[:32].hex())

# Try: if high bit set = literal run, else repeat (common LZSS variant)
def try_lzss(inp, min_off=1, max_off=4096, len_min=3, len_max=18):
    out = bytearray()
    i = 0
    # flag byte every 8 tokens
    try:
        while i < len(inp):
            flags = inp[i]; i += 1
            for bit in range(8):
                if i >= len(inp): break
                if flags & (1 << bit):
                    out.append(inp[i]); i += 1
                else:
                    if i+1 >= len(inp): break
                    b1, b2 = inp[i], inp[i+1]; i += 2
                    off = b1 | ((b2 & 0xF0) << 4)
                    ln = (b2 & 0x0F) + len_min
                    if off == 0 or off > len(out):
                        return None
                    for _ in range(ln):
                        if off > len(out): return None
                        out.append(out[-off])
        return bytes(out)
    except Exception:
        return None

# variant: 0 = literal follows, etc.
def try_lz77_basic(inp):
    # very simple: 0x00 XX = repeat XX, else literal - probably wrong
    return None

dec = try_lzss(data)
print('LZSS flag-byte attempt:', 'OK len='+str(len(dec)) if dec else 'fail')
if dec:
    print('  head:', dec[:40].hex(), 'ascii:', ''.join(chr(x) if 32<=x<127 else '.' for x in dec[:40]))

# Korg often uses: if byte < 0x80 literal, else backref
def try_korg_style(inp):
    out = bytearray()
    i = 0
    while i < len(inp):
        c = inp[i]; i += 1
        if c < 0x80:
            out.append(c)
        else:
            # need at least 1 more
            if i >= len(inp): break
            c2 = inp[i]; i += 1
            # 2-byte backref: top bits of c encode length, c+c2 encode offset?
            off = ((c & 0x7F) << 8) | c2
            ln = 3
            if off == 0 or off > len(out) or len(out) > 1000000:
                return None, i
            for _ in range(ln):
                out.append(out[-off] if off <= len(out) else 0)
    return bytes(out), i

# Better: standard Pa50/Pa60 style format often documented as custom event stream
# Search for delta-encoded events where note numbers cluster
# Print a decoded hex-ascii of a mid-block region that looks like notes
mid = b[ocs[0]+400:ocs[0]+500]
hexdump(b, ocs[0]+400, 100, 'mid-block sample')
mid2 = b[ocs[0]+2000:ocs[0]+2100]
hexdump(b, ocs[0]+2000, 100, 'mid-block+2000')
