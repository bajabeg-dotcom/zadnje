import os
import struct
import sys
import json
import glob

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from oc31 import decompress_block, oc31_errorcorrectioncode

INITKORG = r"C:\Users\Baja\Desktop\Nova mapa\Style Works XT Universal\InitKorg"
OUT_DIR = os.path.dirname(os.path.abspath(__file__))


def find_oc_blocks(data):
    blocks = []
    i = 0
    while True:
        i = data.find(b"OC3", i)
        if i < 0:
            break
        magic = data[i:i + 4]
        if magic in (b"OC31", b"OC32", b"OC33") and i >= 8:
            marker = data[i - 8:i - 4]
            if marker == b"\x06\x00\x00\x30":
                size = struct.unpack_from(">I", data, i - 4)[0]
                uncompr = struct.unpack_from("<I", data, i + 4)[0]
                payload = data[i + 8:i + 8 + size - 8]
                blocks.append({
                    "off": i,
                    "magic": magic.decode(),
                    "size": size,
                    "uncompr": uncompr,
                    "payload": payload,
                })
        i += 1
    return blocks


def extract_all():
    results = []
    for sty in sorted(glob.glob(os.path.join(INITKORG, "*.STY")) + glob.glob(os.path.join(INITKORG, "*.sty"))):
        data = open(sty, "rb").read()
        magic4 = data[:8]
        is_korf = b"KORF" in data[:0x40]
        blocks = find_oc_blocks(data)
        entry = {
            "file": os.path.basename(sty),
            "size": len(data),
            "korf": is_korf,
            "n_blocks": len(blocks),
            "blocks": [],
        }
        for bi, b in enumerate(blocks):
            try:
                out, meta = decompress_block(b["payload"], b["uncompr"])
                ok = meta["ecc_ok"] and len(out) == b["uncompr"] and meta["leftover"] == 0
                rec = {
                    "i": bi,
                    "off": b["off"],
                    "magic": b["magic"],
                    "size": b["size"],
                    "uncompr": b["uncompr"],
                    "ok": ok,
                    "ecc": meta["ecc_ok"],
                    "len": len(out),
                }
                if ok:
                    out_path = os.path.join(OUT_DIR, f"dec_{os.path.splitext(entry['file'])[0]}_{bi:02d}_{b['magic']}.bin")
                    open(out_path, "wb").write(out)
                    rec["out"] = out_path
                entry["blocks"].append(rec)
            except Exception as e:
                entry["blocks"].append({"i": bi, "off": b["off"], "magic": b["magic"], "error": str(e)})
        results.append(entry)
        print(f"{entry['file']}: {entry['n_blocks']} blocks, ok={sum(1 for r in entry['blocks'] if r.get('ok'))}")
    return results


def scan_strings(data, minlen=4):
    out = []
    cur = bytearray()
    start = 0
    for i, b in enumerate(data):
        if 32 <= b < 127:
            if not cur:
                start = i
            cur.append(b)
        else:
            if len(cur) >= minlen:
                out.append((start, cur.decode("ascii")))
            cur = bytearray()
    if len(cur) >= minlen:
        out.append((start, cur.decode("ascii")))
    return out


def guess_chunks(data, base=0):
    chunks = []
    i = 0
    while i + 8 <= len(data):
        a = struct.unpack_from("<I", data, i)[0]
        b = struct.unpack_from("<I", data, i + 4)[0]
        plausible = (
            (0 < b <= len(data) - i and b >= 8)
            or (a in (0x01000000, 0x01000008, 0x01010008, 0x01050000, 0x01000308,
                      0x02000000, 0x02000008, 0x02000308, 0x03000000, 0x03000008,
                      0x01010108, 0x00000000, 0x00000008, 0x00010000))
        )
        if b > 0x80000000 or (a > 0x80000000):
            i += 4
            continue
        i += 4
    return chunks


if __name__ == "__main__":
    results = extract_all()
    with open(os.path.join(OUT_DIR, "korf_decompress_report.json"), "w") as f:
        json.dump(results, f, indent=2)

    # deep-dive first successful block of Initpa01 and InitPx03
    for target in ("Initpa01", "InitPx03"):
        for r in results:
            if r["file"].lower().startswith(target.lower()):
                for blk in r["blocks"]:
                    if not blk.get("out"):
                        continue
                    d = open(blk["out"], "rb").read()
                    print(f"\n==== {blk['out']} len={len(d)} magic={blk['magic']} ====")
                    print("hex head 256:")
                    for off in range(0, min(256, len(d)), 16):
                        h = d[off:off + 16].hex(" ")
                        asc = "".join(chr(b) if 32 <= b < 127 else "." for b in d[off:off + 16])
                        print(f"  {off:04x}  {h:<47}  {asc}")
                    print("strings:", scan_strings(d, 4)[:40])
                    break
                break
