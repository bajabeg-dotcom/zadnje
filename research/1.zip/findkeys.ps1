﻿$p="C:\Users\Baja\Desktop\Nova mapa\KORG PA Manager\v3\KORGPAManager.exe"
$b=[IO.File]::ReadAllBytes($p)
$latin=[Text.Encoding]::GetEncoding(28591).GetString($b)
$uni0=[Text.Encoding]::Unicode.GetString($b)
$uni1=[Text.Encoding]::Unicode.GetString($b,1,$b.Length-1)
$keys=@('.SET','.STY','.PCG','.PAD','.MED','.TPL','.PRS','.ACC','.STR','.BMP','.TTF','.WAV','.KMP','.KSC','SET Folder','PA4X','PA3X','PA2X','PA1X','PA1000','PA700','PA600','PA500','PA800','PA400','PA300','i400','i200','i30','KORF','OC20','OC31','OC21','Korg','KORG','Style','PCG','MSVBVM','Delphi','TForm','TLabel','TButton','IMAGE','Loaded','Supported','version')
foreach($k in $keys){
  $r=@()
  $i=$latin.IndexOf($k,[StringComparison]::Ordinal); if($i -ge 0){$r+="A@0x{0:X}" -f $i}
  $i=$uni0.IndexOf($k,[StringComparison]::Ordinal); if($i -ge 0){$r+="U0@0x{0:X}" -f ($i*2)}
  $i=$uni1.IndexOf($k,[StringComparison]::Ordinal); if($i -ge 0){$r+="U1@0x{0:X}" -f ($i*2+1)}
  if($r){ "{0,-12} {1}" -f $k,($r -join ' ') } else { "{0,-12} NOT FOUND" -f $k }
}
