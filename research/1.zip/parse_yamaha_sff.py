# -*- coding: utf-8 -*-
"""Parse Yamaha SFF (.sty) structure: markers, sysex, tracks, parts."""
import struct, os, sys, re, json
sys.stdout.reconfigure(encoding='utf-8', errors='replace')

ROOT = r'C:\Users\Baja\Desktop\Nova mapa\Style Works XT Universal\Init_Ya'

def vlq(data, i):
    v = 0
    while True:
        if i >= len(data): raise ValueError('vlq eof')
        c = data[i]; i += 1
        v = (v << 7) | (c & 0x7f)
        if not (c & 0x80): break
    return v, i

def parse_smf(path):
    b = open(path, 'rb').read()
    assert b[:4] == b'MThd', f'not SMF: {path}'
    hlen = struct.unpack('>I', b[4:8])[0]
    fmt, ntrk, div = struct.unpack('>HHH', b[8:14])
    pos = 8 + hlen
    tracks = []
    markers = []
    sysexes = []
    tempo = None
    for ti in range(ntrk):
        if b[pos:pos+4] != b'MTrk':
            # try scan
            pos = b.find(b'MTrk', pos)
            if pos < 0: break
        tlen = struct.unpack('>I', b[pos+4:pos+8])[0]
        tdata = b[pos+8:pos+8+tlen]
        pos += 8 + tlen
        # parse events
        i = 0
        tick = 0
        running = None
        events = []
        try:
            while i < len(tdata):
                delta, i = vlq(tdata, i)
                tick += delta
                st = tdata[i]
                if st < 0x80:
                    if running is None: raise ValueError('no running status')
                    status = running
                else:
                    status = st
                    i += 1
                    if st < 0xF0:
                        running = st
                if status == 0xFF:  # meta
                    mt = tdata[i]; i += 1
                    ln, i = vlq(tdata, i)
                    data = tdata[i:i+ln]; i += ln
                    if mt == 0x06:  # marker
                        try: name = data.decode('latin-1')
                        except: name = repr(data)
                        markers.append({'tick': tick, 'name': name})
                    elif mt == 0x51:
                        tempo = int.from_bytes(data, 'big') if len(data)==3 else tempo
                    elif mt == 0x2F:
                        break
                elif status in (0xF0, 0xF7):  # sysex
                    ln, i = vlq(tdata, i)
                    data = tdata[i:i+ln]; i += ln
                    sysexes.append({'tick': tick, 'data': data.hex(),
                                    'hdr': data[:8].hex() if data else ''})
                elif status in (0xF1, 0xF2, 0xF3):
                    i += 1 if status==0xF1 else (2 if status==0xF2 else 1)
                elif status >= 0xC0 and status <= 0xDF:  # 1 data
                    if i >= len(tdata): break
                    d1 = tdata[i]; i += 1
                    events.append((tick, status, d1))
                else:  # 2 data
                    if i+1 >= len(tdata): break
                    d1, d2 = tdata[i], tdata[i+1]; i += 2
                    events.append((tick, status, d1, d2))
        except Exception as e:
            events.append(('PARSE_ERR', str(e)))
        tracks.append({'track': ti, 'len': tlen, 'n_events': len(events),
                       'events_sample': events[:5]})
    return {
        'file': os.path.basename(path),
        'fmt': fmt, 'ntrk': ntrk, 'div': div,
        'tempo_bpm': round(60_000_000 / tempo, 2) if tempo else None,
        'markers': markers,
        'n_sysex': len(sysexes),
        'sysex': sysexes[:30],
        'tracks': tracks,
        'size': len(b),
    }

for fn in sorted(os.listdir(ROOT)):
    if not fn.lower().endswith('.sty'): continue
    path = os.path.join(ROOT, fn)
    print('='*70)
    try:
        info = parse_smf(path)
    except Exception as e:
        print(f'{fn}: ERROR {e}')
        continue
    print(f"{info['file']}  fmt={info['fmt']} ntrk={info['ntrk']} div={info['div']} "
          f"bpm={info['tempo_bpm']} size={info['size']} sysex={info['n_sysex']}")
    print('  markers:')
    for m in info['markers']:
        print(f"    t={m['tick']:6d}  {m['name']}")
    print('  sysex hdrs:')
    seen = set()
    for s in info['sysex']:
        key = s['hdr']
        if key in seen: continue
        seen.add(key)
        print(f"    t={s['tick']:6d}  {s['hdr']}  full[:40]={s['data'][:80]}")
    print('  tracks:')
    for t in info['tracks']:
        evs = t['events_sample']
        kinds = []
        for e in evs[:8]:
            if isinstance(e, tuple) and len(e) >= 2 and not isinstance(e[0], str):
                st = e[1]
                if st == 0x90 or (0x90 <= st < 0xA0): kinds.append('ON')
                elif 0x80 <= st < 0x90: kinds.append('OFF')
                elif 0xB0 <= st < 0xC0: kinds.append(f'CC{e[2]}')
                elif 0xC0 <= st < 0xD0: kinds.append(f'PC{e[2]}')
                elif 0xE0 <= st < 0xF0: kinds.append('PB')
                else: kinds.append(hex(st))
            else:
                kinds.append(str(e))
        print(f"    trk{t['track']}: n={t['n_events']} sample={kinds}")

# Also parse STY from other Yamaha dirs if present
print('\n\n' + '='*70)
print('Herzing.sty and other SFF samples outside Init_Ya')
print('='*70)
for dirpath, dns, fns in os.walk(r'C:\Users\Baja\Desktop\Nova mapa\Style Works XT Universal'):
    for fn in fns:
        if not fn.lower().endswith('.sty'): continue
        path = os.path.join(dirpath, fn)
        rel = os.path.relpath(path, r'C:\Users\Baja\Desktop\Nova mapa\Style Works XT Universal')
        # skip Init_Ya already done
        if rel.lower().startswith('initya'): continue
        head = open(path, 'rb').read(4)
        if head == b'MThd':
            try:
                info = parse_smf(path)
                print(f"\n{rel}  fmt={info['fmt']} ntrk={info['ntrk']} div={info['div']} bpm={info['tempo_bpm']}")
                for m in info['markers'][:40]:
                    print(f"    t={m['tick']:6d}  {m['name']}")
                seen = set()
                for s in info['sysex']:
                    if s['hdr'] in seen: continue
                    seen.add(s['hdr'])
                    print(f"    sysex t={s['tick']} {s['hdr']} {s['data'][:60]}")
            except Exception as e:
                print(f'{rel}: ERR {e}')
        else:
            print(f'\n{rel}: not SMF head={head!r}')
