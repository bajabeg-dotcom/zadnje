import json
import shutil
import subprocess
import sys
import time
from pathlib import Path

ROOT = Path(r"C:\Users\Baja\Desktop\Nova mapa")
sys.path.insert(0, str(ROOT))
TMP = Path(r"C:\Users\Baja\AppData\Local\Temp\opencode\verify")
if TMP.exists():
    shutil.rmtree(TMP, ignore_errors=True)
TMP.mkdir(parents=True)

failures = []


def check(name, ok, detail=""):
    print(f"{'PASS' if ok else 'FAIL'}  {name}" + (f"  {detail}" if detail else ""))
    if not ok:
        failures.append(name)


def run(args, **kw):
    return subprocess.run([sys.executable, "-m", "setconvert", *args],
                          cwd=ROOT, capture_output=True, text=True, encoding="utf-8",
                          errors="replace", **kw)


# --- CLI -----------------------------------------------------------------
r = run(["families"])
check("cli families", r.returncode == 0 and "pa800" in r.stdout)

r = run(["info", "NEWNAME.SET"])
check("cli info SET", r.returncode == 0 and "folders:" in r.stdout)

r = run(["info", str(ROOT / "Style Works XT Universal" / "InitKorg")])
check("cli info folder scans loose STY",
      r.returncode == 0 and "Initpa01.STY" in r.stdout and "family: legacy" in r.stdout)

r = run(["info", str(ROOT / "Style Works XT Universal" / "InitKorg" / "INIT_I30.STY")])
check("cli info unreadable file exits 1", r.returncode == 1 and "not a Korg resource container" in r.stdout)

src = ROOT / "Style Works XT Universal" / "InitKorg" / "Initpa01.STY"
r = run(["convert", str(src), str(TMP / "one.STY"), "--to", "pa800"])
check("cli convert single", r.returncode == 0 and (TMP / "one.STY").exists())

r = run(["convert", str(src), str(TMP / "one.STY"), "--to", "pa800", "--json"])
try:
    payload = json.loads(r.stdout)
except Exception as exc:
    payload = None
    print("   json parse:", exc, r.stdout[:200])
check("cli convert --json", r.returncode == 0 and payload and payload["dst_family"] == "pa800")

bad = ROOT / "Style Works XT Universal" / "InitKorg" / "INIT_I30.STY"
r = run(["convert", str(bad), str(TMP / "bad.STY"), "--to", "pa800"])
check("cli convert unreadable file reports cause",
      r.returncode == 1 and "not a Korg resource container" in (r.stderr + r.stdout)
      and "Traceback" not in r.stderr)

folder = ROOT / "Style Works XT Universal" / "InitKorg"
out = TMP / "batch"
r = run(["convert", str(folder), str(out), "--to", "pa800"])
check("cli convert batch",
      r.returncode == 1 and "done: 7 converted, 3 failed, 10 total" in r.stdout
      and len(list(out.glob("*.STY"))) == 7)

# --- round trip through the produced files -------------------------------
from setconvert.conv import convert_sty
from pa800_native.oc31_codec import decode_oc31

roundtrip_ok = True
detail = ""
for f in sorted(out.glob("*.STY")):
    data = f.read_bytes()
    try:
        converted, report = convert_sty(data, "pa1x", strict=True)
        converted2, report2 = convert_sty(converted, "pa800", strict=True)
    except Exception as exc:
        roundtrip_ok = False
        detail = f"{f.name}: {exc}"
        break
check("converted files convert back (pa800 -> pa1x -> pa800)", roundtrip_ok, detail)

# --- encoder round trip on every resource --------------------------------
from setconvert.sty import StyBank
from setconvert.genab import decode_resource
from pa800_native.oc31_fast_encoder import encode_oc31_greedy

enc_ok = True
detail = ""
count = 0
for sty in sorted((ROOT / "Style Works XT Universal" / "InitKorg").glob("*.[Ss][Tt][Yy]")):
    try:
        bank = StyBank.read(sty.read_bytes())
    except ValueError:
        continue
    for res in bank.resources:
        if res.kind not in (6, 9):
            continue
        dec = decode_resource(res.payload)
        if decode_oc31(encode_oc31_greedy(dec)) != dec:
            enc_ok = False
            detail = f"{sty.name} kind{res.kind} len{len(dec)}"
        count += 1
check(f"greedy encoder round trip ({count} resources)", enc_ok, detail)

# --- GUI -----------------------------------------------------------------
from setconvert.gui import App

app = App()
app.update()

app.identify_path.set(str(ROOT / "Style Works XT Universal" / "InitKorg"))
app._do_identify()
deadline = time.time() + 60
while app._busy and time.time() < deadline:
    app.update()
    time.sleep(0.02)
log = app.log.get("1.0", "end-1c")
check("gui identify job", not app._busy and "family: legacy" in log)

app._clear_log()

app.convert_in.set(str(folder))
app._reset_output()
app.convert_out.set(str(TMP / "gui_batch"))
app.convert_dst.set("pa800")
app._do_convert()
deadline = time.time() + 180
while app._busy and time.time() < deadline:
    app.update()
    time.sleep(0.02)
log = app.log.get("1.0", "end-1c")
check("gui convert job streams results",
      not app._busy and "done: 7 converted, 3 failed, 10 total" in log
      and len(list((TMP / "gui_batch").glob("*.STY"))) == 7)
check("gui status returns to ready", app._status.get() == "ready", app._status.get())

app.destroy()
print()
print("FAILURES:", failures if failures else "none")
sys.exit(1 if failures else 0)
