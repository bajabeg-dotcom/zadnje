﻿import os, struct, collections
d = r"C:\Users\Baja\Desktop\Nova mapa\Style Works XT Universal\InitKorg"
inv=collections.defaultdict(lambda: dict(count=0, sizes=collections.Counter(), files=set(), min=None, max=None, sum=0))
for fn in sorted(os.listdir(d)):
    if not fn.lower().endswith('.sty'): continue
    data=open(os.path.join(d,fn),'rb').read()
    if data[:4]!=b'\x01\x00\x01\x14': continue
    pos=8
    while pos+8<=len(data):
        hw=data[pos:pos+4]; s=struct.unpack('>I',data[pos+4:pos+8])[0]
        if pos+8+s>len(data): break
        k=hw.hex(' ').upper()
        e=inv[k]; e['count']+=1; e['sizes'][s]+=1; e['files'].add(fn); e['sum']+=s
        e['min']=s if e['min'] is None else min(e['min'],s); e['max']=s if e['max'] is None else max(e['max'],s)
        pos+=8+s
print("%-12s %5s %9s %8s %8s  %-7s %s"%("HEADER WORD","n","sum_size","min","max","nfiles","size histogram"))
for k in sorted(inv, key=lambda x:-inv[x]['count']):
    e=inv[k]
    hist=', '.join("%d:%d"%(sz,c) for sz,c in sorted(e['sizes'].items())[:6])
    print("%-12s %5d %9d %8d %8d  %-7d %s"%(k,e['count'],e['sum'],e['min'],e['max'],len(e['files']),hist))
print()
print("per-file record type sequence (first 12):")
for fn in sorted(os.listdir(d)):
    if not fn.lower().endswith('.sty'): continue
    data=open(os.path.join(d,fn),'rb').read()
    if data[:4]!=b'\x01\x00\x01\x14': continue
    seq=[]; pos=8
    while pos+8<=len(data):
        hw=data[pos:pos+4]; s=struct.unpack('>I',data[pos+4:pos+8])[0]
        if pos+8+s>len(data): break
        seq.append("%s/%d"%(hw.hex(' ').upper(),s)); pos+=8+s
    print("  %-14s %s"%(fn, ' '.join(seq[:12]) + (" ..." if len(seq)>12 else "")))
