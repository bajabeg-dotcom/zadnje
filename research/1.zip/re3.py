import sys, os, glob, collections
sys.path.insert(0, r"C:\Users\Baja\Desktop\Nova mapa")
from pa800_native import parse_bank, decode_oc31

D = r"C:\Users\Baja\Desktop\Nova mapa\Style Works XT Universal\InitKorg"

def try_decode_oc32(p, cmd_start=16):
    fake = b"OC31" + p[4:8] + p[cmd_start:-4] + p[-4:]
    return decode_oc31(fake)

ok = fail = 0
fails = []
for f in sorted(set(glob.glob(os.path.join(D, "*.STY")) + glob.glob(os.path.join(D, "*.sty")))):
    data = open(f, "rb").read()
    if data[:4] != b"\x01\x00\x01\x14":
        continue
    bank = parse_bank(data)
    for i, r in enumerate(bank.resources):
        if r.payload[:4] != b"OC32":
            continue
        try:
            out = try_decode_oc32(r.payload)
            ok += 1
            if ok <= 3:
                print(f"OK {os.path.basename(f)} res[{i}] kind={r.kind:02X} comp={len(r.payload)} -> {len(out)} head={out[:24].hex(' ')}")
        except Exception as e:
            fail += 1
            fails.append((os.path.basename(f), i, r.kind, str(e)))
print(f"\nOC32 decode with cmd_start=16: ok={ok} fail={fail}")
for x in fails[:10]:
    print("  FAIL", x)
