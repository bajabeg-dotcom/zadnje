#!/usr/bin/env python3
"""Probe type-09 internal geometry: PA1X vs PA800 vs PA3X."""
from __future__ import annotations

from pathlib import Path
import struct
import sys

sys.path.insert(0, r"C:\Users\Baja\Desktop\BAJA MUSIC\Baja_Music_PA_Manager_V1_WORKING\pa800_native")
from oc31_codec import decode_oc31  # noqa: E402


def resources(data: bytes):
    kend = data.find(b"KEND")
    count = struct.unpack(">I", data[kend + 4 : kend + 8])[0]
    kbeg = kend - 4 - 4 * count
    start = kbeg + 4
    offs = [struct.unpack(">I", data[start + 4 * i : start + 4 * i + 4])[0] for i in range(count)]
    out = []
    for i, o in enumerate(offs):
        hdr = data[o : o + 4]
        sz = struct.unpack(">I", data[o + 4 : o + 8])[0]
        payload = data[o + 8 : o + 8 + sz]
        out.append((hdr, payload))
    return out


def probe_t9(dec: bytes, label: str) -> None:
    print(f"\n  {label}: dec_len={len(dec)} head={dec[:32].hex(' ')}")
    # child walk: marker(4)+size(4)+body
    pos = 0
    child_i = 0
    while pos + 8 <= len(dec) and child_i < 4:
        marker = dec[pos : pos + 4]
        size = struct.unpack(">I", dec[pos + 4 : pos + 8])[0]
        body = dec[pos + 8 : pos + 8 + size]
        print(f"    child{child_i} @ {pos}: marker={marker.hex()} size={size} body_len={len(body)}")
        if len(body) >= 16:
            print(f"      body[0:16]={body[:16].hex(' ')}")
            internal = struct.unpack(">I", body[0:4])[0]
            f4 = struct.unpack(">I", body[4:8])[0]
            f8 = struct.unpack(">I", body[8:12])[0]
            cnt = body[12] if len(body) > 12 else -1
            print(f"      internal={internal} f4={f4} f8={f8} byte12={cnt}")
            # try geometries
            for hdr_off, slot_sz in ((408, 261), (504, 357), (408, 357), (504, 261)):
                need = hdr_off + cnt * slot_sz + 4
                if need == len(body):
                    term = body[-4:]
                    print(f"      MATCH geometry hdr={hdr_off} slot={slot_sz} count={cnt} term={term.hex()}")
            if len(body) >= 4:
                print(f"      tail4={body[-4:].hex()}")
        pos += 8 + size
        child_i += 1
    if pos != len(dec):
        print(f"    trailing={len(dec) - pos} bytes after last child")
    else:
        print("    children consume payload exactly")


def probe_t6(dec: bytes, label: str) -> None:
    print(f"\n  T6 {label}: len={len(dec)} head={dec[:48].hex(' ')}")


samples = {
    "PA1X_LIVE": Path(r"C:\Users\Baja\Desktop\Pantic Pa1X.SET\STYLE\BANK01_LIVE.STY"),
    "PA800_BANK16": Path(r"C:\Users\Baja\Desktop\BAJA MUSIC\extracted_files_oc20_lzss\STARTUP\ALL\STYLE\BANK16.STY"),
    "PA800_BANK01": Path(r"C:\Users\Baja\Desktop\BAJA MUSIC\extracted_files_oc20_lzss\STARTUP\ALL\STYLE\BANK01.STY"),
    "PA800_USER01": Path(r"C:\Users\Baja\Desktop\BAJA MUSIC\extracted_files_oc20_lzss\STARTUP\ALL\STYLE\USER01.sty"),
    "PA3X_USER01": Path(r"C:\Users\Baja\AppData\Local\Temp\opencode\pa3x_extract\BRMA NOVI.SET\STYLE\USER01.STY"),
}

for label, path in samples.items():
    if not path.exists():
        print("MISSING", path)
        continue
    print(f"\n==== {label} ====")
    res = resources(path.read_bytes())
    t9 = [(h, p) for h, p in res if h[0] == 9]
    t6 = [(h, p) for h, p in res if h[0] == 6]
    print(f"  hdr t9 variants: {sorted({h.hex() for h, _ in t9})}")
    print(f"  hdr t6 variants: {sorted({h.hex() for h, _ in t6})}")
    # probe first 3 type09
    for i, (h, p) in enumerate(t9[:3]):
        if p.startswith(b"OC31"):
            try:
                probe_t9(decode_oc31(p), f"t9[{i}]")
            except Exception as e:
                print(f"  t9[{i}] decode err: {e}")
    # one type06
    if t6:
        h, p = t6[0]
        if p.startswith(b"OC31"):
            try:
                probe_t6(decode_oc31(p), f"t6[0] hdr={h.hex()}")
            except Exception as e:
                print(f"  t6 decode err: {e}")
