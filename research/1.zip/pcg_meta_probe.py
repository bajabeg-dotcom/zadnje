﻿import io, sys, collections
sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding="utf-8", errors="replace")
from pathlib import Path
sys.path.insert(0, r"C:\Users\Baja\Desktop\Nova mapa")
from setconvert.sty import StyBank
from setconvert.pcg import parse_catalog

SETS = [
    ("pa4x", r"C:\Users\Baja\Desktop\Pa4x Pro Dejan Shiki.SET"),
    ("pa3x", r"C:\Users\Baja\Desktop\Korg Pa3x Team Serbian.SET"),
    ("pa1x", r"C:\Users\Baja\Desktop\Pantic Pa1X.SET"),
    ("pa800 KOCE", r"C:\Users\Baja\Desktop\KOCE FOLK.SET"),
    ("pa800 GOLE", r"C:\Users\Baja\Desktop\GOLE ARX .SET"),
]

for label, root in SETS:
    for pcg in sorted(Path(root).rglob("*")):
        if pcg.suffix.lower() != ".pcg":
            continue
        bank = StyBank.read(pcg.read_bytes())
        k5 = [r for r in bank.resources if r.kind == 5]
        if not k5:
            print(f"{label}/{pcg.name}: no kind05")
            continue
        payload = k5[0].payload
        hdr = k5[0].header
        entries = parse_catalog(payload, hdr)
        var = hdr[1] == 1
        print(f"{label}/{pcg.name}: hdr={hdr.hex(' ')} entries={len(entries)} var={var}")
        if not var:
            # meta byte distribution
            metas = collections.Counter(payload[i*24+17:(i+1)*24].hex(' ')
                                        for i in range(len(payload)//24))
            print(f"    fixed meta[17:24] distinct={len(metas)} top={metas.most_common(4)}")
        else:
            # walk variable records and dump trailing field distributions
            off = 0
            types = collections.Counter()
            tails = collections.Counter()
            mid = collections.Counter()
            while off + 2 <= len(payload):
                ln = int.from_bytes(payload[off:off+2], "big")
                rec = payload[off:off+2+ln]
                types[rec[2:4].hex()] += 1
                if len(rec) >= 53:
                    mid[rec[43:47].hex(' ')] += 1
                    tails[rec[47:].hex(' ')] += 1
                off += 2 + ln
            print(f"    types={dict(types)}")
            print(f"    [43:47]={dict(list(mid.items())[:6])}")
            print(f"    tail[47:] distinct={len(tails)} sample={list(tails.items())[:4]}")

