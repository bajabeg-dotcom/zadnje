import sys, io, os, glob, collections
sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding='utf-8', errors='replace')
sys.path.insert(0, r'C:\Users\Baja\Desktop\Nova mapa')
from setconvert.sty import StyBank
from setconvert.detect import decode_payload
from setconvert.sts import child_spans, GEN_B_RECORDS, GEN_B_SLOT, DETAIL_OFFSET_GEN_B, DETAIL_SIZE, DETAIL_SELECTOR

STY = r'C:\Users\Baja\Desktop\KOCE FOLK.SET\SOUND\USER01.STY'
if not os.path.exists(STY):
    STY = sorted(glob.glob(r'C:\Users\Baja\Desktop\KOCE FOLK.SET\**\*.sty', recursive=True))[0]
print('file:', STY)

bank = StyBank.read(STY)
for res in bank.resources:
    if res.kind != 9:
        continue
    dec = decode_payload(res.payload)
    spans = child_spans(dec)
    if not spans or spans[0].marker not in (b'\x00\x00\x00\x08', b'\x00\x00\x01\x08'):
        print('  res: marker', spans[0].marker.hex(' ') if spans else None, 'skip')
        continue
    body = dec[spans[0].body_start:spans[0].end]
    records = int.from_bytes(body[8:12], 'big'); count = body[12]
    print(f'\n== kind09 resource records={records} count={count} bodylen={len(body)}')
    if records == 408:
        SLOT, DET = 261, 113
    elif records == 504:
        SLOT, DET = 357, 209
    else:
        print('  (unexpected records)'); continue
    for si in range(count):
        slot = body[records + si*SLOT: records + (si+1)*SLOT]
        sid = slot[0]
        print(f'  slot {sid}: 10B records + detail selectors')
        for t in range(4):
            ten = slot[17 + t*10 : 27 + t*10]
            base = DET + t*DETAIL_SIZE + DETAIL_SELECTOR
            sel = slot[base:base+4]
            print(f'    t{t}: ten={ten.hex(" ")}  detail(msb,lsb,res,pc)={sel[0]:3d},{sel[1]:3d},{sel[2]:3d},{sel[3]:3d}')
    break
