import sys, io, os, glob, collections, traceback
sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding='utf-8', errors='replace', line_buffering=True)
sys.path.insert(0, r'C:\Users\Baja\Desktop\Nova mapa')
from setconvert.pcg import PcgBank, parse_catalog

files = sorted(glob.glob(r'C:\Users\Baja\Desktop\**\*.pcg', recursive=True))
print(f'corpus: {len(files)} PCG')
rt_ok = rt_diff = read_fail = cat_fail = 0
rows = []
for p in files:
    try:
        bank = PcgBank.read(p)
    except Exception as e:
        read_fail += 1; rows.append(('READ-FAIL', p, str(e)[:70])); continue
    try:
        entries = bank.catalog()
    except Exception as e:
        cat_fail += 1; rows.append(('CAT-FAIL', p, str(e)[:70])); continue
    built = bank.build()
    same = built == open(p, 'rb').read()
    if same: rt_ok += 1
    else: rt_diff += 1
    banks = sorted({e.bank for e in entries})
    progs = [e.program for e in entries]
    dup = len(progs) - len(set(zip([e.bank for e in entries], progs)))
    rows.append(('OK' if same else 'RT-DIFF', p, f'n={len(entries)} banks={banks} '
                f'prog={min(progs) if progs else "-"}..{max(progs) if progs else "-"} dup={dup} '
                f'kbeg={bank.kbeg_mode} kinds={bank.kinds}'))

for st, p, info in rows:
    mark = '  ' if st == 'OK' else '* '
    print(f'{mark}{st:10s} {os.path.relpath(p, r"C:\Users\Baja\Desktop"):70s} {info}')
print(f'\nRT-OK={rt_ok} RT-DIFF={rt_diff} READ-FAIL={read_fail} CAT-FAIL={cat_fail}')

# functional checks on one file per family
print('\n-- catalog API checks --')
koce = PcgBank.read(r'C:\Users\Baja\Desktop\KOCE FOLK.SET\SOUND\USER01.PCG')
ent = koce.catalog()
print('KOCE USER01:', len(ent), 'first3:', [(e.name, e.bank, e.program) for e in ent[:3]])
by = koce.catalog_by_bank()
print('by_bank keys:', list(by), 'counts:', {k: len(v) for k, v in by.items()})
print('find(9, 1):', koce.find(9, 1))
print('find(9, 127):', koce.find(9, 127))
print('find(9, 200):', koce.find(9, 200))
dj = PcgBank.read(r'C:\Users\Baja\Desktop\Pa4x Pro Dejan Shiki.SET\SOUND\USER04.PCG')
e4 = dj.catalog()
print('Dejan USER04 (var):', len(e4), 'first3:', [(e.name, e.bank, e.program) for e in e4[:3]])
print('record lens:', sorted({len(e.record) for e in e4}), 'rt=', dj.build() == open(r'C:\Users\Baja\Desktop\Pa4x Pro Dejan Shiki.SET\SOUND\USER04.PCG','rb').read())
# error paths
for bad, why in [(b'', 'empty'), (b'\x05\x00\x00\x18', 'header only')]:
    try:
        parse_catalog(bad, b'\x05\x00\x00\x18') if why == 'empty' else parse_catalog(b'', bad)
        print('  ERROR-PATH NO RAISE:', why)
    except ValueError as e:
        print('  raises OK:', why, '->', e)
try:
    parse_catalog(b'\x00' * 24, b'\x05\x00\x00\x18')
    print('  ERROR-PATH NO RAISE: bad meta')
except ValueError as e:
    print('  raises OK: bad meta ->', e)
try:
    parse_catalog(b'\x00\x33\x00\x03', b'\x05\x01\x00\x18')
    print('  ERROR-PATH NO RAISE: truncated var')
except ValueError as e:
    print('  raises OK: truncated var ->', e)
try:
    PcgBank.read(r'C:\Users\Baja\Desktop\Nova mapa (3)\investigation\ROM.PCG')
    print('  ROM.PCG handled?')
except Exception as e:
    print('  ROM.PCG raises:', type(e).__name__, str(e)[:60])
