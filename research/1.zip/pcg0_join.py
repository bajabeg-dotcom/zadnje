import sys, io, os, struct
sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding='utf-8', errors='replace')
sys.path.insert(0, r'C:\Users\Baja\Desktop\Nova mapa')
from pa800_native.sty_container import parse_bank

PRG = r'C:\Users\Baja\Desktop\PA800_AI_PA800_STUDIO_v5_2026-09-20\factory_evidence\native_factory\SOUND\PRGMAPS.TBL'
ROM = r'C:\Users\Baja\Desktop\PA800_AI_PA800_STUDIO_v5_2026-09-20\factory_evidence\native_factory\SOUND\ROM.PCG'

bank = parse_bank(open(PRG, 'rb').read())
otc_raw = bank.resources[1].payload
nvar_raw = bank.resources[2].payload
sl = bank.resources[5].payload

otc = [int.from_bytes(otc_raw[8+i*2:10+i*2], 'big') for i in range((len(otc_raw)-8)//2)]
nvar = list(nvar_raw[8:])

def valid_ord(p, l):
    return 0 <= p < 128 and 0 <= l <= nvar[p] and otc[p] + l

# scan alignments
print('scan (start, stride): count valid / total')
best = None
for start in range(0, 16):
    for stride in (6,):
        n = (len(sl) - start) // stride
        good = 0
        for i in range(n):
            e = sl[start+i*stride:start+(i+1)*stride]
            msb = int.from_bytes(e[0:2], 'big')
            l, p = e[2], e[3]
            ordinal = int.from_bytes(e[4:6], 'big')
            if msb == 121 and p < 128 and l <= nvar[p] and otc[p] + l == ordinal:
                good += 1
        if best is None or good > best[0]:
            best = (good, n, start, stride)
        print(f'  start={start:2d} stride={stride}: {good}/{n}')
print('BEST:', best)

start = best[2]
n = best[1]
entries = []
bad = []
for i in range(n):
    e = sl[start+i*6:start+(i+1)*6]
    msb = int.from_bytes(e[0:2], 'big')
    l, p = e[2], e[3]
    ordinal = int.from_bytes(e[4:6], 'big')
    ok = (msb == 121 and p < 128 and l <= nvar[p] and otc[p] + l == ordinal)
    entries.append((msb, l, p, ordinal, ok))
    if not ok:
        bad.append((i, e.hex(' '), msb, l, p, ordinal))
print(f'\nparsed {len(entries)} entries from offset {start}; valid={sum(1 for x in entries if x[4])} invalid={len(bad)}')
print('first 12:')
for i, x in enumerate(entries[:12]):
    print('   ', i, x)
print('last 8:')
for i, x in enumerate(entries[-8:], start=len(entries)-8):
    print('   ', i, x)
print('invalid samples:', bad[:10])

# distinct MSB
import collections
print('MSB histogram:', collections.Counter(x[0] for x in entries))

# join with ROM.PCG catalog by ordinal
rom = parse_bank(open(ROM, 'rb').read())
cat = [r for r in rom.resources if r.kind == 5][0].payload
names = [cat[i*24:(i+1)*24].split(b'\x00')[0].decode('ascii', 'replace') for i in range(len(cat)//24)]
print('\nROM catalog records:', len(names))
by_ord = {}
for msb, l, p, ordinal, ok in entries:
    if ok:
        by_ord.setdefault(ordinal, (msb, l, p))
print('distinct ordinals:', len(by_ord), 'max ordinal:', max(by_ord))
joined = 0
miss = []
for ordinal in sorted(by_ord):
    if ordinal < len(names):
        joined += 1
    else:
        miss.append(ordinal)
print(f'ordinals within catalog range: {joined}, beyond: {len(miss)}')
print('sample join:')
for ordinal in list(sorted(by_ord))[:10]:
    nm = names[ordinal] if ordinal < len(names) else '<out of range>'
    print(f'   ordinal={ordinal:5d} (msb,l,p)={by_ord[ordinal]} name={nm!r}')
