import sys, io, os, glob, collections, struct
sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding='utf-8', errors='replace')
sys.path.insert(0, r'C:\Users\Baja\Desktop\Nova mapa')
from setconvert.sty import StyBank
from setconvert import parameters as P
from setconvert import sts as S
from setconvert.sts import StsStats
from setconvert.detect import decode_payload
from setconvert.families import FAMILIES
from pa800_native.sty_container import parse_bank

NUL = b"\x00"

def pcg_catalog(path):
    """Return (catalog_hdr, records) where records = [{name, bank, prog, meta}] or v1 list."""
    bank = parse_bank(open(path, 'rb').read())
    cat = [r for r in bank.resources if r.kind == 5]
    if not cat:
        return None, []
    c = cat[0]
    recs = []
    if c.header[1] == 0:
        for i in range(len(c.payload) // 24):
            rec = c.payload[i*24:(i+1)*24]
            name = rec[:16].split(NUL)[0].decode('ascii', 'replace')
            meta = rec[16:]
            recs.append({'name': name, 'bank': meta[3], 'prog': meta[4], 'meta': meta.hex(' ')})
    else:
        pos = 0
        while pos < len(c.payload):
            a = int.from_bytes(c.payload[pos:pos+2], 'big')
            ln = a + 2
            if c.payload[pos+4:pos+8] != b'\x00\x02\x00\x1c' or ln < 39 or pos + ln > len(c.payload):
                break
            rec = c.payload[pos:pos+ln]
            meta = rec[39:47]
            recs.append({'name': rec[8:24].split(NUL)[0].decode('ascii', 'replace'),
                         'bank': meta[2] if len(meta) > 2 else None,
                         'prog': meta[3] if len(meta) > 3 else None,
                         'meta': meta.hex(' ')})
            pos += ln
    return (c.header, recs)

SETS = [
    ('pa800', r'C:\Users\Baja\Desktop\KOCE FOLK.SET'),
    ('pa800', r'C:\Users\Baja\Desktop\GOLE ARX .SET'),
    ('pa1x',  r'C:\Users\Baja\Desktop\Pantic Pa1X.SET'),
    ('pa3x',  r'C:\Users\Baja\Desktop\Korg Pa3x Team Serbian.SET'),
    ('pa4x',  r'C:\Users\Baja\Desktop\Pa4x Pro Dejan Shiki.SET'),
]

for family, root in SETS:
    print(f'\n######## {family}  {os.path.basename(root)}')
    # --- user PCG catalogs
    pcgs = sorted(glob.glob(os.path.join(root, '**', '*.PCG'), recursive=True)) + \
           sorted(glob.glob(os.path.join(root, '**', '*.pcg'), recursive=True))
    banks = {}
    for p in pcgs:
        hdr, recs = pcg_catalog(p)
        if not recs:
            print(f'  PCG {os.path.basename(p)}: no records hdr={hdr}')
            continue
        bankidx = collections.Counter(r['bank'] for r in recs)
        progs = [r['prog'] for r in recs if r['prog'] is not None]
        print(f'  PCG {os.path.basename(p):12s} hdr={hdr.hex(" ")} records={len(recs)} banks={dict(bankidx)} '
              f'prog range={min(progs) if progs else "-"}/{max(progs) if progs else "-"} '
              f'first3={[r["name"] for r in recs[:3]]}')
        for bi in bankidx:
            banks.setdefault(bi, []).extend(r['prog'] for r in recs if r['bank'] == bi)
    # --- selectors
    stys = sorted({p for p in glob.glob(os.path.join(root, '**', '*'), recursive=True)
                   if p.lower().endswith('.sty')})[:8]
    dialect = FAMILIES[family].sts_dialect
    sel = collections.Counter()
    for sty in stys:
        try:
            bank = StyBank.read(sty)
        except Exception:
            continue
        for res in bank.resources:
            try:
                if res.kind == 6:
                    for blk in P.find_blocks(decode_payload(res.payload)):
                        for rec in blk.records:
                            sel[rec.selector] += 1
                elif res.kind == 9:
                    stats = StsStats()
                    for slot in S.read_document_slots(decode_payload(res.payload), dialect, None, stats):
                        for row in slot.selectors:
                            sel[row] += 1
            except Exception:
                pass
    # group by (msb, lsb)
    grp = collections.defaultdict(list)
    for (msb, lsb, pc), n in sel.items():
        grp[(msb, lsb)].append((pc, n))
    print(f'  selector (msb,lsb) groups: {len(grp)}')
    for key in sorted(grp, key=lambda k: -sum(n for _, n in grp[k])):
        pcs = sorted(p for p, _ in grp[key])
        tot = sum(n for _, n in grp[key])
        flag = 'LSB>=64' if key[1] >= 64 else ''
        print(f'    msb={key[0]:3d} lsb={key[1]:3d}  distinct_pc={len(pcs):3d} pc_minmax={pcs[0]:3d}/{pcs[-1]:3d} hits={tot:5d} {flag}')
