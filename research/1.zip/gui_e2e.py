import io, json, sys, time, zipfile, urllib.request, urllib.error
from pathlib import Path

BASE = "http://127.0.0.1:8767"
TOKEN = None


def req(path, data=None, headers=None, method=None, raw=False):
    h = {"X-App-Token": TOKEN}
    if headers:
        h.update(headers)
    r = urllib.request.Request(BASE + path, data=data, headers=h, method=method)
    try:
        with urllib.request.urlopen(r, timeout=120) as resp:
            body = resp.read()
            ct = resp.headers.get("Content-Type", "")
    except urllib.error.HTTPError as e:
        body = e.read()
        ct = e.headers.get("Content-Type", "")
        print("HTTP", e.code, path, body[:400])
        raise
    if raw:
        return body
    return json.loads(body.decode()) if "json" in ct else body


def get_token():
    html = req("/", method="GET", raw=True).decode()
    for line in html.splitlines():
        if 'app-token' in line:
            return line.split('content="')[1].split('"')[0]
    raise SystemExit("no token")


def multipart(fields, files):
    boundary = "----opencodeboundary7MA4YWxkTrZu0gW"
    out = io.BytesIO()
    for name, value in fields:
        out.write(f"--{boundary}\r\nContent-Disposition: form-data; name=\"{name}\"\r\n\r\n{value}\r\n".encode())
    for name, filename, blob in files:
        out.write(
            f"--{boundary}\r\nContent-Disposition: form-data; name=\"{name}\"; filename=\"{filename}\"\r\n"
            f"Content-Type: application/octet-stream\r\n\r\n".encode()
        )
        out.write(blob)
        out.write(b"\r\n")
    out.write(f"--{boundary}--\r\n".encode())
    return out.getvalue(), {"Content-Type": f"multipart/form-data; boundary={boundary}"}


def zip_set(set_dir: Path) -> bytes:
    buf = io.BytesIO()
    with zipfile.ZipFile(buf, "w", zipfile.ZIP_DEFLATED) as z:
        for p in sorted(set_dir.rglob("*")):
            if p.is_file():
                z.write(p, p.relative_to(set_dir).as_posix())
    return buf.getvalue()


def convert_and_wait(sid, label):
    r = req("/api/convert", data=json.dumps({"id": sid}).encode(),
            headers={"Content-Type": "application/json"}, method="POST")
    jid = r["job"]
    for _ in range(300):
        job = req(f"/api/job?id={jid}")
        if job["status"] in ("done", "error"):
            break
        time.sleep(0.5)
    print(f"[{label}] job status={job['status']} phase={job.get('phase')} err={job.get('error')}")
    det = req(f"/api/details?id={sid}")
    print(f"[{label}] set state={det['set']['state']} artifact={det['set']['artifact']}")
    rep = det.get("report") or {}
    if "error" in rep:
        print(f"[{label}] report error: {rep['error']}")
    print(f"[{label}] converted_sets={rep.get('converted_sets')} total_changed={rep.get('total_changed')}")
    for d in rep.get("details", []):
        for s in d.get("converted_styles", []):
            flag = "ERROR" if "error" in s else ("WARN" if s.get("warnings") else "ok")
            print(f"[{label}]   style {s.get('name')}: {flag} changed={s.get('changed_tracks')}")
            for w in s.get("warnings", [])[:3]:
                print(f"[{label}]     - {w[:140]}")
            if "error" in s:
                print(f"[{label}]     - {s['error']}")
    if det["set"]["artifact"]:
        blob = req(f"/download/{det['set']['artifact']}", raw=True)
        print(f"[{label}] download {len(blob)} bytes; zip ok={zipfile.ZipFile(io.BytesIO(blob)).namelist()[:6]}")
    return job["status"]


def main():
    global TOKEN
    TOKEN = get_token()
    print("token ok")

    # 1) full SET
    set_dir = Path(r"C:\Users\Baja\Desktop\KAFANA 2015.SET")
    data, hdr = multipart([], [("files", "KAFANA 2015.SET.zip", zip_set(set_dir))])
    ids = req("/api/upload", data=data, headers=hdr, method="POST")["ids"]
    print("uploaded SET id", ids[0])
    ok1 = convert_and_wait(ids[0], "SET")

    # 2) single STY
    sty = Path(r"C:\Users\Baja\Desktop\KAFANA 2015.SET\STYLE\Kafana.STY").read_bytes()
    data, hdr = multipart([], [("files", "Kafana.STY", sty)])
    ids = req("/api/upload", data=data, headers=hdr, method="POST")["ids"]
    print("uploaded STY id", ids[0])
    ok2 = convert_and_wait(ids[0], "STY")

    # 3) corrupt-input SET (must not crash)
    set_dir = Path(r"C:\Users\Baja\Desktop\PA800_TEST4_KAFANA\Zikino kolo-A.SET")
    data, hdr = multipart([], [("files", "Zikino kolo-A.SET.zip", zip_set(set_dir))])
    ids = req("/api/upload", data=data, headers=hdr, method="POST")["ids"]
    ok3 = convert_and_wait(ids[0], "TEST4")

    print("RESULT", ok1, ok2, ok3)


if __name__ == "__main__":
    main()
