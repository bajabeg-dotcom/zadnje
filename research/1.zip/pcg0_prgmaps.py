import sys, io, os, struct, collections
sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding='utf-8', errors='replace')
sys.path.insert(0, r'C:\Users\Baja\Desktop\Nova mapa')
from pa800_native.sty_container import parse_bank

PRG = r'E:\Pa800_os_res_v202_EXTRACTED\extracted_files\STARTUP\ALL\SOUND\PRGMAPS.TBL'
ROM = r'C:\Users\Baja\Desktop\PA800_AI_PA800_STUDIO_v5_2026-09-20\factory_evidence\native_factory\SOUND\ROM.PCG'

data = open(PRG, 'rb').read()
print('PRGMAPS.TBL size', len(data), 'head', data[:24].hex(' '))
try:
    bank = parse_bank(data)
    print('parse OK, resources:', len(bank.resources))
    for i, r in enumerate(bank.resources):
        print(f'  [{i}] kind={r.kind} hdr={r.header.hex(" ")} size={len(r.payload)} comp={r.compressed} head={r.payload[:16].hex(" ")}')
except Exception as e:
    print('parse_bank FAIL:', e)

rom = parse_bank(open(ROM, 'rb').read())
cat = [r for r in rom.resources if r.kind == 5][0].payload
names = [cat[i*24:(i+1)*24].split(b'\x00')[0].decode('ascii', 'replace') for i in range(len(cat)//24)]
print()
print('ROM.PCG catalog records:', len(names))
print('  first 5:', names[:5])
print('  last 5:', names[-5:])
