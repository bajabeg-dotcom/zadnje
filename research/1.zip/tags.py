﻿import os, struct, collections
d = r"C:\Users\Baja\Desktop\Nova mapa\Style Works XT Universal\InitKorg"
sty = sorted([f for f in os.listdir(d) if f.lower().endswith('.sty')])
def walk(data, start=8):
    pos=start; n=len(data); recs=[]
    while pos+8<=n:
        h=data[pos:pos+4]; s=struct.unpack('>I',data[pos+4:pos+8])[0]
        if pos+8+s>n: return recs, pos, False
        recs.append((pos,h,s,data[pos+8:pos+8+s])); pos+=8+s
    return recs, pos, pos==n
print("### PA/PX family: record-type header words (4 bytes at record start)")
hdr = collections.Counter(); hdrsz = collections.defaultdict(list)
payloadmagic = collections.defaultdict(lambda: [0, [], set()])
for fn in sty:
    p=os.path.join(d,fn); data=open(p,'rb').read()
    is_pa = data[:4]==b'\x01\x00\x01\x14'
    print("-"*90)
    print("%-16s size=%-8d magic=%s"%(fn,len(data), ' '.join('%02X'%b for b in data[:8])))
    if is_pa:
        # outer record
        outer_h=data[0:4]; outer_s=struct.unpack('>I',data[4:8])[0]
        print("   outer record: header=%s  BE size=%d   (filesize-8=%d)  -> nested container"%(outer_h.hex(' ').upper(), outer_s, len(data)-8))
        recs,end,ok = walk(data,8)
        print("   inner walk from 0x08 BE: %d records, end=0x%X, exact EOF=%s"%(len(recs),end,ok))
        for off,h,s,pl in recs:
            hdr[h]+=1; hdrsz[h].append(s)
            mag = pl[:4]
            if all(32<=c<127 for c in mag):
                key=mag.decode('ascii')
            else:
                key='<binary:'+mag.hex(' ')+'>'
            e=payloadmagic[key]; e[0]+=1; e[1].append(s); e[2].add(fn)
    else:
        print("   starts with 'KORG' -> i-series bulk format, no [tag][size] walk")
        recs,end,ok = walk(data,8)
        print("   trial walk from 0x08 BE: ok=%s end=0x%X"%(ok,end))
print()
print("### distinct 4-byte record header words (PA/PX) + size stats")
for h,c in sorted(hdr.items(), key=lambda kv:-kv[1]):
    szs=sorted(hdrsz[h])
    print("   %s  count=%-4d sizes: min=%d med=%d max=%d  all=%s"%(h.hex(' ').upper(),c,szs[0],szs[len(szs)//2],szs[-1],szs if len(szs)<=10 else str(szs[:6])+'...'+str(szs[-3:])))
print()
print("### distinct payload-start 4-char magic (PA/PX), counts, size ranges, files")
for k,(c,szs,fs) in sorted(payloadmagic.items(), key=lambda kv:-kv[1][0]):
    ss=sorted(szs)
    print("   %-12s count=%-4d size min=%-6d max=%-6d  files=%s"%(repr(k),c,ss[0],ss[-1],",".join(sorted(fs))))
