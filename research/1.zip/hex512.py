﻿import sys, os, glob
d = r"C:\Users\Baja\Desktop\Nova mapa\Style Works XT Universal\InitKorg"
files = sorted(glob.glob(os.path.join(d, "*.STY")) + glob.glob(os.path.join(d, "*.sty")))
seen=set(); out=[]
for f in files:
    k=os.path.basename(f).lower()
    if k in seen: continue
    seen.add(k); out.append(f)
def hd(data, base=0, width=16):
    lines=[]
    for i in range(0, len(data), width):
        chunk=data[i:i+width]
        hexs=' '.join('%02X'%b for b in chunk)
        asc=''.join(chr(b) if 32<=b<127 else '.' for b in chunk)
        lines.append('%08X  %-47s  |%s|'%(base+i, hexs, asc))
    return '\n'.join(lines)
for f in out:
    sz=os.path.getsize(f)
    with open(f,'rb') as fh: data=fh.read(512)
    print('='*100)
    print('%s   size=%d'%(os.path.basename(f), sz))
    print('-'*100)
    print(hd(data))
