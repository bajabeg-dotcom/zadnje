import re, sys
p = r"C:\Users\Baja\Desktop\Nova mapa\Style Works XT Universal\Style Works XT Universal.exe"
b = open(p, "rb").read()
strs = set(m.group().decode() for m in re.finditer(rb"[\x20-\x7e]{5,}", b))
hits = sorted(s for s in strs if re.search(r"Init|Pa\d|PA\d|P[xX]\d|Korg|KORG|\.sty|\.STY", s))
for s in hits[:400]:
    print(s)
print("---- utf16 ----")
strs16 = set(m.group().decode("utf-16le", "replace") for m in re.finditer(rb"(?:[\x20-\x7e]\x00){5,}", b))
hits16 = sorted(s for s in strs16 if re.search(r"Init|Pa\d|PA\d|P[xX]\d|Korg|KORG", s, re.I))
for s in hits16[:400]:
    print(s)
