#!/usr/bin/env python3
"""Validate trackinfo on PA1X; probe sound-record selector semantics."""
from __future__ import annotations

from pathlib import Path
import sys
from collections import Counter

ROOT = r"C:\Users\Baja\Desktop\BAJA MUSIC\Baja_Music_PA_Manager_V1_WORKING"
sys.path.insert(0, ROOT)

from pa800_native import parse_bank, decompress_bank  # noqa: E402
from pa800_native.type06_trackinfo import scan_bank_trackinfo, parse_type06_trackinfo  # noqa: E402
from pa800_native.oc31_codec import decode_oc31  # noqa: E402
from pa800_native.type09_codec import parse_type09  # noqa: E402

samples = {
    "PA1X_LIVE": Path(r"C:\Users\Baja\Desktop\Pantic Pa1X.SET\STYLE\BANK01_LIVE.STY"),
    "PA1X_USER02": Path(r"C:\Users\Baja\Desktop\Pantic Pa1X.SET\STYLE\USER02.STY"),
    "PA800_BANK16": Path(r"C:\Users\Baja\Desktop\BAJA MUSIC\extracted_files_oc20_lzss\STARTUP\ALL\STYLE\BANK16.STY"),
    "PA800_BANK01": Path(r"C:\Users\Baja\Desktop\BAJA MUSIC\extracted_files_oc20_lzss\STARTUP\ALL\STYLE\BANK01.STY"),
}

for label, path in samples.items():
    if not path.exists():
        print("MISSING", path)
        continue
    print(f"\n==== {label} ====")
    data = path.read_bytes()
    try:
        report = scan_bank_trackinfo(data)
        print(f"trackinfo: styles={report['type06_count']} blocks={report['trackinfo_count']}")
        msbs = Counter()
        for st in report["styles"]:
            for b in st["trackinfo_blocks"]:
                for t in b["tracks"]:
                    msbs[t["bank_msb"]] += 1
        print(f"  bank_msb hist={dict(msbs)}")
        if report["styles"]:
            s0 = report["styles"][0]
            print(f"  style0 name={s0['style_name']!r} blocks={s0['trackinfo_count']}")
            if s0["trackinfo_blocks"]:
                for t in s0["trackinfo_blocks"][0]["tracks"][:4]:
                    print(f"    {t['role']}: {t['record_hex']} sel={t['selector']}")
    except Exception as e:
        print(f"trackinfo ERR: {e}")

    # type09 parse with strict PA800 codec
    plain = parse_bank(decompress_bank(data))
    t9 = [r for r in plain.resources if r.kind == 9]
    ok = fail = 0
    errs = Counter()
    for r in t9:
        try:
            parse_type09(r.payload)
            ok += 1
        except Exception as e:
            fail += 1
            errs[str(e)[:60]] += 1
    print(f"type09 strict codec: ok={ok} fail={fail} errs={dict(errs)}")

    # sound record selector analysis: bytes0-2 of 10-byte sound records
    sel_prefix = Counter()
    for r in t9:
        if not r.payload.startswith(b"\x00\x00\x00\x08") and not r.payload.startswith(b"\x00\x01\x00\x08"):
            continue
        mixer_size = int.from_bytes(r.payload[4:8], "big")
        mixer = r.payload[8 : 8 + mixer_size]
        hdr = int.from_bytes(mixer[8:12], "big")
        cnt = mixer[12]
        slot = (len(mixer) - 4 - hdr) // cnt if cnt else 0
        if slot not in (261, 357):
            continue
        for i in range(cnt):
            s = mixer[hdr + i * slot : hdr + (i + 1) * slot]
            for t in range(4):
                sr = s[17 + t * 10 : 27 + t * 10]
                sel_prefix[(sr[0], sr[1])] += 1
    print(f"sound[0:2] prefixes (top): {sel_prefix.most_common(8)}")
