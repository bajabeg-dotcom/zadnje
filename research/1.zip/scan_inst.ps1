﻿foreach($f in @("C:\Users\Baja\Desktop\Nova mapa\KORG PA Manager\v3\unins000.dat","C:\Users\Baja\Desktop\Nova mapa\KORG PA Manager\v3\unins000.msg")){
  $b=[IO.File]::ReadAllBytes($f)
  $latin=[Text.Encoding]::GetEncoding(28591).GetString($b)
  $u=[Text.Encoding]::Unicode.GetString($b)
  "=== $(Split-Path $f -Leaf) size=$($b.Length)"
  foreach($k in @('.SET','.STY','.PCG','.PAD','.MED','.TPL','.PRS','.ACC','.STR','.KSF','.KMP','.KSC','.WAV','SET','Style','Registry','Extension','Assoc','PA4X','PA3X','PA800','PA600','PA300','i400','KORG')){
    $hits=@()
    $idx=0; while(($idx=$latin.IndexOf($k,$idx,[StringComparison]::Ordinal)) -ge 0){ $hits+="A:0x{0:X}" -f $idx; $idx++; if($hits.Count -ge 4){break} }
    $idx=0; while(($idx=$u.IndexOf($k,$idx,[StringComparison]::Ordinal)) -ge 0){ $hits+="U:0x{0:X}" -f ($idx*2); $idx++; if($hits.Count -ge 6){break} }
    if($hits.Count){ "  {0,-12} {1}" -f $k,($hits -join ' ') }
  }
}
