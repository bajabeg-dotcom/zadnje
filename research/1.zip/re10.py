import sys
sys.path.insert(0, r"C:\Users\Baja\Desktop\Nova mapa")
from pa800_native import parse_bank, decode_oc31
sys.stdout.reconfigure(encoding="utf-8", errors="replace")
D = r"C:\Users\Baja\Desktop\Nova mapa\Style Works XT Universal\InitKorg"

def dec(r):
    p = r.payload
    return decode_oc31(b"OC31" + p[4:]) if p[:4] in (b"OC31", b"OC32") else p

def walk(buf, start=8):
    pos, out = start, []
    while pos + 8 <= len(buf):
        tag = buf[pos:pos+4]; size = int.from_bytes(buf[pos+4:pos+8], "big")
        if tag[3] != 8 or pos + 8 + size > len(buf) or size > 10_000_000:
            break
        out.append((pos, tag, size)); pos += 8 + size
    return out, pos

for name in ["InitPx03.STY", "initPx04.STY", "Initpa02.STY", "InitPx01.STY"]:
    d = open(D + "\\" + name, "rb").read()
    bank = parse_bank(d)
    print("=" * 70, name)
    for i, r in enumerate(bank.resources):
        if r.kind not in (6, 9): continue
        out = dec(r)
        ch, endp = walk(out)
        print(f"  kind=0x{r.kind:02X} len={len(out)} children={len(ch)} endp={endp}")
        for pos, tag, size in ch[:10]:
            pl = out[pos+8:pos+8+size]
            print(f"    @0x{pos:04X} {tag.hex(' ')} size={size:6d} head={pl[:24].hex(' ')}")
        if len(ch) > 10:
            print("    ...")
        print(f"    total children: {len(ch)}, walk ends at {endp}/{len(out)}")
