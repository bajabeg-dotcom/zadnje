import struct
import sys
from pathlib import Path

FILES = [
    r"C:\Users\Baja\Desktop\Nova mapa\NEWNAME.SET\GLOBAL\SETUP.GBL",
    r"C:\Users\Baja\Desktop\Nova mapa\NEWNAME.SET\SOUND\USER01.PCG",
    r"C:\Users\Baja\Desktop\Nova mapa\NEWNAME.SET\SOUND\USERDK.PCG",
    r"C:\Users\Baja\Desktop\Nova mapa\NEWNAME.SET\MULTISMP\RAM.KMP",
]


def walk(path: Path) -> None:
    data = path.read_bytes()
    print("=" * 70)
    print(f"{path.name}  size={len(data)}")
    print(f"  head: {data[:40].hex(' ')}")
    if data[:4] != b"\x01\x00\x01\x14":
        print("  !! unexpected outer header")
    total = struct.unpack(">I", data[4:8])[0] + 8
    print(f"  declared total: {total}  (file {len(data)})")
    pos = 8
    index = 0
    while pos + 8 <= len(data):
        hdr = data[pos:pos + 4]
        size = struct.unpack(">I", data[pos + 4:pos + 8])[0]
        payload = data[pos + 8:pos + 8 + size]
        if len(payload) != size:
            print(f"  [{index}] @{pos} hdr={hdr.hex(' ')} size={size} TRUNCATED")
            break
        ascii_head = "".join(chr(b) if 32 <= b < 127 else "." for b in payload[:48])
        print(f"  [{index}] @{pos:<6} hdr={hdr.hex(' ')} size={size:<6} "
              f"pay[:24]={payload[:24].hex(' ')}")
        print(f"        ascii: {ascii_head}")
        pos += 8 + size
        index += 1
    if pos != len(data):
        print(f"  !! ended at {pos}, file {len(data)}, residual {len(data) - pos} bytes")
        print(f"  residual: {data[pos:pos + 32].hex(' ')}")
    else:
        print("  clean end")


for name in FILES:
    p = Path(name)
    if p.exists():
        walk(p)
    else:
        print("missing", name)
