import sys, os, glob, collections
sys.path.insert(0, r"C:\Users\Baja\Desktop\Nova mapa")
from pa800_native import parse_bank

D = r"C:\Users\Baja\Desktop\Nova mapa\Style Works XT Universal\InitKorg"

oc31, oc32 = [], []
for f in sorted(set(glob.glob(os.path.join(D, "*.STY")) + glob.glob(os.path.join(D, "*.sty")))):
    data = open(f, "rb").read()
    if data[:4] != b"\x01\x00\x01\x14":
        continue
    bank = parse_bank(data)
    for i, r in enumerate(bank.resources):
        if r.payload[:4] == b"OC31":
            oc31.append((os.path.basename(f), i, r.kind, r.payload))
        elif r.payload[:4] == b"OC32":
            oc32.append((os.path.basename(f), i, r.kind, r.payload))

print(f"OC31 payloads: {len(oc31)}, OC32 payloads: {len(oc32)}")
print("\n--- OC31 sample headers/trailers ---")
for name, i, kind, p in oc31[:6]:
    print(f" {name} res[{i}] kind={kind:02X} len={len(p)} head={p[:20].hex(' ')} tail={p[-8:].hex(' ')}")
print("\n--- OC32 sample headers/trailers ---")
for name, i, kind, p in oc32[:12]:
    print(f" {name} res[{i}] kind={kind:02X} len={len(p)} head={p[:20].hex(' ')} tail={p[-8:].hex(' ')}")

print("\n--- OC32 structural stats ---")
term = collections.Counter()
sizefields = []
for name, i, kind, p in oc32:
    term[p[-4:-1].hex()] += 1
    sz = int.from_bytes(p[4:8], "little")
    sizefields.append((len(p), sz, name))
print("terminator[-4:-1]:", dict(term))
print("last byte (xor?) distribution:", collections.Counter(p[-1] for _,_,_,p in oc32).most_common(8))
for n, s, nm in sizefields[:10]:
    print(f"  comp_len={n} sizeLE={s} file={nm}")
