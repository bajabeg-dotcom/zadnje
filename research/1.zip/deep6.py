import sys
sys.path.insert(0, r'C:\Users\Baja\Desktop\Nova mapa')
from pathlib import Path
from setconvert.sty import StyBank
from pa800_native.oc31_codec import decode_oc31

path = sys.argv[1]
res_index = int(sys.argv[2])
data = Path(path).read_bytes()
bank = StyBank.read(data)
r = bank.resources[res_index]
payload = decode_oc31(r.payload) if r.compressed else r.payload
print('res %d kind=%d decomp=%d' % (res_index, r.kind, len(payload)))
print('head 64:', payload[:64].hex(' '))

# walk children of top-level child
top_sz = int.from_bytes(payload[4:8], 'big')
print('top tag', payload[:4].hex(' '), 'size', top_sz)
inner = payload[8:8+top_sz]
c = 0
n = 0
while c + 8 <= len(inner):
    tag = inner[c:c+4]
    sz = int.from_bytes(inner[c+4:c+8], 'big')
    if not (0 <= sz <= len(inner) - c - 8):
        print('  stop @%d tag=%s size=%d' % (c, tag.hex(' '), sz))
        break
    body = inner[c+8:c+8+sz]
    print('  child @%d tag=%s size=%d head=%s' % (c, tag.hex(' '), sz, body[:24].hex(' ')))
    c += 8 + sz
    n += 1
    if n > 60:
        print('  ...')
        break
print('inner consumed', c, 'of', len(inner))

# hunt TrackInfo-ish markers anywhere in full payload
for probe in (b'\x02\x00\x00\x08', b'\x02\x00\x02\x08', b'\x02\x00\x03\x08', b'\x02\x00\x04\x08'):
    pos = []
    start = 0
    while True:
        p = payload.find(probe, start)
        if p < 0:
            break
        pos.append(p)
        start = p + 1
        if len(pos) > 40:
            break
    if pos:
        print('marker', probe.hex(' '), 'count', len(pos), 'at', pos[:8])
        p = pos[0]
        print('  follow size', int.from_bytes(payload[p+4:p+8], 'big'))
        print('  bytes:', payload[p:p+16+96].hex(' '))
