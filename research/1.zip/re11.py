import sys, collections, glob, os
sys.path.insert(0, r"C:\Users\Baja\Desktop\Nova mapa")
from pa800_native import parse_bank, decode_oc31
sys.stdout.reconfigure(encoding="utf-8", errors="replace")
D = r"C:\Users\Baja\Desktop\Nova mapa\Style Works XT Universal\InitKorg"

def dec(r):
    p = r.payload
    return decode_oc31(b"OC31" + p[4:]) if p[:4] in (b"OC31", b"OC32") else p

def scan_tags(buf):
    """find [4-byte tag ending with 0x08][u32 BE size] with sane size"""
    out = []
    for pos in range(0, len(buf) - 8):
        if buf[pos+3] != 8: continue
        size = int.from_bytes(buf[pos+4:pos+8], "big")
        if 0 < size <= 200000 and pos + 8 + size <= len(buf):
            out.append((bytes(buf[pos:pos+4]), size, pos))
    return out

for f in sorted(set(glob.glob(os.path.join(D, "*.STY")) + glob.glob(os.path.join(D, "*.sty")))):
    d = open(f, "rb").read()
    if d[:4] != b"\x01\x00\x01\x14": continue
    base = os.path.basename(f)
    bank = parse_bank(d)
    agg = collections.Counter()
    for i, r in enumerate(bank.resources):
        if r.kind not in (6, 9): continue
        out = dec(r)
        for tag, size, pos in scan_tags(out):
            agg[(r.kind, tag)] += 1
    print(f"### {base}")
    for (k, tag), c in sorted(agg.items()):
        print(f"   kind=0x{k:02X} tag={tag.hex(' ')} count={c}")
