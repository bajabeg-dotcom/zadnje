﻿import os, glob, re, struct, sys
d = r"C:\Users\Baja\Desktop\Nova mapa\Style Works XT Universal\InitKorg"
pats = ["*.STY","*.sty","*.ARR","*.arr","*.GBL","*.gbl","*.KBS","*.kbs","*.PRG","*.prg",
        "*.PCG","*.pcg","*.BSQ","*.bsq","*.ARG","*.ARG","*.ARK","*.ARK","*.SNG","*.sng","*.sng"]
files=[]
seen=set()
for p in pats:
    for f in sorted(glob.glob(os.path.join(d,p))):
        k=os.path.basename(f).lower()
        if k in seen: continue
        seen.add(k); files.append(f)
def is_tag(b):
    return len(b)==4 and all(32<=c<127 for c in b)
TAGRE = re.compile(rb'[A-Z0-9_ ][A-Z0-9_ ][A-Z0-9_ ][A-Z0-9_ ]')
for f in files:
    data=open(f,'rb').read()
    print("="*90)
    print(os.path.basename(f), "size", len(data))
    hits=[]
    for m in TAGRE.finditer(data):
        i=m.start(); t=m.group().decode('ascii')
        if i+8<=len(data):
            be=struct.unpack('>I',data[i+4:i+8])[0]
            le=struct.unpack('<I',data[i+4:i+8])[0]
        else: be=le=None
        hits.append((i,t,be,le))
    # keep only where size plausible (>=8 and <= remaining)
    plaus=[]
    for i,t,be,le in hits:
        for e,s in (("BE",be),("LE",le)):
            if s is not None and 8<=s<=len(data)-i:
                plaus.append((i,t,e,s))
    print("  total [A-Z0-9_ ]x4 matches:",len(hits)," plausible-size:",len(plaus))
    for i,t,e,s in plaus[:40]:
        print("    0x%06X %-4s size=%-8d (%s)"%(i,t if False else "",s,e), repr(t))
