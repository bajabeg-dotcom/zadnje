﻿import sys, struct
sys.stdout.reconfigure(encoding="utf-8", errors="replace")
def walk(path, n=8):
    d = open(path, "rb").read()
    print("==", path.split("\\")[-1], len(d))
    print("   outer", d[:8].hex(" "))
    pos = 8
    i = 0
    while pos + 8 <= len(d) and i < n:
        hdr = d[pos:pos+4]
        sz = struct.unpack(">I", d[pos+4:pos+8])[0]
        print("   [%d] @%s hdr=%s sz=%d" % (i, hex(pos), hdr.hex(" "), sz))
        if sz == 0 or pos + 8 + sz > len(d):
            print("      BAD")
            break
        pos += 8 + sz
        i += 1
walk(r"C:\Users\Baja\Desktop\BANK01.STY")
walk(r"C:\Users\Baja\Desktop\USER01_PA800.STY", 10)
