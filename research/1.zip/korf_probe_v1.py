import os, sys, json, glob, struct
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from korf_parse_style import walk

OUT = os.path.dirname(os.path.abspath(__file__))


def probe(path):
    data = open(path, "rb").read()
    tree = []
    walk(data, out=tree)
    print(f"\n=== {os.path.basename(path)} size={len(data)} ===")
    for e in tree:
        k = e.get("kind")
        if not isinstance(k, dict):
            kn = "BRANCH" if not e.get("leaf") else "UNCLASS"
        else:
            kn = k.get("kind", "?")
        if kn in ("UNCLASS", "unknown") or (isinstance(k, dict) and k.get("err")) or e.get("error"):
            print(f"  d={e['depth']} off={e['off']:#06x} id={e['id']:#010x} t={e['type']} v={e['ver']} sz={e['size']} -> {kn} err={e.get('error') or (k.get('err') if isinstance(k,dict) else None)}")
        if e["depth"] <= 1:
            print(f"  d={e['depth']} off={e['off']:#06x} id={e['id']:#010x} t={e['type']} v={e['ver']} sz={e['size']} -> {kn} name={((k or {}).get('data') or {}).get('name') if isinstance(k,dict) else None}")


if __name__ == "__main__":
    # Ricky_1 errors
    p = os.path.join(OUT, "dec_INITPA03_06_OC32.bin")
    if os.path.exists(p):
        probe(p)
    # v1.0 sample
    for p in sorted(glob.glob(os.path.join(OUT, "dec_InitPx01_*.bin")))[:1] + \
             sorted(glob.glob(os.path.join(OUT, "dec_InitPx02_*.bin")))[:1]:
        if os.path.exists(p):
            probe(p)
