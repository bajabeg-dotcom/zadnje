﻿import os, struct, re
d = r"C:\Users\Baja\Desktop\Nova mapa\Style Works XT Universal\InitKorg"
exts=('.sty','.arr','.gbl','.kbs','.prg','.pcg','.bsq','.arg','.ark','.sng')
files=[f for f in sorted(os.listdir(d)) if os.path.splitext(f)[1].lower() in exts]
def hd(b, base=0, w=16):
    out=[]
    for i in range(0,len(b),w):
        c=b[i:i+w]
        out.append('%08X  %-47s  |%s|'%(base+i,' '.join('%02X'%x for x in c),
                   ''.join(chr(x) if 32<=x<127 else '.' for x in c)))
    return '\n'.join(out)
print("### file sizes / block alignment")
print("%-16s %8s  %s"%("FILE","SIZE","mod 512/1024/4096/32768"))
for fn in files:
    n=os.path.getsize(os.path.join(d,fn))
    print("%-16s %8d  %d/%d/%d/%d"%(fn,n,n%512,n%1024,n%4096,n%32768))
print()
print("### PA/PX record-walk end vs file size (trailing data?)")
for fn in files:
    p=os.path.join(d,fn); data=open(p,'rb').read()
    if data[:4]!=b'\x01\x00\x01\x14': continue
    pos=8; cnt=0; last=None
    while pos+8<=len(data):
        s=struct.unpack('>I',data[pos+4:pos+8])[0]
        if pos+8+s>len(data): break
        last=(pos,s); pos+=8+s; cnt+=1
    print("   %-14s size=%-7d last_record@0x%06X size=%-6d walk_end=0x%X  trailing=%d bytes  records=%d"
          %(fn,len(data),last[0],last[1],pos,len(data)-pos,cnt))
print()
print("### TAIL hexdump (last 64 bytes) of each .STY")
for fn in files:
    if not fn.lower().endswith('.sty'): continue
    data=open(os.path.join(d,fn),'rb').read()
    print("-"*80); print(fn, "size",len(data))
    print(hd(data[-64:], len(data)-64))
