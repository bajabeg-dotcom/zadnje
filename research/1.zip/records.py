﻿import os, struct
d = r"C:\Users\Baja\Desktop\Nova mapa\Style Works XT Universal\InitKorg"
def hd(b, base=0, w=16):
    out=[]
    for i in range(0,len(b),w):
        c=b[i:i+w]
        out.append('%08X  %-47s  |%s|'%(base+i,' '.join('%02X'%x for x in c),
                   ''.join(chr(x) if 32<=x<127 else '.' for x in c)))
    return '\n'.join(out)
def recwalk(data, start):
    pos=start; n=len(data); recs=[]
    while pos < n:
        tag=data[pos:pos+4]; s=struct.unpack('>I',data[pos+4:pos+8])[0]
        if s<0 or pos+8+s>n: 
            recs.append((pos,tag,s,None)); break
        recs.append((pos,tag,s,data[pos+8:pos+8+s]))
        pos+=8+s
    return recs,pos
for fn in ("INITPA02.STY","InitPx03.STY"):
    p=os.path.join(d,fn); data=open(p,'rb').read()
    print("="*100)
    print(fn, "size=%d (0x%X)"%(len(data),len(data)))
    print("file header: %s"%' '.join('%02X'%b for b in data[:8]))
    recs,end = recwalk(data,8)
    print("WALK: big-endian, [4B tag][4B BE size][payload] starting at 0x08 -> ended at 0x%X (%s)"%(end,"EXACT EOF" if end==len(data) else "MISALIGNED"))
    print("%-4s %-8s %-12s %-10s %s"%("#","OFFSET","TAG(hex)","SIZE","TAG as ascii / payload preview"))
    for i,(off,tag,s,pl) in enumerate(recs):
        asc=''.join(chr(c) if 32<=c<127 else '.' for c in tag)
        prev=''
        if pl is not None:
            pv=''.join(chr(c) if 32<=c<127 else '.' for c in pl[:40])
            prev='  | '+pv
        else:
            prev='  <TRUNCATED>'
        print("%-4d 0x%06X %-12s %-10s '%s'%s"%(i,off,' '.join('%02X'%b for b in tag),s,asc,prev))
    print()
    print("first 3 records payload hexdump:")
    for i,(off,tag,s,pl) in enumerate(recs[:3]):
        if pl is None: continue
        print("--- rec %d at 0x%X size=%d"%(i,off,s))
        print(hd(pl[:96], off+8))
