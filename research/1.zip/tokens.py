﻿import os, glob, collections, re
d = r"C:\Users\Baja\Desktop\Nova mapa\Style Works XT Universal\InitKorg"
files = sorted(os.listdir(d))
pat = re.compile(rb'[\x20-\x7E]{4}')
agg = collections.defaultdict(lambda: [0, set(), []])
for fn in files:
    p=os.path.join(d,fn)
    if not os.path.isfile(p): continue
    if os.path.splitext(fn)[1].lower() not in ('.sty','.arr','.gbl','.kbs','.prg','.pcg','.bsq','.arg','.ark','.sng'):
        continue
    data=open(p,'rb').read()
    for m in pat.finditer(data):
        t=m.group().decode('latin1')
        if t.strip()=='' : continue
        # only "word-like" tokens: letters/digits/underscore
        if not re.fullmatch(r'[A-Za-z0-9_]{4}', t): continue
        e=agg[t]; e[0]+=1; e[1].add(fn); e[2].append(m.start())
rows = sorted(agg.items(), key=lambda kv:-kv[1][0])
print("%-8s %7s  %s"%("TOKEN","COUNT","FILES"))
for t,(c,fs,offs) in rows:
    print("%-8s %7d  %s   first_offs=%s"%(t,c,",".join(sorted(fs)), [hex(o) for o in offs[:4]]))
