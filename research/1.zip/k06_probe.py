import struct, sys
from pathlib import Path

sys.path.insert(0, r"C:\Users\Baja\Desktop\Nova mapa")
from pa800_native.oc31_codec import decode_oc31

FILES = {
    "pa3x": [
        r"C:\Users\Baja\Desktop\Korg Pa3x Team Serbian.SET\STYLE\FAVORITE12.STY",
        r"C:\Users\Baja\Desktop\Korg Pa3x Team Serbian.SET\STYLE\USER01.STY",
        r"C:\Users\Baja\Desktop\Korg Pa3x Team Serbian.SET\STYLE\USER02.STY",
        r"C:\Users\Baja\Desktop\Korg Pa3x Team Serbian.SET\STYLE\USER03.STY",
    ],
    "pa4x": [
        r"C:\Users\Baja\Desktop\Pa4x Pro Dejan Shiki.SET\STYLE\USER01.STY",
        r"C:\Users\Baja\Desktop\Pa4x Pro Dejan Shiki.SET\STYLE\USER02.STY",
        r"C:\Users\Baja\Desktop\Pa4x Pro Dejan Shiki.SET\STYLE\USER03.STY",
    ],
    "pa800": [
        r"C:\Users\Baja\Desktop\GOLE ARX .SET\GOLE ARX .SET\STYLE\USER01.STY",
        r"C:\Users\Baja\Desktop\GOLE ARX .SET\GOLE ARX .SET\STYLE\FAVORITE01.STY",
        r"C:\Users\Baja\Desktop\USER01_PA800.STY",
    ],
}


def container(data):
    pos = 8
    out = []
    while pos + 8 <= len(data):
        hdr = data[pos:pos + 4]
        size = struct.unpack(">I", data[pos + 4:pos + 8])[0]
        out.append((hdr, data[pos + 8:pos + 8 + size]))
        pos += 8 + size
    return out


def dec(p):
    if p[:4] in (b"OC31", b"OC32"):
        return decode_oc31(p)
    return p


def children(buf):
    pos = 0
    out = []
    while pos + 8 <= len(buf):
        tag = buf[pos:pos + 4]
        size = struct.unpack(">I", buf[pos + 4:pos + 8])[0]
        if pos + 8 + size > len(buf):
            out.append((tag, size, None, pos))
            break
        out.append((tag, size, buf[pos + 8:pos + 8 + size], pos))
        pos += 8 + size
    return out, pos


def hx(b, n=None):
    if n is not None:
        b = b[:n]
    return b.hex(" ")


def valid_core(core):
    if len(core) != 48:
        return False
    STORAGE = {0, 120, 121, 123}
    for i in range(8):
        expr, msb, lsb, prog, low, high = core[i * 6:(i + 1) * 6]
        if not (expr <= 127 and msb in STORAGE and lsb <= 127 and prog <= 127
                and low <= 127 and high <= 127 and low <= high):
            return False
    return True


def find_ti(payload, subs):
    found = []
    for sub in subs:
        marker = b"\x02\x00" + bytes([sub, 0x08])
        pos = 0
        while True:
            pos = payload.find(marker, pos)
            if pos < 0:
                break
            if pos + 8 <= len(payload):
                size = struct.unpack(">I", payload[pos + 4:pos + 8])[0]
                if pos + 8 + size <= len(payload):
                    block = payload[pos + 8:pos + 8 + size]
                    if len(block) >= 48 and valid_core(block[:48]):
                        found.append((pos, sub, size, block))
            pos += 1
    return found


out = []
for fam, paths in FILES.items():
    out.append(f"########## {fam} ##########")
    for p in paths:
        data = Path(p).read_bytes()
        name = Path(p).name
        for hdr, payload in container(data):
            if hdr[0] != 6:
                continue
            d = dec(payload)
            kids, end = children(d)
            out.append(f"--- {Path(p).parent.parent.name}/{name} kind06 hdr={hdr.hex(' ')} decomp={len(d)} end={end}")
            for tag, size, body, at in kids:
                if body is None:
                    out.append(f"    BAD child {tag.hex()} size={size} at {at}")
                    continue
                out.append(f"    child {tag.hex(' ')} size={size} at {at}")
                if tag[0] == 1:
                    # name child: [1B len][name][tail]
                    if body:
                        nlen = body[0]
                        nm = body[1:1 + nlen]
                        tail = body[1 + nlen:]
                        out.append(f"        name len={nlen} name={nm!r} tail({len(tail)})={hx(tail)}")
                elif tag[0] == 3 and size > 8:
                    sub, _e = children(body)
                    for st, ss, sb, _sa in sub:
                        if sb is None:
                            continue
                        out.append(f"        sub {st.hex(' ')} size={ss}")
                        if st[0] == 1 and sb:
                            nlen = sb[0]
                            out.append(f"            name len={nlen} name={sb[1:1+nlen]!r} tail({len(sb)-1-nlen})={hx(sb[1+nlen:])}")
            # TI blocks anywhere
            tis = find_ti(d, (0, 2, 3, 4))
            for pos, sub, size, block in tis:
                out.append(f"    TI pos={pos} sub={sub} size={size} core[0:12]={hx(block[:12])} tail={hx(block[48:])}")
            break  # first kind06 only per file
    out.append("")

text = "\n".join(out)
Path(r"C:\Users\Baja\AppData\Local\Temp\opencode\k06_probe.txt").write_text(text, encoding="utf-8")
print("WROTE", len(text))
