import sys, io, os, glob, collections
sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding='utf-8', errors='replace')
sys.path.insert(0, r'C:\Users\Baja\Desktop\Nova mapa')
from setconvert.sty import StyBank
from setconvert.detect import decode_payload
from setconvert.sts import child_spans

FILES = [
    r'C:\Users\Baja\Desktop\PA800_ENGINE_SESSION_05\bkp_extracted\NewName_final\records\STYLE\USER01.STY',
    r'C:\Users\Baja\Desktop\KOCE FOLK.SET\STYLE\FAVORITE01.STY',
    r'C:\Users\Baja\Desktop\Pantic Pa1X.SET\STYLE\BANK01_LIVE.STY',
    r'C:\Users\Baja\Desktop\GOLE ARX .SET\GOLE ARX .SET\STYLE',
    r'C:\Users\Baja\Desktop\Korg Pa3x Team Serbian.SET\STYLE\USER01.STY',
    r'C:\Users\Baja\Desktop\Pa4x Pro Dejan Shiki.SET\STYLE\USER01.STY',
]

def cells(f):
    bank = StyBank.read(f)
    out = []
    for res in bank.resources:
        if res.kind != 9:
            continue
        try:
            dec = decode_payload(res.payload)
            spans = child_spans(dec)
            if not spans:
                continue
            body = dec[spans[0].body_start:spans[0].end]
            records = int.from_bytes(body[8:12], 'big'); count = body[12]
            if records not in (408, 504) or len(body) < records + count * (261 if records == 408 else 357):
                continue
            SLOT, DET = (261, 113) if records == 408 else (357, 209)
            for si in range(count):
                slot = body[records + si*SLOT: records + (si+1)*SLOT]
                for t in range(4):
                    ten = slot[17 + t*10: 27 + t*10]
                    base = DET + t*37 + 8
                    sel = tuple(slot[base:base+4])
                    out.append((ten, sel))
        except Exception:
            pass
    return out

for f in FILES:
    if not os.path.exists(f):
        if os.path.isdir(f):
            cands = sorted(glob.glob(os.path.join(f, '*.sty'))) + sorted(glob.glob(os.path.join(f, '*.STY')))
            if not cands:
                continue
            f = cands[0]
        else:
            continue
    print(f'\n#### {os.path.basename(f)}  ({f})')
    try:
        rows = cells(f)
    except Exception as e:
        print('  err', e); continue
    joint = collections.Counter()
    pairs = collections.Counter()
    for ten, sel in rows:
        is_user = ten[:3] == b'\xff\xff\x02' and ten[7:10] != b'\x00\x00\x00'
        is_lsb64 = sel[1] >= 64
        joint[(is_user, is_lsb64)] += 1
        if is_user:
            pairs[(ten[7], ten[8], ten[9], sel)] += 1
    print('  joint (user_triple, detail_lsb>=64):', dict(joint))
    triples = collections.Counter((ten[7], ten[8], ten[9]) for ten, sel in rows
                                  if ten[:3] == b'\xff\xff\x02')
    print('  user triples (bank,a,b):', dict(list(triples.items())[:15]), 'distinct', len(triples))
    # detail selector distribution when user
    du = collections.Counter(sel for ten, sel in rows if ten[:3] == b'\xff\xff\x02')
    print('  detail when user: lsb hist', dict(sorted(collections.Counter(s[1] for s in du.elements()).items())))
    dn = collections.Counter(sel for ten, sel in rows if ten[:3] != b'\xff\xff\x02')
    print('  detail when non-user: lsb hist', dict(sorted(collections.Counter(s[1] for s in dn.elements()).items())))
    # candidates: is b == detail pc? is a == detail lsb?
    eq_b_pc = sum(1 for ten, sel in rows if ten[:3] == b'\xff\xff\x02' and ten[9] == sel[3])
    eq_a_lsb = sum(1 for ten, sel in rows if ten[:3] == b'\xff\xff\x02' and ten[8] == sel[1])
    n = sum(1 for ten, sel in rows if ten[:3] == b'\xff\xff\x02')
    print(f'  user cells: {n}  b==detail.pc: {eq_b_pc}  a==detail.lsb: {eq_a_lsb}')
