import struct
import sys
from pathlib import Path

sys.path.insert(0, r"C:\Users\Baja\Desktop\Nova mapa")

from pa800_native.oc31_codec import decode_oc31

PA800 = Path(r"C:\Users\Baja\Desktop\GOLE ARX .SET\GOLE ARX .SET\STYLE\USER01.STY")
PA3X = Path(r"C:\Users\Baja\Desktop\Korg Pa3x Team Serbian.SET\STYLE\FAVORITE12.STY")


def walk_container(data: bytes):
    pos = 8
    out = []
    while pos + 8 <= len(data):
        hdr = data[pos:pos + 4]
        size = struct.unpack(">I", data[pos + 4:pos + 8])[0]
        out.append((hdr, data[pos + 8:pos + 8 + size]))
        pos += 8 + size
    return out


def dec(payload: bytes) -> bytes:
    if payload[:4] in (b"OC31", b"OC32"):
        return decode_oc31(payload)
    return payload


def children(buf: bytes):
    pos = 0
    out = []
    while pos + 8 <= len(buf):
        tag = buf[pos:pos + 4]
        size = struct.unpack(">I", buf[pos + 4:pos + 8])[0]
        if pos + 8 + size > len(buf):
            out.append((tag, size, None))
            break
        out.append((tag, size, buf[pos + 8:pos + 8 + size]))
        pos += 8 + size
    return out, pos


def try_children(buf: bytes):
    kids, end = children(buf)
    if kids and end == len(buf) and all(k[2] is not None for k in kids):
        return kids
    return None


def hx(b: bytes, n: int = 72) -> str:
    text = b[:n].hex(" ")
    if len(b) > n:
        text += f" ...(+{len(b) - n})"
    return text


def dump_pa800_mixer(body: bytes) -> None:
    print(f"    mixer hdr[0:208]: {hx(body[0:208], 208)}")
    for t in range(8):
        rec = body[208 + t * 37:208 + (t + 1) * 37]
        print(f"      track{t} (37): {rec.hex(' ')}")
    print(f"    gap [504:508]: {body[504:508].hex(' ')}  tail[-4:]: {body[-4:].hex(' ')}")
    for s in range(4):
        slot = body[508 + s * 357:508 + (s + 1) * 357]
        if len(slot) < 357:
            alt = body[504 + s * 357:504 + (s + 1) * 357]
            print(f"    slot{s} try504 len={len(alt)} head={hx(alt[:17], 17)}")
            continue
        print(f"    slot{s} head[0:17]: {slot[0:17].hex(' ')}")
        print(f"      sound[17:57]: {slot[17:57].hex(' ')}")
        print(f"      mid[57:113]: {slot[57:113].hex(' ')}")
        for d in range(4):
            det = slot[113 + d * 61:113 + (d + 1) * 61]
            print(f"      detail{d}: {hx(det, 61)}")


def walk(buf: bytes, depth: int = 0, path: str = "") -> None:
    indent = "  " * depth
    kids = try_children(buf)
    if kids is None:
        print(f"{indent}[leaf {len(buf)}B] {hx(buf)}")
        return
    for tag, size, body in kids:
        here = f"{path}/{tag.hex()}"
        print(f"{indent}{tag.hex(' ')} size={size}")
        if body is None:
            continue
        if tag == b"\x00\x01\x00\x08":
            dump_pa800_mixer(body)
            continue
        if tag == b"\x02\x00\x01\x08":
            print(f"{indent}  metadata leaf, {len(body)}B: {hx(body, 96)}")
            sub = try_children(body)
            if sub:
                for stag, ssize, sbody in sub:
                    print(f"{indent}    {stag.hex(' ')} size={ssize} "
                          f"head={hx(sbody, 48) if sbody else None}")
            continue
        if depth >= 6:
            print(f"{indent}  [deep leaf {len(body)}B] {hx(body)}")
            continue
        walk(body, depth + 1, here)


def kind09_of(path: Path) -> bytes:
    data = path.read_bytes()
    for hdr, payload in walk_container(data):
        if hdr[0] == 9:
            return dec(payload)
    raise SystemExit("no kind09 in " + str(path))


print("################ PA800 GOLE USER01 kind09 ################")
buf = kind09_of(PA800)
print("total", len(buf))
walk(buf)

print()
print("################ PA3X FAVORITE12 kind09 ################")
buf = kind09_of(PA3X)
print("total", len(buf))
walk(buf)
