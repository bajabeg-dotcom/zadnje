import sys, io, os, glob, time, collections
sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding='utf-8', errors='replace', line_buffering=True)
sys.path.insert(0, r'C:\Users\Baja\Desktop\Nova mapa')
from setconvert.detect import walk_resources, decode_payload
from setconvert.conv import _compress, _build_payload
from pa800_native import encode_oc32

ROOTS = [
    ('InitKorg', r'C:\Users\Baja\Desktop\Nova mapa\Style Works XT Universal\InitKorg'),
    ('KOCE(pa800)', r'C:\Users\Baja\Desktop\KOCE FOLK.SET'),
    ('GOLE(pa800)', r'C:\Users\Baja\Desktop\GOLE ARX .SET'),
    ('Pantic(pa1x)', r'C:\Users\Baja\Desktop\Pantic Pa1X.SET'),
    ('Serbian(pa3x)', r'C:\Users\Baja\Desktop\Korg Pa3x Team Serbian.SET'),
    ('Dejan(pa4x)', r'C:\Users\Baja\Desktop\Pa4x Pro Dejan Shiki.SET'),
]
tot = fail = 0
optimal_samples = []
for label, root in ROOTS:
    n = f = 0
    sizes = []
    for p in sorted(glob.glob(os.path.join(root, '**', '*.sty'), recursive=True)):
        try:
            _pre, res, _tr = walk_resources(open(p, 'rb').read())
        except Exception:
            continue
        for h, pay in res:
            if pay[:4] != b'OC32':
                continue
            n += 1
            try:
                t0 = time.time()
                plain = decode_payload(pay)
                via = _compress(plain, b'OC32')
                dt = time.time() - t0
                if via[:4] != b'OC32' or decode_payload(via) != plain:
                    f += 1; print(f'  CONV-FAIL {p} {h.hex(" ")}'); continue
                newp, comp = _build_payload(pay, plain, plain + b'\x00')
                if newp[:4] != b'OC32' or not comp:
                    f += 1; print(f'  BUILD-FAIL {p} {h.hex(" ")}'); continue
                sizes.append((len(pay), len(via), dt))
                if len(optimal_samples) < 4 and len(plain) < 4000:
                    optimal_samples.append((p, h, plain))
            except Exception as exc:
                f += 1
                print(f'  EXC {type(exc).__name__}: {exc}  {p} {h.hex(" ")}')
    if sizes:
        avg = sum(s[2] for s in sizes) / len(sizes)
        ratio = sum(s[1] for s in sizes) / sum(s[0] for s in sizes)
        print(f'{label:14s} OC32={n:4d} fails={f}  avg_enc={avg:.3f}s  size_ratio={ratio:.3f}')
    else:
        print(f'{label:14s} OC32={n:4d} fails={f}')
    tot += n; fail += f

print('\n-- optimal encoder samples --')
for p, h, plain in optimal_samples:
    t0 = time.time()
    enc = encode_oc32(plain)
    dt = time.time() - t0
    ok = enc[:4] == b'OC32' and decode_payload(enc) == plain
    print(f'  {os.path.basename(p)} {h.hex(" ")} len={len(plain)} {dt:.2f}s ok={ok}')
    if not ok:
        fail += 1
print(f'\nTOTAL OC32={tot} fails={fail} -> {"PASS" if fail == 0 else "FAIL"}')
