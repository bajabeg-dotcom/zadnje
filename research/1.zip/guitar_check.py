import sys
from pathlib import Path

ROOT = Path(r"C:\Users\Baja\Desktop\Nova mapa")
sys.path.insert(0, str(ROOT))

from setconvert.conv import convert_sty
from setconvert.genab import decode_resource, _find_trackinfo_blocks
from pa800_native.sty_container import parse_bank

ROLES = ("Drum", "Perc", "Bass", "Acc1", "Acc2", "Acc3", "Acc4", "Acc5")
FOLDER = ROOT / "Style Works XT Universal" / "InitKorg"


def kind06s(data):
    return [(i, decode_resource(r.payload))
            for i, r in enumerate(parse_bank(data).resources) if r.kind == 6]


def outside(payload, blocks):
    payload = bytearray(payload)
    if len(payload) > 10:
        payload[1] = payload[10] = 0
    payload = bytes(payload)
    out, cur = bytearray(), 0
    for pos, size in blocks:
        out += payload[cur:pos]
        cur = pos + 8 + size
    out += payload[cur:]
    return bytes(out)


def core_records(payload, pos, size):
    blk = payload[pos + 8: pos + 8 + size][:48]
    return [tuple(blk[i * 6:i * 6 + 6]) for i in range(8)]


tot_diff = tot_same = tot_blocks = 0
seg_ok = seg_bad = 0
files_ok = files_bad = 0
role_same = {r: 0 for r in ROLES}
role_diff = {r: 0 for r in ROLES}
from setconvert.genab import GenabStats
allgen = GenabStats()
open_items = []

for src_file in sorted(FOLDER.glob("*.[Ss][Tt][Yy]")):
    try:
        dst, rep = convert_sty(src_file.read_bytes(), "pa800", strict=True)
    except ValueError as exc:
        print(f"SKIP {src_file.name}: {exc}")
        continue
    files_ok += 1
    g = rep.genab
    for k in GenabStats.__dataclass_fields__:
        if k in ("notes", "open_regions"):
            continue
        setattr(allgen, k, getattr(allgen, k) + getattr(g, k))
    open_items += [f"{src_file.name}: {x}" for x in rep.open_items]
    sk, dk = kind06s(src_file.read_bytes()), kind06s(dst)
    if len(sk) != len(dk):
        files_bad += 1
        print(f"BAD  {src_file.name}: kind06 count {len(sk)} -> {len(dk)}")
        continue
    for (i, s), (j, d) in zip(sk, dk):
        sb, db = _find_trackinfo_blocks(s), _find_trackinfo_blocks(d)
        if len(sb) != len(db):
            files_bad += 1
            print(f"BAD  {src_file.name} res#{i}: TrackInfo {len(sb)} -> {len(db)}")
            continue
        tot_blocks += len(sb)
        for (sp, ssz, _), (dp, dsz, _) in zip(sb, db):
            sr, dr = core_records(s, sp, ssz), core_records(d, dp, dsz)
            for r in range(8):
                if sr[r] == dr[r]:
                    tot_same += 1
                    role_same[ROLES[r]] += 1
                else:
                    tot_diff += 1
                    role_diff[ROLES[r]] += 1
                    print(f"DIFF {src_file.name} res#{i} {ROLES[r]}: {sr[r]} -> {dr[r]}")
        if outside(s, [x[:2] for x in sb]) == outside(d, [x[:2] for x in db]):
            seg_ok += 1
        else:
            seg_bad += 1
            print(f"DIFF {src_file.name} res#{i}: non-TrackInfo bytes changed "
                  f"({len(s)} -> {len(d)})")

print()
print(f"files converted        : {files_ok}")
print(f"kind06 resources       : {seg_ok + seg_bad}  "
      f"(event/note data preserved: {seg_ok}, changed: {seg_bad})")
print(f"TrackInfo blocks       : {tot_blocks}")
print(f"TrackInfo records same : {tot_same}   diff: {tot_diff}")
for r in ROLES:
    print(f"   {r:<5} same={role_same[r]:<5} diff={role_diff[r]}")
print(f"selector stats         : same={allgen.selector_same} moved={allgen.selector_moved} "
      f"missing={allgen.selector_missing} inherited={allgen.selector_inherited}")
print(f"TrackInfo resized 48->80: {allgen.ti_resized_to_genb}   passthrough: {allgen.ti_passthrough}")
print(f"kind09 upgraded        : {allgen.kind09_upgraded}   passthrough: {allgen.kind09_passthrough}")
print(f"open items             : {len(open_items)}")
for x in open_items[:6]:
    print(f"   - {x}")

