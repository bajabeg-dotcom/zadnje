"""Run one optimizer call and print the output SHA256.

argv: <root> <tools_dir|-> <src> <dst>
"""

import hashlib
import sys
from pathlib import Path


def main() -> None:
    root = Path(sys.argv[1])
    tools = sys.argv[2]
    src = Path(sys.argv[3])
    dst = Path(sys.argv[4])

    for entry in (str(root), *([] if tools == "-" else [tools])):
        if entry not in sys.path:
            sys.path.insert(0, entry)

    if tools == "-":
        from pa800.optimizer import optimize
    else:
        from korg_optimizer import optimize  # type: ignore[import-not-found]

    optimize(src, dst)
    print("SHA256 " + hashlib.sha256(dst.read_bytes()).hexdigest())


if __name__ == "__main__":
    main()
