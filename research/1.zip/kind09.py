import sys
sys.path.insert(0, r'C:\Users\Baja\Desktop\Nova mapa')
from pathlib import Path
from setconvert.sty import StyBank
from pa800_native.oc31_codec import decode_oc31

path = sys.argv[1]
res_index = int(sys.argv[2])
data = Path(path).read_bytes()
bank = StyBank.read(data)
r = bank.resources[res_index]
payload = decode_oc31(r.payload) if r.compressed else r.payload
print('res %d kind=%d decomp=%d' % (res_index, r.kind, len(payload)))
print('head 32:', payload[:32].hex(' '))


def walk(buf, indent, base=0, maxdepth=3):
    c = 0
    n = 0
    while c + 8 <= len(buf):
        tag = buf[c:c + 4]
        sz = int.from_bytes(buf[c + 4:c + 8], 'big')
        if sz > len(buf) - c - 8:
            print('%sstop @%d tag=%s size=%d' % ('  ' * indent, base + c, tag.hex(' '), sz))
            break
        body = buf[c + 8:c + 8 + sz]
        print('%s@%d tag=%s size=%d head=%s' % ('  ' * indent, base + c, tag.hex(' '), sz, body[:24].hex(' ')))
        # recurse into children if body looks like child stream
        if indent < maxdepth and len(body) >= 16:
            t2 = body[:4]
            s2 = int.from_bytes(body[4:8], 'big')
            if s2 <= len(body) - 8 and any(t2[i] in (0, 1, 2, 3) for i in (0, 1)):
                # likely nested child at 0
                if not (body[0] in (0, 1, 2, 3) and s2 == len(body) - 8):
                    pass
        c += 8 + sz
        n += 1
        if n > 80:
            print('%s...' % ('  ' * indent))
            break
    if c < len(buf):
        print('%sremaining %d bytes: %s' % ('  ' * indent, len(buf) - c, buf[c:c + 24].hex(' ')))


walk(payload, 0)
# nested: first child body
first_sz = int.from_bytes(payload[4:8], 'big')
inner = payload[8:8 + first_sz]
print('--- inner of first child (len %d) ---' % len(inner))
walk(inner, 1)
