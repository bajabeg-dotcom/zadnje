import sys, io, os, glob, collections
sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding='utf-8', errors='replace')
sys.path.insert(0, r'C:\Users\Baja\Desktop\Nova mapa')
from setconvert.detect import walk_resources, decode_payload

ROOTS = [
    ('KOCE(pa800)', r'C:\Users\Baja\Desktop\KOCE FOLK.SET'),
    ('GOLE(pa800)', r'C:\Users\Baja\Desktop\GOLE ARX .SET'),
    ('Pantic(pa1x)', r'C:\Users\Baja\Desktop\Pantic Pa1X.SET'),
    ('Serbian(pa3x)', r'C:\Users\Baja\Desktop\Korg Pa3x Team Serbian.SET'),
    ('Dejan(pa4x)', r'C:\Users\Baja\Desktop\Pa4x Pro Dejan Shiki.SET'),
    ('InitKorg', r'C:\Users\Baja\Desktop\Nova mapa\Style Works XT Universal\InitKorg'),
]
for label, root in ROOTS:
    mag = collections.Counter()
    for p in sorted(glob.glob(os.path.join(root, '**', '*.sty'), recursive=True)):
        try:
            _pre, res, _tr = walk_resources(open(p, 'rb').read())
        except Exception:
            continue
        for h, pay in res:
            if pay[:4] in (b'OC31', b'OC32'):
                mag[(h[0], pay[:4].decode())] += 1
    print(f'{label:15s} {dict(mag)}')
