﻿import os, sys, glob
sys.stdout.reconfigure(encoding="utf-8", errors="replace")
p = r"C:\Users\Baja\Desktop\BAJA MUSIC\Baja_Music_PA_Manager_V1_WORKING\pa800_studio\cross_model_adapter.py"
print("size", os.path.getsize(p))
with open(p, encoding="utf-8", errors="replace") as f:
    lines = f.readlines()
print("lines", len(lines))
for i, l in enumerate(lines[:80]):
    print("%4d| %s" % (i+1, l.rstrip("\n")))
print("...")
# function/class definitions
import re
for i, l in enumerate(lines):
    if re.match(r"(def |class |[A-Z_]+ =)", l):
        print("%4d| %s" % (i+1, l.rstrip("\n")[:120]))
