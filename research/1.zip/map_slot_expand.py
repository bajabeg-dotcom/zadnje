#!/usr/bin/env python3
"""Map +96 byte expansion inside PA800 mixer slots vs PA1X."""
from __future__ import annotations

from pathlib import Path
import struct
import sys

sys.path.insert(0, r"C:\Users\Baja\Desktop\BAJA MUSIC\Baja_Music_PA_Manager_V1_WORKING\pa800_native")
from oc31_codec import decode_oc31  # noqa: E402


def first_t9(path: Path) -> bytes:
    data = path.read_bytes()
    kend = data.find(b"KEND")
    count = struct.unpack(">I", data[kend + 4 : kend + 8])[0]
    kbeg = kend - 4 - 4 * count
    start = kbeg + 4
    for i in range(count):
        o = struct.unpack(">I", data[start + 4 * i : start + 4 * i + 4])[0]
        hdr = data[o : o + 4]
        if hdr[0] != 9:
            continue
        sz = struct.unpack(">I", data[o + 4 : o + 8])[0]
        payload = data[o + 8 : o + 8 + sz]
        if payload.startswith(b"OC31"):
            return decode_oc31(payload)
    raise SystemExit("no type09")


def mixer_body(dec: bytes) -> tuple[bytes, int]:
    marker = dec[:4]
    size = struct.unpack(">I", dec[4:8])[0]
    return dec[8 : 8 + size], size


def slot_bounds(mixer: bytes) -> tuple[int, int, int]:
    hdr = struct.unpack(">I", mixer[8:12])[0]
    cnt = mixer[12]
    # derive slot size from total
    slot = (len(mixer) - 4 - hdr) // cnt if cnt else 0
    return hdr, cnt, slot


def analyze(label: str, path: Path) -> None:
    dec = first_t9(path)
    mixer, size = mixer_body(dec)
    hdr, cnt, slot = slot_bounds(mixer)
    print(f"\n==== {label} ====")
    print(f"mixer_len={len(mixer)} hdr_off={hdr} count={cnt} slot_size={slot}")
    print(f"header[0:32]={mixer[:32].hex(' ')}")
    print(f"header[32:96]={mixer[32:96].hex(' ')}")
    if hdr > 408:
        print(f"header[408:504]={mixer[408:504].hex(' ')}")
    # dump first slot fully for PA1X-sized view and PA800
    s0 = mixer[hdr : hdr + slot]
    print(f"slot0 id={s0[0]} head32={s0[:32].hex(' ')}")
    # try proven sound/detail offsets
    for name, base, length in (
        ("sound0@17", 17, 10),
        ("sound1@27", 27, 10),
        ("sound2@37", 37, 10),
        ("sound3@47", 47, 10),
        ("detail0@113", 113, 37),
        ("detail3@224", 224, 37),
    ):
        b = int(name.split("@")[1])
        rec = s0[b : b + length]
        print(f"  {name}={rec.hex(' ')}")
    # region 261..end
    if slot > 261:
        print(f"  tail[261:{slot}]={s0[261:].hex(' ')}")
    # validate sound record heuristic: volume/pan etc u7
    def u7_ok(rec: bytes) -> bool:
        return len(rec) == 10 and all(x <= 127 for x in rec[3:7])

    for hdr_off, slot_sz in ((408, 261), (504, 357), (408, 357), (504, 261), (408, 0), (504, 0)):
        if slot_sz == 0:
            continue
        if hdr_off + cnt * slot_sz + 4 != len(mixer):
            continue
        ok_sound = 0
        ok_detail = 0
        for i in range(cnt):
            s = mixer[hdr_off + i * slot_sz : hdr_off + (i + 1) * slot_sz]
            for t in range(4):
                sr = s[17 + t * 10 : 27 + t * 10]
                if len(sr) == 10 and all(x <= 127 for x in sr[3:7]):
                    ok_sound += 1
                dr = s[113 + t * 37 : 150 + t * 37]
                if len(dr) == 37:
                    ok_detail += 1
        print(f"  geom {hdr_off}/{slot_sz}: sound_u7={ok_sound}/{cnt*4} detail_full={ok_detail}/{cnt*4}")


samples = {
    "PA1X_LIVE": Path(r"C:\Users\Baja\Desktop\Pantic Pa1X.SET\STYLE\BANK01_LIVE.STY"),
    "PA1X_USER02": Path(r"C:\Users\Baja\Desktop\Pantic Pa1X.SET\STYLE\USER02.STY"),
    "PA800_BANK16": Path(r"C:\Users\Baja\Desktop\BAJA MUSIC\extracted_files_oc20_lzss\STARTUP\ALL\STYLE\BANK16.STY"),
    "PA800_USER01": Path(r"C:\Users\Baja\Desktop\BAJA MUSIC\extracted_files_oc20_lzss\STARTUP\ALL\STYLE\USER01.sty"),
}
for label, path in samples.items():
    if path.exists():
        analyze(label, path)
    else:
        print("MISSING", path)
