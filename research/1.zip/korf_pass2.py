# -*- coding: utf-8 -*-
"""KORG Pa: dekodiraj OC32 style-block header + AA A0 parametre + note sekvence."""
import struct, os, sys, re, json
from collections import Counter, defaultdict
sys.stdout.reconfigure(encoding='utf-8', errors='replace')

ROOT = r'C:\Users\Baja\Desktop\Nova mapa\Style Works XT Universal\InitKorg'

def u16le(b, o): return struct.unpack_from('<H', b, o)[0]
def u16be(b, o): return struct.unpack_from('>H', b, o)[0]
def u32le(b, o): return struct.unpack_from('<I', b, o)[0]
def s16le(b, o): return struct.unpack_from('<h', b, o)[0]

def cstr(b, o, n):
    s = b[o:o+n]
    z = s.find(b'\x00')
    if z >= 0: s = s[:z]
    return s.decode('latin-1', 'replace').rstrip()

def hexdump(b, o, n, label=''):
    if label:
        print('  ' + label)
    for i in range(0, n, 16):
        chunk = b[o+i:o+i+16]
        hx = ' '.join('{:02x}'.format(x) for x in chunk)
        pr = ''.join(chr(x) if 32 <= x < 127 else '.' for x in chunk)
        print('  {:06x}  {:<48}  {}'.format(o+i, hx, pr))

def parse_names(b, start=0x24):
    names, p = [], start
    while p + 24 <= len(b):
        nm = cstr(b, p, 16)
        if not re.match(r'^[\x20-\x7e]{2,}', nm or ''):
            if nm == '' and b[p:p+16] == b'\x00'*16:
                nm2 = cstr(b, p+24, 16)
                if not (nm2 and re.match(r'^[\x20-\x7e]{2,}', nm2)):
                    break
            else:
                break
        names.append({
            'name': nm, 'bank': b[p+18], 'code': b[p+19],
            'idx': u32le(b, p+20), 'off': p,
        })
        p += 24
    return names, p

def find_all(b, sig):
    hits, pos = [], 0
    while True:
        i = b.find(sig, pos)
        if i < 0: break
        hits.append(i)
        pos = i + 1
    return hits

# ============================================================
# Detailed analysis of ONE style block
# ============================================================
def analyze_blocks(fn, max_blocks=4):
    path = os.path.join(ROOT, fn)
    b = open(path, 'rb').read()
    print('=' * 78)
    print(fn, 'size', len(b))
    print('=' * 78)

    names, end_names = parse_names(b)
    print('name table ends @ {:#x}, {} names'.format(end_names, len(names)))
    # unique style names from index (bank 02 only = primary)
    primary = [n for n in names if n['bank'] == 2]
    print('primary bank styles:', len(primary))
    for i, n in enumerate(primary[:10]):
        print('  [{}] {!r} idx={}'.format(i, n['name'], n['idx']))

    ocs = find_all(b, b'OC3')
    print('OC3x count:', len(ocs), [hex(x) for x in ocs[:16]])

    # ============================================================
    # Hypothesis: each style block starts just BEFORE OC32
    # From earlier dump: pre = ... 06 00 00 30 00 00 XX XX | OC32
    # So: 8 bytes before OC32 is a mini-header?
    # Actually: ...06 00 00 30 00 00 1a 60 OC32
    # Let's dump 64 bytes BEFORE each OC32 and 128 AFTER
    # ============================================================
    for bi, oco in enumerate(ocs[:max_blocks]):
        print('\n--- BLOCK {}  OC32@{:#x} ---'.format(bi, oco))
        # pre-context
        pre_start = max(0, oco - 64)
        hexdump(b, pre_start, 64, 'PRE (64B before OC32)')
        hexdump(b, oco, 96, 'AT OC32 +96B')

        # Try interpret structure after OC32:
        # OC32 | u16 size? | u16 ? | u32 ? | 06 01 00 00 00 00 00 00 | u32 | 40 1d 08 40 20 ...
        # From Initpa01 first block:
        # post=4f433332f44700000601000000000047ec401d0840200b0b05466f78...
        # OC32 | 47 f4 00 00 | 06 01 00 00 00 00 00 00 | 47 ec 40 1d 08 40 20 0b 0b 05 | name?
        # Wait name 'Fox2' appeared... maybe compressed/truncated name
        # Alternative layout after OC32:
        # bytes[4:6] u16le = 0xf447 = 62535? or size of block in some unit
        # Actually looking at post: f447 0000 = u16le 0x47f4=18420, u16le 0
        # 0601 0000 = ?
        # Let's read systematically:

        if oco + 40 > len(b): continue
        w = [u16le(b, oco + 4 + i*2) for i in range(16)]
        d = [u32le(b, oco + 4 + i*4) for i in range(8)]
        print('  u16 after OC32:', w)
        print('  u32 after OC32:', d)

        # Try: size field = u16le at +4 (0x47f4 for first)
        blk_size = u16le(b, oco + 4)
        print('  guess blk_size u16@+4 = {}'.format(blk_size))
        # next style OC32 - first distance
        if bi + 1 < len(ocs):
            dist = ocs[bi+1] - oco
            print('  dist to next OC32 = {}'.format(dist))
            # does blk_size relate? blk_size might be payload after header
            print('  dist - 8 = {}, dist - 16 = {}'.format(dist - 8, dist - 16))

        # Find style name embedded: look for 15-char null-padded name + aa a0
        # Search forward from OC32 for pattern: <printable name> aa a0
        # Earlier: name ends then aa a0 f8 03 ff 02 80 ...
        search_end = min(len(b) - 4, oco + 4096)
        name_end = None
        for j in range(oco + 4, search_end):
            if b[j:j+2] == b'\xaa\xa0':
                # name is null-padded ending just before, or before some non-null prefix
                # walk back over nulls
                k = j - 1
                while k > oco and b[k] == 0:
                    k -= 1
                # now k = last non-null of name (or other)
                # walk back further while printable
                start = k
                while start > oco and (32 <= b[start] < 127):
                    start -= 1
                start += 1
                nm_bytes = b[start:k+1]
                if len(nm_bytes) >= 3:
                    try:
                        nm = nm_bytes.decode('latin-1').rstrip('\x00').strip()
                    except:
                        nm = repr(nm_bytes)
                    if re.match(r'^[\x20-\x7e]{3,}', nm):
                        name_end = (start, nm, j)
                        break
        if name_end:
            start, nm, j = name_end
            print('  embedded name {!r} @ {:#x}, AA A0 @ {:#x}'.format(nm, start, j))
            hexdump(b, j, 128, 'AA A0 params start')
            # decode params after AA A0
            # pattern seen: f8 03 ff 02 80 XX XX XX XX XX 00/01 ...
            # or: aa a0 | u16 | u8 | u8 | u8 | ...
            params = b[j+2:j+2+64]
            print('  params hex:', params[:48].hex())
            u16s = [u16le(b, j+2+i*2) for i in range(16)]
            print('  params u16le:', u16s)
            # common: f803 = 1016, ff02 = 767, 80 = 128
            # try as: u8 flags, u16 tempo*?, meter numerator/denominator
            print('  as bytes:', list(b[j+2:j+30]))

        # ============================================================
        # NOTE DATA: after AA A0 blob, look for note-like events
        # Korg style event codes (hypothesis from known Korg docs / PA style format):
        # - Common: variable-length delta + status-like
        # - Look for runs of small values that look like (delta, note, vel)
        # ============================================================
        # Also search for track markers or section markers (Main/Fill)
        for sig in [b'MAIN', b'Fill', b'INTRO', b'ENDING', b'CHORD', b'VELOCITY',
                    b'TRACK', b'DRUM', b'\x00\x01\x02\x03', b'PA 5', b'Pa50']:
            if sig in b[oco:oco+2048]:
                print('  FOUND sig {!r} near block'.format(sig))

    # ============================================================
    # Cross-block: find common structure
    # Dump bytes immediately before each OC32 (the inter-block header)
    # ============================================================
    print('\n=== PRE-OC32 16 bytes (all blocks) ===')
    for oco in ocs[:16]:
        pre = b[oco-16:oco]
        print('  {:#06x}: {}  ascii={}'.format(
            oco, pre.hex(), ''.join(chr(x) if 32<=x<127 else '.' for x in pre)))

    # ============================================================
    # After name table ends, first style header?
    # ============================================================
    print('\n=== after name table (end_names) ===')
    hexdump(b, end_names, 80, 'end_names region')

    return b, names, end_names, ocs

# Run on Initpa01 (32 styles) and InitPx03 (2 styles x 2 banks - simpler)
b1, n1, e1, o1 = analyze_blocks('Initpa01.STY', max_blocks=3)
print('\n\n')
b2, n2, e2, o2 = analyze_blocks('InitPx03.STY', max_blocks=4)
