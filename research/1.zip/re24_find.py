﻿import os, sys, glob
sys.stdout.reconfigure(encoding="utf-8", errors="replace")
def scan(root, depth=2):
    hits = []
    for dirpath, dirnames, filenames in os.walk(root):
        rel = os.path.relpath(dirpath, root)
        d = rel.count(os.sep)
        if d > depth:
            dirnames[:] = []
            continue
        low = dirnames + [f for f in filenames]
        for n in list(dirnames):
            if n.upper().endswith(".SET") or "PA3" in n.upper() or "PA4" in n.upper() or "PA1" in n.upper() or "PA8" in n.upper():
                hits.append(os.path.join(dirpath, n) + os.sep)
        for n in filenames:
            if n.upper().endswith((".SET", ".STY", ".PCG", ".GBL")) and ("PA3" in n.upper() or "PA4" in n.upper()):
                hits.append(os.path.join(dirpath, n))
    return hits
print("== Desktop ==")
for h in scan(r"C:\Users\Baja\Desktop", 2): print("  ", h)
print("== E: ==")
if os.path.isdir("E:\\"):
    for h in scan("E:\\", 3)[:80]: print("  ", h)
else:
    print("  no E drive")
