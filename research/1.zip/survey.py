import sys
sys.path.insert(0, r'C:\Users\Baja\Desktop\Nova mapa')
from pathlib import Path
from collections import Counter
from setconvert.sty import StyBank

path = sys.argv[1]
data = Path(path).read_bytes()
print('size', len(data))
bank = StyBank.read(data)
print('mode', bank.kbeg_mode, 'prefix', bank.prefix[:8].hex(' '), 'nres', len(bank.resources))
print('kinds', Counter(r.kind for r in bank.resources))
for i, r in enumerate(bank.resources):
    comp = 'C' if r.compressed else '-'
    print('%3d kind=%3d %s hdr=%s payloadlen=%d %s' % (
        i, r.kind, comp, r.header.hex(' '), len(r.payload), r.payload[:8].hex(' ')))
