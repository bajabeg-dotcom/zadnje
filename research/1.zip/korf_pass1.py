# -*- coding: utf-8 -*-
"""KORG Pa (KORF) .STY deep reverse engineering."""
import struct, os, sys, re, json
from collections import Counter, defaultdict
sys.stdout.reconfigure(encoding='utf-8', errors='replace')

ROOT = r'C:\Users\Baja\Desktop\Nova mapa\Style Works XT Universal\InitKorg'
FILES = ['Initpa01.STY', 'INITPA02.STY', 'INITPA03.STY',
         'InitPx01.STY', 'InitPx02.STY', 'InitPx03.STY', 'initPx04.STY']

def u8(b, o): return b[o]
def u16le(b, o): return struct.unpack_from('<H', b, o)[0]
def u16be(b, o): return struct.unpack_from('>H', b, o)[0]
def u32le(b, o): return struct.unpack_from('<I', b, o)[0]
def u32be(b, o): return struct.unpack_from('>I', b, o)[0]
def s16le(b, o): return struct.unpack_from('<h', b, o)[0]

def cstr(b, o, n):
    s = b[o:o+n]
    z = s.find(b'\x00')
    if z >= 0: s = s[:z]
    return s.decode('latin-1', 'replace').rstrip()

def parse_header(b):
    h = {}
    h['magic_ver'] = b[0:4].hex()          # 01 00 01 14
    h['u16_4_be'] = u16be(b, 4)
    h['u16_4_le'] = u16le(b, 4)
    h['u16_6_be'] = u16be(b, 6)            # likely CRC/checksum
    h['u16_6_le'] = u16le(b, 6)
    h['u16_8'] = u16le(b, 8)               # 0x0002
    h['u16_10'] = u16le(b, 10)             # 0x18 = 24 stride
    h['u32_12'] = u32be(b, 12)             # 0x0000000c
    h['u16_16'] = u16le(b, 16)             # 0x000b
    h['zero_pad'] = b[18:23].hex()
    h['korF'] = b[23:27]
    h['post'] = b[27:40].hex()
    # after KORF: 00 05 00 00 18 00 00 NN ...
    h['ver_after'] = b[27:29].hex() if len(b) > 29 else ''
    h['u16_at_31'] = u16le(b, 31) if len(b) > 33 else None  # stride again?
    # number of styles often at offset 33 or in name table termination
    return h

def parse_name_table(b, start=0x24):
    names = []
    p = start
    while p + 24 <= len(b):
        nm = cstr(b, p, 16)
        if not re.match(r'^[\x20-\x7e]{1,}', nm or ''):
            # allow empty only if next would also break soon
            if nm == '' and b[p:p+16] == b'\x00'*16:
                # peek next
                nm2 = cstr(b, p+24, 16)
                if not (nm2 and re.match(r'^[\x20-\x7e]{2,}', nm2)):
                    break
            else:
                break
        bank = b[p+18]
        code = b[p+19]
        idx = u32le(b, p+20)
        names.append({'name': nm, 'bank': bank, 'code': code, 'idx': idx, 'off': p})
        p += 24
    return names, p

def find_oc32(b, start=0):
    hits = []
    pos = start
    while True:
        i = b.find(b'OC3', pos)
        if i < 0: break
        if i + 4 <= len(b):
            tag = b[i:i+4]
            hits.append((i, tag.decode('latin-1', 'replace')))
        pos = i + 1
    return hits

def hexdump(b, o, n, label=''):
    if label:
        print('  ' + label + f' @{o:#x}')
    for i in range(0, n, 16):
        chunk = b[o+i:o+i+16]
        hx = ' '.join('{:02x}'.format(x) for x in chunk)
        pr = ''.join(chr(x) if 32 <= x < 127 else '.' for x in chunk)
        print('  {:06x}  {:<48}  {}'.format(o+i, hx, pr))

# ============================================================
# PASS 1: full header + name table + OC32 map for all files
# ============================================================
print('=' * 78)
print('PASS 1 — headers, name tables, OC32 maps')
print('=' * 78)

all_meta = {}
for fn in FILES:
    path = os.path.join(ROOT, fn)
    if not os.path.isfile(path):
        print(fn, 'MISSING'); continue
    b = open(path, 'rb').read()
    print('\n### {}  size={}'.format(fn, len(b)))
    h = parse_header(b)
    for k, v in h.items():
        print('  {:16s} {}'.format(k, v))
    hexdump(b, 0, 64, 'HEADER')

    # try find count: after KORF often XX 00 00 <count>
    # from earlier: post-KORF = 00 05 00 00 18 00 00 NN 00 <first name>
    # offset of first name byte
    # search for first printable after 0x24
    # Actually name table starts where we can read names.
    # Find count byte: pattern after stride 0x18:
    # 00 05 00 00 18 | 00 00 | <count?> | 00 | name...
    # Let's locate: b.find(b'\x00\x05\x00\x00\x18', 27)
    p = b.find(b'\x00\x05\x00\x00\x18', 20)
    if p >= 0:
        # bytes: 00 05 00 00 18 | ? ?
        after = p + 5
        print('  after_0005 @ {:#x}: {}'.format(after, b[after:after+8].hex()))
        # often 00 00 | count | 00 | name
        # or 00 | count | name
        # try u16le at after, u16le at after+2
        print('    u16le@+0={} u16le@+1={} u16le@+2={} u16@+3={}'.format(
            u16le(b, after), u16le(b, after+1) if after+3<=len(b) else None,
            u16le(b, after+2) if after+4<=len(b) else None,
            u16le(b, after+3) if after+5<=len(b) else None))
        # byte that equals n_names?
        # name table length determines count better

    names, end_names = parse_name_table(b)
    print('  name table: {} entries, ends @ {:#x}'.format(len(names), end_names))
    # group by bank/code
    groups = defaultdict(list)
    for n in names:
        groups[(n['bank'], n['code'])].append(n)
    for k, v in sorted(groups.items()):
        print('    bank={:02x} code={:02x}: n={} idx_range={}..{}  names={}'.format(
            k[0], k[1], len(v), v[0]['idx'], v[-1]['idx'],
            [x['name'] for x in v[:5]]))

    # OC32 map
    ocs = find_oc32(b, 0)
    print('  OC3x markers: {}  positions: {}'.format(len(ocs), [hex(o) for o, _ in ocs[:40]]))
    # compute spans between consecutive OC32 as style block sizes
    if ocs:
        pos_list = [o for o, _ in ocs]
        # first style may start before first OC32 (right after name table)
        starts = [end_names] + [p for p in pos_list]
        # actually OC32 is INSIDE or at start of block — from earlier, pre-end_names first block
        # better: blocks start at OC32 (or just before)
        spans = []
        for i, (o, tag) in enumerate(ocs):
            end = ocs[i+1][0] if i+1 < len(ocs) else len(b)
            spans.append((o, end, end - o))
        sizes = [s for _, _, s in spans]
        print('  block sizes: min={} max={} avg={:.0f} total_span={}'.format(
            min(sizes), max(sizes), sum(sizes)/len(sizes),
            spans[-1][1] - spans[0][0] if spans else 0))
        print('  first 8 sizes:', sizes[:8])

    # Find AA A0 markers (style param blob after name)
    aa = []
    pos = 0
    while True:
        i = b.find(b'\xaa\xa0', pos)
        if i < 0: break
        aa.append(i)
        pos = i + 1
    print('  AA A0 markers: {}  first: {}'.format(len(aa), [hex(x) for x in aa[:8]]))

    all_meta[fn] = {
        'size': len(b),
        'header': {k: (v.hex() if isinstance(v, bytes) else v) for k, v in h.items()},
        'n_names': len(names),
        'end_names': end_names,
        'groups': {str(k): len(v) for k, v in groups.items()},
        'names': [{'n': n['name'], 'b': n['bank'], 'c': n['code'], 'i': n['idx']} for n in names],
        'n_oc32': len(ocs),
        'oc32_positions': [o for o, _ in ocs],
        'block_sizes': sizes if ocs else [],
        'n_aa_a0': len(aa),
    }

# Save meta
with open(r'C:\Users\Baja\AppData\Local\Temp\opencode\korF_meta.json', 'w', encoding='utf-8') as f:
    json.dump(all_meta, f, ensure_ascii=False, indent=1)
print('\nwrote korF_meta.json')
