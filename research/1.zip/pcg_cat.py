import sys, io, os, glob, collections
sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding='utf-8', errors='replace', line_buffering=True)
sys.path.insert(0, r'C:\Users\Baja\Desktop\Nova mapa')
from pa800_native.sty_container import parse_bank

def dump_fixed(pay, label, n=2):
    print(f'  FIXED24 {label}: len={len(pay)} len%24={len(pay)%24} records={len(pay)//24}')
    for i in range(min(n, len(pay)//24)):
        r = pay[i*24:(i+1)*24]
        name = r[:16].split(b'\x00')[0].decode('latin1')
        print(f'    [{i}] name={name!r} raw16={r[:16].hex(" ")}')
        print(f'        meta={r[16:24].hex(" ")} -> [0:3]={r[16:19].hex(" ")} bank={r[19]} prog={r[20]} rest={r[21:24].hex(" ")}')

def dump_var(pay, label, n=3):
    print(f'  VAR {label}: len={len(pay)}')
    pos = 0; recs = []
    while pos < len(pay):
        if pos + 2 > len(pay):
            print(f'    TRUNC at {pos}'); break
        rl = int.from_bytes(pay[pos:pos+2], 'big') + 2
        recs.append((pos, rl))
        if pos + rl > len(pay):
            print(f'    OVERFLOW at {pos} rl={rl}'); break
        pos += rl
    print(f'    walked={len(recs)} endpos={pos} exact={pos==len(pay)} lens={collections.Counter(r[1] for r in recs).most_common(6)}')
    for i, (off, rl) in enumerate(recs[:n]):
        r = pay[off:off+rl]
        print(f'    [{i}] off={off} len={rl} head={r[:8].hex(" ")} name8..36={r[8:36]!r}')
        print(f'        tail={r[-12:].hex(" ")}  @36..48={r[36:48].hex(" ")}')

FILES = []
for root in [r'C:\Users\Baja\Desktop\KOCE FOLK.SET', r'C:\Users\Baja\Desktop\GOLE ARX .SET',
             r'C:\Users\Baja\Desktop\Pantic Pa1X.SET', r'C:\Users\Baja\Desktop\Korg Pa3x Team Serbian.SET',
             r'C:\Users\Baja\Desktop\Pa4x Pro Dejan Shiki.SET']:
    FILES += sorted(glob.glob(os.path.join(root, '**', '*.pcg'), recursive=True))

rt_ok = rt_bad = 0
invariants = collections.Counter()
banks = collections.defaultdict(set)
for p in FILES:
    data = open(p, 'rb').read()
    try:
        bank = parse_bank(data)
        if bank.build() == data: rt_ok += 1
        else: rt_bad += 1; print(f'  RT-DIFF {p}')
    except ValueError as e:
        print(f'  PARSE-FAIL {os.path.basename(p)}: {e}'); continue
    k5 = [r for r in bank.resources if r.kind == 5]
    if not k5: continue
    r = k5[0]
    if r.header[1] == 0:
        ok = len(r.payload) % 24 == 0
        invariants['fixed_len_ok'] += ok
        invariants['fixed_len_bad'] += not ok
        ent = []
        for i in range(len(r.payload)//24):
            rec = r.payload[i*24:(i+1)*24]
            ent.append((rec[:16].split(b'\x00')[0].decode('latin1'), rec[19], rec[20]))
            invariants['meta04_ok'] += rec[16:19] == bytes((0, 0, 4))
        banks[os.path.basename(p).upper()] = {e[1] for e in ent}
        print(f'{os.path.basename(p):16s} hdr={r.header.hex(" ")} n={len(ent)} banks={sorted({e[1] for e in ent})} '
              f'prog={min(e[2] for e in ent)}..{max(e[2] for e in ent)} dup_prog={len(ent)-len({e[2] for e in ent})}')
        if 'USER01' in os.path.basename(p).upper() and len(FILES):
            pass
    else:
        ent = []
        pos = 0; exact = True
        while pos < len(r.payload):
            rl = int.from_bytes(r.payload[pos:pos+2], 'big') + 2
            if pos + rl > len(r.payload): exact = False; break
            rec = r.payload[pos:pos+rl]
            ent.append(rec); pos += rl
        banks[os.path.basename(p).upper()] = set()
        print(f'{os.path.basename(p):16s} hdr={r.header.hex(" ")} n={len(ent)} exact={exact and pos==len(r.payload)} '
              f'lens={sorted({len(e) for e in ent})[:8]}...')
        print(f'   rec0 hex: {ent[0].hex(" ")}')
        print(f'   rec0 name={ent[0][8:36].split(chr(0).encode())[0]!r}  tail={ent[0][-16:].hex(" ")}')

print('\nRT-OK', rt_ok, 'RT-DIFF', rt_bad, 'invariants', dict(invariants))
print('bank sets:', dict(banks))
