﻿import sys, struct
sys.stdout.reconfigure(encoding="utf-8", errors="replace")
def cmp(path, label):
    d = open(path, "rb").read()
    kend = int.from_bytes(d[4:8], "big")
    count = int.from_bytes(d[kend+4:kend+8], "big")
    kbeg = kend - 4 - 4*count
    offs = [int.from_bytes(d[kbeg+4+4*i:kbeg+8+4*i], "big") for i in range(count)]
    # linear chain
    lin = []
    pos = 8
    while pos + 8 <= kend:
        sz = struct.unpack(">I", d[pos+4:pos+8])[0]
        lin.append(pos)
        pos += 8 + sz
    print(label, "count", count, "kbeg", hex(kbeg))
    print("  kbeg offs:", [hex(o) for o in offs[:6]], "...")
    print("  linear  :", [hex(o) for o in lin[:6]], "...")
    print("  match:", offs == lin)
    if offs != lin:
        for i,(a,b) in enumerate(zip(offs, lin)):
            if a != b:
                print("  first diff idx", i, "kbeg", hex(a), "lin", hex(b), "hdr@kbeg", d[a:a+4].hex(" "), "hdr@lin", d[b:b+4].hex(" "))
                break
cmp(r"C:\Users\Baja\Desktop\USER01_PA800.STY", "USER01_PA800")
cmp(r"C:\Users\Baja\Desktop\Pantic Pa1X.SET\STYLE\BANK01_LIVE.STY", "Pantic-LIVE")
