# -*- coding: utf-8 -*-
"""Deep parse Korg KORF (.Pa STY) + KORG9 STY structures."""
import struct, os, sys, re, json
sys.stdout.reconfigure(encoding='utf-8', errors='replace')

ROOT = r'C:\Users\Baja\Desktop\Nova mapa\Style Works XT Universal\InitKorg'

def u16(b, o): return struct.unpack_from('<H', b, o)[0]
def u32(b, o): return struct.unpack_from('<I', b, o)[0]
def cstr(b, o, n):
    s = b[o:o+n]
    z = s.find(b'\x00')
    if z >= 0: s = s[:z]
    return s.decode('latin-1', 'replace').rstrip()

print('='*70)
print('KORF Pa-series STY')
print('='*70)
for fn in sorted(os.listdir(ROOT)):
    if not fn.upper().endswith('.STY'): continue
    path = os.path.join(ROOT, fn)
    b = open(path, 'rb').read()
    if b[22:26] == b'KORF' or b[:4] in (b'\x01\x00\x01\x14',):
        # check KORF at 0x17
        korf_at = b.find(b'KORF')
        print(f'\n### {fn} size={len(b)} KORF@{korf_at}')
        print(f'  head: {b[:32].hex()}')
        # Parse header fields
        v1, v2 = u16(b,0), u16(b,2)
        n_styles = u16(b,4)
        cs = u16(b,6)
        f8, f10 = u16(b,8), u16(b,10)
        print(f'  u16[0]={v1} u16[1]={v2} u16[2]={n_styles}(count?) u16[3]={cs:#x}')
        print(f'  u16[4]={f8} u16[5]={f10}  u32[6]={u32(b,12):#x}')
        # Find name tables: look for stride-24 printable blocks
        # Strategy: find sequences of null-padded ASCII names
        # First table starts after KORF (offset 0x1B)
        start = korf_at + 4 if korf_at >= 0 else 0x1B
        # dump from start
        print(f'  from {start:#x}: {b[start:start+64].hex()}')
        # Try: name records of 24 bytes
        # Scan for first readable name
        for off in range(start, min(start+64, len(b)-24)):
            name = cstr(b, off, 16)
            if len(name) >= 3 and re.match(r'^[\x20-\x7e]{3,}', name):
                # check next name at +24
                name2 = cstr(b, off+24, 16)
                if name2 and re.match(r'^[\x20-\x7e]{3,}', name2):
                    print(f'  name table candidate @ {off:#x}')
                    # parse up to 64 entries of stride 24
                    entries = []
                    p = off
                    while p + 24 <= len(b) and len(entries) < 80:
                        nm = cstr(b, p, 16)
                        if not nm or not re.match(r'^[\x20-\x7e]', nm):
                            # might be end (zeros) or second table gap
                            # allow zero names to continue a bit?
                            if nm == '' and all(x==0 for x in b[p:p+16]):
                                # peek next
                                nm3 = cstr(b, p+24, 16)
                                if not nm3 or not re.match(r'^[\x20-\x7e]{2,}', nm3):
                                    break
                                entries.append({'name': '', 'raw': b[p:p+24].hex()})
                                p += 24
                                continue
                            break
                        meta = b[p+16:p+24]
                        entries.append({
                            'name': nm,
                            'b16_17': meta[0], 'b18_19': meta[1],
                            'u16_at18': struct.unpack_from('<H', meta, 2)[0] if len(meta)>=4 else None,
                            'u32_at20': struct.unpack_from('<I', meta, 4)[0] if len(meta)>=8 else None,
                            'meta': meta.hex(),
                        })
                        p += 24
                    print(f'  -> {len(entries)} entries, first 8:')
                    for i, e in enumerate(entries[:8]):
                        print(f'    [{i}] {e}')
                    if len(entries) > 8:
                        print(f'    ... {len(entries)} total; codes: {set((e.get("b16_17"), e.get("b18_19")) for e in entries if "b16_17" in e)}')
                    # find second table after gap
                    # search forward for next name run
                    q = p
                    while q + 24 <= len(b) and q < off + 0x2000:
                        nm = cstr(b, q, 16)
                        if re.match(r'^[\x20-\x7e]{3,}', nm or ''):
                            nm2 = cstr(b, q+24, 16)
                            if nm2 and re.match(r'^[\x20-\x7e]{3,}', nm2):
                                print(f'  2nd name table candidate @ {q:#x} (gap {q-p} bytes)')
                                # parse briefly
                                e2 = []
                                r = q
                                while r + 24 <= len(b) and len(e2) < 80:
                                    n2 = cstr(b, r, 16)
                                    if not n2 or not re.match(r'^[\x20-\x7e]', n2):
                                        if n2 == '':
                                            nm4 = cstr(b, r+24, 16)
                                            if not (nm4 and re.match(r'^[\x20-\x7e]{2,}', nm4)):
                                                break
                                        else:
                                            break
                                    e2.append(n2)
                                    r += 24
                                print(f'    -> {len(e2)} names: {e2[:6]}...')
                                # hex gap between tables
                                print(f'    gap hex: {b[p:q].hex()[:120]}')
                                break
                            q += 4
                        else:
                            q += 4
                    break

print('\n' + '='*70)
print('KORG9 STY full section parse')
print('='*70)
path = os.path.join(ROOT, 'Init_i3.sty')
b = open(path, 'rb').read()
print(f'size={len(b)}')
print(f'magic={b[:5]} b5={b[5]} b6={b[6]} b7={b[7]}')
# offset table at 0x10: 4 x u32
offs = [u32(b, 0x10+i*4) for i in range(4)]
print(f'offsets: {[hex(x) for x in offs]}')
# names section at first offset
for i, o in enumerate(offs):
    print(f'\n  section[{i}] @ {o:#x} size_hint={offs[i+1]-o if i+1<len(offs) else "?"}')
    chunk = b[o:o+80]
    print(f'    hex: {chunk.hex()}')
    print(f'    ascii: {chunk!r}')

# name table of 10-byte slots
print('\n  name slots (10B):')
p = offs[0]
while p + 10 <= len(b) and p < offs[0] + 400:
    nm = cstr(b, p, 10)
    if not nm:
        # try continue if zeros
        if b[p:p+10] == b'\x00'*10:
            # peek ahead
            if b[p+10:p+20] == b'\x00'*10:
                break
        else:
            break
    print(f'    {p:#x}: {nm!r}  raw={b[p:p+10].hex()}')
    p += 10

# Find all 10-byte ASCII runs as section names
print('\n  scanning for CN_/style-name-like 10-byte slots:')
for o in range(0x20, min(len(b), 0x200), 10):
    nm = cstr(b, o, 10)
    if nm and re.match(r'^[A-Z0-9_ ]{3,}', nm):
        print(f'    {o:#x}: {nm!r}')

# After names: what structure? Look for track data patterns
# dump from 0x48 (first data section per offs)
print(f'\n  data section @ 0x{offs[2]:x}:')
chunk = b[offs[2]:offs[2]+200]
print(f'    {chunk.hex()}')

print('\n' + '='*70)
print('KORGI INIT_I30.STY sections')
print('='*70)
path = os.path.join(ROOT, 'INIT_I30.STY')
b = open(path, 'rb').read()
print(f'size={len(b)} head={b[:0x18].hex()}')
# entries: u16 val, u8 type, u8 flags from 0x18
entries = []
for i in range(40):
    o = 0x18 + i*4
    if o+4 > len(b): break
    val, typ, flg = struct.unpack_from('<HBB', b, o)
    entries.append((val, typ, flg))
print('section table (u16_val, type, flags):')
for val, typ, flg in entries:
    if flg or val:
        print(f'  type={typ:3d} flags={flg} val={val:#06x}({val})')

# For non-zero vals, show data at val as potential offsets
print('\nprobe non-zero vals as offsets:')
for val, typ, flg in entries:
    if val and val < len(b):
        chunk = b[val:val+32]
        pr = ''.join(chr(x) if 32<=x<127 else '.' for x in chunk)
        print(f'  type={typ} @{val:#x}: {chunk.hex()}  {pr!r}')

# Alternative interpretation: maybe u16 is SIZE not offset
# Or: val is offset from some base
print('\nas offset from 0x1000 / other bases:')
for base in (0, 0x100, 0x18, 0x800, 0x1000):
    hits = 0
    for val, typ, flg in entries:
        if val and base + val < len(b):
            hits += 1
    print(f'  base={base:#x}: {hits} in-range')

# Try: records are NOT at 0x18. Check u16 at 0x14 = 0x00e0 = 224
# Maybe header is longer. Look at first 0x80 as hex dump with ascii
print('\nhexdump 0..0x100:')
for o in range(0, 0x100, 16):
    hx = b[o:o+16].hex()
    pr = ''.join(chr(x) if 32<=x<127 else '.' for x in b[o:o+16])
    print(f'  {o:04x}  {hx}  {pr}')
