﻿import os, struct, re
d = r"C:\Users\Baja\Desktop\Nova mapa\Style Works XT Universal\InitKorg"
def hd(b, base=0, w=16):
    out=[]
    for i in range(0,len(b),w):
        c=b[i:i+w]
        out.append('%08X  %-47s  |%s|'%(base+i,' '.join('%02X'%x for x in c),
                   ''.join(chr(x) if 32<=x<127 else '.' for x in c)))
    return '\n'.join(out)
# i-series header 0x00-0x40 detailed decode
for fn in ["INIT_I30.STY","INIT_I40.STY","Init_i3.sty","INIT_I30.ARR","INIT_I40.ARR","Init_i3.arr",
           "INIT_I30.PRG","INIT_I40.PRG","Init_i3.pcg","INIT_I30.GBL","INIT_I40.GBL","Init_i3.sng"]:
    data=open(os.path.join(d,fn),'rb').read()
    print("="*90); print(fn,"size",len(data))
    print(hd(data[:64]))
    if data[:4]==b'KORG':
        w=data[4:8]
        print("   bytes4-7: %s  ('%s')  LE16@4=%d LE16@6=%d   LE32@4=0x%08X"%(
            w.hex(' ').upper(), ''.join(chr(b) if 32<=b<127 else '.' for b in w),
            struct.unpack('<H',w[0:2])[0], struct.unpack('<H',w[2:4])[0], struct.unpack('<I',w)[0]))
        if data[8:16]==b'\x00'*8:
            v=struct.unpack('<I',data[16:20])[0]
            print("   LE32@0x10 = 0x%X (%d)"%(v,v))
