import sys, time, faulthandler, traceback

sys.path.insert(0, r"C:\Users\Baja\Desktop\Nova mapa")
from pathlib import Path

from setconvert.conv import convert_sty

PA1X = r"C:\Users\Baja\Desktop\Pantic Pa1X.SET\STYLE\BANK01_LIVE.STY"
FWD = r"C:\Users\Baja\AppData\Local\Temp\opencode\fwd_pa800.sty"

if not Path(FWD).exists():
    t = time.time()
    out, rep = convert_sty(Path(PA1X).read_bytes(), "pa800")
    Path(FWD).write_bytes(out)
    print(f"fwd done in {time.time()-t:.1f}s", flush=True)

print("starting reverse...", flush=True)
faulthandler.dump_traceback_later(240, exit=True)
t = time.time()
back, rep = convert_sty(Path(FWD).read_bytes(), "pa1x")
faulthandler.cancel()
print(f"reverse done in {time.time()-t:.1f}s", flush=True)
