﻿import sys, struct
sys.stdout.reconfigure(encoding="utf-8", errors="replace")
d = open(r"C:\Users\Baja\Desktop\USER01_PA800.STY", "rb").read()
kend = int.from_bytes(d[4:8], "big")
count = int.from_bytes(d[kend+4:kend+8], "big")
kbeg = kend - 4 - 4*count
offs = [int.from_bytes(d[kbeg+4+4*i:kbeg+8+4*i], "big") for i in range(count)]
print("count", count, "kbeg", hex(kbeg), "kend", hex(kend))
# Check: does size chaining from kbeg[0] reproduce kbeg[1..]?
bad = 0
for i in range(count-1):
    o = offs[i]
    hdr = d[o:o+4]
    sz = int.from_bytes(d[o+4:o+8], "big")
    nxt = o + 8 + sz
    if nxt != offs[i+1]:
        bad += 1
        if bad <= 6:
            print("  chain mismatch @%s: hdr=%s sz=%d -> %s but kbeg[%d]=%s" % (hex(o), hdr.hex(" "), sz, hex(nxt), i+1, hex(offs[i+1])))
            # what header lives at expected vs actual?
            print("      hdr@nxt=%s  hdr@kbeg_nxt=%s" % (d[nxt:nxt+4].hex(" "), d[offs[i+1]:offs[i+1]+4].hex(" ")))
# last resource end
o = offs[-1]; sz = int.from_bytes(d[o+4:o+8], "big")
print("last res @%s hdr=%s sz=%d end=%s kbeg=%s" % (hex(o), d[o:o+4].hex(" "), sz, hex(o+8+sz), hex(kbeg)))
print("total mismatches", bad)
