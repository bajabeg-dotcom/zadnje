﻿import os, sys
sys.stdout.reconfigure(encoding="utf-8", errors="replace")
p = r"C:\Users\Baja\Desktop\BAJA MUSIC\Baja_Music_PA_Manager_V1_WORKING\pa800_studio\pa1x_to_pa800_sty.py"
print("size", os.path.getsize(p))
with open(p, encoding="utf-8", errors="replace") as f:
    lines = f.readlines()
print("lines", len(lines))
for i, l in enumerate(lines):
    print("%4d| %s" % (i+1, l.rstrip("\n")))
