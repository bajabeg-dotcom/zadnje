import ast
import sys
from pathlib import Path

ROOT = Path(r"C:\Users\Baja\Desktop\Nova mapa")
targets = sorted((ROOT / "setconvert").glob("*.py")) + sorted((ROOT / "pa800_native").glob("*.py"))
for f in targets:
    src = f.read_text(encoding="utf-8")
    tree = ast.parse(src)
    imported = {}
    for node in ast.walk(tree):
        if isinstance(node, ast.Import):
            for a in node.names:
                imported[(a.asname or a.name).split(".")[0]] = node.lineno
        elif isinstance(node, ast.ImportFrom):
            for a in node.names:
                if a.name != "*":
                    imported[a.asname or a.name] = node.lineno
    used = set()
    for node in ast.walk(tree):
        if isinstance(node, ast.Name):
            used.add(node.id)
        elif isinstance(node, ast.Attribute):
            v = node.value
            while isinstance(v, ast.Attribute):
                v = v.value
            if isinstance(v, ast.Name):
                used.add(v.id)
        elif isinstance(node, ast.Constant) and isinstance(node.value, str):
            used.add(node.value)
    unused = sorted(k for k in imported if k not in used and f'"{k}"' not in src and f"'{k}'" not in src)
    if unused:
        print(f"{f.relative_to(ROOT)}: {unused}")
