import sys, io, os, glob, collections
sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding='utf-8', errors='replace')
sys.path.insert(0, r'C:\Users\Baja\Desktop\Nova mapa')
from setconvert.sty import StyBank
from setconvert import parameters as P
from setconvert import sts as S
from setconvert.sts import StsStats
from setconvert.detect import decode_payload
from setconvert.families import FAMILIES
from pa800_native.sty_container import parse_bank

NUL = b"\x00"
def pcg_catalog(path):
    bank = parse_bank(open(path, 'rb').read())
    cat = [r for r in bank.resources if r.kind == 5]
    if not cat: return []
    c = cat[0]; recs = []
    if c.header[1] == 0:
        for i in range(len(c.payload)//24):
            rec = c.payload[i*24:(i+1)*24]; meta = rec[16:]
            recs.append({'bank': meta[3], 'prog': meta[4], 'name': rec[:16].split(NUL)[0].decode('ascii','replace')})
    else:
        pos = 0
        while pos < len(c.payload):
            a = int.from_bytes(c.payload[pos:pos+2],'big'); ln = a+2
            if c.payload[pos+4:pos+8] != b'\x00\x02\x00\x1c' or ln < 39 or pos+ln > len(c.payload): break
            meta = c.payload[pos+39:pos+47]
            recs.append({'bank': meta[2], 'prog': meta[3], 'name': c.payload[pos+8:pos+24].split(NUL)[0].decode('ascii','replace')})
            pos += ln
    return recs

SETS = [
    ('pa800', r'C:\Users\Baja\Desktop\KOCE FOLK.SET'),
    ('pa800', r'C:\Users\Baja\Desktop\GOLE ARX .SET'),
    ('pa1x',  r'C:\Users\Baja\Desktop\Pantic Pa1X.SET'),
    ('pa3x',  r'C:\Users\Baja\Desktop\Korg Pa3x Team Serbian.SET'),
    ('pa4x',  r'C:\Users\Baja\Desktop\Pa4x Pro Dejan Shiki.SET'),
]
NAMES = {9:'USER01',10:'USER02',11:'USERDK',12:'USER03',13:'USER04'}

for family, root in SETS:
    print(f'\n######## {family}  {os.path.basename(root)}')
    banks = {}
    for p in sorted(set(glob.glob(os.path.join(root,'**','*.PCG'),recursive=True)+glob.glob(os.path.join(root,'**','*.pcg'),recursive=True))):
        recs = pcg_catalog(p)
        if not recs: continue
        bi = recs[0]['bank']
        banks[bi] = {'file': os.path.basename(p), 'progs': {r['prog'] for r in recs if r['prog'] is not None}}
    stys = sorted({p for p in glob.glob(os.path.join(root,'**','*'),recursive=True) if p.lower().endswith('.sty')})[:8]
    dialect = FAMILIES[family].sts_dialect
    sel = collections.Counter()
    for sty in stys:
        try: bank = StyBank.read(sty)
        except Exception: continue
        for res in bank.resources:
            try:
                if res.kind == 6:
                    for blk in P.find_blocks(decode_payload(res.payload)):
                        for rec in blk.records: sel[rec.selector] += 1
                elif res.kind == 9:
                    st = StsStats()
                    for slot in S.read_document_slots(decode_payload(res.payload), dialect, None, st):
                        for row in slot.selectors: sel[row] += 1
            except Exception: pass
    grp = collections.defaultdict(set)
    for (msb, lsb, pc), n in sel.items():
        if lsb >= 64: grp[(msb, lsb)].add(pc)
    for key in sorted(grp):
        pcs = grp[key]
        parts = []
        for bi in sorted(banks):
            b = banks[bi]
            hit = len(pcs & b['progs'])
            tag = 'DK' if b['file'].upper().startswith('USERDK') else NAMES.get(bi, str(bi))
            parts.append(f'{tag}:{hit}/{len(pcs)}')
        print(f'  (msb={key[0]}, lsb={key[1]}) distinct={len(pcs)}  ' + '  '.join(parts))
