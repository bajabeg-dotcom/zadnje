﻿param(
  [string]$Path = "C:\Users\Baja\Desktop\Nova mapa\KORG PA Manager\v3\KORGPAManager.exe",
  [string]$Out  = "C:\Users\Baja\AppData\Local\Temp\opencode\korgpm_rsrc_strings.txt"
)
$b = [IO.File]::ReadAllBytes($Path)
$rs = 0x0133C800; $re = 0x013AC000   # .rsrc raw range (0x133C800 + 0x6F800 = 0x13AC000)
$sb = New-Object System.Text.StringBuilder
$run = -1
for ($i = $rs; $i -lt $re; $i++) {
  $c = $b[$i]
  if ($c -ge 0x20 -and $c -le 0x7E) { if ($run -lt 0) { $run = $i } }
  else {
    if ($run -ge 0 -and ($i-$run) -ge 4) {
      $s = [Text.Encoding]::ASCII.GetString($b,$run,$i-$run)
      [void]$sb.AppendLine(("{0:X8}`tA`t{1}" -f $run,$s))
    }
    $run = -1
  }
}
if ($run -ge 0 -and ($re-$run) -ge 4) { [void]$sb.AppendLine(("{0:X8}`tA`t{1}" -f $run,[Text.Encoding]::ASCII.GetString($b,$run,$re-$run))) }
foreach ($sh in 0,1) {
  $run = -1; $i = $rs + $sh
  while ($i + 1 -lt $re) {
    $lo=$b[$i]; $hi=$b[$i+1]
    if ($hi -eq 0 -and $lo -ge 0x20 -and $lo -le 0x7E) { if ($run -lt 0) { $run=$i }; $i+=2 }
    else {
      if ($run -ge 0 -and ($i-$run) -ge 8) {
        $s=[Text.Encoding]::Unicode.GetString($b,$run,$i-$run)
        [void]$sb.AppendLine(("{0:X8}`tU`t{1}" -f $run,$s))
      }
      $run=-1; $i+=2
    }
  }
}
[IO.File]::WriteAllText($Out,$sb.ToString(),[Text.Encoding]::UTF8)
Write-Host ("lines: " + ($sb.ToString() -split "`n").Count)
