import sys
sys.path.insert(0, r"C:\Users\Baja\Desktop\Nova mapa")
from pathlib import Path
from dataclasses import fields
from setconvert.conv import convert_sty
from setconvert.detect import fingerprint_sty, decode_payload
from setconvert.sty import StyBank

def dp(data):
    bank = StyBank.read(data)
    return [(r.kind, decode_payload(r.payload)) for r in bank.resources]

def show_diff(a, b, label, maxn=6):
    n = 0
    for i, ((ka, da), (kb, db)) in enumerate(zip(a, b)):
        if da == db:
            continue
        if len(da) == len(db):
            diffs = [j for j in range(len(da)) if da[j] != db[j]]
            print(f"  {label} res{i} kind{ka} same-len diffs={len(diffs)} first={diffs[:8]}")
        else:
            k = min(len(da), len(db))
            diffs = [j for j in range(k) if da[j] != db[j]]
            print(f"  {label} res{i} kind{ka} len {len(da)}->{len(db)} common-diffs={len(diffs)} first={diffs[:8]}")
        n += 1
        if n >= maxn:
            print(f"  {label} ... ({sum(1 for x, y in zip(a, b) if x != y)} total mismatch)")
            return

print("== GOLE USER01: pa800 -> pa1x (drop report) ==")
gole = Path(r"C:\Users\Baja\Desktop\GOLE ARX .SET\GOLE ARX .SET\STYLE\USER01.STY").read_bytes()
down, rep = convert_sty(gole, "pa1x")
for n in rep.notes:
    print("  NOTE:", n)
print("  genab notes:", rep.genab.notes[:4])
print("  drop counters: hdr_ext=", rep.genab.mixer_header_extension_dropped,
      " detail_tail=", rep.genab.mixer_detail_tail_dropped,
      " ti_ext=", rep.genab.ti_extension_dropped_bytes)

back, rep2 = convert_sty(down, "pa800")
a, b = dp(gole), dp(back)
show_diff(a, b, "gole-roundtrip")
print("  -> compare down(orig) vs down(back):")
down2, _ = convert_sty(back, "pa1x")
a2, b2 = dp(gole), dp(down2)
mism = [i for i, (x, y) in enumerate(zip(a2, b2)) if x != y]
print("  down-domain mismatches:", mism)

print("\n== USER03 res7 ==")
u3 = Path(r"C:\Users\Baja\Desktop\Pantic Pa1X.SET\STYLE\USER03.STY").read_bytes()
fwd, r3 = convert_sty(u3, "pa800")
bck, r4 = convert_sty(fwd, "pa1x")
a, b = dp(u3), dp(bck)
show_diff(a, b, "u3", maxn=10)

print("\n== USER01_PA800 fingerprint ==")
broken = Path(r"C:\Users\Baja\Desktop\USER01_PA800.STY").read_bytes()
fixed, r5 = convert_sty(broken, "pa800")
for label, data in (("broken", broken), ("fixed", fixed)):
    p = fingerprint_sty(data)
    print(f"  {label}: family={p.family!r} kbeg={p.kbeg_ok} kind05={p.kind05_hdr.hex() if p.kind05_hdr else None} "
          f"k09={p.kind09_hdrs} mixer={p.mixer_markers} ti={p.trackinfo} namev={p.name_versions} "
          f"pre={p.pre_bytes} magics={p.magics} votes={p.votes if hasattr(p, 'votes') else '?'}")
