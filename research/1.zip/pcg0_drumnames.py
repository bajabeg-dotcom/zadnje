import sys, io, os, re, collections
sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding='utf-8', errors='replace')
sys.path.insert(0, r'C:\Users\Baja\Desktop\Nova mapa')
from pa800_native.sty_container import parse_bank

PRG = r'C:\Users\Baja\Desktop\PA800_AI_PA800_STUDIO_v5_2026-09-20\factory_evidence\native_factory\SOUND\PRGMAPS.TBL'
ROM = r'C:\Users\Baja\Desktop\PA800_AI_PA800_STUDIO_v5_2026-09-20\factory_evidence\native_factory\SOUND\ROM.PCG'
SND = r'C:\Users\Baja\Desktop\Nova mapa\Style Works XT Universal\InitKorg\rom_PA2x.SND'
LINE = re.compile(r"^(\d{3})-(\d{3})-(\d{3})\s+(.*)$")

bank = parse_bank(open(PRG, 'rb').read())
otc_raw, nvar_raw, sl = bank.resources[1].payload, bank.resources[2].payload, bank.resources[5].payload
otc = [int.from_bytes(otc_raw[8+i*2:10+i*2], 'big') for i in range((len(otc_raw)-8)//2)]
nvar = list(nvar_raw[8:])
pos = 8; entries = []
while pos < len(sl):
    n = int.from_bytes(sl[pos:pos+2], 'big'); pos += 2
    if n == 0: break
    for i in range(n):
        e = sl[pos:pos+6]; pos += 6
        entries.append((int.from_bytes(e[0:2], 'big'), e[2], e[3], (e[4] << 7) | e[5], e[4], e[5]))
cat = [r for r in parse_bank(open(ROM, 'rb').read()).resources if r.kind == 5][0].payload
names = [cat[i*24:(i+1)*24].split(b'\x00')[0].decode('ascii', 'replace').strip() for i in range(len(cat)//24)]

snd = {}
for line in open(SND, encoding='latin1').read().splitlines():
    m = LINE.match(line)
    if m:
        pr, lsb, msb = map(int, m.groups()[:3])
        snd[(msb, lsb, pr)] = m.group(4).strip()

drums = [e for e in entries if e[0] == 120]
mel = [e for e in entries if e[0] == 121]
print(f'SoundsLayout: total={len(entries)} drums(msb120)={len(drums)} melodic(msb121)={len(mel)}')
print(f'drum (lsb,pc) sample: {[(e[1], e[2]) for e in drums[:20]]}')
print(f'drum lsb values: {sorted({e[1] for e in drums})}  pc values: {sorted({e[2] for e in drums})[:20]}...')
print('\nDrum entries: SoundsLayout ordinal->ROM.PCG name   vs   SND name at same address')
ok = bad = 0
for msb, lsb, pc, ordi, hi, lo in drums[:24]:
    rom_name = names[ordi] if ordi < len(names) else '<out>'
    s = snd.get((120, lsb, pc), '<no-snd>')
    flag = '' if rom_name == s else '   <-- DIFF'
    if rom_name == s: ok += 1
    else: bad += 1
    print(f'  (120,{lsb:3d},{pc:3d}) ord={ordi:4d} hi={hi} lo={lo:3d}  ROM={rom_name!r:26s} SND={s!r}{flag}')
for msb, lsb, pc, ordi, hi, lo in drums[-8:]:
    rom_name = names[ordi] if ordi < len(names) else '<out>'
    s = snd.get((120, lsb, pc), '<no-snd>')
    print(f'  (120,{lsb:3d},{pc:3d}) ord={ordi:4d} hi={hi} lo={lo:3d}  ROM={rom_name!r:26s} SND={s!r}')

# melodic cross-check
mok = mbad = 0
diffs = []
for msb, lsb, pc, ordi, hi, lo in mel:
    rom_name = names[ordi] if ordi < len(names) else '<out>'
    s = snd.get((121, lsb, pc), None)
    if s is None:
        continue
    if rom_name == s: mok += 1
    else:
        mbad += 1; diffs.append(((121, lsb, pc), rom_name, s))
print(f'\nMelodic: ROM==SND {mok}  DIFF {mbad}')
for d in diffs[:12]:
    print('   DIFF', d)
