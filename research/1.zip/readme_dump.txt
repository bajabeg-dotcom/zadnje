1	# PA800 SONG OPTIMIZER v6
2	
3	> **GLAVNI UGOVOR PROJEKTA:** prije rada proÄŤitaj `00_PROCITAJ_PRVO_CILJ_PROJEKTA.md`.
4	> Ako postoji konflikt sa starijim dokumentom ili eksperimentalnim modulom, taj root dokument ima prednost.
5	
6	Ovo je nova, ÄŤista reimplementacija **samo SONG OPTIMIZER** dijela projekta.
7	Ista logika, isti dokazi, isti ugovor kao u v5 â€” ali ponovo isprogramirano,
8	bez mrtvog koda, bez dupliranja i sa web GUI-jem.
9	
10	Izvorna verzija `PA800_AI_PA800_STUDIO_v5_2026-09-20` ostaje netaknuta kao referenca.
11	
12	## Pokretanje
13	
14	```bat
15	install.bat      :: kreira .venv i instalira zavisnosti
16	run_web.bat      :: WEB GUI na http://127.0.0.1:8770/
17	run_cli.bat      :: isto iz komandne linije
18	run_batch.bat    :: cijeli folder MIDI fajlova odjednom
19	run_tests.bat    :: test suite
20	```
21	
22	## Tok u GUI-ju
23	
24	```
25	IMPORT  ->  OPTIMIZE  ->  EXPORT
26	```
27	
28	1. **IMPORT** â€” prevuci MIDI. ÄŚita se, analizira i prikazuje po kanalima.
29	   Izvorni fajl se nikad ne mijenja. MoĹľeĹˇ prevuÄ‡i i **viĹˇe fajlova odjednom**:
30	   tada ide batch obrata (svaki fajl kroz isti pipeline, tabela rezultata).
31	2. **OPTIMIZE** â€” pokreÄ‡e zakljuÄŤani pipeline ispod haube.
32	3. **EXPORT** â€” preuzima optimizovani MIDI + `.OPTIMIZER_REPORT.json`,
33	   oboje provjereno kroz SHA256 artifact kontrolu. Uz ugaĹľen `guitar mode`
34	   dodaje se i `*_GUITAR.MID` sidecar.
35	
36	`PANIC` je uvijek dostupan gore desno: Ĺˇalje All Notes Off / All Sound Off /
37	Sustain Off na **live MIDI OUT** i nikada se ne upisuje u MIDI fajl.
38	
39	## ZakljuÄŤani pipeline
40	
41	```
42	RESET_PROCESSING_STATE
43	KORG_MAPPER_2
44	DEMO_POPULAR_SOUND_REMAP
45	[STYLE_PATTERN_REMAP]        <- opt-in
46	REMAP
47	FACTORY_INTELLIGENCE
48	[FACTORY_DEMO_DYNAMICS]      <- opt-in
49	VELOCITY_PASSTHROUGH
50	VERIFY
51	SAVE
52	```
53	
54	Stepice u zagradama su **opt-in** (default ugašen) pa je podrazumijevani izlaz
55	byte-identičan referentnoj implementaciji. Kontrole su u GUI-ju (Factory Style
56	element + tri toggle-a) i u CLI-ju: `--style-remap`, `--dynamics`,
57	`--velocity-dynamics`, `--style-element V1..V4 / F1..F2 / I1..I2 / BR / CI / E1..E3`.
58	
59	| Stadij | Šta radi | Šta nikad ne radi |
60	|---|---|---|
61	| RESET | briše interni processing state (EQ/FX/remap/runtime) | ne dira MIDI |
62	| MAPPER 2 | provjerava channel contract; prigušuje CH11 support samo uz validiran evidence packet | ne briše niti premešta note |
63	| DEMO REMAP | najkorišteniji originalni Demo zvukovi, role-safe, hash-verifikovano | ne preuzima kanal bez kompletnog setupa |
64	| STYLE PATTERN REMAP | remap Bar pratnje iz Factory style elementa (`style_patterns/registry`) | ne dira kasniju selector automatiku; CH14–16 (lead) nikad |
65	| REMAP | mijenja jedan kompletni MSB/LSB/PC setup | ne dira kasniju selector automatiku |
66	| FACTORY INTELLIGENCE | tačno evidencirani CC91/CC93 setup za showcase uloge | ne pogađa native A/B/C/D algoritme |
67	| FACTORY/DEMO DINAMIKA | tick-0 CC 10/11/71/74 (Factory) odn. 7/10/11 (Demo) + evidence velocity pomak | ne dira CC91/CC93; kanal bez evidence ostaje REVIEW |
68	| VELOCITY | **passthrough** 1–127 (osim opt-in `--velocity-dynamics`) | ne kliješti, ne normalizuje, ne prepravlja |
69	| VERIFY | replay ledgera + hard lockovi | **BLOCK SAVE** ako je išta nedozvoljeno promijenjeno |
70	
71	### Hard locks
72	
73	note-on timing Â· note-off/duĹľina Â· pitch Â· tempo mapa Â· meter Â· markeri
74	Â· note count Â· nema quantize/humanize/snap.
75	
76	## Struktura
77	
78	```
79	pa800/                  paket (sve isprogramirano iznova)
80	  paths.py              putanje + keĹˇirani read-only pristup evidence fajlovima
81	  midi_io.py            ÄŤitanje/analiza MIDI-ja, Style channel ugovor
82	  korg_native.py        read-only inspekcija .STY/.BKP/.PCG/.KMP
83	  catalog.py            taÄŤan Factory/RX katalog + sound resolver
84	  ownership.py          TRACK OWNERSHIP prvi gate
85	  mapper2.py            channel contract + evidence-gated attenuacija
86	  demo_sounds.py        Demo popular sound policy (hash verifikacija)
87	  style_pattern.py      Factory Style Pattern registry (remap + dinamika)
88	  dynamics.py           Factory/Demo tick-0 CC i evidence velocity
89	  factory_intelligence.py  izbor samo evidenciranog Factory/Demo ponaĹˇanja
90	  articulation.py       multi-signal artikulacija (nikad single-feature)
91	  osc_evidence.py       nativna Factory OSC velocity-zone geometrija
92	  preflight.py          gate prije bilo kakvog rada
93	  verifier.py           baseline, ledger replay, artifact hash, PANIC
94	  optimizer.py          pipeline orkestrator + pipeline_stages()
95	web/                    WEB GUI (stdlib http.server, bez dodatnih frameworka)
96	  server.py             API: /api/import /api/optimize /api/export /api/report
97	                        /api/sounds /api/status /api/elements /api/package /api/panic
98	  static/               index.html + app.js + style.css
99	tests/                  95 testa
100	workspace/              primjeri MIDI dijelova (netaknuti)
101	factory_evidence/       Korg dokazi (read-only)
102	style_patterns/         Demo popular sounds registry
103	SYSTEM_RULES.json       zakljuÄŤana pravila
104	docs/                   reference uz v5 ugovore
105	```
106	
107	## Ĺ ta je namjerno ostavljeno van ovog paketa
108	
109	v5 moduli koji **nisu** dio SONG OPTIMIZER-a i ostaju samo u v5 folderu:
110	`agent/`, `tools/pa800_automation.py`, `tools/style_library.py`,
111	`tools/style_pattern_registry.py`, `tools/seq_*.py`, `tools/guitar_mode.py`,
112	`tools/pa800_arranger.py`, `tools/range_sanitizer.py`, `tools/import_measurement_engine.py`,
113	`tools/correction_planner.py`, tkinter `gui/`.
114	
115	Dokazi i podaci za njih ostaju saÄŤuvani u `factory_evidence/` i `docs/`.
116	
117	## Sigurnosne garancije (potvrÄ‘ene testovima)
118	
119	- **69/69 testova prolazi** (52 ugovornih + 17 parity prema v5).
120	- Optimizer je **bit-po-bit identiÄŤan** v5 izlazu na svih 17 `workspace` MIDI fajlova
121	  (pipeline, selectori, demo planovi, remap, FX, ledger, verifier).
122	- Svaki mutation mora imati `evidence_sources` sa SHA256; verifier replay-uje ledger
123	  nad originalnim event streamom. Ijedna nedozvoljena izmjena = **BLOCK SAVE**.
124	- Source SHA256 se provjerava prije i poslije optimizacije: izvorni fajl se ne mijenja.