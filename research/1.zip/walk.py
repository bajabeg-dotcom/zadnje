﻿import sys
sys.path.insert(0, r'C:\Users\Baja\Desktop\Nova mapa')
from pathlib import Path
from setconvert.sty import StyBank
from pa800_native.oc31_codec import decode_oc31

path = sys.argv[1]
res_index = int(sys.argv[2])
depth_max = int(sys.argv[3]) if len(sys.argv) > 3 else 4
data = Path(path).read_bytes()
bank = StyBank.read(data)
r = bank.resources[res_index]
payload = decode_oc31(r.payload) if r.compressed else r.payload


def walk(buf, depth, base):
    if depth > depth_max:
        return
    c = 0
    n = 0
    while c + 8 <= len(buf):
        tag = buf[c:c + 4]
        sz = int.from_bytes(buf[c + 4:c + 8], 'big')
        if sz > len(buf) - c - 8 or sz < 0:
            print('%sstop @%d tag=%s size=%d' % ('  ' * depth, base + c, tag.hex(' '), sz))
            return c
        body = buf[c + 8:c + 8 + sz]
        print('%s@%d tag=%s size=%d head=%s' % ('  ' * depth, base + c, tag.hex(' '), sz, body[:20].hex(' ')))
        # descend if body starts with a plausible child
        if depth < depth_max and len(body) >= 16:
            s2 = int.from_bytes(body[4:8], 'big')
            if 0 < s2 <= len(body) - 8:
                consumed = walk(body, depth + 1, base + c + 8)
                if consumed is None:
                    pass
        c += 8 + sz
        n += 1
        if n > 60:
            print('%s...' % ('  ' * depth))
            return c
    if c < len(buf):
        print('%s[%d trailing bytes: %s]' % ('  ' * depth, len(buf) - c, buf[c:c + 16].hex(' ')))
    return c


print('res %d decomp=%d' % (res_index, len(payload)))
walk(payload, 0, 0)
