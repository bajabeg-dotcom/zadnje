import sys, os, glob, collections
sys.path.insert(0, r"C:\Users\Baja\Desktop\Nova mapa")
from pa800_native import parse_bank, decode_oc31
sys.stdout.reconfigure(encoding="utf-8", errors="replace")

TARGETS = [
    (r"C:\Users\Baja\Desktop\Moduli na PYTHONU\Pa800_System\output\Pa800_os_res_v202\STARTUP\ALL\STYLE\BANK01.STY", "PA800-OS"),
    (r"C:\Users\Baja\Desktop\BAJA MUSIC\extracted_files_oc20_lzss\STARTUP\ALL\STYLE\BANK01.STY", "PA800-OC20"),
    (r"C:\Users\Baja\Desktop\Pantic Pa1X.SET\STYLE\BANK01_LIVE.STY", "PanticSET"),
    (r"C:\Users\Baja\Desktop\Pantic Pa1X.SET\STYLE\BANK01_PA800.STY", "PanticSET-PA800named"),
    (r"C:\Users\Baja\Desktop\Pantic Pa1X.SET\STYLE\USER02.STY", "PanticSET-USER02"),
    (r"C:\Users\Baja\Desktop\GOLE ARX .SET\GOLE ARX .SET\STYLE\FAVORITE01.STY", "GOLEARX-FAV01"),
    (r"C:\Users\Baja\Desktop\GOLE ARX .SET\GOLE ARX .SET\STYLE\USER01.STY", "GOLEARX-USER01"),
    (r"C:\Users\Baja\Desktop\USER01.STY", "Desktop-USER01"),
    (r"C:\Users\Baja\Desktop\USER01_PA800.STY", "Desktop-USER01_PA800"),
    (r"C:\Users\Baja\Desktop\BANK01.STY", "Desktop-BANK01"),
    (r"C:\Users\Baja\Desktop\STYLE\USER01_IZOLACIJA.STY", "DesktopSTYLE-IZOLACIJA"),
    (r"C:\Users\Baja\Desktop\Nova mapa\Style Works XT Universal\InitKorg\Initpa01.STY", "Init-pa01"),
    (r"C:\Users\Baja\Desktop\Nova mapa\Style Works XT Universal\InitKorg\INITPA02.STY", "Init-pa02"),
    (r"C:\Users\Baja\Desktop\Nova mapa\Style Works XT Universal\InitKorg\INITPA03.STY", "Init-pa03"),
    (r"C:\Users\Baja\Desktop\Nova mapa\Style Works XT Universal\InitKorg\InitPx01.STY", "Init-Px01"),
    (r"C:\Users\Baja\Desktop\Nova mapa\Style Works XT Universal\InitKorg\InitPx02.STY", "Init-Px02"),
    (r"C:\Users\Baja\Desktop\Nova mapa\Style Works XT Universal\InitKorg\InitPx03.STY", "Init-Px03"),
    (r"C:\Users\Baja\Desktop\Nova mapa\Style Works XT Universal\InitKorg\initPx04.STY", "Init-Px04"),
]

def dec(r):
    p = r.payload
    if p[:4] == b"OC31" or p[:4] == b"OC32":
        return decode_oc31(b"OC31" + p[4:])
    return p

for path, label in TARGETS:
    if not os.path.exists(path):
        print(f"### {label}: MISSING {path}")
        continue
    d = open(path, "rb").read()
    print(f"### {label}  size={len(d)}  head={d[:8].hex(' ')}")
    try:
        bank = parse_bank(d)
    except Exception as e:
        print("   parse error:", e)
        continue
    kinds = collections.Counter(r.kind for r in bank.resources)
    magics = collections.Counter()
    for r in bank.resources:
        if r.payload[:4] in (b"OC31", b"OC32"):
            magics[r.payload[:4].decode()] += 1
        elif r.compressed:
            magics["OTHER:" + r.payload[:4].hex()] += 1
    print("   kinds:", dict(sorted((f"0x{k:02x}", v) for k, v in kinds.items())),
          "magics:", dict(magics))
    # kind06 first child tag + kind09 header + trackinfo markers
    k6tags = collections.Counter()
    k9hdrs = collections.Counter()
    ti = collections.Counter()
    n6 = 0
    for r in bank.resources:
        if r.kind == 6:
            n6 += 1
            out = dec(r)
            if len(out) >= 12:
                k6tags[out[8:12].hex(" ")] += 1
            for marker in (b"\x02\x00\x00\x08", b"\x02\x00\x01\x08", b"\x02\x00\x02\x08",
                           b"\x02\x00\x03\x08", b"\x02\x00\x04\x08"):
                c = out.count(marker + b"\x00\x00\x00\x30")
                if c:
                    ti[marker[2].to_string() if False else marker.hex(" ")] += c
        elif r.kind == 9:
            out = dec(r)
            if len(out) >= 4:
                k9hdrs[out[:4].hex(" ")] += 1
    print(f"   kind06 count={n6} name-child tags={dict(k6tags)}")
    print(f"   kind09 headers={dict(k9hdrs)}")
    print(f"   TrackInfo markers={dict(ti)}")
