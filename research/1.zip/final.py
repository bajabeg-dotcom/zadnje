﻿import os, re, struct
d = r"C:\Users\Baja\Desktop\Nova mapa\Style Works XT Universal\InitKorg"
def hd(b, base=0, w=16):
    out=[]
    for i in range(0,len(b),w):
        c=b[i:i+w]
        out.append('%08X  %-47s  |%s|'%(base+i,' '.join('%02X'%x for x in c),
                   ''.join(chr(x) if 32<=x<127 else '.' for x in c)))
    return '\n'.join(out)

print("### i-series STY header 0x10..0x110")
for fn in ["INIT_I30.STY","INIT_I40.STY"]:
    data=open(os.path.join(d,fn),'rb').read()
    print("="*90); print(fn)
    print(hd(data[0x10:0x110],0x10))

print()
print("### PRG tail + stride record count")
for fn in ["INIT_I30.PRG","INIT_I40.PRG"]:
    data=open(os.path.join(d,fn),'rb').read()
    print("--",fn,"size",len(data))
    print(hd(data[-48:],len(data)-48))
    # count stride-172 printable-name records from 0x30
    n=0; off=0x30
    while off+16<=len(data):
        nm=data[off:off+16]
        if not all(32<=b<127 for b in nm): break
        n+=1; off+=172
    print("   stride-172 readable names = %d, next off=0x%X, bytes left=%d"%(n,off,len(data)-off))

print()
print("### INIT_I30.GBL full hexdump (448 bytes)")
g=open(os.path.join(d,"INIT_I30.GBL"),'rb').read()
print(hd(g))

print()
print("### footer KBEG/KEND verification across all PA/PX files")
for fn in sorted(os.listdir(d)):
    if not fn.lower().endswith('.sty'): continue
    data=open(os.path.join(d,fn),'rb').read()
    if data[:4]!=b'\x01\x00\x01\x14': continue
    # locate footer
    i=data.rfind(b'KBEG'); j=data.rfind(b'KEND')
    if i<0: print(fn,"no KBEG"); continue
    n=struct.unpack('>I',data[j+4:j+8])[0]
    cnt=(j-i-4)//4
    offs=[struct.unpack('>I',data[i+4+4*k:i+8+4*k])[0] for k in range(cnt)]
    # actual record offsets
    recs=[]; pos=8
    while pos+8<=len(data):
        s=struct.unpack('>I',data[pos+4:pos+8])[0]
        if pos+8+s>len(data): break
        recs.append(pos); pos+=8+s
    print("   %-14s footer@0x%06X  KBEG offsets=%d  trailing_count_field=%d  actual_records=%d  offset_match=%s  header_match=%s"
          %(fn,i,cnt,n,len(recs),offs==recs[1:], data[i-8:i]==b'\xfe\x00\x00\x18'+struct.pack('>I',len(data)-i)))
