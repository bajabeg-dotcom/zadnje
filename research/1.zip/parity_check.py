"""Byte-for-byte parity check between the v5 optimizer and the v6 rewrite."""

import subprocess
import sys
from pathlib import Path

V5 = Path(r"C:\Users\Baja\Desktop\PA800_AI_PA800_STUDIO_v5_2026-09-20")
V6 = Path(r"C:\Users\Baja\Desktop\PA800_SONG_OPTIMIZER_v6_2026-09-26")
WORKER = Path(r"C:\Users\Baja\AppData\Local\Temp\opencode\parity_worker.py")
OUT = Path(r"C:\Users\Baja\AppData\Local\Temp\opencode\parity_out")

PY5 = V5 / ".venv" / "Scripts" / "python.exe"
PY6 = V6 / ".venv" / "Scripts" / "python.exe"


def run(python: Path, root: Path, tools: str, src: Path, dst: Path) -> str:
    proc = subprocess.run(
        [str(python), str(WORKER), str(root), tools, str(src), str(dst)],
        capture_output=True,
        text=True,
        timeout=600,
    )
    if proc.returncode != 0:
        raise RuntimeError(f"{python}: {proc.stdout}\n{proc.stderr}")
    for line in proc.stdout.splitlines():
        if line.startswith("SHA256 "):
            return line[7:]
    raise RuntimeError(f"no hash: {proc.stdout} {proc.stderr}")


def main() -> int:
    OUT.mkdir(parents=True, exist_ok=True)
    sources = sorted((V6 / "workspace" / "midi_parts").glob("*.MID"))
    matched = 0
    failed = []
    for src in sources:
        a = OUT / ("v5_" + src.name)
        b = OUT / ("v6_" + src.name)
        for stale in (a, b):
            stale.unlink(missing_ok=True)
        try:
            hash_a = run(PY5, V5, str(V5 / "tools"), src, a)
            hash_b = run(PY6, V6, "-", src, b)
        except Exception as exc:  # noqa: BLE001
            failed.append((src.name, f"ERROR {exc}"))
            continue
        if hash_a == hash_b and a.read_bytes() == b.read_bytes():
            matched += 1
            print(f"  MATCH {src.name} {hash_a[:16]}")
        else:
            failed.append((src.name, f"v5={hash_a} v6={hash_b} size={a.stat().st_size}/{b.stat().st_size}"))
    print(f"\nparity: {matched}/{len(sources)} byte-identical")
    for name, why in failed:
        print(f"  DIFF {name}: {why}")
    return 0 if not failed else 1


if __name__ == "__main__":
    sys.exit(main())
