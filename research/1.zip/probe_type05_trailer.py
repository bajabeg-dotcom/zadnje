#!/usr/bin/env python3
from pathlib import Path
import struct
import sys

sys.path.insert(0, r"C:\Users\Baja\Desktop\BAJA MUSIC\Baja_Music_PA_Manager_V1_WORKING\pa800_native")
from oc31_codec import decode_oc31  # noqa: E402

def dump(path: Path, label: str) -> None:
    data = path.read_bytes()
    kend = data.find(b"KEND")
    count = struct.unpack(">I", data[kend + 4 : kend + 8])[0]
    kbeg = kend - 4 - 4 * count
    start = kbeg + 4
    offs = [struct.unpack(">I", data[start + 4 * i : start + 4 * i + 4])[0] for i in range(count)]
    print(f"\n== {label} ==")
    print(f"prefix={data[:28].hex(' ')}")
    # trailer = between last resource end and kbeg
    last = offs[-1]
    last_sz = struct.unpack(">I", data[last + 4 : last + 8])[0]
    last_end = last + 8 + last_sz
    trailer = data[last_end:kbeg]
    print(f"trailer({len(trailer)})={trailer.hex(' ')}")
    for i, o in enumerate(offs):
        hdr = data[o : o + 4]
        sz = struct.unpack(">I", data[o + 4 : o + 8])[0]
        payload = data[o + 8 : o + 8 + sz]
        gap = data[o + 8 + sz : (offs[i + 1] if i + 1 < count else kbeg)]
        if hdr[0] == 5:
            print(f"kind05 hdr={hdr.hex()} size={sz} payload={payload.hex(' ')} gap={gap.hex(' ')}")
        if i == 0:
            print(f"res0 hdr={hdr.hex()} gap_after_first={gap[:16].hex(' ')} gap_len={len(gap)}")

for p, lab in [
    (Path(r"C:\Users\Baja\Desktop\Pantic Pa1X.SET\STYLE\BANK01_LIVE.STY"), "PA1X_LIVE"),
    (Path(r"C:\Users\Baja\Desktop\BAJA MUSIC\extracted_files_oc20_lzss\STARTUP\ALL\STYLE\BANK16.STY"), "PA800_BANK16"),
]:
    dump(p, lab)
