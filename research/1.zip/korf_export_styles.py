import os
import sys
import json
import glob

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from korf_parse_style import summarize, STYLE_ELEMENT_NAMES, ACC_TRACK

OUT = os.path.dirname(os.path.abspath(__file__))


def build_style(path):
    s = summarize(path)
    data = open(path, "rb").read()
    tree = []
    from korf_parse_style import walk
    walk(data, out=tree)

    style = {
        "file": s["file"],
        "size": s["size"],
        "name": s.get("name"),
        "kinds": s["kinds"],
        "n_errors": s["n_errors"],
        "midi_tracks": [],
        "style_elements": [],
        "track_mapping": None,
        "root_version": None,
    }

    root = next((e for e in tree if e["depth"] == 0 and not e["leaf"]), None)
    if root:
        style["root_version"] = root["ver"]

    for e in tree:
        k = e.get("kind")
        if not isinstance(k, dict):
            continue
        kn = k.get("kind")
        d = k.get("data")
        if kn == "track_mapping" and isinstance(d, dict):
            style["track_mapping"] = d
        elif kn == "midi_track" and isinstance(d, dict) and e["depth"] == 2 and e["parent_type"] == 2:
            style["midi_tracks"].append({
                "chunk_type": e["type"],
                "ver": e["ver"],
                "n_events": len(d.get("events") or []),
                "events_sample": (d.get("events") or [])[:8],
            })
        elif kn == "se_info" and e["parent_type"] == 3:
            style["style_elements"].append({
                "se_info": d,
                "tracks": None,
                "cvs": [],
            })
        elif kn == "style_tracks" and e["parent_type"] == 3 and style["style_elements"]:
            style["style_elements"][-1]["tracks"] = d
        elif kn == "cv" and e["parent_type"] == 3 and style["style_elements"]:
            style["style_elements"][-1]["cvs"].append(d)

    for i, se in enumerate(style["style_elements"]):
        se["index"] = i
        se["label"] = STYLE_ELEMENT_NAMES[i] if i < len(STYLE_ELEMENT_NAMES) else f"SE{i}"

    return style


if __name__ == "__main__":
    patterns = [
        "dec_Initpa01_*.bin", "dec_INITPA02_*.bin", "dec_INITPA03_*.bin",
        "dec_InitPx01_*.bin", "dec_InitPx02_*.bin", "dec_InitPx03_*.bin",
        "dec_initPx04_*.bin",
    ]
    files = []
    for p in patterns:
        files.extend(sorted(glob.glob(os.path.join(OUT, p))))
    # unique preserve order
    seen = set()
    uniq = []
    for f in files:
        if f not in seen:
            seen.add(f)
            uniq.append(f)

    styles = []
    for f in uniq:
        try:
            st = build_style(f)
            styles.append(st)
            print(f"OK {st['file']}: name={st['name']!r} ver={st['root_version']} "
                  f"midi={len(st['midi_tracks'])} se={len(st['style_elements'])} err={st['n_errors']}")
        except Exception as e:
            print(f"FAIL {os.path.basename(f)}: {e}")

    out_path = os.path.join(OUT, "korf_styles_full.json")
    with open(out_path, "w", encoding="utf-8") as fh:
        json.dump(styles, fh, indent=1, ensure_ascii=False)
    print(f"\n{len(styles)} styles -> {out_path}")

    idx = [{"file": s["file"], "name": s["name"], "root_version": s["root_version"],
            "midi_tracks": len(s["midi_tracks"]), "style_elements": len(s["style_elements"]),
            "n_errors": s["n_errors"]} for s in styles]
    idx_path = os.path.join(OUT, "korf_styles_index.json")
    with open(idx_path, "w", encoding="utf-8") as fh:
        json.dump(idx, fh, indent=1, ensure_ascii=False)
    print(f"index -> {idx_path}")
