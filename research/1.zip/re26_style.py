﻿import os, sys, struct, collections
sys.path.insert(0, r"C:\Users\Baja\Desktop\Nova mapa")
from pa800_native import decode_oc31
sys.stdout.reconfigure(encoding="utf-8", errors="replace")

def dec(p):
    if p[:4] in (b"OC31", b"OC32"):
        return decode_oc31(b"OC31" + p[4:])
    return p

def res_walk(d):
    if d[:4] != b"\x01\x00\x01\x14": return None
    if struct.unpack(">I", d[4:8])[0] != len(d) - 8: return None
    out = []; pos = 8
    while pos + 8 <= len(d):
        hdr = d[pos:pos+4]; sz = struct.unpack(">I", d[pos+4:pos+8])[0]
        if sz == 0 or pos + 8 + sz > len(d): return None
        out.append((hdr, d[pos+8:pos+8+sz])); pos += 8 + sz
    return out

def scan(path, label, limit=None):
    d = open(path, "rb").read()
    res = res_walk(d)
    if res is None:
        print(label, "BAD CONTAINER"); return
    s06 = [(h, p) for h, p in res if h[0] == 6]
    s09 = [(h, p) for h, p in res if h[0] == 9]
    print("=" * 70)
    print(label, "styles=%d sts=%d" % (len(s06), len(s09)))
    combo = collections.Counter()
    for i, (h6, p6) in enumerate(s06):
        out = dec(p6)
        namev = out[10] if len(out) > 11 else -1
        pre = out[1] if len(out) > 1 else -1
        # find elem-hdr and TI
        elems = set(); tis = set()
        for pos in range(0, len(out) - 8):
            t = out[pos:pos+4]
            if t[1] == 0 and t[3] == 8 and t[0] in (1, 2) and t[2] in (0, 1):
                sz = int.from_bytes(out[pos+4:pos+8], "big")
                if 0 < sz < 100 and pos + 8 + sz <= len(out):
                    elems.add((t[0], t[2], sz))
            if t[0] == 2 and t[1] == 0 and t[3] == 8 and t[2] >= 2:
                sz = int.from_bytes(out[pos+4:pos+8], "big")
                if sz in (80, 88, 96, 48) and pos + 8 + sz <= len(out):
                    tis.add((t[2], sz))
        h9 = s09[i] if i < len(s09) else (b"", b"")
        out9 = dec(h9[1]) if h9[1] else b""
        mixer = out9[:4].hex(" ") if out9 else "?"
        h9hdr = h9[0].hex(" ") if h9[0] else "?"
        mag = p6[:4].decode("latin1") if p6[:4] in (b"OC31", b"OC32") else "RAW"
        combo[(namev, pre, mag, h9hdr, mixer, tuple(sorted(elems)), tuple(sorted(tis)))] += 1
    for k, c in combo.most_common():
        print("   namev=%02x pre=%02d mag=%-4s h9=%s mix=%s" % (k[0], k[1], k[2], k[3], k[4]))
        print("        elems=%s  TIs=%s   x%d" % (k[5], k[6], c))

T = [
 (r"C:\Users\Baja\Desktop\Pantic Pa1X.SET\STYLE\BANK01_LIVE.STY", "Pantic-Pa1X"),
 (r"C:\Users\Baja\Desktop\BANK01.STY", "Desktop-BANK01"),
 (r"C:\Users\Baja\Desktop\Moduli na PYTHONU\Pa800_System\output\Pa800_os_res_v202\STARTUP\ALL\STYLE\BANK01.STY", "PA800-OS-BANK01"),
 (r"C:\Users\Baja\Desktop\GOLE ARX .SET\GOLE ARX .SET\STYLE\FAVORITE01.STY", "GOLE-FAV01"),
 (r"C:\Users\Baja\Desktop\GOLE ARX .SET\GOLE ARX .SET\STYLE\USER01.STY", "GOLE-USER01"),
 (r"C:\Users\Baja\Desktop\KOCE FOLK.SET\STYLE\FAVORITE01.STY", "KOCE-FAV01"),
 (r"C:\Users\Baja\Desktop\Korg Pa3x Team Serbian.SET\STYLE\USER01.STY", "Pa3X-USER01"),
 (r"C:\Users\Baja\Desktop\Pa4x Pro Dejan Shiki.SET\STYLE\USER01.STY", "Pa4X-USER01"),
 (r"C:\Users\Baja\Desktop\STYLE\USER01_IZOLACIJA.STY", "IZOLACIJA"),
 (r"C:\Users\Baja\Desktop\USER01_PA800.STY", "USER01_PA800(raw)"),
 (r"C:\Users\Baja\Desktop\Nova mapa\Style Works XT Universal\InitKorg\Initpa01.STY", "Init-pa01"),
 (r"C:\Users\Baja\Desktop\Nova mapa\Style Works XT Universal\InitKorg\InitPx01.STY", "Init-Px01"),
 (r"C:\Users\Baja\Desktop\Nova mapa\Style Works XT Universal\InitKorg\InitPx03.STY", "Init-Px03"),
 (r"C:\Users\Baja\Desktop\Nova mapa\Style Works XT Universal\InitKorg\initPx04.STY", "Init-Px04"),
]
for p, l in T:
    try: scan(p, l)
    except Exception as e: print(l, "ERR", repr(e))
