# -*- coding: utf-8 -*-
"""Repair README.md: opt-in stage rows, ordering and encoding artifacts."""
from pathlib import Path

ROOT = Path(r"C:\Users\Baja\Desktop\PA800_SONG_OPTIMIZER_v6_2026-09-26")
path = ROOT / "README.md"
text = path.read_text(encoding="utf-8")
lines = text.splitlines()

# 1. Repair the corrupted paragraph under the pipeline block.
paragraph = (
    "Stepice u zagradama su **opt-in** (default uga\u0161en) pa je podrazumijevani izlaz\n"
    "byte-identi\u010dan referentnoj implementaciji. Kontrole su u GUI-ju (Factory Style\n"
    "element + tri toggle-a) i u CLI-ju: `--style-remap`, `--dynamics`,\n"
    "`--velocity-dynamics`, `--style-element V1..V4 / F1..F2 / I1..I2 / BR / CI / E1..E3`."
)
start = next(i for i, line in enumerate(lines) if line.startswith("Stepice u zagradama"))
end = start
while end < len(lines) and lines[end].strip() and not lines[end].startswith("|"):
    end += 1
lines[start:end] = paragraph.split("\n")

# 2. Rebuild the stage table in pipeline order.
table_start = next(i for i, line in enumerate(lines) if line.startswith("| Stadij |"))
table_end = table_start
while table_end < len(lines) and lines[table_end].startswith("|"):
    table_end += 1

rows = [
    "| Stadij | \u0160ta radi | \u0160ta nikad ne radi |",
    "|---|---|---|",
    "| RESET | bri\u0161e interni processing state (EQ/FX/remap/runtime) | ne dira MIDI |",
    "| MAPPER 2 | provjerava channel contract; prigu\u0161uje CH11 support samo uz validiran evidence packet "
    "| ne bri\u0161e niti preme\u0161ta note |",
    "| DEMO REMAP | najkori\u0161teniji originalni Demo zvukovi, role-safe, hash-verifikovano "
    "| ne preuzima kanal bez kompletnog setupa |",
    "| STYLE PATTERN REMAP | remap Bar pratnje iz Factory style elementa (`style_patterns/registry`) "
    "| ne dira kasniju selector automatiku; CH14\u201316 (lead) nikad |",
    "| REMAP | mijenja jedan kompletni MSB/LSB/PC setup | ne dira kasniju selector automatiku |",
    "| FACTORY INTELLIGENCE | ta\u010dno evidencirani CC91/CC93 setup za showcase uloge "
    "| ne poga\u0111a native A/B/C/D algoritme |",
    "| FACTORY/DEMO DINAMIKA | tick-0 CC 10/11/71/74 (Factory) odn. 7/10/11 (Demo) + evidence velocity pomak "
    "| ne dira CC91/CC93; kanal bez evidence ostaje REVIEW |",
    "| VELOCITY | **passthrough** 1\u2013127 (osim opt-in `--velocity-dynamics`) "
    "| ne klije\u0161ti, ne normalizuje, ne prepravlja |",
    "| VERIFY | replay ledgera + hard lockovi | **BLOCK SAVE** ako je i\u0161ta nedozvoljeno promijenjeno |",
]
lines[table_start:table_end] = rows

text = "\n".join(lines) + ("\n" if text.endswith("\n") else "")

# 3. Structure section: new modules, API route, test count.
if "style_pattern.py" not in text:
    text = text.replace(
        "  factory_intelligence.py",
        "  style_pattern.py      Factory Style Pattern registry (remap + dinamika)\n"
        "  dynamics.py           Factory/Demo tick-0 CC i evidence velocity\n"
        "  factory_intelligence.py",
        1,
    )
if "pipeline_stages()" not in text:
    text = text.replace(
        "  optimizer.py          pipeline orkestrator",
        "  optimizer.py          pipeline orkestrator + pipeline_stages()",
        1,
    )
text = text.replace("/api/sounds /api/status /api/panic", "/api/sounds /api/status /api/elements /api/package /api/panic", 1)
text = text.replace("69 testa", "95 testa")

path.write_text(text, encoding="utf-8")
print("README repaired")

scope = ROOT / "docs" / "V6_SCOPE.md"
scope_text = scope.read_text(encoding="utf-8")
scope_text = scope_text.replace(
    "`pa800/demo_sounds.py` |",
    "`pa800/demo_sounds.py`, `pa800/style_pattern.py`, `pa800/dynamics.py` |",
    1,
)
scope.write_text(scope_text, encoding="utf-8")
print("V6_SCOPE updated")
