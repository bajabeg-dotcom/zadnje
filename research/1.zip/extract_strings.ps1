﻿param(
  [string]$Path = "C:\Users\Baja\Desktop\Nova mapa\KORG PA Manager\v3\KORGPAManager.exe",
  [string]$Out  = "C:\Users\Baja\AppData\Local\Temp\opencode\korgpm_strings.txt"
)
$bytes = [IO.File]::ReadAllBytes($Path)
Write-Host "Bytes: $($bytes.Length)"
$sb = New-Object System.Text.StringBuilder
$max = $bytes.Length
$runStart = -1
for ($i = 0; $i -lt $max; $i++) {
  $b = $bytes[$i]
  if ($b -ge 0x20 -and $b -le 0x7E) {
    if ($runStart -lt 0) { $runStart = $i }
  } else {
    if ($runStart -ge 0 -and ($i - $runStart) -ge 5) {
      $s = [Text.Encoding]::ASCII.GetString($bytes, $runStart, $i - $runStart)
      [void]$sb.AppendLine(("{0:X8}`tASCII`t{1}" -f $runStart, $s))
    }
    $runStart = -1
  }
}
if ($runStart -ge 0 -and ($max - $runStart) -ge 5) {
  $s = [Text.Encoding]::ASCII.GetString($bytes, $runStart, $max - $runStart)
  [void]$sb.AppendLine(("{0:X8}`tASCII`t{1}" -f $runStart, $s))
}
foreach ($shift in 0,1) {
  $runStart = -1
  $i = $shift
  while ($i + 1 -lt $max) {
    $lo = $bytes[$i]; $hi = $bytes[$i+1]
    $ok = ($hi -eq 0 -and $lo -ge 0x20 -and $lo -le 0x7E)
    if ($ok) {
      if ($runStart -lt 0) { $runStart = $i }
      $i += 2
    } else {
      if ($runStart -ge 0 -and ($i - $runStart) -ge 10) {
        $len = $i - $runStart
        $s = [Text.Encoding]::Unicode.GetString($bytes, $runStart, $len)
        [void]$sb.AppendLine(("{0:X8}`tUTF16`t{1}" -f $runStart, $s))
      }
      $runStart = -1
      $i += 2
    }
  }
  if ($runStart -ge 0) {
    $len = (($max - $runStart) - (($max - $runStart) % 2))
    if ($len -ge 10) {
      $s = [Text.Encoding]::Unicode.GetString($bytes, $runStart, $len)
      [void]$sb.AppendLine(("{0:X8}`tUTF16`t{1}" -f $runStart, $s))
    }
  }
}
[IO.File]::WriteAllText($Out, $sb.ToString(), [Text.Encoding]::UTF8)
Write-Host "Done lines: $(($sb.ToString() -split "`n").Count)"
