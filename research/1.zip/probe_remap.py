import io, sys, collections, traceback
sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding="utf-8", errors="replace")
from pathlib import Path

sys.path.insert(0, r"C:\Users\Baja\Desktop\Nova mapa")
from setconvert.conv import convert_sty
from setconvert.detect import fingerprint_sty
from pa800_native.sty_container import parse_bank
import json

DESK = Path(r"C:\Users\Baja\Desktop")
CASES = [
    ("Pa4x Pro Dejan Shiki.SET", "pa4x", ["pa3x", "pa800", "pa1x"]),
    ("Korg Pa3x Team Serbian.SET", "pa3x", ["pa4x", "pa800", "pa1x"]),
    ("Pantic Pa1X.SET", "pa1x", ["pa800", "pa4x"]),
    ("KOCE FOLK.SET", "pa800", ["pa1x", "pa4x"]),
]

for set_name, family, targets in CASES:
    root = DESK / set_name
    stys = sorted(p for p in root.rglob("*") if p.suffix.lower() == ".sty")
    print(f"=== {set_name} [{family}] styles={len(stys)}")
    for sty in stys[:3]:
        data = sty.read_bytes()
        prof = fingerprint_sty(data)
        for target in targets:
            try:
                out, rep = convert_sty(data, target, strict=True)
                parse_bank(out)
                json.dumps(rep.as_dict())
                p = rep.parameters
                s = rep.sts
                print(
                    f"  {sty.name} -> {target}: "
                    f"sel same={p.selector_same + s.selector_same} "
                    f"moved={p.selector_moved + s.selector_moved} "
                    f"missing={p.selector_missing + s.selector_missing} "
                    f"core_moved={p.core_selector_moved} "
                    f"open={len(rep.open_items)} k09skip={rep.kind09_skipped}"
                )
                for oi in rep.open_items[:2]:
                    print(f"      OPEN: {oi[:110]}")
            except Exception as exc:
                print(f"  {sty.name} -> {target}: FAIL {type(exc).__name__}: {exc}")
                traceback.print_exc()
