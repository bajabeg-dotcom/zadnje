import sys, re
sys.stdout.reconfigure(encoding="utf-8", errors="replace")
p = r"C:\Users\Baja\Desktop\Nova mapa\KORG PA Manager\v3\KORGPAManager.exe"
data = open(p, "rb").read()
print("size", len(data))
ascii_pat = re.compile(rb"[\x20-\x7e]{6,}")
keys = ("pa1x","pa2x","pa3x","pa4x","pa5x","pa50","pa60","pa80","pa500","pa600","pa700","pa800","pa900","pa1000","pa300","pa588","pa1x","stversion","sts version","bank0","version","korg pa","arranger","microarranger",".set","set folder")
hits = []
for m in ascii_pat.finditer(data):
    s = m.group().decode("ascii")
    low = s.lower()
    if any(k in low for k in keys):
        hits.append((m.start(), s))
print("ascii hits:", len(hits))
seen = set()
for off, s in hits:
    if s in seen: continue
    seen.add(s)
    if len(s) < 200:
        print(f"  0x{off:07x}  {s}")
