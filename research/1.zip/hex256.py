﻿import os, glob, struct
d = r"C:\Users\Baja\Desktop\Nova mapa\Style Works XT Universal\InitKorg"
def hd(data, base=0, width=16):
    lines=[]
    for i in range(0, len(data), width):
        chunk=data[i:i+width]
        hexs=' '.join('%02X'%b for b in chunk)
        asc=''.join(chr(b) if 32<=b<127 else '.' for b in chunk)
        lines.append('%08X  %-47s  |%s|'%(base+i, hexs, asc))
    return '\n'.join(lines)
targets = ["INIT_I30.ARR","INIT_I30.GBL","INIT_I30.PRG","Init_i3.pcg","Init_i3.sng",
           "INIT_I30.KBS","INIT_I30.BSQ","INIT_I30.ARG","INIT_I30.ARK"]
for t in targets:
    f=os.path.join(d,t)
    if not os.path.exists(f):
        print("MISSING",t); continue
    data=open(f,'rb').read()
    print("="*100); print(t,"size",len(data)); print("-"*100)
    print(hd(data[:256]))
