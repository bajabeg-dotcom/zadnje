﻿import sys, struct, collections
sys.stdout.reconfigure(encoding="utf-8", errors="replace")
d = open(r"C:\Users\Baja\Desktop\USER01_PA800.STY", "rb").read()
pos = 8
mags = collections.Counter()
i = 0
while pos + 8 <= len(d):
    hdr = d[pos:pos+4]
    sz = struct.unpack(">I", d[pos+4:pos+8])[0]
    mags[(hdr[0], d[pos+8:pos+12])] += 1
    pos += 8 + sz
    i += 1
for k in sorted(mags): print(k[0], k[1], mags[k])
