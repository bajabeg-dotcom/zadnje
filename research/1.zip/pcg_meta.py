import sys, io, os, glob, collections
sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding='utf-8', errors='replace', line_buffering=True)
sys.path.insert(0, r'C:\Users\Baja\Desktop\Nova mapa')
from pa800_native.sty_container import parse_bank

files = sorted(glob.glob(r'C:\Users\Baja\Desktop\**\*.pcg', recursive=True))
hist = collections.Counter()
b17 = collections.Counter(); b18 = collections.Counter()
b21_23 = collections.Counter()
weird = []
total = 0
for p in files:
    try:
        bank = parse_bank(open(p, 'rb').read())
    except Exception:
        continue
    k5 = [r for r in bank.resources if r.kind == 5]
    if not k5 or k5[0].header[1] != 0:
        continue
    pay = k5[0].payload
    if len(pay) % 24:
        print('not multiple of 24:', p, len(pay)); continue
    for i in range(len(pay) // 24):
        r = pay[i*24:(i+1)*24]
        total += 1
        hist[r[16]] += 1
        b17[r[17]] += 1
        b18[r[18]] += 1
        b21_23[r[21:24]] += 1
        if r[16] != 0:
            weird.append((os.path.relpath(p, r'C:\Users\Baja\Desktop'), i, r[:16].split(b'\x00')[0].decode('latin1'), r[16:24].hex(' ')))
print(f'total fixed records={total}')
print('byte16 hist:', dict(sorted(hist.items())))
print('byte17 hist:', dict(sorted(b17.items())))
print('byte18 hist:', dict(sorted(b18.items())))
print('bytes21:24 hist:', dict(b21_23.most_common(8)))
print(f'\nrecords with byte16 != 0: {len(weird)}')
for w in weird[:25]:
    print('   ', w)
# ROM.PCG size check
for p in files:
    if p.upper().endswith('ROM.PCG'):
        try:
            bank = parse_bank(open(p, 'rb').read())
        except Exception as e:
            continue
        k5 = [r for r in bank.resources if r.kind == 5]
        if k5 and k5[0].header[1] == 0:
            pay = k5[0].payload
            print(f'\n{os.path.relpath(p, r"C:\Users\Baja\Desktop")}: kind5 len={len(pay)} records={len(pay)/24} hdr={k5[0].header.hex(" ")}')
            i = 249
            r = pay[i*24:(i+1)*24]
            print(f'  rec249={r.hex(" ")} name={r[:16].split(bchr)[0]!r}' if False else f'  rec249={r.hex(" ")} name={r[:16].split(bytes([0]))[0]!r}')
