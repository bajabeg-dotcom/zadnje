﻿import sys, os
sys.stdout.reconfigure(encoding="utf-8", errors="replace")
base = r"C:\Users\Baja\Desktop\Nova mapa (6)"
for f in [r"pa800_style_converter\core.py", r"pa800_style_converter\cli.py", r"pa800_manager\ir.py", r"pa800_manager\container.py", r"pa800_manager\oc3x.py"]:
    p = os.path.join(base, f)
    st = os.stat(p)
    print("==", f, st.st_size, "bytes")
    with open(p, "r", encoding="utf-8", errors="replace") as fh:
        lines = fh.readlines()
    print("   lines:", len(lines))
    # print module docstring + first 40 lines
    for i, l in enumerate(lines[:45]):
        print("   %3d| %s" % (i+1, l.rstrip("\n")))
