PA800 GOLD KORPUS -- tvoja provjerena MIDI baza
====================================================

MIDI pjesama : 817 (.mid)
Karaoke      : 13 (.kar)
Ostalo       : 1 (manifest)
Ukupno       : 831 fajla

STA JE OVO
  Materijal koji si sam izdvojio kao GOLD (provjereno dobro).
  Program ga koristi kao dokaz: kako pjesma stvarno svira --
  opseg po tipu instrumenta, velocity, duzina nota, gustoca.

KAKO SE KORISTI
  1) raspakuj ovaj zip u npr. C:\GOLD
  2) u programskoj mapi pokreni:
       python -m pa800_midi index gold C:\GOLD
     (upise pa800_midi\data\gold_index.json)
  3) provjeri pravila opsega:
       python -m pa800_midi key-range
  4) onda normalno radis:
       python -m pa800_midi optimize "pjesma.mid"

GOLD_INDEX.json u ovom zipu je gotovo mjerenje istog korpusa:
  - types : po tipu instrumenta -- svirano naspram pravila,
            koliko nota i u koliko pjesama prelazi granicu
  - profiles : po roli (bas, bubnjevi, gitara...) velocity/gate

PRAVILO OPSEGA (Key Range)
  Redoslijed: tvoje pravilo > izmjereni profil zvuka >
  pravilo po tipu instrumenta > bez tvrdnje.
  Izmjereni profil (npr. Finger Bass RX 28-60) je konkretan dokaz
  za taj zvuk i uvijek je jaci od opcenitog pravila po tipu.
  Tvoje pravilo:  --key-range "guitar=D2-E6"
  Samo osnova:   --key-range-strict

  Key Range je HARD LIMIT: program samo prijavi KEY_RANGE_CONFLICT,
  nikad ne pomjera ni jednu notu. Note-on tick i visina su sveti.

Izvor: C:\Users\Baja\Desktop\Midi Bazaa (selection_manifest.json)
