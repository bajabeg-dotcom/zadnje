PA800 FACTORY REFERENCE: STYLES, PATTERNS AND PADS
===================================================

STYLE contains the factory style banks. The patterns are embedded inside the .STY resources; there are no separate pattern files in this corpus.

PAD contains the factory PAD banks.
PERFORM contains a representative .PRF file.
SOUND contains ROM.PCG.
MULTISMP contains ROM.KMP.
DRAWBARS contains KMP/DWB drawbar references.

USER01.DK was not present in the available factory corpus and has not been fabricated.
