#!/usr/bin/env python3
"""Build song-specific native Korg Pa800 Style banks from the VALJA MIDI set.

The builder keeps every Variation/Fill/Break/Ending from a verified optimized
base Style and replaces Intro 1 with the complete pre-vocal MIDI arrangement.
Intro patterns are fixed-transpose (the same native NTT/NTR mode used by the
song intros in USER02), run at PPQ 384, and use one native Pattern per active
Pa800 track.  All output banks are reopened and every Pattern event stream is
parsed before acceptance.
"""
from __future__ import annotations

from collections import defaultdict, deque, Counter
from dataclasses import dataclass
from fractions import Fraction
from pathlib import Path
import csv
import difflib
import hashlib
import json
import math
import re
import statistics
import sys
import unicodedata

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "PA800_Native_Style_Editor"))

from pa800_editor.codec import walk_children, _be32, encode_oc  # noqa: E402
from pa800_editor.events import parse_pattern_stream  # noqa: E402
from pa800_editor.model import (  # noqa: E402
    CompressedResource, NativeStyleBank, ROLES, StyleResource, ModelError,
)
from pa800_editor.transplant import ElementGraph, _pattern_graph  # noqa: E402
from midi_inventory import parse_file  # noqa: E402

PPQ_NATIVE = 384
INPUT_DIR = ROOT / "valja_work" / "input"
BOUNDARIES_PATH = ROOT / "valja_work" / "intro_boundaries.json"
MANIFEST_PATH = ROOT / "valja_work" / "VALJA_SONG_STYLE_MANIFEST.csv"
BASE_USER_PATH = ROOT / "zaarenu_work" / "output" / "USER01_ARENA_FACTORY_ENHANCED.STY"
BASE_USER02_PATH = ROOT / "zaarenu_work" / "output" / "USER02_ARENA_PA3X_REPAIR.STY"
USER_TEMPLATE = ROOT / "zaarenu_work" / "output" / "USER01_ARENA_LIVE_OPT.STY"
FAVORITE_TEMPLATE = ROOT / "inspect_pa" / "stylecorpus" / "FAVORITE01.STY"
OUTPUT_DIR = ROOT / "valja_work" / "output"

BANKS = [
    ("USER01.STY", 0x11, "user"),
    ("USER02.STY", 0x12, "user"),
    ("USER03.STY", 0x13, "user"),
    ("FAVORITE01.STY", 0x14, "favorite"),
    ("FAVORITE02.STY", 0x15, "favorite"),
    ("FAVORITE03.STY", 0x16, "favorite"),
]


@dataclass
class Note:
    start: int
    end: int
    pitch: int
    velocity: int
    channel: int


@dataclass
class Lane:
    role: int
    channels: list[int]
    primary_channel: int
    program: int
    notes: list[Note]
    controls: list[tuple[int, int, int]]
    bends: list[tuple[int, int, int]]
    target_velocity: float
    velocity_scale: float = 1.0


@dataclass
class BuiltStyle:
    name: str
    full_title: str
    midi_file: str
    style_data: bytes
    companion_data: bytes
    base_name: str
    base_source: str
    bpm: float
    meter: tuple[int, int]
    intro_bars: int
    intro_ticks: int
    lane_summary: dict
    patterns: int
    events: int
    is_base: bool = False


def ascii_name(value: str, limit: int = 16) -> str:
    value = unicodedata.normalize("NFKD", value).encode("ascii", "ignore").decode()
    value = re.sub(r"[^A-Za-z0-9 &+._/-]+", "", value)
    value = re.sub(r"\s+", " ", value).strip()
    return (value[:limit].rstrip() or "SONG")


def normalized(value: str) -> str:
    value = unicodedata.normalize("NFKD", value).encode("ascii", "ignore").decode().lower()
    return re.sub(r"[^a-z0-9]", "", value)


def song_title(filename: str) -> str:
    value = re.sub(r"\.enhanced\.mid$|\.mid$", "", filename, flags=re.I).replace("_", " ")
    value = re.sub(r"\s*\)\s*$", "", value).strip()
    if " - " in value:
        value = value.split(" - ")[0]
    return re.sub(r"\s+", " ", value).strip(" '-_$")


def unique_names(titles: list[str]) -> list[str]:
    used: set[str] = set()
    result = []
    for title in titles:
        base = ascii_name(title)
        name = base
        serial = 2
        while name.lower() in used:
            suffix = f"~{serial}"
            name = ascii_name(base[:16-len(suffix)] + suffix)
            serial += 1
        used.add(name.lower())
        result.append(name)
    return result


def delta_bytes(value: int) -> bytes:
    """Native PA800 delta: a VLQ whose delta bytes all carry bit 7."""
    if value < 0:
        raise ValueError("negative delta")
    if value == 0:
        return b""
    chunks = [value & 0x7F]
    value >>= 7
    while value:
        chunks.append(value & 0x7F)
        value >>= 7
    return bytes((part | 0x80) for part in reversed(chunks))


def encode_native_events(duration: int, notes: list[Note], controls: list[tuple[int, int, int]],
                         bends: list[tuple[int, int, int]], velocity_scale: float) -> tuple[bytes, int]:
    events: list[tuple[int, int, int, tuple[int, int]]] = []
    for note in notes:
        start = max(0, min(duration - 1, note.start)) if duration else 0
        end = max(start + 1, min(duration, note.end))
        velocity = max(1, min(127, round(note.velocity * velocity_scale)))
        events.append((start, 2, 1, (note.pitch, velocity)))
        events.append((end, 1, 0, (note.pitch, 64)))
    for tick, controller, value in controls:
        if 0 <= tick < duration:
            events.append((tick, 0, 3, (controller, value)))
    for tick, lsb, msb in bends:
        if 0 <= tick < duration:
            events.append((tick, 0, 6, (lsb, msb)))
    # Controller first, note-off second and note-on last gives deterministic
    # retriggering when an old note and a new note meet on the same tick.
    events.sort(key=lambda item: (item[0], item[1], item[2], item[3]))
    out = bytearray()
    previous = 0
    for tick, _priority, opcode, data in events:
        out.extend(delta_bytes(tick - previous))
        out.append(opcode)
        out.append(data[0] & 0x7F)
        out.append((data[1] & 0x7F) | 0x80)
        previous = tick
    out.extend(delta_bytes(duration - previous))
    out.extend(b"\x09\x2f\x00\x00")
    parsed = parse_pattern_stream(out, duration)
    return bytes(out), len(parsed)


def native_tick(tick: int, origin: int, ppq: int) -> int:
    return max(0, round(Fraction((tick - origin) * PPQ_NATIVE, ppq)))


def pair_midi_notes(parsed: dict) -> tuple[dict[int, list[Note]], dict[int, list[tuple]], dict[int, int]]:
    notes: dict[int, list[Note]] = defaultdict(list)
    channel_events: dict[int, list[tuple]] = defaultdict(list)
    programs: dict[int, list[tuple[int, int]]] = defaultdict(list)
    active: dict[tuple[int, int], deque[tuple[int, int]]] = defaultdict(deque)
    last_tick = 0
    merged = []
    for track in parsed["tracks"]:
        merged.extend(track)
    merged.sort(key=lambda event: event[0])
    for tick, kind, code, payload in merged:
        last_tick = max(last_tick, tick)
        if kind != "midi":
            continue
        typ, channel = code
        channel_events[channel].append((tick, typ, bytes(payload)))
        if typ == 0xC:
            programs[channel].append((tick, payload[0]))
        elif typ == 0x9 and payload[1] > 0:
            active[(channel, payload[0])].append((tick, payload[1]))
        elif typ == 0x8 or (typ == 0x9 and payload[1] == 0):
            queue = active[(channel, payload[0])]
            if queue:
                start, velocity = queue.popleft()
                notes[channel].append(Note(start, max(start + 1, tick), payload[0], velocity, channel))
    fallback = max(1, parsed["division"] // 4)
    for (channel, pitch), queue in active.items():
        while queue:
            start, velocity = queue.popleft()
            notes[channel].append(Note(start, min(last_tick, start + fallback), pitch, velocity, channel))
    initial_program: dict[int, int] = {}
    for channel, changes in programs.items():
        initial_program[channel] = changes[0][1]
    return notes, channel_events, initial_program


def program_at(events: list[tuple], tick: int, fallback: int = 0) -> int:
    result = fallback
    for at, typ, payload in events:
        if at > tick:
            break
        if typ == 0xC:
            result = payload[0]
    return result


def signature(notes: list[Note], start: int, end: int) -> set[tuple[int, int]]:
    return {(n.start, n.pitch) for n in notes if start <= n.start < end}


def similarity(a: set[tuple[int, int]], b: set[tuple[int, int]]) -> float:
    if not a or not b:
        return 0.0
    return len(a & b) / max(1, min(len(a), len(b)))


def melodic_relation(a: list[Note], b: list[Note], start: int, end: int) -> float:
    """Detect copied, delayed or harmonized lead layers.

    Karaoke files commonly carry the same solo on several MIDI channels: one
    exact copy, one beat-delayed copy and a third line transposed in parallel.
    Comparing absolute onset/pitch pairs misses those layers, so compare the
    melodic interval contour and inter-onset contour instead.
    """
    aa = sorted((n for n in a if start <= n.start < end), key=lambda n: (n.start, n.pitch))
    bb = sorted((n for n in b if start <= n.start < end), key=lambda n: (n.start, n.pitch))
    if min(len(aa), len(bb)) < 5 or min(len(aa), len(bb)) / max(len(aa), len(bb)) < 0.65:
        return 0.0
    pa = [n.pitch for n in aa]; pb = [n.pitch for n in bb]
    ia = [max(-24, min(24, pa[i+1] - pa[i])) for i in range(len(pa)-1)]
    ib = [max(-24, min(24, pb[i+1] - pb[i])) for i in range(len(pb)-1)]
    ta = [aa[i+1].start - aa[i].start for i in range(len(aa)-1)]
    tb = [bb[i+1].start - bb[i].start for i in range(len(bb)-1)]
    pitch_score = difflib.SequenceMatcher(None, ia, ib, autojunk=False).ratio()
    time_score = difflib.SequenceMatcher(None, ta, tb, autojunk=False).ratio()
    return 0.72 * pitch_score + 0.28 * time_score


def extract_lanes(midi_path: Path, boundary: dict, velocity_targets: dict[int, float]) -> tuple[list[Lane], dict]:
    parsed = parse_file(midi_path)
    ppq = parsed["division"]
    meter = tuple(boundary["meter"])
    origin = int(boundary["music_start"])
    lyric = int(boundary["lyric_tick"])
    bar_midi = Fraction(ppq * 4 * meter[0], meter[1])
    relative = Fraction(max(0, lyric - origin), 1)
    bars = max(1, math.ceil(relative / bar_midi))
    section_end = origin + int(bar_midi * bars)
    bar_native = PPQ_NATIVE * 4 * meter[0] // meter[1]
    duration = bar_native * bars

    all_notes, channel_events, initial_programs = pair_midi_notes(parsed)
    in_intro = {ch: [n for n in values if origin <= n.start < section_end]
                for ch, values in all_notes.items()}
    in_intro = {ch: values for ch, values in in_intro.items() if values}
    lead_channel = 0 if 0 in in_intro else None
    if lead_channel is None:
        melodic = [(len(values), ch) for ch, values in in_intro.items() if ch not in (1, 9)]
        lead_channel = max(melodic, default=(0, 0))[1]

    skipped_duplicates: list[int] = []
    lead_layers = [lead_channel]
    lead_notes = in_intro.get(lead_channel, [])
    lead_sig = signature(lead_notes, origin, lyric)
    candidates = [ch for ch in in_intro if ch not in (9, 1, lead_channel)]
    lead_onsets = {n.start for n in lead_notes if origin <= n.start < lyric}
    for ch in list(candidates):
        exact = similarity(lead_sig, signature(in_intro[ch], origin, lyric))
        contour = melodic_relation(lead_notes, in_intro[ch], origin, lyric)
        channel_onsets = {n.start for n in in_intro[ch] if origin <= n.start < lyric}
        onset_match = (len(lead_onsets & channel_onsets) / max(1, min(len(lead_onsets), len(channel_onsets))))
        if exact >= 0.82 or contour >= 0.82 or onset_match >= 0.88:
            # Keep all melody/harmony/echo notes, but keep them together on the
            # isolated Acc5 solo lane instead of leaking them into accompaniment.
            lead_layers.append(ch)
            candidates.remove(ch)

    # Seed the standardized arranger roles first, then use measured activity.
    seeds: list[int] = []
    for preferred in (7, 2):
        if preferred in candidates:
            seeds.append(preferred)
            candidates.remove(preferred)
    candidates.sort(key=lambda ch: (-len(in_intro[ch]), ch))
    while candidates and len(seeds) < 4:
        channel = candidates.pop(0)
        # Avoid allocating a second lane to an almost exact duplicate layer.
        if any(similarity(signature(in_intro[channel], origin, section_end),
                          signature(in_intro[s], origin, section_end)) >= 0.90 for s in seeds):
            skipped_duplicates.append(channel)
        else:
            seeds.append(channel)
    groups: list[list[int]] = [[ch] for ch in seeds]
    # Fold remaining non-duplicate layers into the closest GM family so their
    # notes survive even though Pa800 offers only four accompaniment lanes.
    for channel in candidates:
        if not groups:
            break
        program = program_at(channel_events[channel], origin, initial_programs.get(channel, 0))
        target = min(range(len(groups)), key=lambda i: (
            abs(program_at(channel_events[groups[i][0]], origin,
                           initial_programs.get(groups[i][0], 0)) // 8 - program // 8),
            sum(len(in_intro[ch]) for ch in groups[i]),
        ))
        groups[target].append(channel)

    role_channels: dict[int, list[int]] = {}
    if 9 in in_intro:
        role_channels[0] = [9]
    if 1 in in_intro:
        role_channels[2] = [1]
    for role, channels in zip((3, 4, 5, 6), groups):
        role_channels[role] = channels
    if lead_channel in in_intro:
        role_channels[7] = lead_layers

    lanes: list[Lane] = []
    for role in sorted(role_channels):
        channels = role_channels[role]
        primary = channels[0]
        lane_end = lyric if role == 7 else section_end
        selected: list[Note] = []
        for channel in channels:
            for note in all_notes[channel]:
                if origin <= note.start < lane_end:
                    selected.append(Note(
                        native_tick(note.start, origin, ppq),
                        max(native_tick(min(note.end, lane_end), origin, ppq),
                            native_tick(note.start, origin, ppq) + 1),
                        note.pitch, note.velocity, channel,
                    ))
        selected.sort(key=lambda n: (n.start, n.pitch, n.channel))
        # Remove byte-identical doubled notes after multiple channels are merged.
        dedup: dict[tuple[int, int, int], Note] = {}
        for note in selected:
            key = (note.start, note.end, note.pitch)
            if key not in dedup or note.velocity > dedup[key].velocity:
                dedup[key] = note
        selected = sorted(dedup.values(), key=lambda n: (n.start, n.pitch))

        controls: list[tuple[int, int, int]] = []
        bends: list[tuple[int, int, int]] = []
        for tick, typ, payload in channel_events[primary]:
            if not origin <= tick < lane_end:
                continue
            at = native_tick(tick, origin, ppq)
            if typ == 0xB and payload[0] in (1, 11, 64):
                controls.append((at, payload[0], payload[1]))
            elif typ == 0xE:
                bends.append((at, payload[0], payload[1]))
        # Deterministic de-duplication of controller events.
        controls = sorted(set(controls))
        bends = sorted(set(bends))
        program = program_at(channel_events[primary], origin, initial_programs.get(primary, 0))
        mean_velocity = statistics.mean(n.velocity for n in selected) if selected else 90.0
        target = velocity_targets.get(role, 92.0 if role >= 3 else mean_velocity)
        scale = max(0.75, min(1.25, target / max(1.0, mean_velocity)))
        lanes.append(Lane(role, channels, primary, program, selected, controls, bends, target, scale))

    report = {
        "ppq_source": ppq,
        "music_start_tick": origin,
        "lyric_tick": lyric,
        "normalized_end_tick": section_end,
        "intro_bars_normalized": bars,
        "intro_ticks_native": duration,
        "lead_channel": lead_channel,
        "lead_layer_channels": lead_layers,
        "skipped_duplicate_channels": sorted(set(skipped_duplicates)),
        "lanes": [
            {"role": ROLES[l.role], "channels": l.channels, "primary_channel": l.primary_channel,
             "gm_program": l.program, "notes": len(l.notes), "controls": len(l.controls),
             "bends": len(l.bends), "velocity_scale": round(l.velocity_scale, 4)}
            for l in lanes
        ],
    }
    return lanes, report


def style_tempo(style: StyleResource) -> int:
    node = walk_children(style.data)[0]
    payload = style.data[node.offset+8:node.end]
    length = payload[0]
    return payload[1 + length]


def nominal_style_tempo(style: StyleResource) -> int:
    """Use an explicit tempo in the Style name when converted metadata is stale."""
    values = [int(value) for value in re.findall(r"(?<!\d)(\d{2,3})(?!\d)", style.name)]
    values = [value for value in values if 40 <= value <= 220]
    return values[-1] if values else max(1, style_tempo(style))


def role_velocity_targets(style: StyleResource) -> dict[int, float]:
    roles = style.pattern_role_map()
    pool = walk_children(style.data, style.pattern_pool.offset)[1:]
    values: dict[int, list[int]] = defaultdict(list)
    for index, node in enumerate(pool, start=1):
        start = node.offset + 8
        duration = _be32(style.data, start)
        length = _be32(style.data, start + 4)
        try:
            events = parse_pattern_stream(style.data[start+8:start+8+length], duration)
        except Exception:
            continue
        velocities = [e.velocity for e in events if e.opcode == 1 and e.velocity]
        for role in roles.get(index, set()):
            values[role].extend(velocities)
    return {role: statistics.median(v) for role, v in values.items() if v}


def midi_drum_profile(path: Path, boundary: dict) -> list[float]:
    parsed = parse_file(path)
    ppq = parsed["division"]
    origin = boundary["music_start"]
    start = boundary["lyric_tick"]
    meter = tuple(boundary["meter"])
    bar = Fraction(ppq * 4 * meter[0], meter[1])
    bins = [0.0] * 64
    groups = ((35, 36), (38, 40), (42, 44, 46), tuple(range(37, 82)))
    events = []
    for track in parsed["tracks"]:
        for tick, kind, code, payload in track:
            if kind == "midi" and code == (0x9, 9) and payload[1] > 0 and start <= tick < start + int(bar * 16):
                events.append((tick, payload[0], payload[1]))
    for tick, pitch, velocity in events:
        phase = Fraction(tick - origin, 1) % bar
        step = min(15, int(phase * 16 / bar))
        group = 3
        for i, pitches in enumerate(groups[:3]):
            if pitch in pitches:
                group = i
                break
        bins[group * 16 + step] += velocity / 127.0
    norm = math.sqrt(sum(v*v for v in bins))
    return [v / norm for v in bins] if norm else bins


def style_drum_profile(style: StyleResource) -> list[float]:
    graph = _pattern_graph(style)[3]
    role_map = style.pattern_role_map()
    pool = walk_children(style.data, style.pattern_pool.offset)[1:]
    refs = []
    for element_index in (0, 1, 2, 3):
        refs.extend(graph.get(element_index, ElementGraph(b"", [], 0)).refs)
    bins = [0.0] * 64
    for index in refs:
        if 0 not in role_map.get(index, set()):
            continue
        node = pool[index-1]
        start = node.offset + 8
        duration = _be32(style.data, start)
        length = _be32(style.data, start+4)
        for event in parse_pattern_stream(style.data[start+8:start+8+length], duration):
            if event.opcode != 1 or not event.velocity or event.pitch is None:
                continue
            # All 4/4 candidates are phase-compared on a 1536-tick bar.
            step = int((event.tick % 1536) * 16 / 1536) % 16
            pitch = event.pitch
            group = 0 if pitch in (35, 36) else 1 if pitch in (38, 40) else 2 if pitch in (42, 44, 46) else 3
            bins[group*16+step] += event.velocity / 127.0
    norm = math.sqrt(sum(v*v for v in bins))
    return [v / norm for v in bins] if norm else bins


def choose_base(title: str, midi_path: Path, boundary: dict, user: NativeStyleBank,
                user02: NativeStyleBank, style_profiles: dict[int, list[float]]) -> tuple[NativeStyleBank, int, dict]:
    meter = tuple(boundary["meter"])
    bpm = 120.0
    parsed = parse_file(midi_path)
    tempos = []
    for track in parsed["tracks"]:
        for tick, kind, code, payload in track:
            if kind == "meta" and code == 0x51 and len(payload) == 3:
                tempos.append((tick, 60_000_000 / int.from_bytes(payload, "big")))
    if tempos:
        bpm = min(tempos)[1]

    # Song-tailored USER02 gets priority only on a high-confidence title match.
    title_norm = normalized(title)
    matches = [(difflib.SequenceMatcher(None, title_norm, normalized(e.style.name)).ratio(), e.ordinal)
               for e in user02.entries]
    ratio, match_index = max(matches, default=(0.0, 0))
    if ratio >= 0.86:
        return user02, match_index, {"method": "song-title", "score": round(ratio, 4)}
    if meter == (7, 8):
        return user, 7, {"method": "meter", "score": 1.0}
    if meter == (9, 8):
        return user, 6, {"method": "meter", "score": 1.0}
    if meter == (6, 8):
        # The repaired USER02 Okuj style is the proven song-specific 6/8 base.
        idx = next((e.ordinal for e in user02.entries if "okuj" in normalized(e.style.name)), 1)
        return user02, idx, {"method": "meter+song-family", "score": 1.0}

    profile = midi_drum_profile(midi_path, boundary)
    candidates = [i for i in range(len(user.entries)) if i not in (6, 7)]
    scored = []
    for index in candidates:
        style = user.entries[index].style
        cosine = sum(a*b for a, b in zip(profile, style_profiles[index]))
        nominal = nominal_style_tempo(style)
        tempo_ratio = abs(math.log2(max(1.0, bpm) / max(1.0, nominal)))
        # Groove remains the primary cue, but a Style designed far from the
        # song tempo is audibly inferior even when its onset histogram matches.
        score = cosine - 0.55 * min(1.5, tempo_ratio)
        scored.append((score, cosine, tempo_ratio, index))
    score, cosine, tempo_ratio, index = max(scored)
    return user, index, {"method": "meter+drum-groove+tempo", "score": round(score, 4),
                         "drum_cosine": round(cosine, 4), "tempo_octaves": round(tempo_ratio, 4),
                         "nominal_base_bpm": nominal_style_tempo(user.entries[index].style)}


def pattern_streams_for_lanes(lanes: list[Lane], duration: int) -> tuple[dict[int, bytes], int]:
    result = {}
    event_count = 0
    for lane in lanes:
        if not lane.notes and not lane.controls and not lane.bends:
            continue
        stream, count = encode_native_events(duration, lane.notes, lane.controls, lane.bends, lane.velocity_scale)
        result[lane.role] = stream
        event_count += count
    return result, event_count


def replace_intro(style_data: bytes, streams: dict[int, bytes], lanes: list[Lane], duration: int) -> bytes:
    resource = CompressedResource(6, bytearray(style_data), "OC31", style_data, b"")
    style = StyleResource(resource, 0)
    t_info, t_suffix, t_patterns, t_elements = _pattern_graph(style)
    if 4 not in t_elements:
        raise ModelError(f"{style.name}: optimized base lacks Intro 1")
    old = t_elements[4].raw
    children = walk_children(old)
    if len(children) < 3:
        raise ModelError("Intro 1 lacks CV template")

    info = children[0]
    info_raw = bytearray(old[info.offset:info.end])
    info_raw[8] = 1  # exactly one Chord Variation

    track = children[1]
    track_raw = bytearray(old[track.offset:track.end])
    if track.length < 80:
        raise ModelError("song Intro requires native v4/v5 TrackData")
    lane_by_role = {lane.role: lane for lane in lanes}
    for role in range(8):
        track_raw[8 + 72 + role] = 3  # fixed/no-transpose song-intro mode, proven in USER02
        if role in lane_by_role and lane_by_role[role].notes:
            pitches = [n.pitch for n in lane_by_role[role].notes]
            p = 8 + role * 6
            track_raw[p+4] = max(0, min(pitches))
            track_raw[p+5] = min(127, max(pitches))
    # Use the verified Pa800 RX drum kit and a GM-compatible Pa sound for the
    # isolated solo lane. Accompaniment selectors stay inherited from base.
    if 0 in streams:
        track_raw[8+1:8+4] = bytes((120, 0, 4))
    if 7 in lane_by_role:
        p = 8 + 7*6
        track_raw[p+1:p+4] = bytes((121, 0, lane_by_role[7].program & 0x7F))
        track_raw[p] = max(96, track_raw[p])

    new_patterns = list(t_patterns)
    refs: list[int] = []
    tail_pairs = bytearray()
    active_roles = sorted(streams)
    for role in active_roles:
        stream = streams[role]
        ident = 2 if role in (0, 1) else 3 if role == 2 else 4
        suffix = b"" if role in (0, 1) else b"\x07\x09"
        payload = duration.to_bytes(4, "big") + len(stream).to_bytes(4, "big") + stream + suffix
        raw = bytes((ident, 0, 0, 8)) + len(payload).to_bytes(4, "big") + payload
        new_patterns.append(raw)
        refs.append(len(new_patterns))
        tail_pairs.extend((ident - 2, role))

    cv_stream = bytearray()
    for local in range(len(refs)):
        cv_stream.extend((9, 0x7E, 0, 4, 3, local, 0, 0))
    cv_stream.extend(delta_bytes(duration))
    cv_stream.extend((9, 0x2F, 0, 0))
    cv_payload = (duration.to_bytes(4, "big") + len(cv_stream).to_bytes(4, "big") +
                  bytes(cv_stream) + bytes((len(refs),)) + bytes(tail_pairs))
    cv_template = children[2]
    cv_raw = old[cv_template.offset:cv_template.offset+4] + len(cv_payload).to_bytes(4, "big") + cv_payload
    element_body = bytes(info_raw) + bytes(track_raw) + cv_raw
    element_raw = old[:4] + len(element_body).to_bytes(4, "big") + element_body

    final_elements = dict(t_elements)
    final_elements[4] = ElementGraph(element_raw, refs, 0)
    ordered = sorted(final_elements)

    # Prune patterns that became orphaned when the original Intro 1 graph was
    # replaced, then remap every BE16 association deterministically.
    used_order: list[int] = []
    seen: set[int] = set()
    for index in ordered:
        for ref in final_elements[index].refs:
            if ref not in seen:
                seen.add(ref)
                used_order.append(ref)
    mapping = {old_index: new_index+1 for new_index, old_index in enumerate(used_order)}
    patterns = [new_patterns[index-1] for index in used_order]
    all_refs: list[int] = []
    for index in ordered:
        final_elements[index].refs = [mapping[ref] for ref in final_elements[index].refs]
        all_refs.extend(final_elements[index].refs)

    old_info_raw = bytes(style.data[t_info.offset:t_info.end])
    info_payload = (len(patterns).to_bytes(2, "big") + len(all_refs).to_bytes(2, "big") +
                    b"".join(ref.to_bytes(2, "big") for ref in all_refs) + t_suffix)
    pattern_info_raw = old_info_raw[:4] + len(info_payload).to_bytes(4, "big") + info_payload
    old_pool_raw = bytes(style.data[style.pattern_pool.offset:style.pattern_pool.end])
    pool_body = pattern_info_raw + b"".join(patterns)
    pool_raw = old_pool_raw[:4] + len(pool_body).to_bytes(4, "big") + pool_body

    root = walk_children(style.data)
    style_info_raw = bytes(style.data[root[0].offset:root[0].end])
    root_body = style_info_raw + pool_raw + b"".join(final_elements[i].raw for i in ordered)
    rebuilt = bytes(style.data[:4]) + len(root_body).to_bytes(4, "big") + root_body
    check = StyleResource(CompressedResource(6, bytearray(rebuilt), "OC31", rebuilt, b""), 0)
    check.validate_events()
    return rebuilt


def rename_and_tempo(style_data: bytes, name: str, bpm: float) -> bytes:
    resource = CompressedResource(6, bytearray(style_data), "OC31", style_data, b"")
    style = StyleResource(resource, 0)
    root = walk_children(style.data)
    info = root[0]
    payload = bytes(style.data[info.offset+8:info.end])
    old_length = payload[0]
    rest = bytearray(payload[1+old_length:])
    if not rest:
        raise ModelError("StyleInfo has no tempo byte")
    rest[0] = max(20, min(250, round(bpm)))
    encoded = ascii_name(name).encode("latin-1")
    new_payload = bytes((len(encoded),)) + encoded + bytes(rest)
    new_info = bytes(style.data[info.offset:info.offset+4]) + len(new_payload).to_bytes(4, "big") + new_payload
    body = new_info + b"".join(bytes(style.data[node.offset:node.end]) for node in root[1:])
    rebuilt = bytes(style.data[:4]) + len(body).to_bytes(4, "big") + body
    check = StyleResource(CompressedResource(6, bytearray(rebuilt), "OC31", rebuilt, b""), 0)
    if check.name != ascii_name(name):
        raise ModelError("Style rename verification failed")
    check.validate_events()
    return rebuilt


def midi_bpm(path: Path) -> float:
    parsed = parse_file(path)
    values = []
    for track in parsed["tracks"]:
        for tick, kind, code, payload in track:
            if kind == "meta" and code == 0x51 and len(payload) == 3:
                values.append((tick, 60_000_000 / int.from_bytes(payload, "big")))
    return min(values)[1] if values else 120.0


def build_song(midi_path: Path, title: str, name: str, boundary: dict,
               base_bank: NativeStyleBank, base_index: int, match: dict) -> BuiltStyle:
    base_entry = base_bank.entries[base_index]
    targets = role_velocity_targets(base_entry.style)
    lanes, lane_report = extract_lanes(midi_path, boundary, targets)
    duration = lane_report["intro_ticks_native"]
    streams, imported_events = pattern_streams_for_lanes(lanes, duration)
    style_data = replace_intro(bytes(base_entry.style.data), streams, lanes, duration)
    bpm = midi_bpm(midi_path)
    style_data = rename_and_tempo(style_data, name, bpm)
    verify = StyleResource(CompressedResource(6, bytearray(style_data), "OC31", style_data, b""), 0)
    patterns, events = verify.validate_events()
    if not base_entry.companion:
        raise ModelError(f"base {base_entry.style.name} lacks editable type-09 companion")
    lane_report["base_match"] = match
    lane_report["imported_native_events"] = imported_events
    lane_report["active_intro_roles"] = [ROLES[r] for r in sorted(streams)]
    return BuiltStyle(
        name=verify.name, full_title=title, midi_file=midi_path.name,
        style_data=style_data, companion_data=bytes(base_entry.companion.resource.decoded),
        base_name=base_entry.style.name,
        base_source=base_bank.path.name if base_bank.path else "",
        bpm=bpm, meter=tuple(boundary["meter"]),
        intro_bars=lane_report["intro_bars_normalized"], intro_ticks=duration,
        lane_summary=lane_report, patterns=patterns, events=events,
    )


def catalog_payload(template: NativeStyleBank, names: list[str], bank_code: int) -> bytes:
    node = next(child for child in template.children if child.node.ident == 5)
    data = bytearray(node.original[8:])
    if len(data) % 24:
        raise ModelError("bank catalog is not a sequence of 24-byte records")
    for pos in range(0, len(data), 24):
        record = data[pos:pos+24]
        slot = record[20]
        if slot >= len(names):
            continue
        label = ascii_name(names[slot]).encode("latin-1")[:16].ljust(16, b"\x00")
        data[pos:pos+16] = label
        data[pos+19] = bank_code
        data[pos+20] = slot
    return bytes(data)


def outer_node(template_child, decoded: bytes) -> bytes:
    payload = encode_oc(decoded, "OC31")
    return template_child.original[:4] + len(payload).to_bytes(4, "big") + payload


def build_bank(template_path: Path, output_path: Path, bank_code: int, styles: list[BuiltStyle]) -> dict:
    if len(styles) != 32:
        raise ValueError("hardware bank build expects exactly 32 slots")
    template = NativeStyleBank.load(template_path)
    if len(template.entries) != 32:
        raise ModelError("bank template must contain 32 Style resources")
    names = [style.name for style in styles]
    catalog = catalog_payload(template, names, bank_code)
    built: list[bytes] = []
    offsets: list[int] = []
    position = 8
    style_cursor = companion_cursor = 0
    fe_template = None
    for child in template.children:
        ident = child.node.ident
        if ident == 0xFE:
            fe_template = child
            continue
        if ident == 5:
            raw = child.original[:4] + len(catalog).to_bytes(4, "big") + catalog
        elif ident == 6:
            raw = outer_node(child, styles[style_cursor].style_data)
            style_cursor += 1
        elif ident == 9:
            raw = outer_node(child, styles[companion_cursor].companion_data)
            companion_cursor += 1
        else:
            raw = child.original
        if ident in (5, 6, 9):
            offsets.append(position)
        built.append(raw)
        position += len(raw)
    if style_cursor != 32 or companion_cursor != 32:
        raise ModelError("template resource count mismatch")
    if fe_template is not None:
        payload = b"KBEG" + b"".join(offset.to_bytes(4, "big") for offset in offsets) + b"KEND" + len(offsets).to_bytes(4, "big")
        built.append(fe_template.original[:4] + len(payload).to_bytes(4, "big") + payload)
    body = b"".join(built)
    raw = template.logical[:4] + len(body).to_bytes(4, "big") + body
    output_path.parent.mkdir(parents=True, exist_ok=True)
    output_path.write_bytes(raw)

    reopened = NativeStyleBank.load(output_path)
    if len(reopened.entries) != 32:
        raise ModelError("reopen Style count mismatch")
    pattern_count = event_count = 0
    reopened_names = []
    for expected, entry in zip(styles, reopened.entries):
        if entry.style.name != expected.name:
            raise ModelError(f"reopen name mismatch: {entry.style.name!r} != {expected.name!r}")
        patterns, events = entry.style.validate_events()
        pattern_count += patterns
        event_count += events
        reopened_names.append(entry.style.name)
    return {
        "file": output_path.name, "bytes": len(raw), "sha256": hashlib.sha256(raw).hexdigest(),
        "styles": len(reopened.entries), "patterns": pattern_count, "events": event_count,
        "names": reopened_names,
    }


def clone_base(entry, name: str | None = None) -> BuiltStyle:
    if not entry.companion:
        raise ModelError("base filler lacks companion")
    target_name = ascii_name(name or entry.style.name)
    data = rename_and_tempo(bytes(entry.style.data), target_name, style_tempo(entry.style))
    check = StyleResource(CompressedResource(6, bytearray(data), "OC31", data, b""), 0)
    patterns, events = check.validate_events()
    return BuiltStyle(
        name=target_name, full_title=f"Optimized base: {entry.style.name}", midi_file="",
        style_data=data, companion_data=bytes(entry.companion.resource.decoded),
        base_name=entry.style.name, base_source="optimized-base", bpm=style_tempo(entry.style),
        meter=(0, 0), intro_bars=0, intro_ticks=0, lane_summary={}, patterns=patterns,
        events=events, is_base=True,
    )


def main() -> None:
    OUTPUT_DIR.mkdir(parents=True, exist_ok=True)
    boundaries = {item["file"]: item for item in json.loads(BOUNDARIES_PATH.read_text(encoding="utf-8"))}
    midi_paths = sorted(INPUT_DIR.glob("*.mid"), key=lambda p: p.name.lower())
    if len(midi_paths) != 163:
        raise SystemExit(f"expected 163 MIDI files, found {len(midi_paths)}")
    titles = [song_title(path.name) for path in midi_paths]
    names = unique_names(titles)

    user = NativeStyleBank.load(BASE_USER_PATH)
    user02 = NativeStyleBank.load(BASE_USER02_PATH)
    style_profiles = {entry.ordinal: style_drum_profile(entry.style) for entry in user.entries
                      if entry.ordinal not in (6, 7)}

    built_songs: list[BuiltStyle] = []
    failures = []
    for sequence, (path, title, name) in enumerate(zip(midi_paths, titles, names), start=1):
        try:
            boundary = boundaries[path.name]
            base_bank, base_index, match = choose_base(title, path, boundary, user, user02, style_profiles)
            result = build_song(path, title, name, boundary, base_bank, base_index, match)
            built_songs.append(result)
            print(f"[{sequence:03}/163] {name:<16} <- {result.base_name:<20} "
                  f"Intro {result.intro_bars:2} bars, {len(result.lane_summary['lanes'])} lanes")
        except Exception as exc:
            failures.append({"file": path.name, "error": f"{type(exc).__name__}: {exc}"})
            print(f"[{sequence:03}/163] FAIL {path.name}: {exc}")
    if failures:
        (OUTPUT_DIR / "build_failures.json").write_text(json.dumps(failures, indent=2, ensure_ascii=False), encoding="utf-8")
        raise SystemExit(f"song build failed for {len(failures)} MIDI files")

    # Slots 164..192 carry the most-used optimized bases, then remaining USER01
    # bases. This keeps the song banks self-contained while using otherwise free
    # hardware slots in FAVORITE03.
    usage = Counter((item.base_source, item.base_name) for item in built_songs)
    candidates = []
    for bank in (user, user02):
        for entry in bank.entries:
            key = (bank.path.name if bank.path else "", entry.style.name)
            candidates.append((usage.get(key, 0), bank, entry))
    candidates.sort(key=lambda item: (-item[0], 0 if item[1] is user else 1, item[2].ordinal))
    fillers: list[BuiltStyle] = []
    filler_names = set(names)
    for _use, bank, entry in candidates:
        if len(fillers) >= 29:
            break
        base_label = ascii_name("B-" + entry.style.name)
        serial = 2
        unique = base_label
        while unique.lower() in {n.lower() for n in filler_names}:
            suffix = f"~{serial}"; unique = ascii_name(base_label[:16-len(suffix)] + suffix); serial += 1
        filler_names.add(unique)
        fillers.append(clone_base(entry, unique))

    all_slots = built_songs + fillers
    if len(all_slots) != 192:
        raise ModelError(f"expected 192 populated slots, got {len(all_slots)}")
    bank_results = []
    style_dir = OUTPUT_DIR / "VALJA_SONG_STYLES.SET" / "STYLE"
    for bank_index, (filename, code, layout) in enumerate(BANKS):
        template = USER_TEMPLATE if layout == "user" else FAVORITE_TEMPLATE
        slots = all_slots[bank_index*32:(bank_index+1)*32]
        print(f"Building {filename} ...")
        bank_results.append(build_bank(template, style_dir / filename, code, slots))

    # Final manifest maps every hardware slot, including optimized bases.
    manifest_rows = []
    for index, item in enumerate(all_slots):
        bank_name = BANKS[index // 32][0]
        row = {
            "bank": bank_name, "slot": index % 32 + 1, "style_name": item.name,
            "full_title": item.full_title, "midi_file": item.midi_file,
            "base_style": item.base_name, "base_source": item.base_source,
            "bpm": round(item.bpm, 3), "meter": f"{item.meter[0]}/{item.meter[1]}" if item.meter != (0, 0) else "base",
            "intro_bars": item.intro_bars, "intro_ticks_384": item.intro_ticks,
            "patterns": item.patterns, "events": item.events,
            "kind": "optimized-base" if item.is_base else "song-style",
        }
        manifest_rows.append(row)
    with (OUTPUT_DIR / "VALJA_STYLE_MAP.csv").open("w", encoding="utf-8-sig", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=list(manifest_rows[0]))
        writer.writeheader(); writer.writerows(manifest_rows)

    audit = {
        "builder": "VALJA song-specific native Style builder",
        "songs": len(built_songs), "optimized_base_slots": len(fillers),
        "total_slots": len(all_slots), "banks": bank_results,
        "song_audits": [
            {"style_name": item.name, "song": item.full_title, "midi_file": item.midi_file,
             "base_style": item.base_name, "base_source": item.base_source,
             "bpm": round(item.bpm, 3), "meter": item.meter,
             "intro_bars": item.intro_bars, "intro_ticks": item.intro_ticks,
             "patterns": item.patterns, "events": item.events,
             "intro": item.lane_summary}
            for item in built_songs
        ],
    }
    (OUTPUT_DIR / "BUILD_AUDIT.json").write_text(json.dumps(audit, indent=2, ensure_ascii=False), encoding="utf-8")
    summary = {
        "songs": len(built_songs), "base_slots": len(fillers), "banks": len(bank_results),
        "bank_bytes": sum(item["bytes"] for item in bank_results),
        "patterns": sum(item["patterns"] for item in bank_results),
        "events": sum(item["events"] for item in bank_results),
    }
    print("DONE", json.dumps(summary, ensure_ascii=False))


if __name__ == "__main__":
    main()
