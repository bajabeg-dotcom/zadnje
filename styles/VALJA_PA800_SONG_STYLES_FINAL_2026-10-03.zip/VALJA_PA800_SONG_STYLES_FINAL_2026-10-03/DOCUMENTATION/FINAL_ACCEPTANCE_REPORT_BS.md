# VALJA PA800 — završni softverski acceptance audit

**Status: PASS**

- Native bankovi ponovno otvoreni: 7/7
- Popunjeni i parsirani slotovi: 224/224
- Song-specific Styleovi: 163/163
- Patterni parsirani bez greške: 21,868
- Native događaji parsirani bez greške: 2,321,078
- Intro track postavke potvrđene u fixed/no-transpose modu: 1,304
- Očuvani ne-Intro elementi, byte-identični osnovnom Styleu: 1,946
- Očuvane ne-Intro Pattern reference, byte-identične osnovnom Styleu: 17,315
- Catalog zapisi provjereni: 448
- KBEG offseti provjereni: 455

## Potvrđeno

- Svih 163 MIDI uvoda kodirano je u native PPQ 384 Pattern streamove.
- Intro 1 je normalizovan na puni takt; instrumentalni lead završava najkasnije na prvom stvarnom lyric događaju.
- Lead, harmonizovani lead i delay kopije ostaju zajedno na izolovanom Acc5 Intro laneu.
- Variation, Fill, Break i Ending objekti i njihovi Patterni ostali su byte-identični izabranom optimizovanom osnovnom Styleu.
- Svih sedam bankova prošlo je export → reopen → puni event parse.
- Svih 40 optimizovanih osnovnih Styleova prisutno je u slobodnim slotovima FAVORITE03 i dodatnom FAVORITE04 banku.

## Preostala obavezna provjera

Softverski audit ne može zamijeniti fizičko slušanje na Korg Pa800. Prvo učitati SET uz backup korisničkih podataka, zatim probati nekoliko 4/4, 7/8, 9/8 i 6/8 pjesama pri prijelazu Intro 1 → Variation 1.

## SHA-256

- `ada8ff745ee9f27746cc42f2e29ec5fe2d1f51d757832150e04c841e5f37029b  USER01.STY`
- `24db329d1ebfeaced7e60ef8d24226c916faa51cdfb538fec1768a67caf967c8  USER02.STY`
- `255a1c87291acf719cdbc6eb8ba16041abf369aecb11d49274ec3c86120e5ef9  USER03.STY`
- `6753d930166260fa917d9925e1e0eb2cfe4a549e17bc9deb18e17470c592f436  FAVORITE01.STY`
- `b5aaebd6d9e6a6494ba02d754ea900a68de6aa06d5b728e47f9531ff92e747de  FAVORITE02.STY`
- `310ace7609cb2eb7cd2255009f515125c35e6b7f10f788dcd5a2b93af57f1f7d  FAVORITE03.STY`
- `ceb534d2f105199ddbde0aba36cdb2683b004606861e87997486ce2566bc894f  FAVORITE04.STY`
