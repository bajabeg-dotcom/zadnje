VALJA — 163 SONG-SPECIFIC KORG PA800 STYLEA
Datum izrade: 03.10.2026.

VAŽNO
======
Prije učitavanja obavezno sačuvajte backup trenutnog PA800 SET-a.
Ovaj SET popunjava USER01–USER03 i FAVORITE01–FAVORITE04 bankove i može
prepisati postojeće korisničke Styleove u tim bankovima.

ŠTA JE U PAKETU
===============
- 163 zasebna native PA800 song-specific Stylea.
- Svaka pjesma ima originalni instrumentalni uvod u Intro 1.
- Variation, Fill, Break i Ending sekcije potiču iz odabranog optimizovanog
  osnovnog Stylea.
- Intro lead, harmonija lead-a i delay kopije ostaju izolovani na Acc5 traci.
- Intro pratnja je raspoređena na Drum, Bass i Acc1–Acc4.
- Svih 40 optimizovanih osnovnih Styleova također je prisutno u slobodnim
  slotovima FAVORITE03 i u FAVORITE04.

RASPORED PJESAMA
================
USER01.STY      pjesme 1–32
USER02.STY      pjesme 33–64
USER03.STY      pjesme 65–96
FAVORITE01.STY  pjesme 97–128
FAVORITE02.STY  pjesme 129–160
FAVORITE03.STY  pjesme 161–163; slotovi 4–32 sadrže osnovne Styleove
FAVORITE04.STY  dodatni osnovni Styleovi i praktične kopije najčešćih baza

Tačan naziv, bank i slot svake pjesme nalazi se u VALJA_STYLE_MAP.csv.

UČITAVANJE
==========
1. Raspakujte ZIP na računar ili USB medij.
2. Kopirajte folder VALJA_SONG_STYLES.SET na USB.
3. Na Pa800 otvorite MEDIA > Load.
4. Izaberite VALJA_SONG_STYLES.SET i učitajte SET.
5. Sačekajte da se učitavanje potpuno završi prije sviranja.

PREPORUČENA PRVA PROVJERA
=========================
1. USER01 / slot 1  — Ko je pijan... (4/4)
2. USER01 / slot 15 — More i planine (7/8)
3. USER01 / slot 32 — Nek puknu dušmani (9/8)
4. USER02 / slot 24 — Okuj me care (6/8)

Za svaki primjer pokrenite Intro 1 i poslušajte automatski prijelaz na
Variation 1. Zatim provjerite Fill, Break i Ending.

STATUS VALIDACIJE
=================
Softverski acceptance audit: PASS
- 7/7 native bankova ponovo otvoreno
- 224/224 slotova parsirano
- 21.868 Patterna bez parser greške
- 2.321.078 native događaja bez parser greške
- svi ne-Intro elementi i njihove Pattern reference ostali su byte-identični
  izabranom optimizovanom osnovnom Styleu

Fizički Pa800 nije bio dostupan tokom izrade. Konačnu glasnoću, izbor zvukova
i osjećaj prijelaza Intro 1 > Variation 1 treba potvrditi na instrumentu.
Detalji su u FINAL_ACCEPTANCE_REPORT_BS.md i HARDWARE_TEST_CHECKLIST_BS.txt.
